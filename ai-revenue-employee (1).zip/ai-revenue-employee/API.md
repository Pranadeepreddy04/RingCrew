# API

Versioned REST API under `/api/v1`. Interactive docs: `/api/docs`; machine-readable spec: [`docs/openapi.json`](docs/openapi.json) (regenerate with `python -c "import json;from app.main import app;print(json.dumps(app.openapi()))" > ../../docs/openapi.json` from `apps/api`).

## Conventions

- **Auth**: session cookie `are_session` (browser; unsafe methods also need `X-CSRF-Token` = `csrf_token` from `/auth/me`) or `Authorization: Bearer <session token>`.
- **Tenant**: `X-Organization-Id: <uuid>` selects the business (defaults to the user's first). Resources of another tenant return `404`; an organization you are not a member of returns `403`.
- **Errors**: `{"error": {"code": "...", "message": "...", "request_id": "...", "details": ...}}`. Common codes: `validation_error` (422), `unauthorized`/`session_expired` (401), `forbidden`/`csrf_failed` (403), `not_found` (404), `slot_unavailable`/`conflict` (409), `plan_required`/`plan_limit` (402), `rate_limited` (429), `calendar_unavailable` (503).
- **Pagination**: `?page=1&page_size=25` → `{items, total, page, page_size}`.
- **Idempotency**: `Idempotency-Key` header on `POST /appointments`; provider webhooks are de-duplicated by provider event id.
- Every response carries `X-Request-ID` (echoed from the request if supplied) for correlation with logs and AI traces.

## Outgoing webhooks

Events: `lead.created`, `lead.qualified`, `lead.status_changed`, `appointment.created`, `appointment.cancelled`, `appointment.rescheduled`, `conversation.escalated`, `customer.opted_out`.

```
POST <your url>
X-ARE-Event: appointment.created
X-ARE-Signature: t=<unix>,v1=<hex HMAC-SHA256(secret, "<t>." + body)>
Idempotency-Key: <event id>
{"id": "...", "type": "appointment.created", "created_at": "...", "organization_id": "...", "data": {...}}
```

Verify the signature, reject timestamps older than 5 minutes, and de-duplicate by `id`. Non-2xx responses are retried with backoff (30 s → 6 h, 5 attempts).

## Endpoints

### admin

- `GET /api/v1/admin/audit-logs`
- `GET /api/v1/admin/conversations/{conversation_id}/investigate`
- `GET /api/v1/admin/feature-flags`
- `PUT /api/v1/admin/feature-flags`
- `POST /api/v1/admin/impersonate`
- `GET /api/v1/admin/industry-templates`
- `PUT /api/v1/admin/industry-templates/{key}`
- `GET /api/v1/admin/integrations/health`
- `GET /api/v1/admin/jobs`
- `POST /api/v1/admin/jobs/{job_id}/retry`
- `GET /api/v1/admin/metrics`
- `GET /api/v1/admin/organizations`
- `POST /api/v1/admin/organizations/{org_id}/status`
- `GET /api/v1/admin/overview`
- `GET /api/v1/admin/plans`
- `PUT /api/v1/admin/plans/{key}`
- `GET /api/v1/admin/users`
- `POST /api/v1/admin/users/{user_id}/status`

### ai-employees

- `GET /api/v1/agents`
- `POST /api/v1/agents`
- `DELETE /api/v1/agents/{agent_id}`
- `GET /api/v1/agents/{agent_id}`
- `PATCH /api/v1/agents/{agent_id}`
- `POST /api/v1/agents/{agent_id}/activate`
- `GET /api/v1/agents/{agent_id}/activation-checks`
- `GET /api/v1/agents/{agent_id}/pack`
- `PUT /api/v1/agents/{agent_id}/pack`
- `POST /api/v1/agents/{agent_id}/pause`
- `POST /api/v1/agents/{agent_id}/rotate-widget-token`
- `POST /api/v1/agents/{agent_id}/test/conversations`
- `POST /api/v1/agents/{agent_id}/test/conversations/{conversation_id}/messages`

### analytics

- `GET /api/v1/analytics`
- `GET /api/v1/dashboard`
- `GET /api/v1/notifications`
- `POST /api/v1/notifications/read-all`

### appointments

- `GET /api/v1/appointments`
- `POST /api/v1/appointments`
- `GET /api/v1/appointments/availability`
- `GET /api/v1/appointments/{appointment_id}`
- `POST /api/v1/appointments/{appointment_id}/reschedule`
- `POST /api/v1/appointments/{appointment_id}/status`

### auth

- `GET /api/v1/auth/google/callback`
- `GET /api/v1/auth/google/start`
- `GET /api/v1/auth/google/status`
- `POST /api/v1/auth/invitations/accept`
- `GET /api/v1/auth/invitations/{token}`
- `POST /api/v1/auth/login`
- `POST /api/v1/auth/logout`
- `GET /api/v1/auth/me`
- `POST /api/v1/auth/password-reset/confirm`
- `POST /api/v1/auth/password-reset/request`
- `POST /api/v1/auth/password/change`
- `POST /api/v1/auth/resend-verification`
- `POST /api/v1/auth/signup`
- `POST /api/v1/auth/verify-email`

### billing

- `GET /api/v1/billing`
- `POST /api/v1/billing/cancel`
- `POST /api/v1/billing/change-plan`
- `POST /api/v1/billing/checkout`
- `POST /api/v1/billing/portal`
- `POST /api/v1/billing/resume`
- `POST /api/v1/billing/sandbox/simulate`
- `GET /api/v1/plans`

### customers

- `GET /api/v1/customers`
- `POST /api/v1/customers`
- `GET /api/v1/customers/duplicates`
- `DELETE /api/v1/customers/{customer_id}`
- `GET /api/v1/customers/{customer_id}`
- `PATCH /api/v1/customers/{customer_id}`
- `POST /api/v1/customers/{customer_id}/merge`
- `POST /api/v1/customers/{customer_id}/sms-consent`

### inbox

- `GET /api/v1/conversations`
- `GET /api/v1/conversations/files/{file_id}/download`
- `GET /api/v1/conversations/{conversation_id}`
- `POST /api/v1/conversations/{conversation_id}/messages`
- `POST /api/v1/conversations/{conversation_id}/resolve`
- `POST /api/v1/conversations/{conversation_id}/return-to-ai`
- `POST /api/v1/conversations/{conversation_id}/takeover`

### integrations

- `GET /api/v1/integrations`
- `GET /api/v1/integrations/google-calendar/callback`
- `GET /api/v1/integrations/google-calendar/connect`
- `POST /api/v1/integrations/hubspot/connect`
- `POST /api/v1/integrations/phone-numbers`
- `DELETE /api/v1/integrations/phone-numbers/{number_id}`
- `PATCH /api/v1/integrations/phone-numbers/{number_id}`
- `POST /api/v1/integrations/sandbox-calendar/connect`
- `GET /api/v1/integrations/webhooks`
- `POST /api/v1/integrations/webhooks`
- `DELETE /api/v1/integrations/webhooks/{endpoint_id}`
- `POST /api/v1/integrations/webhooks/{endpoint_id}/test`
- `DELETE /api/v1/integrations/{integration_id}`
- `POST /api/v1/integrations/{integration_id}/test`

### knowledge

- `POST /api/v1/knowledge/documents`
- `POST /api/v1/knowledge/faqs`
- `GET /api/v1/knowledge/faqs/{source_id}`
- `PUT /api/v1/knowledge/faqs/{source_id}`
- `GET /api/v1/knowledge/search`
- `GET /api/v1/knowledge/sources`
- `POST /api/v1/knowledge/sources`
- `DELETE /api/v1/knowledge/sources/{source_id}`
- `GET /api/v1/knowledge/sources/{source_id}`
- `PATCH /api/v1/knowledge/sources/{source_id}`

### leads

- `GET /api/v1/leads`
- `POST /api/v1/leads`
- `GET /api/v1/leads/board`
- `DELETE /api/v1/leads/{lead_id}`
- `GET /api/v1/leads/{lead_id}`
- `PATCH /api/v1/leads/{lead_id}`
- `GET /api/v1/tasks`
- `PATCH /api/v1/tasks/{task_id}`

### organizations

- `GET /api/v1/industries`
- `GET /api/v1/industries/{key}`
- `POST /api/v1/organizations`
- `DELETE /api/v1/organizations/current`
- `GET /api/v1/organizations/current`
- `PATCH /api/v1/organizations/current`
- `GET /api/v1/organizations/current/export`
- `POST /api/v1/organizations/current/import-website`
- `POST /api/v1/organizations/current/onboarding`
- `PUT /api/v1/organizations/current/profile`
- `POST /api/v1/services`
- `DELETE /api/v1/services/{service_id}`
- `PUT /api/v1/services/{service_id}`
- `GET /api/v1/team`
- `POST /api/v1/team/invitations`
- `DELETE /api/v1/team/invitations/{invitation_id}`
- `DELETE /api/v1/team/members/{membership_id}`
- `PATCH /api/v1/team/members/{membership_id}`
- `GET /api/v1/timezones`

### public

- `GET /api/v1/public/conversations/{conversation_id}/messages`
- `POST /api/v1/public/conversations/{conversation_id}/messages`
- `GET /api/v1/public/conversations/{conversation_id}/upload-token`
- `POST /api/v1/public/demo`
- `POST /api/v1/public/uploads`
- `GET /api/v1/public/widget/{token}/config`
- `POST /api/v1/public/widget/{token}/conversations`

### workflows

- `GET /api/v1/workflows`
- `POST /api/v1/workflows`
- `POST /api/v1/workflows/runs/{run_id}/stop`
- `DELETE /api/v1/workflows/{workflow_id}`
- `PUT /api/v1/workflows/{workflow_id}`
- `GET /api/v1/workflows/{workflow_id}/runs`

Provider webhooks (not in the public schema): `POST /api/v1/webhooks/sms/incoming`, `/sms/status`, `/voice/incoming`, `/voice/language`, `/voice/gather`, `/voice/keepalive`, `/voice/status` (Twilio-signed), `POST /api/v1/webhooks/stripe` (Stripe-signed). Widget script: `GET /widget.js`. Health: `/healthz`, `/readyz`, `/metrics`.

## Languages (v1.1)

- AI employees: `languages` (ordered list, first = default; any of `en es zh tl vi ar fr`) and `greetings` (`{"es": "…"}`) on `POST/PATCH /api/v1/agents`.
- Conversations: `language` on every conversation. Start in a language with `POST /api/v1/public/widget/{token}/conversations` `{"language": "es"}` or `POST /api/v1/agents/{id}/test/conversations` `{"language": "es"}`; otherwise it is detected from the customer's messages. Visitor message responses include `language`.
- Widget config: `languages` (`code`, `name`, `native`, `bcp47`, `rtl`), `default_language`, `voice_input` (`asr`: `vibevoice` | `browser`, `vibevoice_languages`).

## Realtime voice (WebSocket, not in the OpenAPI schema)

`WS /api/v1/public/conversations/{id}/voice` — browser voice for a widget conversation.
1. Client sends `{"type":"start","visitor_token":"…","sample_rate":16000,"format":"s16"|"f32","language":"es"}`.
2. Server answers `{"type":"ready","language","asr":"vibevoice"}` or `{"type":"unavailable","reason"}` (no streaming ASR, or language not routed to it — use the browser's recognizer and the normal message endpoint).
3. Client streams binary mono little-endian PCM; `{"type":"stop"}` ends an utterance early (push-to-talk).
4. Server sends `speech_start`, `partial {text}`, `final {text}`, then `reply {messages, language, handoff, customer_message_id}`.

`WS /api/v1/voice/stream` — Twilio Media Streams endpoint opened by `<Start><Stream>`; requires the signed `token` custom parameter. Not for direct use.
