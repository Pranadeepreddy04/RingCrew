# Architecture

## Overview

```mermaid
flowchart LR
  subgraph Channels
    W[Website widget] --> PUB[/public API/]
    SMS[Twilio SMS] --> WH[/signed webhooks/]
    V[Twilio Voice] --> WH
  end
  Browser[Owner & staff browser] --> WEB[Next.js web app] -->|/api proxy, same-origin cookies| API[FastAPI API]
  PUB --> API
  WH --> API
  API --> ORCH[AI Orchestrator]
  ORCH --> POL[Policy layer: injection / human / complaint / emergency]
  ORCH --> NLU[Deterministic NLU + optional LLM extraction]
  ORCH --> KB[(Knowledge: Postgres FTS)]
  ORCH --> TOOLS[Typed, permission-checked tools]
  TOOLS --> CRM[(Customers / leads / tasks)]
  TOOLS --> SCHED[Scheduling: exclusion constraint + idempotency]
  SCHED --> CAL[Calendar adapter: Google / sandbox]
  API --> DB[(PostgreSQL)]
  WORKER[Worker: job queue + follow-ups + maintenance] --> DB
  WORKER --> SMSOUT[SMS provider] & HOOKS[Outgoing webhooks] & MAIL[Email] & CRMX[HubSpot]
  API --> BILL[Billing: Stripe / sandbox]
```

- **apps/api** — FastAPI (Python 3.11), SQLAlchemy 2, Alembic, Pydantic v2. One process type serves HTTP; `python -m app.worker` runs background work.
- **apps/web** — Next.js 16 (App Router, React 19, TypeScript strict, Tailwind v4). All API calls go to `/api/*` on the web origin, which rewrites to the API, so session cookies are first-party and no secrets reach the browser.
- **PostgreSQL** is the system of record *and* the job queue (`SELECT … FOR UPDATE SKIP LOCKED`), so there is no second store to lose work in. Redis is optional (shared rate-limit counters across instances).

## Multi-tenancy (spec §4, §83)

Every tenant-owned table has `organization_id` (FK, indexed, `ON DELETE CASCADE`). Tenant scope is resolved **only** on the server:

1. `get_auth` validates the session (cookie + CSRF header, or Bearer token).
2. `get_org_ctx` loads the membership for `X-Organization-Id` — a header naming an organization the user doesn't belong to returns **403**.
3. Every query includes `organization_id == ctx.org_id`; lookups by id that belong to another tenant return **404**.
4. AI tools never accept an organization id — the tool context carries it.

Public endpoints use scoped capabilities instead of sessions: a widget token identifies one AI employee; a signed visitor token grants access to exactly one conversation; signed, expiring upload tokens grant one conversation's uploads.

`tests/test_tenant_isolation.py` exercises every resource type with another tenant's ids (release-blocking).

## Conversation engine (spec §14, §42–44, §72–73)

`app/ai/orchestrator.py` handles every inbound message on every channel:

1. **Handoff check** — if a human owns the conversation the AI stays silent (it still records contact details the customer types).
2. **Entitlement & usage limits** — no active subscription / paused agent / limit reached ⇒ polite message + task for the team.
3. **Policy layer** (deterministic, runs first): prompt-injection patterns → refusal; emergency keywords → safety line + business emergency instructions + escalation (voice transfers to the escalation phone); "talk to a person" → handoff; complaint/refund → handoff.
4. **Understanding** — deterministic extraction (phone, email, ZIP incl. spoken digits, names, enum/boolean fields from the Industry Pack keywords). When an LLM is configured, a structured tool call extracts intent/fields; every value is validated against the pack's field definitions before use; malformed output is repaired once, then discarded.
5. **Questions** — business facts (hours, service area, address, services) come from the profile; everything else from approved knowledge via Postgres full-text search with a coverage threshold. Pricing questions require knowledge that actually contains pricing. LLM answers are grounded: any money amount, percentage or phone number not present verbatim in the retrieved knowledge rejects the answer. No knowledge ⇒ *"I don't have that information available. I can have someone from the team help you."* + a task.
6. **Booking flow** — asks the pack's required fields in order, validates service area, creates customer + lead (idempotent per conversation), offers **real** open slots honoring the customer's day/time preference, books the chosen slot, and confirms **only after** the booking transaction succeeds. Reschedule/cancel supported.

All actions go through `app/ai/tools.py`: a registry of typed tools with Pydantic input schemas, per-agent capability checks, and extra validation for high-impact tools (the AI can only book a slot that the backend offered in this conversation). Every call is logged as a `tool` message (visible in the inbox) and failures emit analytics events. In the owner **test environment** and the public **demo**, side-effecting tools run as validated dry runs.

Prompts are versioned (`app/ai/prompts.py`, `PROMPT_VERSION`) and layered: safety policy → business config → industry pack → role → conversation state → retrieved knowledge (wrapped in delimited data tags).

## Industry Pack engine (spec §15)

Packs are JSON in `packages/industry-config/packs`, synced to `industry_templates` (admin-editable, versioned), and can be overridden per AI employee (enable/require/reword questions). Packs `extend` a base (home services) and add fields, keywords, escalation terms, safety rules and evaluation cases. The engine never branches on an industry name. Regulated packs (dental, healthcare, legal, financial) exist as **disabled** and cannot be activated through the admin API.

## Scheduling (spec §30, §89–90)

- Slots = business hours (org timezone, DST-safe via `zoneinfo`) − lead time − horizon − active appointments − external busy time.
- Postgres `EXCLUDE USING gist (organization_id =, resource =, tstzrange(start,end) &&) WHERE status in (scheduled, confirmed)` makes double-booking impossible, even under concurrency (tested with 6 threads racing for one slot).
- Capacity > 1 is modelled as crews (`booking_capacity` setting).
- Availability is re-checked inside the booking transaction; external calendar event creation happens inside a savepoint that is rolled back if the calendar fails.
- Idempotency keys (`conv:<id>:<start>` for AI, `Idempotency-Key` header for staff).

## Background work

`jobs` table (queued → running → done/failed, exponential backoff, stuck-job recovery) handles: outgoing webhook delivery (HMAC-signed), notification emails, AI replies to inbound SMS, CRM sync, tenant purge. `workflow_runs` drive follow-ups/reminders with quiet hours, max attempts, bounded provider retries and stop conditions (booked, replied, opted out, closed, human takeover, cancelled).

## Provider abstractions (spec §36, §41, §91)

| Concern | Interface | Real adapter | Sandbox adapter |
|---|---|---|---|
| LLM | `LLMProvider` (`generate`, `tool_call`, `embed`) + `LLMGateway` (timeout, retry, validation, fallback, tracing, cost) | Anthropic Messages API | deterministic, offline |
| SMS | `SmsProvider` | Twilio REST + signature validation | records to outbox |
| Voice | `VoiceProvider` (TwiML `Gather`/`Dial`/`Hangup`, provisioning) | Twilio | same TwiML, simulated numbers |
| Calendar | `ExternalCalendar` (busy, create, update, delete, health) | Google Calendar (OAuth, refresh tokens) | in-memory busy blocks, outage switch |
| CRM | `CRMAdapter` | HubSpot private app | — |
| Billing | `BillingProvider` | Stripe (Checkout, Portal, subscription updates, signed webhooks) | immediate state transitions, sandbox invoices |
| Email | `EmailProvider` | SMTP | stored in `outbound_emails` |
| Storage | `Storage` | S3-compatible (boto3) | local disk |

Production config validation refuses to start with any sandbox provider unless `ALLOW_SANDBOX_PROVIDERS_IN_PRODUCTION=true`.

## Data model (ERD)

```mermaid
erDiagram
  organizations ||--o{ organization_users : has
  users ||--o{ organization_users : member
  users ||--o{ sessions : has
  organizations ||--|| business_profiles : has
  organizations ||--o{ services : offers
  organizations ||--o{ ai_agents : employs
  organizations ||--o{ phone_numbers : owns
  ai_agents ||--o{ phone_numbers : answers
  organizations ||--o{ customers : has
  customers ||--o{ customer_consents : records
  customers ||--o{ leads : has
  customers ||--o{ conversations : has
  ai_agents ||--o{ conversations : handles
  conversations ||--o{ messages : contains
  conversations ||--o| calls : "voice"
  conversations ||--o{ files : receives
  leads ||--o{ appointments : results_in
  customers ||--o{ appointments : books
  organizations ||--o{ tasks : has
  organizations ||--o{ knowledge_sources : has
  knowledge_sources ||--o{ knowledge_chunks : chunked_into
  organizations ||--o{ workflows : defines
  workflows ||--o{ workflow_runs : runs
  organizations ||--o{ integrations : connects
  organizations ||--o{ webhook_endpoints : has
  webhook_endpoints ||--o{ webhook_events : delivers
  organizations ||--|| subscriptions : has
  plans ||--o{ subscriptions : priced_by
  organizations ||--o{ invoices : billed
  organizations ||--o{ events : analytics
  organizations ||--o{ usage_records : metered
  organizations ||--o{ ai_traces : traced
  organizations ||--o{ audit_logs : audited
  industry_templates ||..o{ ai_agents : configures
```

Other tables: `email_tokens`, `invitations`, `jobs`, `inbound_webhook_events` (replay/duplicate protection), `feature_flags`, `notifications`, `outbound_emails`. All ids are UUIDs; timestamps use `clock_timestamp()` so rows written in one transaction keep their real order.

## Key decisions

- **Deterministic core, LLM-assisted.** The conversation state machine, confirmations and all actions are deterministic; the LLM improves understanding and phrasing of knowledge answers. This makes behaviour testable, bounded and honest, and means the product works (in a more literal way) without an LLM key.
- **Postgres full-text retrieval** instead of vector search for the MVP: no extra infrastructure or provider, deterministic, tenant-filtered at the SQL layer. The `embedding` column and `LLMProvider.embed` allow adding pgvector later.
- **Postgres as the queue.** Simpler operations and transactional enqueueing; adequate for MVP volume.
- **Follow-ups use approved templates only** — the AI never free-writes outbound messages, so there are no AI messaging loops.

## Languages and voice (v1.1)

- `app/ai/i18n.py` — language registry (7 languages: names, BCP-47, Twilio ASR codes, `<Say>` voices), detection, the reply catalog, multilingual keyword tables and date/slot formatting. The orchestrator picks the language each turn (`choose_language`: sticky, switches only on confident detection among the agent's enabled languages), renders every reply through the catalog, and runs the policy layer on the original text plus the English translation (LLM mode).
- `app/providers/asr.py` — `VibeVoiceASR` (websocket client for VibeVoice-ASR-Streaming: `/config`, `/ws/asr`, float32 PCM, cumulative text, `end`→`done`), `SandboxASR`; `get_asr_provider()` by `VOICE_ASR_PROVIDER`.
- `app/voice/engine.py` — μ-law decode, resampling, energy VAD `Endpointer` (pre-roll, silence end, max length), `StreamingRecognizer` (one ASR session per utterance, partial/final callbacks).
- `app/routers/voice_sms.py` — language menu, greeting, `run_voice_turn()` shared by `<Gather>` and streaming modes, keepalive.
- `app/routers/voice_stream.py` — Twilio Media Streams socket (signed token → recognizer → AI turn in a worker thread → `update_call` TwiML; barge-in; fallback) and the browser voice socket.

```
Twilio call ─► /webhooks/voice/incoming ─► language menu ─► /voice/language ─► TwiML <Start><Stream> + <Say>
                                                                  │
         media frames (μ-law 8 kHz) ─► WS /voice/stream ─► VAD ─► VibeVoice (24 kHz float32) ─► text
                                                                  └► orchestrator ─► update_call(<Say lang voice> + <Pause>)
```
