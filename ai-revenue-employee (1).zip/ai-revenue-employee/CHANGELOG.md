# Changelog

## 1.1.0-rc1 — 2026-10-02

### Added
- **Multilingual AI employee**: English, Spanish, Chinese (Mandarin), Tagalog, Vietnamese, Arabic, French. Per-agent `languages` + per-language `greetings`; language detection (script + vocabulary, sticky, names/numbers never switch language); full reply catalog per language; multilingual extraction (enums, yes/no, names incl. Unicode, spoken digits, dates, ordinals); policy layer (emergency/gas checked in every language, human request, complaint) in every language; localized dates/hours/slots; LLM translation for understanding and answers in the customer's language when an LLM is configured. Migration 0003.
- **Voice in 7 languages**: phone language menu (press 1, 2, …) with each option spoken in its own language, per-language Twilio `<Gather>` recognition and native `<Say>` voices.
- **VibeVoice-ASR-Streaming integration**: streaming client for Microsoft's model server (`app/providers/asr.py`), μ-law decoding, resampling, energy VAD endpointing (`app/voice/engine.py`), Twilio Media Streams socket with signed tokens, replies via live call update, barge-in, automatic fallback to Twilio recognition, keepalive silence handling; browser voice socket for the widget. `calls.language` / `calls.asr_provider` (migration 0004). GPU server Dockerfile in `infrastructure/vibevoice/`.
- **Web**: languages & greetings editor, test console language picker + microphone, demo page language picker + microphone + multilingual suggestions, inbox language badges, right-to-left rendering; widget language menu, microphone and spoken replies.
- **Postman collection** generated from OpenAPI (`scripts/make_postman.py`) with runnable multilingual and owner quick starts.
- **Deploy configs**: `netlify.toml` (web), `render.yaml` (API + worker + Postgres); Postgres URL normalization; `PORT` support in the API image.
- Tests: +51 backend tests (multilingual conversations in all 7 languages, voice menu, VibeVoice protocol client against a protocol-faithful simulator, phone media stream booking, barge-in, fallback, browser voice socket auth); browser E2E `e2e/multilingual.mjs` (fake microphone → streamed voice turn).

### Fixed
- Requests phrased as questions ("Can someone inspect it?") with no matching FAQ no longer answer "I don't have that information" before starting the booking.
- `Permissions-Policy` now allows the microphone for the app's own origin (voice chat).

## 1.0.0-rc1 — 2026-09-29

### Added
- Multi-tenant FastAPI backend: 40 tables, Alembic migrations (0001 schema incl. double-booking exclusion constraint; 0002 ordered timestamps).
- Authentication (email/password, verification, reset, invitations, Google sign-in), CSRF-protected cookie sessions, RBAC.
- AI orchestrator with policy layer, deterministic NLU + validated LLM extraction, grounded knowledge answers, typed permission-checked tools, dry-run test environment, versioned prompts, AI traces and cost tracking.
- Industry Pack engine with roofing, HVAC, plumbing, remodeling (active), six beta home-service packs and four locked regulated packs.
- Knowledge base (FAQs, text, PDF/DOCX/TXT upload, SSRF-safe website import) with tenant-scoped full-text retrieval.
- Website chat widget (`/widget.js`), SMS and voice webhook flows (Twilio + sandbox), STOP/START/HELP, consent records.
- Scheduling with timezone-aware availability, idempotent booking, reschedule/cancel, Google Calendar adapter.
- Lead CRM (board/table/detail), customers (timeline, merge, consent, deletion), tasks, human handoff and takeover inbox.
- Follow-up/reminder workflows with quiet hours, stop conditions and consent enforcement.
- Dashboard, analytics, notifications (in-app + email).
- Subscription billing (Stripe + sandbox), plans configurable by admins, usage limits.
- Platform admin (businesses, users, impersonation, plans, templates, flags, jobs, integrations, audit log, conversation investigation).
- Outgoing signed webhooks, HubSpot sync, durable Postgres job queue and worker.
- Next.js web app: marketing site, industry pages, pricing, live demo, 9-step onboarding, business app, admin.
- Tests: 82 backend tests + headless-browser acceptance; CI workflow; Dockerfiles and compose; docs.

### Security
- Upgraded cryptography → 50.0.1, pypdf → 6.19.0, pydantic-settings → 2.15.0, python-multipart → 0.0.32 (pip-audit clean).
