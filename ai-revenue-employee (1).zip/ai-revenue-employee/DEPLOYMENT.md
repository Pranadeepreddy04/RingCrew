# Deployment

## Topology

```
Internet ──HTTPS──> load balancer / reverse proxy
                       ├── web  (Next.js standalone, :3000)  — serves UI and proxies /api/* and /widget.js to the API
                       └── (optional) /api/* straight to api (:8000)
api (N replicas, stateless)   worker (1+ replicas)   PostgreSQL 16 (managed, PITR)   Redis (optional)   S3 bucket
```

`PUBLIC_API_URL` = the public HTTPS origin that serves `/api` (usually the same as `PUBLIC_WEB_URL`). Twilio/Stripe/Google call back to it.

## Netlify (web) + Render (API, worker, Postgres)

Netlify hosts static/serverless sites and cannot run the Python API, the job worker or PostgreSQL, so the stack is split:

1. **Render** → New → Blueprint → this repository (`render.yaml`). Fill `ENCRYPTION_KEY` (`python -m app.cli gen-key`),
   `PUBLIC_API_URL` (the API's Render URL), `PUBLIC_WEB_URL` and `CORS_ORIGINS` (your Netlify URL). `APP_ENV=staging` keeps
   sandbox providers allowed until you add real credentials. Migrations + bootstrap run as the pre-deploy step.
2. **Netlify** → Add new site → Import from Git → this repository (`netlify.toml`, base `apps/web`). Set `API_URL` to the
   Render API URL **before the first build** (the `/api/*` proxy is compiled in) and `NEXT_PUBLIC_VOICE_WS_URL` to
   `wss://<render api host>` (Netlify does not proxy WebSockets, so voice connects to the API directly).
3. Embed the widget from the API host (`<script src="https://<render api>/widget.js" data-token="…">`) or via the Netlify
   site (`/widget.js` is proxied).
4. Optional: VibeVoice GPU server (`infrastructure/vibevoice/`), then `VOICE_ASR_PROVIDER=vibevoice`, `VIBEVOICE_ASR_URL`.

## Environments

| `APP_ENV` | Purpose | Enforced |
|---|---|---|
| development | local | sandbox providers allowed, dev-only helpers (sandbox calendar, billing simulator, invite links in responses) |
| test | automated tests | as development |
| staging | pre-production | strong `SECRET_KEY`, `ENCRYPTION_KEY`, `COOKIE_SECURE=true`, credentials for any real provider selected |
| production | live | all of staging + **no sandbox providers** unless `ALLOW_SANDBOX_PROVIDERS_IN_PRODUCTION=true` |

## Release procedure

1. CI green (lint, types, tests, audits, secret scan, image builds, browser E2E).
2. Build images:
   ```bash
   docker build -f apps/api/Dockerfile -t REGISTRY/are-api:$VERSION .
   docker build -f apps/web/Dockerfile --build-arg API_URL=http://api:8000 -t REGISTRY/are-web:$VERSION .
   ```
   `API_URL` is baked into the web image's rewrites at build time and must also be set at runtime.
3. **Back up** the database (or confirm a fresh PITR restore point).
4. Run migrations as a one-off release job **before** rolling the API:
   ```bash
   docker run --env-file prod.env REGISTRY/are-api:$VERSION sh -c "python -m app.cli check-config && alembic upgrade head && python -m app.cli bootstrap"
   ```
5. Roll out `api`, then `worker`, then `web`. Health: `GET /healthz` (process), `GET /readyz` (database). Metrics: `GET /metrics` (restrict to your network).
6. Smoke test (see FINAL_RELEASE_REPORT.md → Verification). Create the first platform admin with `python -m app.cli create-superadmin`.
7. Configure provider callbacks (SETUP.md → Turning on real providers). Set Stripe price ids in **Admin → Plans**.

Staging: identical procedure with `APP_ENV=staging`, Stripe test-mode keys, a Twilio test number, and a separate database.

## Scaling notes

- API is stateless; scale horizontally. Set `REDIS_URL` so rate limits are shared.
- Worker uses `SKIP LOCKED`; multiple workers are safe.
- Inbound SMS replies are processed by the worker, so Twilio webhooks return immediately. Voice turns are synchronous (Twilio needs the TwiML response); keep `LLM_TIMEOUT_SECONDS` below ~8 s for voice-heavy tenants.

## Backups and disaster recovery (spec §99)

What the application provides:
- All state is in PostgreSQL (+ uploaded files in object storage). Workers and API hold no state.
- Migrations are forward-only in normal operation; every migration has a `downgrade()` for emergency rollback (tested: `alembic downgrade base && alembic upgrade head` on an empty database).
- Tenant export (JSON) and tenant purge are built in.

What you must configure (not provided by this repository):
- **Database**: managed PostgreSQL with automated daily snapshots + point-in-time recovery (e.g. 7–35 days). Test a restore quarterly into staging.
- **Object storage**: bucket versioning + lifecycle rules; block public access; SSE.
- **Secrets**: store in a secret manager.

Recovery procedure:
1. Restore the database to the target point in time into a new instance.
2. Point `DATABASE_URL` at it; run `alembic current` to confirm the schema revision matches the deployed image (roll images back if not).
3. Start API and worker; check `/readyz`, admin → Jobs (requeue failed jobs if needed), admin → Integrations health.
4. Messages or bookings made at providers after the restore point (Twilio, Stripe, Google) are not in the database; Stripe/Twilio webhooks are replay-safe, so replaying events from their dashboards reconciles state.

Recovery-time/recovery-point objectives depend entirely on your hosting choices; none are guaranteed by this code.

## Secret rotation

| Secret | How to rotate |
|---|---|
| `SECRET_KEY` | Change and restart. All sessions, visitor tokens, upload/download links and sandbox webhook signatures become invalid (users sign in again; open widget chats restart). |
| `ENCRYPTION_KEY` | Integration credentials and webhook secrets are encrypted with it. Rotating requires re-encryption: decrypt with old key, encrypt with new (MultiFernet). **Not automated yet** — until then, rotate by reconnecting integrations and recreating webhook endpoints after changing the key. |
| Twilio / Stripe / Anthropic / SMTP / Google | Replace the environment variable and restart API + worker. Stripe: add the new webhook secret, deploy, then remove the old endpoint. |
| Per-business HubSpot token, Google Calendar | Business owner reconnects in **Connections**. |
| Webhook endpoint secret | Remove and re-add the endpoint (new secret shown once). |
| Widget token | **AI employees → Website chat → Replace code** (old snippet stops working). |
