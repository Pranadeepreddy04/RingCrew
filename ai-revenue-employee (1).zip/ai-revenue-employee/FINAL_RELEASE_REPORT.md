# FINAL RELEASE REPORT — AI Revenue Employee v1.1.0-rc1

Date: 2026-10-02 (v1.1 adds 7 languages and VibeVoice streaming voice; v1.0 content below still applies). This report follows spec §100. **The application is not labeled "100% complete"**: the core product is implemented and verified, but several channels need your production credentials before they can be verified against real providers, and some spec items are explicitly not implemented (listed below).

---

## Working (implemented and verified by automated tests in this environment)

- **Primary workflow (§94, §77)** — signup → onboarding (9 steps) → Roofing pack → business profile, services, hours, service area → knowledge (FAQs, text, documents, website import) → AI employee → dry-run test environment → explicit activation → website chat widget → knowledge answer → qualification → customer + qualified lead → real availability → booking → confirmation only after persistence → dashboard, inbox, leads, appointments, analytics. Verified by the API acceptance test **and** a headless-Chromium run through the real UI.
- **Multi-tenancy & RBAC (§4, §5, §83)** — isolation of every resource type, header spoofing and token scoping tests pass.
- **Authentication (§6, §84)** — signup, email verification, login, sessions, CSRF, logout, password reset/change, expiry, disabled accounts, invitations.
- **AI orchestration & safety (§13–14, §42–44, §85–88)** — policy layer, validated tools, grounded answers, prompt-injection defense, confirmation rule, degraded operation during LLM outages, tenant-gated fallback, traces for every AI call.
- **Industry Pack engine (§15–20)** — roofing, HVAC, plumbing, remodeling active with evaluation suites; per-agent overrides; regulated packs locked.
- **Scheduling (§30, §89–90)** — timezone-correct availability, DB-level double-booking prevention (concurrency-tested), idempotency, reschedule/cancel, multi-crew capacity, external-calendar busy time with outage handling.
- **Lead CRM & customers (§28–29)** — pipeline (board with drag-and-drop + table + detail), custom stages, assignment, estimated vs actual revenue, duplicate detection & merge, consent records, activity timeline.
- **Human handoff & inbox (§32, §34)** — triggers (request, complaint, emergency, repeated failure, booking failure, offline/limits), tasks with summaries, takeover silences AI, staff replies (web/SMS), return to AI.
- **Follow-up engine (§31)** — triggers, delays, templates, quiet hours, max attempts, stop conditions, consent checks, reminders, review-request workflows via `appointment.completed`.
- **Dashboard & analytics (§33, §35, §57, §71)** — today's metrics, agent status, pipeline, upcoming appointments, tasks, daily charts, funnel, source/channel/hand-off breakdowns, response time, after-hours calls, usage & cost; estimated value always separate from confirmed revenue.
- **SMS flow (§11, §96) and voice flow (§10, §95)** — verified end-to-end through the same signed-webhook code paths Twilio uses, using sandbox providers (see "Mocked").
- **Billing logic (§47, §97)** — trials, plans (admin-configurable prices), entitlements enforced on the backend, upgrades/downgrade guard, cancellation, renewal, failed payment grace, recovery, usage limits; Stripe webhook verification and state machine contract-tested.
- **Outgoing webhooks (§38)** — HMAC-signed, retried, logged; verified against a real local HTTP server.
- **Admin panel (§49)** — overview, businesses (suspend/reactivate), users (disable, audited impersonation), plans, industry templates, feature flags, failed jobs retry, integration health, audit log, conversation investigation.
- **Privacy (§46)** — tenant export, customer deletion (redaction), business deletion with delayed purge, consent records, recording off by default.
- **Files (§51)** — signed uploads from the widget, type/size/magic-byte validation, private signed downloads.
- **Personalized demo (§48)** — sandboxed demo org from a website + industry; no production actions.
- **Operations (§52, §65, §82, §93, §98)** — migrations from empty DB (+ downgrade round-trip), environment validation, structured JSON logs, request ids, Prometheus-style `/metrics`, `/healthz`, `/readyz`, durable job queue with retries and stuck-job recovery.

- **Multilingual AI employee (v1.1)** — English, Spanish, Chinese, Tagalog, Vietnamese, Arabic, French across website chat, SMS and voice: detection, per-agent languages and greetings, localized replies/dates/slots, multilingual extraction and safety policy. Verified by 31 API tests (a full booking in each language) and a headless-browser run (demo page in Spanish incl. booking; widget in Chinese, Arabic RTL, Vietnamese, Tagalog, French with localized greetings).
- **Voice agent (v1.1)** — phone language menu, per-language recognition and voices (Twilio); **VibeVoice-ASR-Streaming** path: Twilio Media Streams → μ-law decode → resample → VAD → per-utterance ASR session → AI turn → live call update, barge-in, fallback to Twilio recognition, browser voice socket. Verified by 20 tests against a protocol-faithful VibeVoice simulator, and in Chromium with a fake microphone (streamed audio → partial transcripts → Spanish reply, two consecutive turns).
- **Postman collection** — generated from OpenAPI; the two quick-start folders ran with Newman against the full local stack: 30 requests, 36 assertions, 0 failures.

## Requires credentials (implemented; real-provider behaviour not verified here)

| Integration | What you need | Code |
|---|---|---|
| Anthropic LLM | `ANTHROPIC_API_KEY` | `app/ai/llm.py` (contract-tested with mocked HTTP) |
| Twilio SMS + Voice | Account SID, auth token, a number, A2P 10DLC registration | `app/providers/messaging.py`, `app/routers/voice_sms.py` |
| Google Calendar | OAuth client id/secret | `app/providers/calendar.py` |
| Google sign-in | OAuth client id/secret | `app/routers/auth.py` |
| Stripe | secret key, webhook secret, a Price per plan | `app/services/billing.py`, `app/routers/billing.py` |
| SMTP email | SMTP host/user/password, sending domain DNS | `app/providers/email.py` |
| HubSpot | per-business private-app token | `app/providers/crm.py` |
| S3 storage | bucket + credentials, `pip install boto3` | `app/services/files.py` |
| VibeVoice-ASR-Streaming | an NVIDIA GPU host running `infrastructure/vibevoice` (model `microsoft/VibeVoice-ASR-Streaming-7B`) | `app/providers/asr.py`, `app/routers/voice_stream.py` |
| Netlify + Render hosting | your accounts (configs: `netlify.toml`, `render.yaml`) | DEPLOYMENT.md |

## Mocked (development providers — active by default, rejected in production)

- `PRIMARY_LLM_PROVIDER=sandbox` — deterministic understanding and extractive answers; no LLM calls. The product works end to end in this mode but understands only the phrasings the Industry Packs cover.
- `SMS_PROVIDER` / `VOICE_PROVIDER=sandbox` — messages stored with status `sandbox_not_delivered`; simulated numbers; the AI never claims a text was sent in this mode.
- `BILLING_PROVIDER=sandbox` — plan changes apply without charging; sandbox invoices.
- `EMAIL_PROVIDER=sandbox` — emails recorded in `outbound_emails`, not sent (dev invite links are returned in API responses only in development/test).
- Sandbox calendar integration (development only).

## Not implemented

- **Industries beyond the MVP (§61–62):** auto repair, restaurants/reservations, real estate, property management, salons, spas, fitness, pet services, events, professional services, and home-service packs for flooring, fencing, pool, appliance repair, handyman, windows/gutters, tree services. Electrical, landscaping, pest control, cleaning, garage doors and painting exist as **beta** packs built on the generic home-services template (no trade-specific questions or eval suites yet). Industry landing pages for planned industries say "planned".
- **Email as a conversation channel** (§9 optional/future).
- **Outbound AI calls** (`makeCall`), `sendDTMF`, call-recording retrieval/storage/playback (recording can be enabled via TwiML, but recordings are not fetched or shown).
- **Server-side neural TTS**: phone replies use Twilio `<Say>` voices; browser replies use the browser's speech synthesis.
- **Microsoft 365 calendar** and **Salesforce** adapters (interfaces ready; shown as "not available").
- **MFA** (schema hook only).
- **Malware scanning** (integration point only).
- **Usage-based overage invoicing** (usage is metered and limits enforced; Stripe metered billing not wired).
- **Vector embeddings / pgvector** (retrieval uses Postgres full-text search).
- **Push notifications / SMS alerts to owners** (in-app + email only); PWA is manifest-only.
- **Sentry/error-tracking SDK** (config key exists; logs + `/metrics` are the alert integration points).
- **Automated `ENCRYPTION_KEY` rotation**; retention period UI (the worker honours `settings.retention.message_days`, settable via the database only).
- **Languages beyond the seven** (e.g. Korean, Russian, Haitian Creole, Portuguese).
- **Final legal copy** for privacy policy and terms (drafts marked for counsel).

## Known issues

1. Without an LLM key, understanding is keyword-based: unusual phrasings may be re-asked (after 3 re-asks an optional field is marked "unspecified"; a required contact field triggers a hand-off).
2. A question that also contains a service keyword (e.g. "Do you offer maintenance plans?") is answered and then the AI starts qualification — slightly eager.
3. Website import is limited to 5 same-site pages and simple HTML (no JavaScript-rendered sites); DNS-rebinding SSRF residual risk (mitigate with egress rules).
4. Voice replies are generated synchronously; a slow LLM increases silence on calls (keep `LLM_TIMEOUT_SECONDS` low for voice).
5. Timezone shown in the dashboard follows the business; some staff screens show times in the viewer's browser timezone.
6. Docker images and `docker compose` were written but not executed in the build environment (no Docker daemon); CI builds them.
7. **Translations** (6 non-English catalogs) were written for this release and have not been reviewed by native speakers. Without an LLM, non-English understanding is keyword-based (the same limits as item 1, per language).
8. **VibeVoice** was not run on real hardware here (no GPU); latency/accuracy, and which of its 10 languages beyond en/es/zh/fr perform well, must be measured. Phone streaming relies on Twilio keeping `<Start><Stream>` running across call updates (documented Twilio behaviour) — confirm on a live call.
9. Barge-in timing estimates the agent's speech length from text length (~14 chars/s); interrupting very early or very late in a reply may be off by a moment.
10. Browser voice uses `ScriptProcessorNode` (deprecated but supported by all current browsers); speech synthesis voices depend on the visitor's OS/browser.

## Security

Performed: tenant-isolation suite (all resource types, id tampering, header spoofing, token scoping); auth lifecycle; CSRF; RBAC matrix; prompt injection (6 attacks incl. poisoned knowledge); tool abuse (un-offered slots, malformed args, unknown tools, disabled capabilities); webhook signatures/replay/duplicates (Twilio, Stripe); outgoing webhook signing; SSRF targets; upload validation and cross-tenant download; production-config validation; dependency audits (`pip-audit`, `npm audit`: 0 known vulnerabilities after upgrading cryptography 50.0.1, pypdf 6.19.0, pydantic-settings 2.15.0, python-multipart 0.0.32); secret scan (no findings). Not performed: external penetration test. Details: SECURITY.md.

## Tests (exact commands and results from the release run)

| Command | Result |
|---|---|
| `cd apps/api && python -m pytest -q` | **133 passed** (107 s) — includes migrations from an empty database |
| `ruff check app tests` / `ruff format --check app tests` | All checks passed / 70 files formatted |
| `python -m mypy app` | Success: no issues in 55 source files |
| `alembic check` | No new upgrade operations detected |
| `alembic upgrade head && alembic downgrade base && alembic upgrade head` (fresh DB) | head = 0004 |
| `pip-audit -r requirements.txt` | No known vulnerabilities found |
| `cd apps/web && npx tsc --noEmit` | 0 errors (strict mode) |
| `npx eslint .` | 0 problems |
| `npm run build` | Success, 39 routes |
| `npm audit --omit=dev` | 0 vulnerabilities |
| `node e2e/acceptance.mjs` (headless Chromium, full stack) | ALL BROWSER ACCEPTANCE STEPS PASSED |
| `node e2e/multilingual.mjs` (fake microphone, VibeVoice simulator) | All multilingual browser checks passed (8 steps) |
| `newman run docs/postman/… --folder 0 --folder 1` | 30 requests, 36 assertions, 0 failed |
| `python3 scripts/secret_scan.py` | no findings |
| `python -m app.simulate call …` / `sms …` (manual) | booked a service visit by voice; SMS FAQ answered via worker |

Per-suite coverage: TESTING.md.

## Integrations

| Provider | Status |
|---|---|
| Anthropic | Adapter + reliability gateway implemented, contract-tested; live **requires credentials** |
| Twilio SMS/Voice | Implemented incl. signature validation, STOP/HELP, status callbacks, number provisioning; live **requires credentials** |
| Google Calendar | OAuth + free/busy + event create/update/delete implemented; live **requires credentials** |
| Microsoft 365 Calendar | **Not implemented** |
| HubSpot | Contact + deal sync via worker; live **requires a token** |
| Salesforce | **Not implemented** |
| Stripe | Checkout, portal, plan change, cancel/resume, signed webhooks implemented and webhook-contract-tested; live **requires test/live keys** |
| SMTP | Implemented; **requires credentials** |
| S3 | Implemented; **requires bucket/credentials** (not exercised) |
| Outgoing webhooks | **Working** (tested against a real HTTP endpoint) |
| VibeVoice-ASR-Streaming | Client + phone/browser streaming implemented and protocol-tested; live model **requires a GPU server** |

## Deployment

See DEPLOYMENT.md. Summary: build `apps/api/Dockerfile` and `apps/web/Dockerfile` (with `API_URL`), run `python -m app.cli check-config && alembic upgrade head && python -m app.cli bootstrap` as a release job, roll API → worker → web, set `PUBLIC_API_URL` to the public origin serving `/api`, configure provider callbacks, create a super-admin, set Stripe price ids in Admin → Plans. Managed PostgreSQL with PITR and a versioned private bucket are required for backup/recovery.

## Verification (human procedure)

1. `docker compose up --build` (or SETUP.md), open http://localhost:3000.
2. **Build my AI employee** → complete all 9 steps with Roofing. In step 8 ask "Do you offer free inspections?" — the answer must come from your FAQ. Activate.
3. **AI employees → Website chat**: paste the snippet into any HTML page (or use `/demo`). As a customer: "My roof is leaking" → house → your ZIP → name → phone → "1". Confirm the reply says "You're all set" and the time matches **Appointments**.
4. Ask "What's your cheapest roof?" → must say it doesn't have that information (no price). Say "I want to talk to a person" → conversation shows *Needs a person* in **Inbox**; further customer messages get no AI reply until you click **Return to AI**.
5. **Dashboard** shows the lead, appointment and counts; **Leads** shows the lead in *Appointment*; **Analytics** funnel counts it.
6. Sign in as a second business (seeded owner) and confirm none of the first business's data is visible; try opening a first-business lead URL → "Lead not found".
7. Phone/SMS: add a number in **Connections**, then `python -m app.simulate call --to <number> …` and `… sms …`; check **Inbox**. With Twilio credentials: call and text the real number and repeat step 3–4 by voice/SMS; reply STOP and confirm no further texts (spec §95–96 real-provider acceptance).
8. Billing: with Stripe test keys and price ids, subscribe with card 4242…, use card 4000 0000 0000 0341 to trigger a failed renewal, then recover; confirm entitlements follow (spec §97).
9. Admin: `create-superadmin`, sign in, check **Platform admin → Overview**, investigate the conversation id from step 3.
10. Languages: in **AI employees → Settings** tick Spanish and Arabic, save. In **Test**, write "Mi techo tiene una gotera" — the reply must be Spanish. In the widget pick العربية — the greeting and replies are Arabic, right-to-left. Call the number: the menu offers "press 2 para español"; press 2 and speak Spanish.
11. VibeVoice: start the GPU server, set `VOICE_ASR_PROVIDER=vibevoice`, call the number, speak while the agent is talking (it should stop), and check **Inbox** shows "VibeVoice ASR" on the replies.
