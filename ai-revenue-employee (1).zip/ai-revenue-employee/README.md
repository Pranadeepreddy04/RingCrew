# AI Revenue Employee

A multi-tenant SaaS platform that gives small service businesses an **AI employee**: it answers website chat, phone calls and text messages, qualifies the request with industry-specific questions, books real appointments on the business's calendar, follows up by the rules the owner sets, and shows everything in a dashboard.

> **Status:** Version 1 release candidate. The complete primary workflow is implemented and verified by automated API tests and a real-browser acceptance test. Production use of phone, SMS, LLM, Google Calendar, Stripe and email **requires your credentials** — until they're configured those channels run on clearly-labelled sandbox providers. See [FINAL_RELEASE_REPORT.md](FINAL_RELEASE_REPORT.md) for exactly what is verified, what needs credentials, and what is not implemented.

## Languages and voice (v1.1)

The AI employee converses in **English, Spanish, Chinese (Mandarin), Tagalog, Vietnamese, Arabic and French** — the most spoken languages in the United States after English. Owners choose which languages each AI employee speaks; customers are answered in the language they write or speak (or pick it in the widget / phone menu). Arabic renders right-to-left.

Voice: phone calls use Twilio speech recognition per language by default, or **Microsoft VibeVoice-ASR-Streaming** (self-hosted, GPU) for streaming recognition with barge-in. The website widget and demo have a microphone button (VibeVoice stream when configured, otherwise the browser's speech recognition) and read replies aloud. Setup: [infrastructure/vibevoice/README.md](infrastructure/vibevoice/README.md).

Replies come from a reviewed phrase catalog in each language (no LLM needed); with an LLM key, customer messages are also translated for understanding and knowledge answers are written in the customer's language. **Have native speakers review the catalog (`apps/api/app/ai/i18n.py`) before launch.**

API collection: [docs/postman/ai-revenue-employee.postman_collection.json](docs/postman/ai-revenue-employee.postman_collection.json) (folder 0 runs a multilingual demo without an account). Hosting: [netlify.toml](netlify.toml) (web) + [render.yaml](render.yaml) (API, worker, Postgres) — see DEPLOYMENT.md.

## Repository

```
apps/
  api/        FastAPI + SQLAlchemy + Alembic backend, AI orchestrator, worker, tests
  web/        Next.js 16 app (marketing site, onboarding, business app, admin), browser E2E
packages/
  industry-config/packs/   Industry Packs (JSON) — roofing, HVAC, plumbing, remodeling (+ beta/disabled)
docs/         openapi.json (generated), postman/ collection
infrastructure/vibevoice/  GPU server for VibeVoice-ASR-Streaming
scripts/      secret scan, Postman generator
.github/workflows/ci.yml
```

Key documents: [ARCHITECTURE.md](ARCHITECTURE.md) · [SETUP.md](SETUP.md) · [TESTING.md](TESTING.md) · [SECURITY.md](SECURITY.md) · [DEPLOYMENT.md](DEPLOYMENT.md) · [API.md](API.md) · [PROJECT_STATUS.md](PROJECT_STATUS.md) · [CHANGELOG.md](CHANGELOG.md)

## Quick start (Docker)

```bash
cp .env.example .env
docker compose up --build
# web: http://localhost:3000    api docs: http://localhost:8000/api/docs
```

The `migrate` service runs migrations, loads industry templates and plans, and seeds three demo businesses:

| Business | Owner login | Password |
|---|---|---|
| Mike's Roofing | mike@mikes-roofing.example.com | `DemoPass!2026` |
| CoolAir HVAC | owner@coolair-hvac.example.com | `DemoPass!2026` |
| Rapid Plumbing | owner@rapid-plumbing.example.com | `DemoPass!2026` |

Create a platform admin: `docker compose run --rm api python -m app.cli create-superadmin you@example.com`.

Without Docker, see [SETUP.md](SETUP.md).

## Try the core flow in 3 minutes

1. Open http://localhost:3000 → **Build my AI employee** → finish the 9-step setup (pick Roofing).
2. In **AI employees → Website chat**, copy the install snippet, or use **Test** to chat in dry-run mode.
3. Chat as a customer: *"My roof is leaking"* → answer the questions → pick a time.
4. The AI confirms **only after** the booking is saved. Open **Dashboard**, **Inbox**, **Leads**, **Appointments**.

Phone and SMS can be exercised locally with signed sandbox webhooks:

```bash
cd apps/api
python -m app.simulate call --to <business number> "My AC is not cooling" "house" "75001" "soon" "Dana Reyes" "1"
python -m app.simulate sms  --to <business number> "Do you offer maintenance plans?"
```
