# Security

## Controls implemented

| Area | Implementation |
|---|---|
| Authentication | bcrypt (cost 12) password hashes; opaque random session tokens stored as SHA-256 hashes; server-side session expiry & revocation; logout, password reset and password change revoke sessions; constant-time login path to limit account enumeration; identical response for reset requests; single-use expiring email tokens; optional Google sign-in (OIDC, verified email only); MFA column reserved (`mfa_secret_encrypted`) — **MFA flow not implemented**. |
| Session cookies | `HttpOnly`, `SameSite=Lax`, `Secure` (required in staging/production), `Path=/`. |
| CSRF | Double-submit: cookie-authenticated unsafe requests must send `X-CSRF-Token` matching the session's token. Bearer-token API clients are not cookie-based and are exempt. |
| Authorization | RBAC (owner, manager, staff, readonly) enforced by backend dependencies on every route; platform super-admin separate. |
| Tenant isolation | `organization_id` on every tenant table and in every query; membership verified server-side; cross-tenant ids → 404. Release-blocking tests. |
| Public surfaces | Widget token (one AI employee), signed visitor token (one conversation), signed expiring upload/download tokens; rate limits on signup, login, reset, widget and upload endpoints (Redis-backed when configured). |
| AI safety | Deterministic policy layer before any model call; untrusted content wrapped as data; tools typed/validated/capability-checked; high-impact validation (only offered slots can be booked); grounding guard on generated answers; confirmation only after backend success; no model access to shell, SQL, filesystem or network. |
| Webhooks in | Twilio HMAC-SHA1 signature, Stripe signature with 5-minute tolerance; `inbound_webhook_events` unique constraint for replay/duplicate protection. |
| Webhooks out | HMAC-SHA256 `X-ARE-Signature: t=…,v1=…` over `timestamp.body`, per-endpoint secrets shown once and stored encrypted; public-address check in production. |
| SSRF | Website import resolves hosts and blocks private, loopback, link-local, reserved and multicast addresses on every redirect hop; only http(s); size and page limits. *Residual risk*: DNS rebinding between check and fetch — run the API with egress restrictions to internal ranges in production. |
| Uploads | Allow-listed MIME types verified by magic bytes, 10 MB limit, unguessable storage keys (≥64 hex chars), tenant ownership, short-lived signed downloads for authenticated staff only, `nosniff`, `Content-Disposition: attachment`; malware-scan integration point (`services/files.scan_for_malware`, **not connected to a scanner**). |
| Secrets | Integration credentials and webhook secrets encrypted at rest with Fernet (`ENCRYPTION_KEY`); never returned by the API after storage; no secrets in frontend code; `.env` ignored by git; CI secret scan. |
| Headers | `X-Content-Type-Options`, `X-Frame-Options: DENY` (except widget/public), `Referrer-Policy`, `Permissions-Policy` (camera/geolocation off; microphone only for the app's own origin, for voice chat), HSTS when `COOKIE_SECURE`. |
| Voice sockets | Twilio media stream requires an HMAC token bound to conversation id + call SID (forged or mismatched → closed 1008); browser voice requires the conversation's visitor token in the first frame (constant-time compare), per-IP rate limit, 15-minute session cap, frame size cap; audio is not stored. The VibeVoice server should be reachable only from the API (private network). |
| Multilingual safety | Emergency/gas phrases are checked in all languages regardless of detected language; injection detection runs on the original text and on the English translation. |
| Config safety | Staging/production refuse to start with default secret key, missing encryption key, insecure cookies, missing provider credentials, or sandbox providers (unless explicitly allowed). |
| Audit | `audit_logs` for auth events, configuration changes, team/role changes, privacy actions, admin actions and impersonation (with reason, IP, request id). |
| Logging | JSON structured logs with request ids; tool-call logs redact name/phone/email/address arguments. |
| Dependencies | `pip-audit` and `npm audit` clean at release (vulnerable `cryptography`, `pypdf`, `pydantic-settings`, `python-multipart` versions were upgraded). |

## Security tests performed

See TESTING.md: tenant isolation (every resource type, header spoofing, token scoping), authentication lifecycle, CSRF, RBAC matrix, prompt injection (6 cases incl. poisoned knowledge), un-offered slot booking, malformed tool arguments, unknown tools, webhook signature/replay/duplicates (Twilio, Stripe), SSRF targets, upload validation, cross-tenant file download, production configuration validation.

## Known gaps / operator responsibilities

- MFA: schema hook only; add TOTP before selling to larger customers.
- Malware scanning of uploads is not connected (files are only served to authenticated staff as attachments).
- No WAF/bot protection on public widget endpoints beyond rate limiting.
- Database row-level security (RLS) is not enabled; isolation is enforced in the application layer and verified by tests.
- A2P 10DLC registration, TCPA/consent language and call-recording disclosures must be reviewed by counsel for your jurisdictions. Defaults are conservative: recording off, follow-ups only with recorded consent, STOP honored immediately.
- Penetration test not performed.
