# Setup (without Docker)

Requirements: Python 3.11, Node 22, PostgreSQL 16 with the `btree_gist` extension available (part of `postgresql-contrib`), optionally Redis.

```bash
# 1. Database
createdb are_dev
createdb are_test          # used by the test suite

# 2. API
cd apps/api
python -m venv .venv && . .venv/bin/activate
pip install -r requirements-dev.txt
cp ../../.env.example .env                 # defaults work for local development
alembic upgrade head                       # migrations (separate from seeding)
python -m app.cli bootstrap                # industry templates + plans (idempotent, safe in production)
python -m app.cli seed-demo                # development only: 3 demo businesses with fake data
python -m app.cli create-superadmin admin@example.com
uvicorn app.main:app --reload --port 8000  # API  → http://localhost:8000/api/docs
python -m app.worker                       # worker (second terminal)

# 3. Web
cd ../web
npm install
API_URL=http://localhost:8000 npm run dev  # → http://localhost:3000
```

`PUBLIC_API_URL` should be the origin the outside world uses to reach `/api` — in local dev that's the web app (`http://localhost:3000`), because the web app proxies `/api` to the API. Provider webhooks, OAuth callbacks and signed links are built from it.

## Development scripts

| Command | What it does |
|---|---|
| `python -m app.cli gen-key` | new `ENCRYPTION_KEY` |
| `python -m app.cli check-config` | validate configuration for the current `APP_ENV` |
| `python -m app.worker --once` | process due jobs/follow-ups once |
| `python -m app.simulate sms|call …` | send signed sandbox telephony webhooks to the local API |
| `alembic revision --autogenerate -m "…"` | new migration (review before committing); `alembic check` detects drift |

## Turning on real providers

Each is independent; set the variables and restart API + worker. Production refuses sandbox providers unless explicitly allowed.

| Provider | Variables | Also do |
|---|---|---|
| Anthropic (AI understanding & answers) | `PRIMARY_LLM_PROVIDER=anthropic`, `ANTHROPIC_API_KEY` | — |
| Twilio (calls & texts) | `SMS_PROVIDER=twilio`, `VOICE_PROVIDER=twilio`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, optional `TWILIO_MESSAGING_SERVICE_SID` | Point numbers' Voice URL to `…/api/v1/webhooks/voice/incoming`, Messaging URL to `…/webhooks/sms/incoming`, status callback `…/webhooks/voice/status`. Register A2P 10DLC. |
| Google Calendar | `GOOGLE_CALENDAR_CLIENT_ID/SECRET` | OAuth client redirect URI: `{PUBLIC_API_URL}/api/v1/integrations/google-calendar/callback` |
| Google sign-in | `GOOGLE_OAUTH_CLIENT_ID/SECRET` | redirect URI `{PUBLIC_API_URL}/api/v1/auth/google/callback` |
| Stripe | `BILLING_PROVIDER=stripe`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | Create a Price per plan and set it in **Admin → Plans**; webhook endpoint `…/api/v1/webhooks/stripe` with `customer.subscription.*`, `checkout.session.completed`, `invoice.*` events |
| SMTP | `EMAIL_PROVIDER=smtp`, `SMTP_*`, `EMAIL_FROM` | SPF/DKIM for the sending domain |
| S3 storage | `S3_BUCKET`, AWS credentials, optional `S3_ENDPOINT_URL`; `pip install boto3` | private bucket, SSE on |
| HubSpot | per business in **Connections** (private-app token) | — |

## Voice: VibeVoice-ASR-Streaming (optional)

Phone and browser voice work without it (Twilio / browser speech recognition). For streaming recognition with barge-in,
run the model server on a GPU host (`infrastructure/vibevoice/README.md`) and set `VOICE_ASR_PROVIDER=vibevoice`,
`VIBEVOICE_ASR_URL=http://<gpu-host>:7870`. Twilio must reach `wss://<PUBLIC_API_URL host>/api/v1/voice/stream`.

Without a GPU you can exercise the whole streaming path with the protocol simulator used by the tests:

```bash
cd apps/api && python -c "from tests.fake_vibevoice import FakeVibeVoice; import time; f=FakeVibeVoice(); f.script.extend(['Hola, mi techo tiene una gotera']*50); f.__enter__(); print(f.url); time.sleep(10**9)"
# then start the API with VOICE_ASR_PROVIDER=vibevoice VIBEVOICE_ASR_URL=<printed url>
```
