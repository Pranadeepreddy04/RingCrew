# Testing

## Commands

```bash
# Backend (needs PostgreSQL; uses database are_test, recreated from empty via migrations on every run)
cd apps/api
python -m pytest -q                         # 133 tests
ruff check app tests && ruff format --check app tests
python -m mypy app
alembic check                               # models ↔ migrations drift
pip-audit -r requirements.txt               # dependency vulnerabilities

# Frontend
cd apps/web
npx tsc --noEmit && npx eslint . && npm run build
npm audit --omit=dev

# Real-browser acceptance (API + worker + web running; see SETUP.md)
BASE_URL=http://localhost:3000 node e2e/acceptance.mjs     # CHROME_PATH=/path/to/chrome optional
# Multilingual + voice (API started with VOICE_ASR_PROVIDER=vibevoice VIBEVOICE_ASR_URL=<server or simulator>)
BASE_URL=http://localhost:3000 node e2e/multilingual.mjs   # needs ffmpeg (generates the fake-microphone WAV)

# Postman collection (quick-start folders) with Newman
npx newman run docs/postman/ai-revenue-employee.postman_collection.json --env-var baseUrl=http://localhost:3000 \
  --folder "0. Quick start — multilingual demo (no account)" --folder "1. Quick start — owner (account, 7-language AI employee)"
# screenshots → apps/web/e2e/screenshots/

# Secrets
python3 scripts/secret_scan.py
```

## What the suites prove

| File | Tests | Covers (spec §) |
|---|---|---|
| `test_e2e_acceptance.py` | 3 | **Release-blocking primary workflow (§94, §77)**: owner signup → org → Roofing → profile/services → knowledge → agent → test env → activation → widget conversation → knowledge answer → qualification → customer + qualified lead → real availability → booking → confirmation only after persistence → dashboard, inbox (tool calls), analytics events, follow-up stopped. Test environment and public demo are dry runs (nothing persisted). |
| `test_tenant_isolation.py` | 6 | **Release-blocking (§83)**: org A reading/modifying org B leads, customers, appointments, conversations, messages, agents, knowledge, workflows, integrations, services, tasks by direct id → 403/404; lists & analytics isolated; `X-Organization-Id` spoofing → 403; widget token grants no admin access; visitor token scoped to one conversation; AI never reveals another customer. |
| `test_auth_rbac.py` | 10 | §84 signup/login/session/protected route/logout, invalid credentials, weak passwords, CSRF enforcement, expired session, disabled account, email verification (single-use), password reset (no enumeration, revokes sessions), password change, bearer tokens, RBAC for owner/manager/staff/readonly, last-owner protection, security headers & request IDs. |
| `test_ai_safety.py` | 19 | §43/44/87: 5 prompt-injection attacks, injected instructions inside knowledge ignored, no invented prices/discounts, human request → handoff & AI silence & contact capture & staff reply & return-to-AI, takeover blocks AI, complaint & emergency escalation with instructions, **calendar failure between offer and booking never reported as success**, calendar down before offer, service-area checks, inactive agent never answers, **industry evaluation suites for roofing/HVAC/plumbing/remodeling (§54)**, per-agent question overrides. |
| `test_llm_reliability.py` | 7 | §85/86/91: LLM-proposed fields validated before use, invalid structured output repaired then discarded, provider outage → degraded but correct answers, fallback provider used **only** when the tenant allows it, ungrounded LLM answers (invented $/%) rejected, grounding guard, Anthropic adapter request/response/error-mapping contract, every AI call traced (org, agent, model, prompt version, latency, status). |
| `test_scheduling.py` | 8 | §30/89/90: hours + timezone + lead time, booked slot removed, double booking rejected, idempotent booking, **6 concurrent threads racing for one slot → exactly one wins**, multi-crew capacity, external busy time respected & outage → 503, reschedule/cancel/status rules, AI cannot book un-offered slots / malformed args / unknown tools / disabled capabilities. |
| `test_channels.py` | 10 | §95/96 with signed sandbox webhooks: signature required, full SMS conversation to booking, duplicate SMS webhook processed once, STOP/START/HELP, opted-out customer never auto-answered, invalid numbers, provider failure retried without fabricated reply + delivery status callback; full voice call to booking with disclosure, silence, low-confidence speech, human transfer (`<Dial>`), duplicate call webhook, early hang-up → callback lead, voice unavailable → forwarded. |
| `test_multilingual.py` | 31 | Booking an inspection end to end in Spanish, Chinese, Tagalog, Vietnamese, Arabic and French (detected language, no English leakage, appointment + lead with the Unicode name); English unchanged and accented names don't switch language; languages not enabled are ignored; widget config + explicit start language + custom greetings; agent language validation; gas emergency handoff in 5 languages; hours in Chinese/Spanish; English FAQ not pasted into a Spanish chat without an LLM; detection table; spoken digits; catalog completeness. |
| `test_voice_streaming.py` | 20 | Phone language menu (each option in its own language/voice), Spanish call via Twilio recognition to booking, menu timeout, Vietnamese silence prompt; μ-law/resampling and VAD endpointing; **VibeVoice client over the real wire protocol** (options frame, float32 @ 24 kHz, partials, `end`→`done`) against `tests/fake_vibevoice.py`; **phone call over Twilio Media Streams + VibeVoice booking in Spanish**; barge-in cuts the agent; forged/mismatched stream tokens rejected; ASR down → Twilio fallback; keepalive silence handling; browser voice socket (auth, unsupported language, no ASR configured); configurable VibeVoice languages. |
| `test_workflows.py` | 6 | §31: delays, multi-step, max attempts (no loops), stop on reply / booking / STOP, quiet hours defer, no consent → no follow-up, workflow validation. |
| `test_billing.py` | 5 | §97: trial entitlements enforced on backend, checkout, upgrade, downgrade guard, renewal, failed payment (grace), recovery, cancel/resume/period end, trial expiry takes AI offline, usage limits; **Stripe webhook** signature, replay window, duplicate event, subscription/invoice lifecycle. |
| `test_platform.py` | 8 | Outgoing webhooks (HMAC signature verified by a real HTTP server, retry on 500), knowledge CRUD/search/approval/documents, SSRF blocking on website import, secure uploads (magic bytes, size, token, unguessable keys, cross-tenant download denied), privacy export & customer deletion redaction, org deletion + purge, admin access/suspension/impersonation audit/regulated-template lock, production config validation. |

**Browser acceptance** (`apps/web/e2e/acceptance.mjs`, headless Chromium): marketing page → signup → full 9-step onboarding through the UI → test console → activation → install snippet → widget on a separate page books an inspection as a customer → dashboard, inbox (AI actions), leads board, analytics, appointments → mobile layout; fails on any page error.

## Not covered by automated tests here

- The real VibeVoice model (needs an NVIDIA GPU): the client is verified against a protocol-faithful simulator; recognition accuracy/latency must be measured on your GPU.
- Translation quality of the 6 non-English catalogs: written for this release, not yet reviewed by native speakers.
- Real carrier calls/texts, real Google Calendar, real Stripe test mode, real SMTP, real Anthropic calls: adapters are contract-tested with mocked HTTP; live verification needs your credentials (procedures in FINAL_RELEASE_REPORT.md → Verification).
- `docker compose up` and the Dockerfiles were not executed in the build environment (no Docker daemon available). CI builds them.
- Load/performance testing.
