"""Multilingual support for the AI employee.

Supported conversation languages — English plus the six most-spoken non-English languages in
US homes (Census ACS): Spanish, Chinese (Mandarin), Tagalog/Filipino, Vietnamese, Arabic, French.

This module provides, without any external service:
- language detection for a customer message (script + vocabulary scoring),
- the full catalog of everything the AI employee says, in every supported language,
- localized question prompts for the active Industry Packs,
- multilingual keywords so qualification answers are understood in every language,
- localized date/time and business-hours formatting.

When an LLM is configured, it additionally translates free-form customer text for understanding
and phrases knowledge answers in the customer's language (see orchestrator).

Translations were written for this product and should be reviewed by native speakers before
production use with real customers."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

LANGS: dict[str, dict[str, str]] = {
    # code: display name (English), native name, BCP-47 for browser speech, Twilio speech-recognition code,
    # Twilio <Say> language + voice (Google voices on Twilio)
    "en": {"name": "English", "native": "English", "bcp47": "en-US", "twilio_asr": "en-US", "tts_lang": "en-US", "tts_voice": "Google.en-US-Neural2-F"},
    "es": {"name": "Spanish", "native": "Español", "bcp47": "es-US", "twilio_asr": "es-US", "tts_lang": "es-US", "tts_voice": "Google.es-US-Neural2-A"},
    "zh": {"name": "Chinese", "native": "中文", "bcp47": "zh-CN", "twilio_asr": "cmn-Hans-CN", "tts_lang": "cmn-CN", "tts_voice": "Google.cmn-CN-Wavenet-A"},
    "tl": {"name": "Tagalog", "native": "Tagalog", "bcp47": "fil-PH", "twilio_asr": "fil-PH", "tts_lang": "fil-PH", "tts_voice": "Google.fil-PH-Wavenet-A"},
    "vi": {"name": "Vietnamese", "native": "Tiếng Việt", "bcp47": "vi-VN", "twilio_asr": "vi-VN", "tts_lang": "vi-VN", "tts_voice": "Google.vi-VN-Wavenet-A"},
    "ar": {"name": "Arabic", "native": "العربية", "bcp47": "ar-SA", "twilio_asr": "ar-SA", "tts_lang": "ar-XA", "tts_voice": "Google.ar-XA-Wavenet-A"},
    "fr": {"name": "French", "native": "Français", "bcp47": "fr-FR", "twilio_asr": "fr-FR", "tts_lang": "fr-FR", "tts_voice": "Google.fr-FR-Neural2-A"},
}
SUPPORTED = tuple(LANGS)
# Languages the VibeVoice-ASR-Streaming model recognizes among ours (it supports zh, en, fr, de, it, ja, ko, pt, ru, es).
LANGUAGE_ORDER = ("en", "es", "zh", "tl", "vi", "ar", "fr")
VIBEVOICE_LANGS = frozenset({"en", "es", "zh", "fr"})
RTL = frozenset({"ar"})

# ---------------------------------------------------------------------------------------------- detection

_CJK = re.compile(r"[一-鿿㐀-䶿]")
_ARABIC = re.compile(r"[؀-ۿݐ-ݿ]")
# letters that only occur in Vietnamese among our languages
_VI_CHARS = re.compile(r"[ăđơưạảấầẩẫậắằẳẵặẹẻẽếềểễệỉịọỏốồổỗộớờởỡợụủứừửữựỳỵỷỹ]", re.I)
_WORDS: dict[str, set[str]] = {
    "es": {
        "hola",
        "gracias",
        "necesito",
        "quiero",
        "tengo",
        "por",
        "favor",
        "techo",
        "casa",
        "cita",
        "mi",
        "el",
        "la",
        "los",
        "las",
        "de",
        "que",
        "es",
        "una",
        "un",
        "con",
        "para",
        "está",
        "esta",
        "buenos",
        "días",
        "dias",
        "tardes",
        "sí",
        "si",
        "no",
        "agua",
        "aire",
        "fuga",
        "gotea",
        "goteando",
        "puede",
        "pueden",
        "venir",
        "mañana",
        "manana",
        "hoy",
        "cuánto",
        "cuanto",
        "cuesta",
        "llamo",
        "nombre",
        "ayuda",
        "reparación",
        "reparacion",
        "inspección",
        "inspeccion",
        "hablar",
        "persona",
        "urgente",
        "mío",
        "pronto",
        "semana",
        "ofrecen",
        "tienen",
        "hacen",
        "financiamiento",
        "precio",
        "horario",
        "dónde",
        "donde",
        "cuándo",
        "cuando",
        "huele",
        "gas",
        "tormenta",
        "gotera",
    },
    "fr": {
        "bonjour",
        "merci",
        "je",
        "j'ai",
        "besoin",
        "toit",
        "maison",
        "rendez-vous",
        "rendez",
        "vous",
        "est",
        "une",
        "des",
        "les",
        "le",
        "la",
        "pour",
        "avec",
        "fuite",
        "réparation",
        "reparation",
        "s'il",
        "plaît",
        "plait",
        "demain",
        "aujourd'hui",
        "combien",
        "coûte",
        "appelle",
        "voudrais",
        "pouvez",
        "oui",
        "non",
        "nous",
        "notre",
        "mon",
        "ma",
        "chauffage",
        "climatisation",
        "urgent",
        "parler",
        "quelqu'un",
        "semaine",
        "sent",
        "chez",
        "moi",
        "avez",
        "proposez",
        "financement",
        "horaires",
        "où",
        "quand",
        "orage",
        "fuit",
        "ça",
        "il",
    },
    "tl": {
        "po",
        "opo",
        "salamat",
        "kailangan",
        "ko",
        "ng",
        "bubong",
        "bahay",
        "magandang",
        "umaga",
        "hapon",
        "ako",
        "mga",
        "sa",
        "na",
        "ang",
        "may",
        "tumutulo",
        "tulo",
        "ayusin",
        "pwede",
        "puwede",
        "bukas",
        "ngayon",
        "magkano",
        "pangalan",
        "oo",
        "hindi",
        "kami",
        "namin",
        "aming",
        "gusto",
        "kausapin",
        "tao",
        "agad",
        "linggo",
        "aircon",
        "nasira",
        "sira",
        "ba",
        "lang",
        "kasi",
        "nyo",
        "ninyo",
    },
    "vi": {
        "tôi",
        "không",
        "được",
        "cảm",
        "ơn",
        "xin",
        "chào",
        "cần",
        "nhà",
        "mái",
        "bị",
        "dột",
        "sửa",
        "của",
        "và",
        "có",
        "là",
        "ngày",
        "mai",
        "hôm",
        "nay",
        "bao",
        "nhiêu",
        "tên",
        "vâng",
        "dạ",
        "muốn",
        "nói",
        "chuyện",
        "người",
        "gấp",
        "tuần",
        "máy",
        "lạnh",
    },
    "en": {
        "the",
        "and",
        "my",
        "is",
        "i",
        "need",
        "roof",
        "please",
        "thanks",
        "thank",
        "you",
        "hello",
        "hi",
        "can",
        "someone",
        "come",
        "what",
        "your",
        "have",
        "leak",
        "leaking",
        "house",
        "home",
        "tomorrow",
        "today",
        "how",
        "much",
        "with",
        "for",
        "this",
        "want",
        "talk",
        "yes",
        "no",
        "it's",
        "its",
        "there",
        "are",
        "do",
        "does",
        "fix",
        "repair",
        "inspection",
        "appointment",
    },
}
_ACCENTS = {"es": re.compile(r"[ñ¿¡áéíóú]", re.I), "fr": re.compile(r"[çàâèêëîïôûùœ]", re.I)}


def detect(text: str) -> tuple[str | None, float]:
    """Return (language, confidence 0..1). None when the text carries no language signal
    (numbers, names, phone numbers, ZIP codes, single ambiguous words)."""
    t = (text or "").strip()
    if not t:
        return None, 0.0
    if _CJK.search(t):
        return "zh", 1.0
    if _ARABIC.search(t):
        return "ar", 1.0
    if _VI_CHARS.search(t):
        return "vi", 0.95
    words = re.findall(r"[a-zà-ÿ'’\-ñ]+", t.lower().replace("’", "'"))
    if not words:
        return None, 0.0
    vocab_hits: dict[str, int] = {lang: sum(1 for w in words if w in vocab) for lang, vocab in _WORDS.items()}
    if max(vocab_hits.values()) == 0:
        return None, 0.0  # names and other bare words carry no language signal, even with accents
    scores: dict[str, float] = {k: float(v) for k, v in vocab_hits.items()}
    for lang, rx in _ACCENTS.items():
        scores[lang] += 0.4 * min(len(rx.findall(t)), 3)
    best = max(scores, key=lambda k: scores[k])
    if vocab_hits[best] == 0:
        return None, 0.0
    second = sorted(scores.values())[-2]
    margin = (scores[best] - second) / max(scores[best], 1)
    conf = min(1.0, 0.35 + 0.15 * scores[best]) * (0.5 + 0.5 * margin)
    return best, round(conf, 3)


def choose_language(text: str, current: str | None, allowed: list[str], default: str) -> str:
    """Sticky selection: start in the detected language; switch mid-conversation only on a clear signal."""
    lang, conf = detect(text)
    allowed_set = [lng for lng in allowed if lng in LANGS] or [default]
    if lang is None or lang not in allowed_set:
        return current if current in allowed_set else (default if default in allowed_set else allowed_set[0])
    if current is None or current == lang:
        return lang
    return lang if conf >= 0.6 else current


# ---------------------------------------------------------------------------------------------- catalog

M: dict[str, dict[str, str]] = {
    "offline": {
        "en": "Thanks for reaching out to {org}! Our team will get back to you as soon as possible.",
        "es": "¡Gracias por comunicarse con {org}! Nuestro equipo le responderá lo antes posible.",
        "zh": "感谢您联系{org}！我们的团队会尽快回复您。",
        "tl": "Salamat sa pakikipag-ugnayan sa {org}! Babalikan kayo ng aming team sa lalong madaling panahon.",
        "vi": "Cảm ơn bạn đã liên hệ {org}! Đội ngũ của chúng tôi sẽ phản hồi bạn sớm nhất có thể.",
        "ar": "شكرًا لتواصلك مع {org}! سيتواصل معك فريقنا في أقرب وقت ممكن.",
        "fr": "Merci d'avoir contacté {org} ! Notre équipe vous répondra dès que possible.",
    },
    "limit": {
        "en": "Thanks for reaching out to {org}! Our team will follow up with you shortly.",
        "es": "¡Gracias por comunicarse con {org}! Nuestro equipo se pondrá en contacto con usted en breve.",
        "zh": "感谢您联系{org}！我们的团队会很快与您联系。",
        "tl": "Salamat sa pakikipag-ugnayan sa {org}! Makikipag-ugnayan sa inyo ang aming team sa lalong madaling panahon.",
        "vi": "Cảm ơn bạn đã liên hệ {org}! Đội ngũ của chúng tôi sẽ liên lạc lại với bạn ngay.",
        "ar": "شكرًا لتواصلك مع {org}! سيتابع معك فريقنا قريبًا.",
        "fr": "Merci d'avoir contacté {org} ! Notre équipe vous recontactera sous peu.",
    },
    "not_caught": {
        "en": "Sorry, I didn't catch that. Could you say that again?",
        "es": "Disculpe, no le entendí. ¿Podría repetirlo?",
        "zh": "抱歉，我没有听清楚。您能再说一遍吗？",
        "tl": "Pasensya na, hindi ko po narinig. Puwede po bang pakiulit?",
        "vi": "Xin lỗi, tôi chưa nghe rõ. Bạn có thể nói lại được không?",
        "ar": "عذرًا، لم أفهم ذلك. هل يمكنك تكرار ما قلته؟",
        "fr": "Désolé, je n'ai pas bien compris. Pourriez-vous répéter ?",
    },
    "confirm_cancel": {
        "en": "Just to confirm — would you like me to cancel your appointment? (yes or no)",
        "es": "Solo para confirmar: ¿desea que cancele su cita? (sí o no)",
        "zh": "确认一下：您要取消预约吗？（是或否）",
        "tl": "Para lang makumpirma — gusto n'yo po bang kanselahin ang inyong appointment? (oo o hindi)",
        "vi": "Xin xác nhận — bạn có muốn tôi hủy lịch hẹn không? (có hoặc không)",
        "ar": "للتأكيد فقط — هل تريد أن ألغي موعدك؟ (نعم أو لا)",
        "fr": "Pour confirmer : voulez-vous que j'annule votre rendez-vous ? (oui ou non)",
    },
    "welcome": {
        "en": "You're welcome! Is there anything else I can help you with?",
        "es": "¡Con gusto! ¿Hay algo más en lo que pueda ayudarle?",
        "zh": "不客气！还有什么可以帮您的吗？",
        "tl": "Walang anuman po! May iba pa po ba akong maitutulong?",
        "vi": "Không có gì! Tôi có thể giúp gì thêm cho bạn không?",
        "ar": "على الرحب والسعة! هل هناك أي شيء آخر يمكنني مساعدتك به؟",
        "fr": "Je vous en prie ! Puis-je vous aider pour autre chose ?",
    },
    "greet": {
        "en": "Hi! I can answer questions about {org} or help you set up {appt_a}. What can I help you with today?",
        "es": "¡Hola! Puedo responder preguntas sobre {org} o ayudarle a programar {appt_a}. ¿En qué le puedo ayudar hoy?",
        "zh": "您好！我可以回答有关{org}的问题，或帮您预约{appt}。今天有什么可以帮您的吗？",
        "tl": "Hello po! Puwede kong sagutin ang mga tanong tungkol sa {org} o tulungan kayong mag-iskedyul ng {appt}. Ano po ang maitutulong ko ngayon?",
        "vi": "Xin chào! Tôi có thể trả lời câu hỏi về {org} hoặc giúp bạn đặt lịch {appt}. Hôm nay tôi có thể giúp gì cho bạn?",
        "ar": "مرحبًا! يمكنني الإجابة عن أسئلتك حول {org} أو مساعدتك في حجز {appt}. كيف يمكنني مساعدتك اليوم؟",
        "fr": "Bonjour ! Je peux répondre à vos questions sur {org} ou vous aider à planifier {appt_a}. Comment puis-je vous aider aujourd'hui ?",
    },
    "help_menu": {
        "en": "I can help with questions about {org} or schedule {appt_a}. What would you like to do?",
        "es": "Puedo ayudarle con preguntas sobre {org} o programar {appt_a}. ¿Qué le gustaría hacer?",
        "zh": "我可以解答有关{org}的问题，或帮您预约{appt}。您想做什么？",
        "tl": "Matutulungan ko kayo sa mga tanong tungkol sa {org} o sa pag-iskedyul ng {appt}. Ano po ang gusto ninyong gawin?",
        "vi": "Tôi có thể giải đáp câu hỏi về {org} hoặc đặt lịch {appt}. Bạn muốn làm gì?",
        "ar": "يمكنني المساعدة في الأسئلة حول {org} أو حجز {appt}. ماذا تود أن تفعل؟",
        "fr": "Je peux répondre à vos questions sur {org} ou planifier {appt_a}. Que souhaitez-vous faire ?",
    },
    "injection": {
        "en": "I'm not able to help with that. I can answer questions about {org} or help schedule service.",
        "es": "No puedo ayudarle con eso. Puedo responder preguntas sobre {org} o ayudarle a programar un servicio.",
        "zh": "这个我无法提供帮助。我可以回答有关{org}的问题，或帮您预约服务。",
        "tl": "Hindi ko po kayo matutulungan diyan. Puwede kong sagutin ang mga tanong tungkol sa {org} o tumulong mag-iskedyul ng serbisyo.",
        "vi": "Tôi không thể giúp việc đó. Tôi có thể trả lời câu hỏi về {org} hoặc giúp đặt lịch dịch vụ.",
        "ar": "لا يمكنني المساعدة في ذلك. يمكنني الإجابة عن أسئلتك حول {org} أو مساعدتك في حجز خدمة.",
        "fr": "Je ne peux pas vous aider avec cela. Je peux répondre à vos questions sur {org} ou vous aider à planifier un service.",
    },
    "danger": {
        "en": "If anyone is in danger, please call 911 right away.",
        "es": "Si alguien está en peligro, llame al 911 de inmediato.",
        "zh": "如有任何人身危险，请立即拨打911。",
        "tl": "Kung may nasa panganib, tumawag po agad sa 911.",
        "vi": "Nếu có ai đang gặp nguy hiểm, hãy gọi 911 ngay lập tức.",
        "ar": "إذا كان أي شخص في خطر، يرجى الاتصال بالرقم 911 فورًا.",
        "fr": "Si quelqu'un est en danger, appelez immédiatement le 911.",
    },
    "gas": {
        "en": "Please leave the building now and call 911 or your gas company from outside.",
        "es": "Por favor, salga del edificio ahora y llame al 911 o a su compañía de gas desde afuera.",
        "zh": "请立即离开建筑物，并在室外拨打911或燃气公司电话。",
        "tl": "Lumabas po kayo agad ng gusali at tumawag sa 911 o sa inyong gas company mula sa labas.",
        "vi": "Vui lòng rời khỏi tòa nhà ngay và gọi 911 hoặc công ty gas từ bên ngoài.",
        "ar": "يرجى مغادرة المبنى الآن والاتصال بالرقم 911 أو بشركة الغاز من الخارج.",
        "fr": "Veuillez quitter le bâtiment immédiatement et appeler le 911 ou votre fournisseur de gaz depuis l'extérieur.",
    },
    "complaint": {
        "en": "I'm sorry about your experience. I'm bringing in someone from our team who can help with this directly.",
        "es": "Lamento mucho su experiencia. Voy a comunicarle con alguien de nuestro equipo que puede ayudarle directamente.",
        "zh": "很抱歉给您带来不好的体验。我会请我们团队的同事直接为您处理。",
        "tl": "Paumanhin po sa inyong naging karanasan. Ipapasa ko po kayo sa isang kasama namin na direktang makakatulong.",
        "vi": "Rất tiếc về trải nghiệm của bạn. Tôi sẽ nhờ một người trong đội ngũ trực tiếp hỗ trợ bạn.",
        "ar": "نأسف لتجربتك. سأحيل الأمر إلى أحد أعضاء فريقنا ليساعدك مباشرة.",
        "fr": "Je suis désolé pour ce désagrément. Je fais appel à un membre de notre équipe qui pourra vous aider directement.",
    },
    "transferring": {
        "en": "Of course — I'm transferring you to someone on our team now.",
        "es": "Por supuesto, le comunico ahora con alguien de nuestro equipo.",
        "zh": "好的，我现在为您转接我们的团队成员。",
        "tl": "Sige po — ikokonekta ko na kayo sa isang kasama namin.",
        "vi": "Vâng — tôi đang chuyển bạn đến một người trong đội ngũ của chúng tôi.",
        "ar": "بالطبع — سأحوّلك الآن إلى أحد أعضاء فريقنا.",
        "fr": "Bien sûr, je vous transfère maintenant à un membre de notre équipe.",
    },
    "team_will_reach": {
        "en": "Of course — I've let our team know and someone will reach out to you shortly.",
        "es": "Por supuesto, ya avisé a nuestro equipo y alguien se comunicará con usted en breve.",
        "zh": "好的，我已通知我们的团队，很快会有人与您联系。",
        "tl": "Sige po — naabisuhan ko na ang aming team at may makikipag-ugnayan sa inyo sa lalong madaling panahon.",
        "vi": "Vâng — tôi đã báo cho đội ngũ và sẽ có người liên hệ với bạn ngay.",
        "ar": "بالطبع — لقد أبلغت فريقنا وسيتواصل معك أحدهم قريبًا.",
        "fr": "Bien sûr, j'ai prévenu notre équipe et quelqu'un vous contactera sous peu.",
    },
    "ask_phone_for_team": {
        "en": "What's the best phone number for them to reach you?",
        "es": "¿Cuál es el mejor número de teléfono para comunicarnos con usted?",
        "zh": "请问联系您的最佳电话号码是多少？",
        "tl": "Ano po ang pinakamagandang numero ng telepono para matawagan kayo?",
        "vi": "Số điện thoại nào tốt nhất để liên lạc với bạn?",
        "ar": "ما أفضل رقم هاتف للتواصل معك؟",
        "fr": "Quel est le meilleur numéro de téléphone pour vous joindre ?",
    },
    "next_openings": {
        "en": "Our next openings are {slots}",
        "es": "Nuestros próximos horarios disponibles son {slots}",
        "zh": "我们最近的空档是：{slots}",
        "tl": "Ang mga susunod naming bakanteng oras ay {slots}",
        "vi": "Các khung giờ trống tiếp theo là {slots}",
        "ar": "مواعيدنا المتاحة القادمة هي {slots}",
        "fr": "Nos prochaines disponibilités sont {slots}",
    },
    "no_info": {
        "en": "I don't have that information available. I can have someone from the team help you.",
        "es": "No tengo esa información disponible. Puedo pedir que alguien del equipo le ayude.",
        "zh": "我目前没有这方面的信息。我可以请团队同事为您解答。",
        "tl": "Wala po akong impormasyong iyan. Puwede kong ipasa sa isang kasama namin para matulungan kayo.",
        "vi": "Tôi chưa có thông tin đó. Tôi có thể nhờ người trong đội ngũ hỗ trợ bạn.",
        "ar": "لا تتوفر لدي هذه المعلومات. يمكنني أن أطلب من أحد أعضاء الفريق مساعدتك.",
        "fr": "Je n'ai pas cette information. Je peux demander à un membre de l'équipe de vous aider.",
    },
    "area_yes": {
        "en": "Yes — {zip} is in our service area.",
        "es": "Sí, {zip} está dentro de nuestra área de servicio.",
        "zh": "是的，{zip}在我们的服务范围内。",
        "tl": "Opo — sakop ng aming serbisyo ang {zip}.",
        "vi": "Có — {zip} nằm trong khu vực phục vụ của chúng tôi.",
        "ar": "نعم — الرمز البريدي {zip} ضمن منطقة خدمتنا.",
        "fr": "Oui, {zip} fait partie de notre zone de service.",
    },
    "area_no": {
        "en": "I'm sorry — {zip} is outside our listed service area. I can still take your details so the team can let you know if they're able to help.",
        "es": "Lo siento, {zip} está fuera de nuestra área de servicio. Aun así puedo tomar sus datos para que el equipo le diga si puede ayudarle.",
        "zh": "抱歉，{zip}不在我们列出的服务范围内。我仍可以记下您的信息，团队会告诉您是否能够提供帮助。",
        "tl": "Paumanhin po — ang {zip} ay labas sa aming nakalistang service area. Puwede ko pa ring kunin ang inyong detalye para masabi ng team kung matutulungan nila kayo.",
        "vi": "Xin lỗi — {zip} nằm ngoài khu vực phục vụ của chúng tôi. Tôi vẫn có thể ghi lại thông tin để đội ngũ báo cho bạn nếu có thể hỗ trợ.",
        "ar": "عذرًا — الرمز البريدي {zip} خارج منطقة خدمتنا. لا يزال بإمكاني أخذ بياناتك ليخبرك الفريق إن كان بإمكانهم المساعدة.",
        "fr": "Désolé, {zip} est en dehors de notre zone de service. Je peux tout de même noter vos coordonnées pour que l'équipe vous dise si elle peut vous aider.",
    },
    "hours": {
        "en": "Our hours are {hours}.",
        "es": "Nuestro horario es: {hours}.",
        "zh": "我们的营业时间是：{hours}。",
        "tl": "Ang aming oras ay: {hours}.",
        "vi": "Giờ làm việc của chúng tôi: {hours}.",
        "ar": "ساعات عملنا: {hours}.",
        "fr": "Nos horaires sont : {hours}.",
    },
    "located": {
        "en": "We're located at {address}.",
        "es": "Estamos ubicados en {address}.",
        "zh": "我们的地址是：{address}。",
        "tl": "Matatagpuan kami sa {address}.",
        "vi": "Chúng tôi ở địa chỉ {address}.",
        "ar": "عنواننا: {address}.",
        "fr": "Nous sommes situés au {address}.",
    },
    "reach_us": {
        "en": "You can reach us at {phone}.",
        "es": "Puede comunicarse con nosotros al {phone}.",
        "zh": "您可以拨打{phone}联系我们。",
        "tl": "Maaari ninyo kaming tawagan sa {phone}.",
        "vi": "Bạn có thể liên hệ chúng tôi qua số {phone}.",
        "ar": "يمكنك التواصل معنا على {phone}.",
        "fr": "Vous pouvez nous joindre au {phone}.",
    },
    "we_offer": {
        "en": "We offer {list}.",
        "es": "Ofrecemos: {list}.",
        "zh": "我们提供以下服务：{list}。",
        "tl": "Nag-aalok kami ng: {list}.",
        "vi": "Chúng tôi cung cấp: {list}.",
        "ar": "نقدم الخدمات التالية: {list}.",
        "fr": "Nous proposons : {list}.",
    },
    "trouble": {
        "en": "I'm having trouble getting that down correctly.",
        "es": "Estoy teniendo dificultades para anotarlo correctamente.",
        "zh": "抱歉，我没能正确记录这项信息。",
        "tl": "Nahihirapan po akong maitala iyan nang tama.",
        "vi": "Tôi đang gặp khó khăn khi ghi lại thông tin này.",
        "ar": "أواجه صعوبة في تسجيل ذلك بشكل صحيح.",
        "fr": "J'ai du mal à noter cela correctement.",
    },
    "retry_phone": {
        "en": "Sorry, I didn't catch a valid number. What's a 10-digit phone number we can reach you at?",
        "es": "Disculpe, no entendí un número válido. ¿Cuál es su número de teléfono de 10 dígitos?",
        "zh": "抱歉，没有识别到有效号码。请提供一个10位数的电话号码。",
        "tl": "Pasensya na po, hindi ko nakuha ang tamang numero. Ano po ang 10-digit na numero ng telepono ninyo?",
        "vi": "Xin lỗi, tôi chưa nhận được số hợp lệ. Số điện thoại 10 chữ số của bạn là gì?",
        "ar": "عذرًا، لم ألتقط رقمًا صحيحًا. ما رقم هاتفك المكوّن من 10 أرقام؟",
        "fr": "Désolé, je n'ai pas reconnu un numéro valide. Quel est votre numéro de téléphone à 10 chiffres ?",
    },
    "retry_zip": {
        "en": "Sorry, I need a 5-digit ZIP code. What's the ZIP code where the work is needed?",
        "es": "Disculpe, necesito un código postal de 5 dígitos. ¿Cuál es el código postal donde se necesita el trabajo?",
        "zh": "抱歉，我需要一个5位数的邮政编码。请问需要施工的地址邮编是多少？",
        "tl": "Pasensya na po, kailangan ko ng 5-digit na ZIP code. Ano po ang ZIP code ng lugar na gagawan?",
        "vi": "Xin lỗi, tôi cần mã ZIP gồm 5 chữ số. Mã ZIP nơi cần thực hiện công việc là gì?",
        "ar": "عذرًا، أحتاج إلى رمز بريدي من 5 أرقام. ما الرمز البريدي لمكان العمل؟",
        "fr": "Désolé, il me faut un code postal (ZIP) à 5 chiffres. Quel est le code postal du lieu des travaux ?",
    },
    "retry_name": {
        "en": "Sorry — could you tell me your first and last name?",
        "es": "Disculpe, ¿podría decirme su nombre y apellido?",
        "zh": "抱歉，请问您的姓名是？",
        "tl": "Pasensya na po — ano po ang inyong pangalan at apelyido?",
        "vi": "Xin lỗi — bạn có thể cho tôi biết họ tên được không?",
        "ar": "عذرًا — هل يمكنك إخباري باسمك الأول واسم العائلة؟",
        "fr": "Désolé, pourriez-vous me donner votre prénom et votre nom ?",
    },
    "sms_disclosure": {
        "en": " (By sharing it, you agree we may text you about this request. Reply STOP anytime to opt out.)",
        "es": " (Al compartirlo, acepta que le enviemos mensajes de texto sobre esta solicitud. Responda STOP en cualquier momento para no recibir más.)",
        "zh": "（提供号码即表示您同意我们就此请求向您发送短信。随时回复STOP即可退订。）",
        "tl": " (Sa pagbibigay nito, pumapayag kayong i-text namin kayo tungkol sa request na ito. Mag-reply ng STOP anumang oras para huminto.)",
        "vi": " (Khi cung cấp số, bạn đồng ý để chúng tôi nhắn tin về yêu cầu này. Trả lời STOP bất cứ lúc nào để hủy.)",
        "ar": " (بمشاركته، توافق على أن نرسل إليك رسائل نصية بخصوص هذا الطلب. أرسل STOP في أي وقت لإيقافها.)",
        "fr": " (En le partageant, vous acceptez que nous vous envoyions des SMS au sujet de cette demande. Répondez STOP à tout moment pour vous désabonner.)",
    },
    "passed_to_team": {
        "en": "Thanks! I've passed your request to our team and someone will contact you shortly.",
        "es": "¡Gracias! Pasé su solicitud a nuestro equipo y alguien se comunicará con usted en breve.",
        "zh": "谢谢！我已将您的请求转给团队，很快会有人与您联系。",
        "tl": "Salamat po! Naipasa ko na ang inyong request sa aming team at may makikipag-ugnayan sa inyo agad.",
        "vi": "Cảm ơn bạn! Tôi đã chuyển yêu cầu đến đội ngũ và sẽ có người liên hệ bạn ngay.",
        "ar": "شكرًا! لقد أحلت طلبك إلى فريقنا وسيتواصل معك أحدهم قريبًا.",
        "fr": "Merci ! J'ai transmis votre demande à notre équipe et quelqu'un vous contactera sous peu.",
    },
    "out_of_area_done": {
        "en": "Thanks, {name}! I've shared your request with the team and they'll let you know if they can help.",
        "es": "¡Gracias, {name}! Compartí su solicitud con el equipo y le avisarán si pueden ayudarle.",
        "zh": "谢谢，{name}！我已把您的请求告知团队，他们会告诉您能否提供帮助。",
        "tl": "Salamat, {name}! Naibahagi ko na ang inyong request sa team at sasabihan nila kayo kung matutulungan nila kayo.",
        "vi": "Cảm ơn {name}! Tôi đã chuyển yêu cầu đến đội ngũ và họ sẽ báo cho bạn nếu có thể hỗ trợ.",
        "ar": "شكرًا يا {name}! شاركت طلبك مع الفريق وسيخبرونك إن كان بإمكانهم المساعدة.",
        "fr": "Merci, {name} ! J'ai transmis votre demande à l'équipe, qui vous dira si elle peut vous aider.",
    },
    "no_scheduling": {
        "en": "Thanks, {name}! I've passed your request to our team and someone will contact you shortly to schedule your {appt}.",
        "es": "¡Gracias, {name}! Pasé su solicitud a nuestro equipo y alguien le contactará en breve para programar su {appt}.",
        "zh": "谢谢，{name}！我已把您的请求转给团队，很快会有人联系您安排{appt}。",
        "tl": "Salamat, {name}! Naipasa ko na ang inyong request at may tatawag sa inyo para i-iskedyul ang inyong {appt}.",
        "vi": "Cảm ơn {name}! Tôi đã chuyển yêu cầu và sẽ có người liên hệ để sắp xếp {appt} cho bạn.",
        "ar": "شكرًا يا {name}! أحلت طلبك إلى فريقنا وسيتواصل معك أحدهم قريبًا لتحديد موعد {appt}.",
        "fr": "Merci, {name} ! J'ai transmis votre demande et quelqu'un vous contactera bientôt pour planifier votre {appt}.",
    },
    "calendar_down": {
        "en": "Thanks, {name} — I've saved your request, but I'm not able to check the schedule right now. I've let the team know and someone will contact you to confirm a time.",
        "es": "Gracias, {name}. Guardé su solicitud, pero en este momento no puedo consultar la agenda. Avisé al equipo y alguien le contactará para confirmar un horario.",
        "zh": "谢谢，{name}。我已保存您的请求，但目前无法查看日程。我已通知团队，会有人联系您确认时间。",
        "tl": "Salamat, {name} — na-save ko na ang inyong request, pero hindi ko po masilip ang iskedyul ngayon. Naabisuhan ko na ang team at may tatawag para kumpirmahin ang oras.",
        "vi": "Cảm ơn {name} — tôi đã lưu yêu cầu, nhưng hiện chưa thể kiểm tra lịch. Tôi đã báo đội ngũ và sẽ có người liên hệ để xác nhận thời gian.",
        "ar": "شكرًا يا {name} — حفظت طلبك، لكن لا يمكنني الاطلاع على الجدول الآن. أبلغت الفريق وسيتواصل معك أحدهم لتأكيد الموعد.",
        "fr": "Merci, {name}. J'ai enregistré votre demande, mais je ne peux pas consulter le planning pour le moment. L'équipe a été prévenue et vous contactera pour confirmer un horaire.",
    },
    "no_availability": {
        "en": "Thanks, {name} — I've saved your request. I don't see any open {appt} times in the next couple of weeks, so I've asked the team to reach out and find a time that works.",
        "es": "Gracias, {name}. Guardé su solicitud. No veo horarios disponibles para {appt} en las próximas semanas, así que pedí al equipo que le contacte para encontrar un horario.",
        "zh": "谢谢，{name}。我已保存您的请求。未来两周内没有可预约的{appt}时间，我已请团队联系您另行安排。",
        "tl": "Salamat, {name} — na-save ko na ang inyong request. Wala akong nakikitang bakanteng oras para sa {appt} sa susunod na dalawang linggo, kaya pinakiusapan ko ang team na tawagan kayo.",
        "vi": "Cảm ơn {name} — tôi đã lưu yêu cầu. Trong hai tuần tới chưa có giờ trống cho {appt}, nên tôi đã nhờ đội ngũ liên hệ để sắp xếp thời gian phù hợp.",
        "ar": "شكرًا يا {name} — حفظت طلبك. لا أرى مواعيد متاحة لـ{appt} خلال الأسبوعين القادمين، لذا طلبت من الفريق التواصل معك لإيجاد موعد مناسب.",
        "fr": "Merci, {name}. J'ai enregistré votre demande. Je ne vois aucun créneau pour {appt} dans les deux prochaines semaines ; j'ai demandé à l'équipe de vous contacter pour trouver un horaire.",
    },
    "retaken": {
        "en": "Sorry — that time was just taken. ",
        "es": "Lo siento, ese horario acaba de ocuparse. ",
        "zh": "抱歉，这个时间刚刚被预订了。",
        "tl": "Pasensya na po — may nakakuha na ng oras na iyon. ",
        "vi": "Xin lỗi — khung giờ đó vừa có người đặt. ",
        "ar": "عذرًا — تم حجز هذا الموعد للتو. ",
        "fr": "Désolé, ce créneau vient d'être réservé. ",
    },
    "no_pref_match": {
        "en": "I don't have openings at that time. ",
        "es": "No tengo horarios disponibles en ese momento. ",
        "zh": "该时间段没有空档。",
        "tl": "Wala po kaming bakante sa oras na iyon. ",
        "vi": "Không có khung giờ trống vào thời điểm đó. ",
        "ar": "لا توجد مواعيد متاحة في ذلك الوقت. ",
        "fr": "Je n'ai pas de disponibilité à ce moment-là. ",
    },
    "thanks_name": {
        "en": "Thanks, {name}! ",
        "es": "¡Gracias, {name}! ",
        "zh": "谢谢，{name}！",
        "tl": "Salamat, {name}! ",
        "vi": "Cảm ơn {name}! ",
        "ar": "شكرًا يا {name}! ",
        "fr": "Merci, {name} ! ",
    },
    "openings": {
        "en": "We currently have {appt} openings on {slots}",
        "es": "Tenemos horarios disponibles para {appt}: {slots}",
        "zh": "目前{appt}可预约的时间有：{slots}",
        "tl": "May bakante kami para sa {appt} sa {slots}",
        "vi": "Hiện có các khung giờ trống cho {appt}: {slots}",
        "ar": "لدينا مواعيد متاحة ({appt}): {slots}",
        "fr": "Voici nos disponibilités ({appt}) : {slots}",
    },
    "reschedule_openings": {
        "en": "Sure — to reschedule, we have {appt} openings on {slots}",
        "es": "Claro, para cambiar la cita tenemos estos horarios: {slots}",
        "zh": "好的，改约可选的时间有：{slots}",
        "tl": "Sige po — para sa paglipat ng iskedyul, may bakante kami sa {slots}",
        "vi": "Vâng — để đổi lịch, chúng tôi có các khung giờ: {slots}",
        "ar": "بالتأكيد — لتغيير الموعد، لدينا الأوقات التالية: {slots}",
        "fr": "Bien sûr, pour déplacer le rendez-vous, nous avons : {slots}",
    },
    "other_openings": {
        "en": "Here are some other openings: {slots}",
        "es": "Estos son otros horarios disponibles: {slots}",
        "zh": "其他可预约时间：{slots}",
        "tl": "Narito ang iba pang bakanteng oras: {slots}",
        "vi": "Đây là một số khung giờ khác: {slots}",
        "ar": "إليك مواعيد أخرى متاحة: {slots}",
        "fr": "Voici d'autres disponibilités : {slots}",
    },
    "and_for_appt": {
        "en": "And for your appointment, we have {slots}",
        "es": "Y para su cita, tenemos {slots}",
        "zh": "关于您的预约，可选时间有：{slots}",
        "tl": "At para sa inyong appointment, mayroon kaming {slots}",
        "vi": "Còn về lịch hẹn, chúng tôi có {slots}",
        "ar": "وبالنسبة لموعدك، لدينا {slots}",
        "fr": "Et pour votre rendez-vous, nous avons {slots}",
    },
    "another_day": {
        "en": "No problem. Would another day work better? Just tell me a day or time of day that suits you.",
        "es": "No hay problema. ¿Le funciona mejor otro día? Dígame qué día u hora le conviene.",
        "zh": "没问题。换一天可以吗？请告诉我您方便的日期或时段。",
        "tl": "Walang problema po. Mas okay ba ang ibang araw? Sabihin lang po kung anong araw o oras ang maginhawa sa inyo.",
        "vi": "Không sao. Ngày khác có tiện hơn không? Hãy cho tôi biết ngày hoặc buổi phù hợp với bạn.",
        "ar": "لا مشكلة. هل يناسبك يوم آخر؟ أخبرني باليوم أو الوقت الذي يناسبك.",
        "fr": "Pas de problème. Un autre jour vous conviendrait-il ? Indiquez-moi le jour ou le moment qui vous arrange.",
    },
    "which_time": {
        "en": "Just let me know which time works — {slots}",
        "es": "Dígame qué horario le conviene: {slots}",
        "zh": "请告诉我哪个时间适合您：{slots}",
        "tl": "Sabihin lang po kung anong oras ang okay — {slots}",
        "vi": "Bạn cho tôi biết giờ nào phù hợp nhé — {slots}",
        "ar": "أخبرني أي موعد يناسبك — {slots}",
        "fr": "Dites-moi quel créneau vous convient : {slots}",
    },
    "booked": {
        "en": "You're all set, {name}! Your {appt} is booked for {when}.",
        "es": "¡Listo, {name}! Su cita de {appt} quedó programada para el {when}.",
        "zh": "预约成功，{name}！您的{appt}已预约在{when}。",
        "tl": "Ayos na po, {name}! Naka-book na ang inyong {appt} sa {when}.",
        "vi": "Xong rồi, {name}! {appt_cap} của bạn đã được đặt vào {when}.",
        "ar": "تم كل شيء يا {name}! تم حجز موعد {appt} يوم {when}.",
        "fr": "C'est confirmé, {name} ! Votre rendez-vous ({appt}) est fixé au {when}.",
    },
    "texted": {
        "en": " I've also texted you a confirmation.",
        "es": " También le envié una confirmación por mensaje de texto.",
        "zh": "我也已通过短信向您发送了确认。",
        "tl": " Nag-text na rin ako sa inyo ng kumpirmasyon.",
        "vi": " Tôi cũng đã nhắn tin xác nhận cho bạn.",
        "ar": " أرسلت إليك أيضًا رسالة تأكيد نصية.",
        "fr": " Je vous ai aussi envoyé une confirmation par SMS.",
    },
    "anything_else": {
        "en": " Is there anything else I can help you with?",
        "es": " ¿Hay algo más en lo que pueda ayudarle?",
        "zh": "还有什么可以帮您的吗？",
        "tl": " May iba pa po ba akong maitutulong?",
        "vi": " Tôi có thể giúp gì thêm cho bạn không?",
        "ar": " هل هناك أي شيء آخر يمكنني مساعدتك به؟",
        "fr": " Puis-je vous aider pour autre chose ?",
    },
    "booking_failed": {
        "en": "I wasn't able to confirm that appointment yet. Let me connect you with the team.",
        "es": "Todavía no pude confirmar esa cita. Le comunico con el equipo.",
        "zh": "我暂时无法确认该预约。让我为您联系团队。",
        "tl": "Hindi ko pa po makumpirma ang appointment na iyon. Ikokonekta ko kayo sa team.",
        "vi": "Tôi chưa thể xác nhận lịch hẹn đó. Để tôi kết nối bạn với đội ngũ.",
        "ar": "لم أتمكن من تأكيد هذا الموعد بعد. دعني أوصلك بالفريق.",
        "fr": "Je n'ai pas encore pu confirmer ce rendez-vous. Je vous mets en relation avec l'équipe.",
    },
    "rescheduled": {
        "en": "Done — your appointment is now {when}.",
        "es": "Listo, su cita ahora es el {when}.",
        "zh": "已完成，您的预约已改至{when}。",
        "tl": "Tapos na po — ang inyong appointment ay sa {when} na.",
        "vi": "Xong — lịch hẹn của bạn đã đổi sang {when}.",
        "ar": "تم — أصبح موعدك {when}.",
        "fr": "C'est fait, votre rendez-vous est maintenant le {when}.",
    },
    "reschedule_failed": {
        "en": "I wasn't able to change that appointment yet. Let me connect you with the team.",
        "es": "Todavía no pude cambiar esa cita. Le comunico con el equipo.",
        "zh": "我暂时无法更改该预约。让我为您联系团队。",
        "tl": "Hindi ko pa po mapalitan ang appointment na iyon. Ikokonekta ko kayo sa team.",
        "vi": "Tôi chưa thể đổi lịch hẹn đó. Để tôi kết nối bạn với đội ngũ.",
        "ar": "لم أتمكن من تغيير هذا الموعد بعد. دعني أوصلك بالفريق.",
        "fr": "Je n'ai pas encore pu modifier ce rendez-vous. Je vous mets en relation avec l'équipe.",
    },
    "cancelled": {
        "en": "Your appointment has been cancelled. If you'd like to book another time, just let me know.",
        "es": "Su cita fue cancelada. Si desea programar otro horario, avíseme.",
        "zh": "您的预约已取消。如需另约时间，请告诉我。",
        "tl": "Nakansela na po ang inyong appointment. Kung gusto ninyong mag-book ng ibang oras, sabihan lang po ako.",
        "vi": "Lịch hẹn của bạn đã được hủy. Nếu muốn đặt giờ khác, hãy cho tôi biết.",
        "ar": "تم إلغاء موعدك. إذا رغبت في حجز وقت آخر، فقط أخبرني.",
        "fr": "Votre rendez-vous a été annulé. Si vous souhaitez réserver un autre créneau, dites-le-moi.",
    },
    "cancel_failed": {
        "en": "I wasn't able to cancel that appointment yet. Let me connect you with the team.",
        "es": "Todavía no pude cancelar esa cita. Le comunico con el equipo.",
        "zh": "我暂时无法取消该预约。让我为您联系团队。",
        "tl": "Hindi ko pa po makansela ang appointment na iyon. Ikokonekta ko kayo sa team.",
        "vi": "Tôi chưa thể hủy lịch hẹn đó. Để tôi kết nối bạn với đội ngũ.",
        "ar": "لم أتمكن من إلغاء هذا الموعد بعد. دعني أوصلك بالفريق.",
        "fr": "Je n'ai pas encore pu annuler ce rendez-vous. Je vous mets en relation avec l'équipe.",
    },
    "kept": {
        "en": "No problem — your appointment is still on the schedule.",
        "es": "No hay problema, su cita sigue programada.",
        "zh": "没问题，您的预约保持不变。",
        "tl": "Walang problema po — nasa iskedyul pa rin ang inyong appointment.",
        "vi": "Không sao — lịch hẹn của bạn vẫn giữ nguyên.",
        "ar": "لا مشكلة — موعدك لا يزال قائمًا.",
        "fr": "Pas de problème, votre rendez-vous est maintenu.",
    },
    "yes_or_no": {
        "en": "Please reply yes to cancel your appointment, or no to keep it.",
        "es": "Responda sí para cancelar su cita o no para mantenerla.",
        "zh": "请回复“是”取消预约，或回复“否”保留预约。",
        "tl": "Sumagot po ng oo para kanselahin, o hindi para panatilihin ang appointment.",
        "vi": "Vui lòng trả lời có để hủy lịch hẹn, hoặc không để giữ lại.",
        "ar": "يرجى الرد بنعم لإلغاء موعدك، أو لا للإبقاء عليه.",
        "fr": "Répondez oui pour annuler votre rendez-vous, ou non pour le conserver.",
    },
    "slots_many": {
        "en": "{list}, or {last}. Which works best?",
        "es": "{list} o {last}. ¿Cuál le conviene más?",
        "zh": "{list}，或{last}。哪个时间最适合您？",
        "tl": "{list}, o {last}. Alin po ang pinakamainam?",
        "vi": "{list}, hoặc {last}. Giờ nào phù hợp nhất với bạn?",
        "ar": "{list}، أو {last}. أيها يناسبك أكثر؟",
        "fr": "{list} ou {last}. Lequel vous convient le mieux ?",
    },
    "slots_one": {
        "en": "{only}. Does that work for you?",
        "es": "{only}. ¿Le funciona?",
        "zh": "{only}。这个时间可以吗？",
        "tl": "{only}. Ayos lang po ba iyon?",
        "vi": "{only}. Giờ đó có phù hợp không?",
        "ar": "{only}. هل يناسبك ذلك؟",
        "fr": "{only}. Cela vous convient-il ?",
    },
    "list_sep": {"en": ", ", "es": ", ", "zh": "、", "tl": ", ", "vi": ", ", "ar": "، ", "fr": ", "},
    "and": {"en": " and ", "es": " y ", "zh": "和", "tl": " at ", "vi": " và ", "ar": " و", "fr": " et "},
    "closed": {"en": "closed", "es": "cerrado", "zh": "休息", "tl": "sarado", "vi": "nghỉ", "ar": "مغلق", "fr": "fermé"},
    "there": {"en": "there", "es": "", "zh": "", "tl": "", "vi": "bạn", "ar": "", "fr": ""},
    "conf_sms": {
        "en": "{org}: your {appt} is confirmed for {when}. Reply here to reschedule. Reply STOP to opt out.",
        "es": "{org}: su {appt} está confirmada para el {when}. Responda aquí para cambiarla. Responda STOP para no recibir más mensajes.",
        "zh": "{org}：您的{appt}已确认于{when}。如需改约请回复此短信。回复STOP退订。",
        "tl": "{org}: Kumpirmado ang inyong {appt} sa {when}. Mag-reply dito para ilipat. Mag-reply ng STOP para huminto.",
        "vi": "{org}: {appt} của bạn đã được xác nhận vào {when}. Trả lời tin này để đổi lịch. Trả lời STOP để hủy nhận tin.",
        "ar": "{org}: تم تأكيد {appt} في {when}. رد هنا لتغيير الموعد. أرسل STOP لإيقاف الرسائل.",
        "fr": "{org} : votre {appt} est confirmé(e) pour le {when}. Répondez ici pour le déplacer. Répondez STOP pour vous désabonner.",
    },
    "greeting_default": {
        "en": "Hi, thanks for contacting {org}! I'm {agent}. How can I help you today?",
        "es": "¡Hola, gracias por comunicarse con {org}! Soy {agent}. ¿En qué le puedo ayudar hoy?",
        "zh": "您好，感谢您联系{org}！我是{agent}。今天有什么可以帮您的吗？",
        "tl": "Hello po, salamat sa pakikipag-ugnayan sa {org}! Ako si {agent}. Ano po ang maitutulong ko ngayon?",
        "vi": "Xin chào, cảm ơn bạn đã liên hệ {org}! Tôi là {agent}. Hôm nay tôi có thể giúp gì cho bạn?",
        "ar": "مرحبًا، شكرًا لتواصلك مع {org}! أنا {agent}. كيف يمكنني مساعدتك اليوم؟",
        "fr": "Bonjour, merci d'avoir contacté {org} ! Je suis {agent}. Comment puis-je vous aider aujourd'hui ?",
    },
    # ---- voice
    "voice_disclosure": {
        "en": "Hi, thanks for calling {org}. You're speaking with {agent}, an AI assistant.",
        "es": "Hola, gracias por llamar a {org}. Habla con {agent}, un asistente de inteligencia artificial.",
        "zh": "您好，感谢致电{org}。我是人工智能助理{agent}。",
        "tl": "Hello po, salamat sa pagtawag sa {org}. Kausap ninyo si {agent}, isang AI assistant.",
        "vi": "Xin chào, cảm ơn bạn đã gọi đến {org}. Bạn đang nói chuyện với {agent}, trợ lý AI.",
        "ar": "مرحبًا، شكرًا لاتصالك بـ{org}. أنت تتحدث مع {agent}، مساعد ذكاء اصطناعي.",
        "fr": "Bonjour, merci d'avoir appelé {org}. Vous parlez avec {agent}, un assistant d'intelligence artificielle.",
    },
    "voice_recorded": {
        "en": " This call is recorded for quality purposes.",
        "es": " Esta llamada se graba con fines de calidad.",
        "zh": "本次通话将被录音以保证服务质量。",
        "tl": " Nire-record ang tawag na ito para sa kalidad ng serbisyo.",
        "vi": " Cuộc gọi này được ghi âm để đảm bảo chất lượng.",
        "ar": " يتم تسجيل هذه المكالمة لأغراض الجودة.",
        "fr": " Cet appel est enregistré à des fins de qualité.",
    },
    "voice_how_help": {
        "en": " How can I help you today?",
        "es": " ¿En qué le puedo ayudar hoy?",
        "zh": "今天有什么可以帮您的吗？",
        "tl": " Ano po ang maitutulong ko ngayon?",
        "vi": " Hôm nay tôi có thể giúp gì cho bạn?",
        "ar": " كيف يمكنني مساعدتك اليوم؟",
        "fr": " Comment puis-je vous aider aujourd'hui ?",
    },
    "voice_menu": {
        "en": "For English, press {n}.",
        "es": "Para español, oprima {n}.",
        "zh": "中文服务请按{n}。",
        "tl": "Para sa Tagalog, pindutin ang {n}.",
        "vi": "Tiếng Việt, xin bấm phím {n}.",
        "ar": "للعربية، اضغط {n}.",
        "fr": "Pour le français, appuyez sur {n}.",
    },
    "voice_silence": {
        "en": "Sorry, I didn't hear anything. How can I help you?",
        "es": "Disculpe, no escuché nada. ¿En qué le puedo ayudar?",
        "zh": "抱歉，我没有听到声音。有什么可以帮您的吗？",
        "tl": "Pasensya na po, wala akong narinig. Ano po ang maitutulong ko?",
        "vi": "Xin lỗi, tôi không nghe thấy gì. Tôi có thể giúp gì cho bạn?",
        "ar": "عذرًا، لم أسمع شيئًا. كيف يمكنني مساعدتك؟",
        "fr": "Désolé, je n'ai rien entendu. Comment puis-je vous aider ?",
    },
    "voice_silence_bye": {
        "en": "I'm not hearing anything, so I'll let our team know to call you back. Goodbye.",
        "es": "No escucho nada, así que pediré a nuestro equipo que le devuelva la llamada. Adiós.",
        "zh": "我听不到声音，会请团队给您回电。再见。",
        "tl": "Wala po akong naririnig, kaya sasabihan ko ang team na tawagan kayo ulit. Paalam po.",
        "vi": "Tôi không nghe thấy gì, nên tôi sẽ nhờ đội ngũ gọi lại cho bạn. Tạm biệt.",
        "ar": "لا أسمع شيئًا، لذا سأطلب من فريقنا معاودة الاتصال بك. مع السلامة.",
        "fr": "Je n'entends rien, je vais demander à notre équipe de vous rappeler. Au revoir.",
    },
    "voice_unclear": {
        "en": "Sorry, I didn't quite catch that. Could you say it again?",
        "es": "Disculpe, no le entendí bien. ¿Podría repetirlo?",
        "zh": "抱歉，我没有听清。您能再说一遍吗？",
        "tl": "Pasensya na po, hindi ko masyadong narinig. Puwede pong pakiulit?",
        "vi": "Xin lỗi, tôi chưa nghe rõ. Bạn nói lại được không?",
        "ar": "عذرًا، لم أفهم جيدًا. هل يمكنك التكرار؟",
        "fr": "Désolé, je n'ai pas bien saisi. Pourriez-vous répéter ?",
    },
    "voice_unclear_bye": {
        "en": "I'm having trouble hearing you, so I'll have our team call you back shortly. Goodbye.",
        "es": "Tengo dificultades para escucharle, así que nuestro equipo le devolverá la llamada en breve. Adiós.",
        "zh": "我听不太清楚，会请团队尽快给您回电。再见。",
        "tl": "Nahihirapan po akong marinig kayo, kaya tatawagan kayo ng team sa lalong madaling panahon. Paalam po.",
        "vi": "Tôi khó nghe được bạn, nên đội ngũ sẽ gọi lại cho bạn sớm. Tạm biệt.",
        "ar": "أجد صعوبة في سماعك، لذا سيعاود فريقنا الاتصال بك قريبًا. مع السلامة.",
        "fr": "J'ai du mal à vous entendre, notre équipe vous rappellera rapidement. Au revoir.",
    },
    "voice_unclear_transfer": {
        "en": "I'm having trouble hearing you. Let me connect you with someone on our team.",
        "es": "Tengo dificultades para escucharle. Le comunico con alguien de nuestro equipo.",
        "zh": "我听不太清楚。让我为您转接团队成员。",
        "tl": "Nahihirapan po akong marinig kayo. Ikokonekta ko kayo sa isang kasama namin.",
        "vi": "Tôi khó nghe được bạn. Để tôi kết nối bạn với người trong đội ngũ.",
        "ar": "أجد صعوبة في سماعك. دعني أوصلك بأحد أعضاء فريقنا.",
        "fr": "J'ai du mal à vous entendre. Je vous mets en relation avec un membre de notre équipe.",
    },
    "voice_goodbye": {
        "en": "Thanks for calling {org}. Goodbye!",
        "es": "Gracias por llamar a {org}. ¡Adiós!",
        "zh": "感谢致电{org}。再见！",
        "tl": "Salamat sa pagtawag sa {org}. Paalam po!",
        "vi": "Cảm ơn bạn đã gọi đến {org}. Tạm biệt!",
        "ar": "شكرًا لاتصالك بـ{org}. مع السلامة!",
        "fr": "Merci d'avoir appelé {org}. Au revoir !",
    },
    "voice_thanks_bye": {
        "en": " Thank you for calling. Goodbye.",
        "es": " Gracias por llamar. Adiós.",
        "zh": "感谢您的来电。再见。",
        "tl": " Salamat po sa pagtawag. Paalam.",
        "vi": " Cảm ơn bạn đã gọi. Tạm biệt.",
        "ar": " شكرًا لاتصالك. مع السلامة.",
        "fr": " Merci de votre appel. Au revoir.",
    },
    "voice_no_one": {
        "en": "Sorry, no one was available. We have your details and the team will call you back shortly.",
        "es": "Lo siento, no hay nadie disponible. Tenemos sus datos y el equipo le devolverá la llamada en breve.",
        "zh": "抱歉，目前没有人接听。我们已记录您的信息，团队会尽快回电。",
        "tl": "Pasensya na po, walang available ngayon. Nasa amin ang inyong detalye at tatawagan kayo ng team agad.",
        "vi": "Xin lỗi, hiện không có ai trực máy. Chúng tôi đã có thông tin của bạn và sẽ gọi lại sớm.",
        "ar": "عذرًا، لا يوجد أحد متاح حاليًا. لدينا بياناتك وسيعاود الفريق الاتصال بك قريبًا.",
        "fr": "Désolé, personne n'est disponible. Nous avons vos coordonnées et l'équipe vous rappellera rapidement.",
    },
}

# Appointment labels per Industry Pack label (English key → localized noun). "_a" variants carry the article where the
# language needs one in the "help you set up X" sentence.
APPT: dict[str, dict[str, str]] = {
    "inspection": {"en": "inspection", "es": "inspección", "zh": "上门检查", "tl": "inspeksyon", "vi": "buổi kiểm tra", "ar": "الفحص", "fr": "inspection"},
    "service visit": {
        "en": "service visit",
        "es": "visita de servicio",
        "zh": "上门服务",
        "tl": "service visit",
        "vi": "buổi sửa chữa tại nhà",
        "ar": "زيارة الخدمة",
        "fr": "intervention",
    },
    "consultation": {"en": "consultation", "es": "consulta", "zh": "咨询", "tl": "konsultasyon", "vi": "buổi tư vấn", "ar": "الاستشارة", "fr": "consultation"},
    "estimate": {"en": "estimate", "es": "cotización", "zh": "报价评估", "tl": "estimate", "vi": "buổi báo giá", "ar": "التقدير", "fr": "devis"},
    "walkthrough": {
        "en": "walkthrough",
        "es": "visita de evaluación",
        "zh": "现场查看",
        "tl": "walkthrough",
        "vi": "buổi khảo sát",
        "ar": "المعاينة",
        "fr": "visite",
    },
    "appointment": {"en": "appointment", "es": "cita", "zh": "预约", "tl": "appointment", "vi": "lịch hẹn", "ar": "الموعد", "fr": "rendez-vous"},
}
_ARTICLE = {
    "es": {
        "inspección": "una inspección",
        "visita de servicio": "una visita de servicio",
        "consulta": "una consulta",
        "cotización": "una cotización",
        "visita de evaluación": "una visita de evaluación",
        "cita": "una cita",
    },
    "fr": {
        "inspection": "une inspection",
        "intervention": "une intervention",
        "consultation": "une consultation",
        "devis": "un devis",
        "visite": "une visite",
        "rendez-vous": "un rendez-vous",
    },
}

# ---------------------------------------------------------------------------------------------- field prompts

FIELD_PROMPTS: dict[str, dict[str, str]] = {
    "service_requested": {
        "en": "What can we help you with? A short description of the project or problem is perfect.",
        "es": "¿En qué le podemos ayudar? Una breve descripción del proyecto o problema es suficiente.",
        "zh": "请问需要我们帮什么忙？简单描述一下项目或问题就可以。",
        "tl": "Ano po ang maitutulong namin? Sapat na ang maikling paglalarawan ng proyekto o problema.",
        "vi": "Chúng tôi có thể giúp gì cho bạn? Chỉ cần mô tả ngắn gọn công việc hoặc vấn đề.",
        "ar": "بماذا يمكننا مساعدتك؟ يكفي وصف مختصر للمشروع أو المشكلة.",
        "fr": "Comment pouvons-nous vous aider ? Une courte description du projet ou du problème suffit.",
    },
    "roofing.service_requested": {
        "en": "Are you looking for a roof repair, a full replacement, or an inspection?",
        "es": "¿Necesita una reparación del techo, un reemplazo completo o una inspección?",
        "zh": "您需要屋顶维修、整体更换，还是检查？",
        "tl": "Kailangan n'yo po ba ng pagkukumpuni ng bubong, buong pagpapalit, o inspeksyon?",
        "vi": "Bạn cần sửa mái nhà, thay toàn bộ mái hay kiểm tra?",
        "ar": "هل تحتاج إلى إصلاح السقف، أم استبداله بالكامل، أم فحصه؟",
        "fr": "Avez-vous besoin d'une réparation de toiture, d'un remplacement complet ou d'une inspection ?",
    },
    "hvac.service_requested": {
        "en": "Is this for a repair, routine maintenance, or a replacement estimate?",
        "es": "¿Es para una reparación, mantenimiento de rutina o una cotización de reemplazo?",
        "zh": "是需要维修、例行保养，还是更换报价？",
        "tl": "Para po ba ito sa pagkukumpuni, regular na maintenance, o estimate para sa pagpapalit?",
        "vi": "Bạn cần sửa chữa, bảo trì định kỳ hay báo giá thay mới?",
        "ar": "هل هذا لإصلاح، أم صيانة دورية، أم تقدير لاستبدال الجهاز؟",
        "fr": "Est-ce pour une réparation, un entretien de routine ou un devis de remplacement ?",
    },
    "plumbing.service_requested": {
        "en": "What's going on with the plumbing? For example a leak, a clogged drain, or a water heater issue.",
        "es": "¿Qué problema tiene con la plomería? Por ejemplo, una fuga, un desagüe tapado o un problema con el calentador de agua.",
        "zh": "水管出了什么问题？例如漏水、下水道堵塞或热水器故障。",
        "tl": "Ano po ang problema sa tubero? Halimbawa, tagas, baradong drain, o problema sa water heater.",
        "vi": "Hệ thống ống nước gặp vấn đề gì? Ví dụ rò rỉ, tắc cống hoặc lỗi máy nước nóng.",
        "ar": "ما مشكلة السباكة لديك؟ مثل تسرب، أو انسداد في المصرف، أو مشكلة في سخان المياه.",
        "fr": "Quel est le problème de plomberie ? Par exemple une fuite, un drain bouché ou un chauffe-eau en panne.",
    },
    "remodeling.service_requested": {
        "en": "What kind of project are you planning — for example a kitchen, bathroom, basement or addition?",
        "es": "¿Qué tipo de proyecto está planeando? Por ejemplo cocina, baño, sótano o ampliación.",
        "zh": "您计划做什么类型的项目？例如厨房、浴室、地下室或加建。",
        "tl": "Anong klaseng proyekto po ang plano ninyo — halimbawa kusina, banyo, basement, o dagdag na kuwarto?",
        "vi": "Bạn dự định làm hạng mục nào — ví dụ bếp, phòng tắm, tầng hầm hay xây thêm?",
        "ar": "ما نوع المشروع الذي تخطط له — مثل المطبخ أو الحمام أو القبو أو توسعة؟",
        "fr": "Quel type de projet envisagez-vous ? Par exemple cuisine, salle de bain, sous-sol ou agrandissement.",
    },
    "property_type": {
        "en": "Is this for a home or a commercial property?",
        "es": "¿Es para una vivienda o una propiedad comercial?",
        "zh": "是住宅还是商业物业？",
        "tl": "Para po ba ito sa bahay o sa commercial na property?",
        "vi": "Đây là nhà ở hay cơ sở kinh doanh?",
        "ar": "هل هذا لمنزل أم لعقار تجاري؟",
        "fr": "S'agit-il d'une maison ou d'un local commercial ?",
    },
    "zip": {
        "en": "What's the ZIP code where the work is needed?",
        "es": "¿Cuál es el código postal donde se necesita el trabajo?",
        "zh": "需要施工地址的邮政编码是多少？",
        "tl": "Ano po ang ZIP code ng lugar na gagawan?",
        "vi": "Mã ZIP nơi cần thực hiện công việc là gì?",
        "ar": "ما الرمز البريدي لمكان العمل؟",
        "fr": "Quel est le code postal (ZIP) du lieu des travaux ?",
    },
    "urgency": {
        "en": "How urgent is this — is it an emergency, something you'd like handled in the next few days, or are you flexible?",
        "es": "¿Qué tan urgente es? ¿Es una emergencia, algo para los próximos días, o tiene flexibilidad?",
        "zh": "有多紧急？是紧急情况、希望近几天处理，还是时间比较灵活？",
        "tl": "Gaano po ito kaapura — emergency ba, sa susunod na ilang araw, o flexible kayo?",
        "vi": "Mức độ gấp như thế nào — khẩn cấp, cần xử lý trong vài ngày tới, hay bạn linh hoạt về thời gian?",
        "ar": "ما مدى الاستعجال — هل هي حالة طارئة، أم خلال الأيام القليلة القادمة، أم أن وقتك مرن؟",
        "fr": "Est-ce urgent : une urgence, dans les prochains jours, ou êtes-vous flexible ?",
    },
    "name": {
        "en": "Great. What's your full name?",
        "es": "Perfecto. ¿Cuál es su nombre completo?",
        "zh": "好的。请问您的全名是？",
        "tl": "Sige po. Ano po ang buong pangalan ninyo?",
        "vi": "Tốt quá. Họ tên đầy đủ của bạn là gì?",
        "ar": "ممتاز. ما اسمك الكامل؟",
        "fr": "Parfait. Quel est votre nom complet ?",
    },
    "phone": {
        "en": "And the best phone number to reach you?",
        "es": "¿Y el mejor número de teléfono para comunicarnos con usted?",
        "zh": "请问联系您的最佳电话号码是多少？",
        "tl": "At ano po ang pinakamagandang numero para matawagan kayo?",
        "vi": "Và số điện thoại tốt nhất để liên lạc với bạn?",
        "ar": "وما أفضل رقم هاتف للتواصل معك؟",
        "fr": "Et le meilleur numéro pour vous joindre ?",
    },
    "email": {
        "en": "What's your email address?",
        "es": "¿Cuál es su correo electrónico?",
        "zh": "请问您的电子邮箱是？",
        "tl": "Ano po ang inyong email address?",
        "vi": "Địa chỉ email của bạn là gì?",
        "ar": "ما بريدك الإلكتروني؟",
        "fr": "Quelle est votre adresse e-mail ?",
    },
    "system": {
        "en": "Is this about heating or cooling?",
        "es": "¿Es sobre calefacción o aire acondicionado?",
        "zh": "是供暖还是制冷的问题？",
        "tl": "Tungkol po ba ito sa heating o sa aircon?",
        "vi": "Vấn đề về sưởi ấm hay làm mát?",
        "ar": "هل يتعلق الأمر بالتدفئة أم التبريد؟",
        "fr": "Est-ce pour le chauffage ou la climatisation ?",
    },
    "timeline": {
        "en": "When would you ideally like the project to start?",
        "es": "¿Cuándo le gustaría comenzar el proyecto?",
        "zh": "您希望项目什么时候开始？",
        "tl": "Kailan po ninyo gustong magsimula ang proyekto?",
        "vi": "Bạn muốn bắt đầu dự án khi nào?",
        "ar": "متى تود أن يبدأ المشروع؟",
        "fr": "Quand souhaiteriez-vous que le projet commence ?",
    },
    "insurance_claim": {
        "en": "Have you filed, or do you plan to file, an insurance claim?",
        "es": "¿Ha presentado o piensa presentar un reclamo al seguro?",
        "zh": "您是否已提出或计划提出保险理赔？",
        "tl": "Nakapag-file na po ba kayo, o balak mag-file, ng insurance claim?",
        "vi": "Bạn đã hoặc dự định nộp yêu cầu bồi thường bảo hiểm chưa?",
        "ar": "هل قدمت أو تنوي تقديم مطالبة تأمين؟",
        "fr": "Avez-vous déclaré, ou comptez-vous déclarer, un sinistre à votre assurance ?",
    },
    "roof_age": {
        "en": "Roughly how old is the roof?",
        "es": "¿Aproximadamente cuántos años tiene el techo?",
        "zh": "屋顶大约用了多少年？",
        "tl": "Mga ilang taon na po ang bubong?",
        "vi": "Mái nhà khoảng bao nhiêu năm tuổi?",
        "ar": "كم عمر السقف تقريبًا؟",
        "fr": "Quel âge a la toiture, environ ?",
    },
    "budget_range": {
        "en": "Do you have a budget range in mind?",
        "es": "¿Tiene un rango de presupuesto en mente?",
        "zh": "您有大概的预算范围吗？",
        "tl": "May budget range po ba kayo?",
        "vi": "Bạn đã có mức ngân sách dự kiến chưa?",
        "ar": "هل لديك نطاق ميزانية في ذهنك؟",
        "fr": "Avez-vous une fourchette de budget en tête ?",
    },
}
GENERIC_FIELD = {
    "en": "Could you share the {label}?",
    "es": "¿Podría indicarme: {label}?",
    "zh": "请提供：{label}。",
    "tl": "Puwede po bang ibigay ang {label}?",
    "vi": "Bạn có thể cho biết {label} không?",
    "ar": "هل يمكنك إخباري بـ: {label}؟",
    "fr": "Pourriez-vous m'indiquer : {label} ?",
}

# ---------------------------------------------------------------------------------------------- multilingual understanding

# Keywords that map an answer in each language onto a pack field's canonical option. Applies to every pack that has the field.
FIELD_KEYWORDS: dict[str, dict[str, list[str]]] = {
    "property_type": {
        "residential": [
            "casa",
            "vivienda",
            "hogar",
            "residencial",
            "mi casa",
            "apartamento",
            "住宅",
            "家",
            "公寓",
            "我家",
            "bahay",
            "residential",
            "nhà",
            "nhà ở",
            "căn hộ",
            "منزل",
            "بيت",
            "سكني",
            "شقة",
            "maison",
            "résidentiel",
            "résidence",
            "appartement",
            "logement",
        ],
        "commercial": [
            "comercial",
            "negocio",
            "oficina",
            "tienda",
            "商业",
            "公司",
            "店",
            "办公室",
            "商铺",
            "negosyo",
            "opisina",
            "tindahan",
            "kinh doanh",
            "văn phòng",
            "cửa hàng",
            "công ty",
            "تجاري",
            "مكتب",
            "متجر",
            "شركة",
            "commercial",
            "commerce",
            "bureau",
            "magasin",
            "entreprise",
        ],
    },
    "urgency": {
        "emergency": [
            "emergencia",
            "urgente",
            "ya mismo",
            "ahora mismo",
            "紧急",
            "马上",
            "立刻",
            "急",
            "emergency",
            "agad",
            "ngayon na",
            "madalian",
            "khẩn cấp",
            "gấp",
            "ngay",
            "طارئ",
            "طوارئ",
            "عاجل",
            "فورًا",
            "حالا",
            "urgence",
            "urgent",
            "tout de suite",
            "immédiatement",
        ],
        "soon": [
            "gotera",
            "gotea",
            "tormenta",
            "漏水",
            "暴风",
            "暴雨",
            "冰雹",
            "tagas",
            "tumutulo",
            "bagyo",
            "dột",
            "bão",
            "mưa đá",
            "تسرب",
            "يسرب",
            "عاصفة",
            "fuite",
            "fuit",
            "orage",
            "tempête",
            "grêle",
            "pronto",
            "esta semana",
            "próximos días",
            "proximos dias",
            "en unos días",
            "mañana",
            "这周",
            "本周",
            "几天内",
            "尽快",
            "明天",
            "sa susunod na araw",
            "ngayong linggo",
            "bukas",
            "sa lalong madaling panahon",
            "vài ngày tới",
            "tuần này",
            "sớm",
            "ngày mai",
            "قريبًا",
            "هذا الأسبوع",
            "خلال أيام",
            "غدًا",
            "bientôt",
            "cette semaine",
            "prochains jours",
            "demain",
            "rapidement",
        ],
        "flexible": [
            "flexible",
            "sin prisa",
            "cuando sea",
            "no es urgente",
            "不急",
            "灵活",
            "随时",
            "都可以",
            "hindi apurahan",
            "kahit kailan",
            "flexible lang",
            "không gấp",
            "linh hoạt",
            "lúc nào cũng được",
            "مرن",
            "غير مستعجل",
            "ليس عاجلا",
            "أي وقت",
            "pas pressé",
            "pas urgent",
            "quand vous voulez",
        ],
    },
    "service_requested": {
        # roofing / hvac / plumbing option values
        "repair": [
            "reparación",
            "reparacion",
            "reparar",
            "arreglar",
            "gotera",
            "gotea",
            "fuga",
            "no enfría",
            "no calienta",
            "维修",
            "修理",
            "修",
            "漏水",
            "漏",
            "坏了",
            "ayusin",
            "kumpunihin",
            "tumutulo",
            "tulo",
            "sira",
            "sửa",
            "sửa chữa",
            "dột",
            "rò",
            "hỏng",
            "إصلاح",
            "تسرب",
            "تصليح",
            "يسرب",
            "معطل",
            "réparation",
            "réparer",
            "fuite",
            "fuit",
            "en panne",
            "tagas",
            "may tagas",
            "ne refroidit pas",
            "ne chauffe pas",
        ],
        "replacement": [
            "reemplazo",
            "reemplazar",
            "techo nuevo",
            "cambiar el techo",
            "nuevo sistema",
            "更换",
            "换新",
            "新屋顶",
            "palitan",
            "bagong bubong",
            "pagpapalit",
            "thay mới",
            "thay toàn bộ",
            "mái mới",
            "استبدال",
            "سقف جديد",
            "تغيير",
            "remplacement",
            "remplacer",
            "nouveau toit",
            "nouvelle toiture",
        ],
        "inspection": [
            "inspeccionar",
            "inspeccionarlo",
            "inspeccione",
            "inspecter",
            "inspectez",
            "ipa-inspeksyon",
            "ipainspeksyon",
            "inspección",
            "inspeccion",
            "revisar",
            "revisión",
            "检查",
            "查看",
            "inspeksyon",
            "tingnan",
            "kiểm tra",
            "فحص",
            "معاينة",
            "inspection",
            "vérifier",
            "contrôle",
        ],
        "maintenance": ["mantenimiento", "afinación", "保养", "维护", "maintenance", "linis", "bảo trì", "bảo dưỡng", "صيانة", "entretien", "révision"],
    },
    "system": {
        "cooling": [
            "aire acondicionado",
            "enfriar",
            "no enfría",
            "frío",
            "aire",
            "冷气",
            "空调",
            "制冷",
            "aircon",
            "malamig",
            "máy lạnh",
            "làm mát",
            "điều hòa",
            "تكييف",
            "تبريد",
            "مكيف",
            "climatisation",
            "clim",
            "refroidit",
            "froid",
        ],
        "heating": [
            "calefacción",
            "calefaccion",
            "calentador",
            "no calienta",
            "供暖",
            "暖气",
            "取暖",
            "heater",
            "mainit",
            "sưởi",
            "lò sưởi",
            "تدفئة",
            "سخان",
            "دفاية",
            "chauffage",
            "chaudière",
            "ne chauffe pas",
        ],
    },
    "timeline": {
        "asap": [
            "lo antes posible",
            "cuanto antes",
            "ya",
            "尽快",
            "马上",
            "agad",
            "sa lalong madaling panahon",
            "càng sớm càng tốt",
            "ngay",
            "في أقرب وقت",
            "حالا",
            "dès que possible",
            "au plus vite",
        ],
        "1_3_months": [
            "próximo mes",
            "en un par de meses",
            "unos meses",
            "下个月",
            "几个月",
            "susunod na buwan",
            "ilang buwan",
            "tháng sau",
            "vài tháng",
            "الشهر القادم",
            "بضعة أشهر",
            "le mois prochain",
            "dans quelques mois",
        ],
        "3_plus_months": [
            "el próximo año",
            "solo planeando",
            "明年",
            "只是计划",
            "susunod na taon",
            "nagpaplano pa lang",
            "năm sau",
            "đang lên kế hoạch",
            "العام القادم",
            "مجرد تخطيط",
            "l'année prochaine",
            "je planifie seulement",
        ],
    },
}
BOOL_TRUE: dict[str, list[str]] = {
    "active_leak": [
        "gotea",
        "gotera",
        "fuga",
        "goteando",
        "漏水",
        "漏",
        "tumutulo",
        "tulo",
        "tagas",
        "fuit",
        "dột",
        "rò",
        "nhỏ giọt",
        "تسرب",
        "يسرب",
        "fuite",
        "goutte",
        "infiltration",
    ],
    "storm_damage": [
        "tormenta",
        "granizo",
        "viento",
        "huracán",
        "暴风",
        "暴雨",
        "冰雹",
        "台风",
        "bagyo",
        "unos",
        "bão",
        "mưa đá",
        "عاصفة",
        "برد",
        "إعصار",
        "tempête",
        "grêle",
        "orage",
    ],
}
BOOKING: dict[str, list[str]] = {
    "es": [
        "cita",
        "programar",
        "agendar",
        "venir",
        "visita",
        "inspeccionar",
        "inspeccionarlo",
        "inspección",
        "inspeccion",
        "reparación",
        "reparacion",
        "arreglar",
        "techo",
        "gotera",
        "fuga",
        "aire acondicionado",
        "calefacción",
        "plomero",
        "necesito",
        "presupuesto",
        "cotización",
        "remodelar",
        "cocina",
        "baño",
    ],
    "zh": ["预约", "上门", "安排", "维修", "修理", "检查", "屋顶", "漏水", "空调", "暖气", "水管", "报价", "装修", "厨房", "浴室", "需要"],
    "tl": [
        "appointment",
        "iskedyul",
        "pumunta",
        "bisita",
        "tagas",
        "ipa-inspeksyon",
        "ayusin",
        "kumpunihin",
        "bubong",
        "tumutulo",
        "aircon",
        "tubero",
        "kailangan",
        "inspeksyon",
        "kusina",
        "banyo",
    ],
    "vi": ["đặt lịch", "lịch hẹn", "đến", "sửa", "sửa chữa", "kiểm tra", "mái", "dột", "máy lạnh", "sưởi", "ống nước", "báo giá", "cần", "bếp", "phòng tắm"],
    "ar": ["موعد", "حجز", "زيارة", "إصلاح", "فحص", "سقف", "تسرب", "تكييف", "تدفئة", "سباك", "أحتاج", "عرض سعر", "مطبخ", "حمام", "تجديد"],
    "fr": [
        "rendez-vous",
        "planifier",
        "venir",
        "visite",
        "réparation",
        "réparer",
        "inspecter",
        "inspection",
        "fuit",
        "toit",
        "toiture",
        "fuite",
        "climatisation",
        "chauffage",
        "plombier",
        "besoin",
        "devis",
        "rénover",
        "cuisine",
        "salle de bain",
    ],
}
HUMAN: dict[str, list[str]] = {
    "es": ["hablar con alguien", "hablar con una persona", "una persona real", "un humano", "con un agente", "con el dueño", "con un gerente", "representante"],
    "zh": ["人工", "真人", "转人工", "找人", "跟人说", "客服", "经理", "老板"],
    "tl": ["kausapin ang tao", "makausap ang tao", "totoong tao", "tao po", "may-ari", "manager", "ahente"],
    "vi": ["nói chuyện với người", "gặp người", "nhân viên", "người thật", "quản lý", "chủ"],
    "ar": ["التحدث مع شخص", "شخص حقيقي", "موظف", "مدير", "إنسان", "ممثل خدمة"],
    "fr": ["parler à quelqu'un", "parler à une personne", "une vraie personne", "un humain", "un conseiller", "le responsable", "le gérant"],
}
COMPLAINT: dict[str, list[str]] = {
    "es": ["queja", "reembolso", "terrible", "pésimo", "inaceptable", "abogado", "demanda", "estafa"],
    "zh": ["投诉", "退款", "太差", "骗子", "律师", "起诉", "不可接受"],
    "tl": ["reklamo", "refund", "ibalik ang pera", "manloloko", "abogado", "idedemanda"],
    "vi": ["khiếu nại", "hoàn tiền", "tệ", "lừa đảo", "luật sư", "kiện"],
    "ar": ["شكوى", "استرداد", "سيء جدا", "احتيال", "محامي", "مقاضاة", "غير مقبول"],
    "fr": ["plainte", "remboursement", "inacceptable", "arnaque", "avocat", "poursuivre", "nul"],
}
EMERGENCY: dict[str, list[str]] = {
    "es": ["fuga de gas", "huele a gas", "olor a gas", "huele gas", "incendio", "fuego", "humo", "chispas", "inundación", "inundando", "monóxido"],
    "zh": ["煤气泄漏", "燃气泄漏", "闻到煤气", "煤气味", "燃气味", "天然气味", "着火", "火灾", "冒烟", "火花", "淹水", "一氧化碳"],
    "tl": ["tagas ng gas", "amoy gas", "sunog", "usok", "kislap", "baha", "binabaha"],
    "vi": ["rò rỉ gas", "mùi gas", "cháy", "khói", "tia lửa", "ngập", "khí co"],
    "ar": ["تسرب غاز", "رائحة غاز", "حريق", "دخان", "شرارة", "فيضان", "أول أكسيد الكربون"],
    "fr": ["fuite de gaz", "odeur de gaz", "sent le gaz", "ça sent le gaz", "incendie", "feu", "fumée", "étincelles", "inondation", "monoxyde"],
}
GAS = {
    "fuga de gas",
    "huele a gas",
    "olor a gas",
    "huele gas",
    "煤气味",
    "燃气味",
    "天然气味",
    "sent le gaz",
    "ça sent le gaz",
    "煤气泄漏",
    "燃气泄漏",
    "闻到煤气",
    "tagas ng gas",
    "amoy gas",
    "rò rỉ gas",
    "mùi gas",
    "تسرب غاز",
    "رائحة غاز",
    "fuite de gaz",
    "odeur de gaz",
    "monóxido",
    "一氧化碳",
    "khí co",
    "أول أكسيد الكربون",
    "monoxyde",
}
# Safety: emergency phrases are checked in every language, whatever language the conversation is in.
EMERGENCY_ALL: list[str] = sorted({p for phrases in EMERGENCY.values() for p in phrases}, key=len, reverse=True)

NOT_NAME_ALL = {
    "casa",
    "techo",
    "sí",
    "si",
    "no",
    "gracias",
    "hola",
    "urgente",
    "pronto",
    "mañana",
    "hoy",
    "comercial",
    "residencial",
    "oui",
    "non",
    "merci",
    "bonjour",
    "maison",
    "toit",
    "demain",
    "urgent",
    "bahay",
    "bubong",
    "oo",
    "hindi",
    "salamat",
    "bukas",
    "ngayon",
    "nhà",
    "mái",
    "có",
    "không",
    "vâng",
    "cảm",
    "ơn",
    "ngày",
    "mai",
    "gấp",
    "住宅",
    "商业",
    "是",
    "不",
    "谢谢",
    "明天",
    "紧急",
    "نعم",
    "لا",
    "شكرا",
    "منزل",
    "غدا",
    "عاجل",
    "tôi",
    "ako",
    "je",
    "yo",
    "我",
    "أنا",
}

YES_RX = re.compile(r"^\s*(sí|si|claro|correcto|是|是的|对|好|好的|oo|opo|sige|có|vâng|dạ|đúng|نعم|أجل|oui|d'accord|bien sûr)(?![\w])", re.I)
NO_RX = re.compile(r"^\s*(no|nope|不|不是|不要|算了|hindi|huwag|wag|không|thôi|لا|non)(?![\w])", re.I)
THANKS_RX = re.compile(r"^\s*(gracias|muchas gracias|谢谢|多谢|salamat|maraming salamat|cảm ơn|cám ơn|شكرا|شكرًا|merci|merci beaucoup)\W*$", re.I)
GREET_RX = re.compile(
    r"^\s*(hola|buenos días|buenas tardes|你好|您好|hello po|magandang (umaga|hapon|gabi)|xin chào|chào|مرحبا|السلام عليكم|bonjour|bonsoir|salut)\W*$", re.I
)
QUESTION_RX = re.compile(
    r"[?？؟]|^\s*(qué|que|cuál|cuándo|dónde|cómo|cuánto|tienen|hacen|ofrecen|ano|saan|kailan|paano|magkano|mayroon ba|meron ba|"
    r"có .* không|bao nhiêu|ở đâu|khi nào|thế nào|ماذا|متى|أين|كيف|كم|هل|quel|quelle|quand|où|comment|combien|est-ce|avez-vous|faites-vous)\b",
    re.I,
)
# "Can you / could someone …?" — a request phrased as a question. Combined with a booking signal it is a service request,
# not an information question, so the agent moves on with the booking instead of saying it has no information.
REQUEST_RX = re.compile(
    r"\b(?:can|could|would) (?:you|someone|somebody|anyone|your team)\b|\bare you able\b|\b(?:pueden|puede|podrían|podria|podría)\b|可以|能不能|能否|能来|"
    r"\b(?:pwede|puwede|maaari|kaya)\b|có thể|được không|هل يمكن|يمكنكم|\b(?:pouvez|pourriez|peut-on|pourrait)\b",
    re.I,
)
HOURS_RX = re.compile(
    r"horario|horas|abren|cierran|营业时间|几点|开门|oras|bukas kayo|giờ làm việc|mấy giờ|mở cửa|ساعات|مواعيد العمل|تفتحون|horaires|ouvert|fermez", re.I
)
LOCATION_RX = re.compile(r"dirección|dónde están|地址|在哪|address|saan kayo|địa chỉ|ở đâu|عنوان|أين أنتم|adresse|où êtes", re.I)
SERVICES_RX = re.compile(r"qué servicios|que servicios|提供什么服务|什么服务|anong serbisyo|dịch vụ gì|ما الخدمات|quels services", re.I)
NAME_INTRO_RX = re.compile(
    r"(?:me llamo|mi nombre es|soy|je m'appelle|mon nom est|je suis|ako si|ang pangalan ko ay|pangalan ko ay|tên tôi là|tôi tên là|tôi là|我叫|我的名字是|我是|اسمي|أنا)\s*"
    r"([^\d,.!?;，。！？]{1,60})",
    re.I,
)

WEEKDAYS = {
    "es": ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"],
    "fr": ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"],
    "tl": ["lunes", "martes", "miyerkules", "huwebes", "biyernes", "sabado", "linggo"],
    "vi": ["thứ hai", "thứ ba", "thứ tư", "thứ năm", "thứ sáu", "thứ bảy", "chủ nhật"],
    "zh": ["星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"],
    "ar": ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"],
}
WEEKDAY_ALT = {
    "zh": [["周一", "礼拜一"], ["周二", "礼拜二"], ["周三", "礼拜三"], ["周四", "礼拜四"], ["周五", "礼拜五"], ["周六", "礼拜六"], ["周日", "星期天", "礼拜天"]]
}
RELATIVE = {
    "today": ["hoy", "aujourd'hui", "ngayon", "hôm nay", "今天", "اليوم"],
    "tomorrow": ["mañana", "manana", "demain", "bukas", "ngày mai", "明天", "غدًا", "غدا"],
}
PARTS = {
    "morning": ["mañana por la", "por la mañana", "matin", "umaga", "buổi sáng", "sáng", "上午", "早上", "صباح", "صباحًا"],
    "afternoon": ["tarde", "après-midi", "hapon", "buổi chiều", "chiều", "下午", "بعد الظهر", "ظهرًا"],
    "evening": ["noche", "soir", "gabi", "buổi tối", "tối", "晚上", "مساء", "مساءً"],
}
ORDINALS = {
    0: [
        "el primero",
        "la primera",
        "primero",
        "primera",
        "le premier",
        "la première",
        "premier",
        "première",
        "unang",
        "yung una",
        "ang una",
        "cái đầu tiên",
        "đầu tiên",
        "lựa chọn một",
        "第一个",
        "第一",
        "الأول",
        "الاول",
        "الأولى",
    ],
    1: [
        "el segundo",
        "la segunda",
        "segundo",
        "segunda",
        "le deuxième",
        "la deuxième",
        "deuxième",
        "second",
        "ikalawa",
        "pangalawa",
        "cái thứ hai",
        "lựa chọn hai",
        "第二个",
        "第二",
        "الثاني",
        "الثانية",
    ],
    2: [
        "el tercero",
        "la tercera",
        "tercero",
        "tercera",
        "le troisième",
        "troisième",
        "ikatlo",
        "pangatlo",
        "cái thứ ba",
        "lựa chọn ba",
        "第三个",
        "第三",
        "الثالث",
        "الثالثة",
    ],
}
OTHER_TIMES_RX = re.compile(
    r"otro (día|horario)|ninguno|ningún|ibang (araw|oras)|wala sa|ngày khác|giờ khác|không được|其他时间|别的时间|都不行|يوم آخر|وقت آخر|"
    r"un autre (jour|créneau)|aucun",
    re.I,
)
RESCHEDULE_RX = re.compile(
    r"cambiar (mi |la )?cita|reprogramar|改约|改时间|ilipat|baguhin ang iskedyul|đổi lịch|dời lịch|تغيير الموعد|تأجيل|déplacer|reporter", re.I
)
CANCEL_RX = re.compile(r"cancelar|取消|kanselahin|hủy|إلغاء|annuler", re.I)

# ---------------------------------------------------------------------------------------------- helpers


def t(key: str, lang: str, **kw: Any) -> str:
    table = M[key]
    s = table.get(lang) or table["en"]
    return s.format(**kw) if kw else s


def appt_label(label: str, lang: str, *, article: bool = False) -> str:
    loc = APPT.get(label, {}).get(lang) or (label if lang == "en" else APPT["appointment"].get(lang, label))
    if article:
        if lang == "en":
            return ("an " if loc[:1].lower() in "aeiou" else "a ") + loc
        return _ARTICLE.get(lang, {}).get(loc, loc)
    return loc


def field_prompt(pack_key: str, field_key: str, lang: str, label: str) -> str | None:
    for k in (f"{pack_key}.{field_key}", field_key):
        if k in FIELD_PROMPTS and lang in FIELD_PROMPTS[k]:
            return FIELD_PROMPTS[k][lang]
    if lang == "en":
        return None
    return GENERIC_FIELD[lang].format(label=label.lower())


def contains(text: str, phrases: list[str]) -> str | None:
    low = text.lower()
    for p in phrases:
        pl = p.lower()
        if re.search(r"[一-鿿؀-ۿ]", pl):
            if pl in low:
                return p
        elif re.search(r"(?<![\w])" + re.escape(pl) + r"(?![\w])", low):
            return p
    return None


def match_option(text: str, field_key: str, extra: dict[str, list[str]] | None = None) -> str | None:
    options = dict(FIELD_KEYWORDS.get(field_key, {}))
    for k, v in (extra or {}).items():
        options[k] = list(options.get(k, [])) + v
    best: tuple[int, str] | None = None
    for value, kws in options.items():
        hit = contains(text, sorted(kws, key=len, reverse=True))
        if hit and (best is None or len(hit) > best[0]):
            best = (len(hit), value)
    return best[1] if best else None


def join_list(items: list[str], lang: str) -> str:
    if not items:
        return ""
    if len(items) == 1:
        return items[0]
    return t("list_sep", lang).join(items[:-1]) + t("and", lang) + items[-1]


_MONTHS = {
    "en": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    "es": ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"],
    "fr": ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"],
    "tl": ["Enero", "Pebrero", "Marso", "Abril", "Mayo", "Hunyo", "Hulyo", "Agosto", "Setyembre", "Oktubre", "Nobyembre", "Disyembre"],
    "ar": ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"],
}
_DAYS = {
    "en": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    "es": WEEKDAYS["es"],
    "fr": WEEKDAYS["fr"],
    "zh": WEEKDAYS["zh"],
    "ar": WEEKDAYS["ar"],
    "tl": ["Lunes", "Martes", "Miyerkules", "Huwebes", "Biyernes", "Sabado", "Linggo"],
    "vi": ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"],
}


def day_name(idx: int, lang: str) -> str:
    return _DAYS.get(lang, _DAYS["en"])[idx]


def clock(h: int, m: int, lang: str) -> str:
    h12 = h % 12 or 12
    am = h < 12
    mm = f"{m:02d}"
    if lang == "en":
        return f"{h12}:{mm} {'AM' if am else 'PM'}"
    if lang == "es":
        return f"{h12}:{mm} {'a. m.' if am else 'p. m.'}"
    if lang == "fr":
        return f"{h} h {mm}" if m else f"{h} h"
    if lang == "zh":
        return f"{'上午' if am else '下午'}{h12}:{mm}"
    if lang == "vi":
        return f"{h12}:{mm} {'sáng' if am else ('chiều' if h < 18 else 'tối')}"
    if lang == "tl":
        return f"{h12}:{mm} {'AM' if am else 'PM'}"
    if lang == "ar":
        return f"{h12}:{mm} {'صباحًا' if am else 'مساءً'}"
    return f"{h:02d}:{mm}"


def format_when(dt: datetime, tz: ZoneInfo, lang: str) -> str:
    d = dt.astimezone(tz)
    wd, day, mon = d.weekday(), d.day, d.month
    c = clock(d.hour, d.minute, lang)
    if lang == "en":
        return f"{_DAYS['en'][wd]}, {_MONTHS['en'][mon - 1]} {day} at {c}"
    if lang == "es":
        return f"{_DAYS['es'][wd]} {day} de {_MONTHS['es'][mon - 1]} a las {c}"
    if lang == "fr":
        return f"{_DAYS['fr'][wd]} {day} {_MONTHS['fr'][mon - 1]} à {c}"
    if lang == "zh":
        return f"{mon}月{day}日（{_DAYS['zh'][wd]}）{c}"
    if lang == "vi":
        return f"{_DAYS['vi'][wd]}, ngày {day} tháng {mon} lúc {c}"
    if lang == "tl":
        return f"{_DAYS['tl'][wd]}, {_MONTHS['tl'][mon - 1]} {day} nang {c}"
    if lang == "ar":
        return f"{_DAYS['ar'][wd]} {day} {_MONTHS['ar'][mon - 1]} الساعة {c}"
    return d.isoformat()


def slot_prompt(starts: list[datetime], tz: ZoneInfo, lang: str) -> str:
    labels = [format_when(s, tz, lang) for s in starts]
    if len(labels) == 1:
        return t("slots_one", lang, only=labels[0])
    return t("slots_many", lang, list=t("list_sep", lang).join(labels[:-1]), last=labels[-1])


def voice_for(lang: str, override: str | None = None) -> tuple[str, str]:
    """(Twilio <Say> voice, language attribute) for a conversation language."""
    info = LANGS.get(lang, LANGS["en"])
    if override:
        has_locale = re.search(r"[a-z]{2,3}-[A-Z]{2}", override) is not None
        # An owner-chosen voice is used only when it speaks this language ("Google.es-US-…" for Spanish, or a
        # locale-less name such as "Polly.Joanna" for English); otherwise use the language's default voice.
        if (has_locale and info["tts_lang"].split("-")[0] in override.split(".")[-1][:4]) or (not has_locale and lang == "en"):
            return override, info["tts_lang"]
    return info["tts_voice"], info["tts_lang"]


def language_options() -> list[dict[str, Any]]:
    return [
        {"code": k, "name": v["name"], "native": v["native"], "bcp47": v["bcp47"], "vibevoice_asr": k in VIBEVOICE_LANGS, "rtl": k in RTL}
        for k, v in LANGS.items()
    ]
