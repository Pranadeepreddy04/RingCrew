"""LLM provider abstraction + reliability gateway (spec §41, §85, §86).

- `LLMProvider` is the only place model-specific calls live.
- `LLMGateway` adds timeouts, safe retries, structured-output validation/repair, optional
  fallback (only when the tenant allows it), cost/usage accounting and tracing.
- The sandbox provider is deterministic and makes no network calls; it is rejected in
  production unless explicitly allowed (config validation)."""

from __future__ import annotations

import json
import logging
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Protocol, TypeVar

import httpx
from pydantic import BaseModel, ValidationError
from sqlalchemy.orm import Session

from app.ai.prompts import PROMPT_VERSION
from app.config import get_settings
from app.models import AITrace, Organization
from app.observability import current_request_id, metrics
from app.services.billing import record_usage

log = logging.getLogger("app.ai")
T = TypeVar("T", bound=BaseModel)

# Estimated USD per 1M tokens (input, output). Estimates only — used for cost dashboards/limits.
MODEL_PRICING = {
    "claude-haiku-4-5": (1.0, 5.0),
    "claude-sonnet-4-5": (3.0, 15.0),
}


class LLMError(Exception):
    def __init__(self, message: str, *, transient: bool) -> None:
        super().__init__(message)
        self.transient = transient


@dataclass
class LLMResult:
    text: str | None = None
    tool_input: dict[str, Any] | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    model: str | None = None


@dataclass
class ChatMessage:
    role: str  # user|assistant
    content: str


class LLMProvider(Protocol):
    name: str
    is_sandbox: bool

    def generate(self, system: str, messages: list[ChatMessage], *, model: str | None = None, max_tokens: int = 400) -> LLMResult: ...

    def tool_call(
        self, system: str, messages: list[ChatMessage], tool_name: str, schema: dict[str, Any], *, model: str | None = None, max_tokens: int = 600
    ) -> LLMResult: ...

    def embed(self, texts: list[str]) -> list[list[float]] | None: ...


class AnthropicProvider:
    name = "anthropic"
    is_sandbox = False
    URL = "https://api.anthropic.com/v1/messages"

    def __init__(self) -> None:
        s = get_settings()
        if not s.anthropic_api_key:
            raise LLMError("ANTHROPIC_API_KEY not configured", transient=False)
        self.key = s.anthropic_api_key
        self.model = s.anthropic_model
        self.timeout = s.llm_timeout_seconds

    def _post(self, body: dict[str, Any]) -> dict[str, Any]:
        try:
            r = httpx.post(
                self.URL,
                json=body,
                headers={"x-api-key": self.key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                timeout=self.timeout,
            )
        except httpx.TimeoutException as exc:
            raise LLMError("timeout", transient=True) from exc
        except httpx.HTTPError as exc:
            raise LLMError(f"network: {exc.__class__.__name__}", transient=True) from exc
        if r.status_code in (429, 500, 502, 503, 504, 529):
            raise LLMError(f"http {r.status_code}", transient=True)
        if r.status_code >= 400:
            raise LLMError(f"http {r.status_code}: {r.text[:200]}", transient=False)
        return r.json()

    def generate(self, system: str, messages: list[ChatMessage], *, model: str | None = None, max_tokens: int = 400) -> LLMResult:
        m = model or self.model
        data = self._post({"model": m, "max_tokens": max_tokens, "system": system, "messages": [{"role": x.role, "content": x.content} for x in messages]})
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
        u = data.get("usage", {})
        return LLMResult(text=text.strip(), input_tokens=u.get("input_tokens", 0), output_tokens=u.get("output_tokens", 0), model=m)

    def tool_call(
        self, system: str, messages: list[ChatMessage], tool_name: str, schema: dict[str, Any], *, model: str | None = None, max_tokens: int = 600
    ) -> LLMResult:
        m = model or self.model
        data = self._post(
            {
                "model": m,
                "max_tokens": max_tokens,
                "system": system,
                "messages": [{"role": x.role, "content": x.content} for x in messages],
                "tools": [{"name": tool_name, "description": "Record the structured result.", "input_schema": schema}],
                "tool_choice": {"type": "tool", "name": tool_name},
            }
        )
        block = next((b for b in data.get("content", []) if b.get("type") == "tool_use" and b.get("name") == tool_name), None)
        u = data.get("usage", {})
        return LLMResult(
            tool_input=block.get("input") if block else None, input_tokens=u.get("input_tokens", 0), output_tokens=u.get("output_tokens", 0), model=m
        )

    def embed(self, texts: list[str]) -> list[list[float]] | None:
        return None  # Anthropic does not provide embeddings; lexical retrieval is used.


class SandboxProvider:
    """Deterministic, offline provider. Structured extraction is delegated to the rule-based NLU
    (tool_call returns no input), and answers are extractive from business knowledge."""

    name = "sandbox"
    is_sandbox = True

    def generate(self, system: str, messages: list[ChatMessage], *, model: str | None = None, max_tokens: int = 400) -> LLMResult:
        return LLMResult(text=None, model="sandbox-deterministic")

    def tool_call(
        self, system: str, messages: list[ChatMessage], tool_name: str, schema: dict[str, Any], *, model: str | None = None, max_tokens: int = 600
    ) -> LLMResult:
        return LLMResult(tool_input=None, model="sandbox-deterministic")

    def embed(self, texts: list[str]) -> list[list[float]] | None:
        return None


class FailingProvider:
    """Test double used to exercise failover paths."""

    name = "failing"
    is_sandbox = False

    def __init__(self, transient: bool = True) -> None:
        self.transient = transient
        self.calls = 0

    def generate(self, *a: Any, **k: Any) -> LLMResult:
        self.calls += 1
        raise LLMError("simulated outage", transient=self.transient)

    tool_call = generate

    def embed(self, texts: list[str]) -> None:
        return None


def build_provider(name: str) -> LLMProvider | None:
    if name == "anthropic":
        try:
            return AnthropicProvider()
        except LLMError:
            return None
    if name == "sandbox":
        return SandboxProvider()
    return None


_provider_override: dict[str, LLMProvider | None] = {}


def set_provider_override(primary: LLMProvider | None, fallback: LLMProvider | None = None) -> None:
    """Testing hook: inject providers."""
    _provider_override.clear()
    if primary is not None:
        _provider_override["primary"] = primary
        _provider_override["fallback"] = fallback


def clear_provider_override() -> None:
    _provider_override.clear()


@dataclass
class TraceCtx:
    org: Organization
    conversation_id: uuid.UUID | None = None
    agent_id: uuid.UUID | None = None
    tools: list[dict[str, Any]] = field(default_factory=list)


class LLMGateway:
    MAX_ATTEMPTS = 2

    def __init__(self, db: Session, trace: TraceCtx) -> None:
        s = get_settings()
        self.db = db
        self.trace = trace
        if "primary" in _provider_override:
            self.primary = _provider_override["primary"]
            self.fallback = _provider_override.get("fallback")
        else:
            self.primary = build_provider(s.primary_llm_provider) or SandboxProvider()
            self.fallback = build_provider(s.fallback_llm_provider) if s.fallback_llm_provider != "none" else None
        allow_fb = bool(((trace.org.settings or {}).get("ai") or {}).get("allow_fallback_provider"))
        if not allow_fb:
            self.fallback = None  # never route tenant data to another provider without permission (spec §86)

    @property
    def is_sandbox(self) -> bool:
        return bool(self.primary and self.primary.is_sandbox)

    def _record(self, provider: LLMProvider, op: str, res: LLMResult | None, start: float, status: str, error: str | None) -> None:
        latency = int((time.perf_counter() - start) * 1000)
        in_t = res.input_tokens if res else 0
        out_t = res.output_tokens if res else 0
        model = res.model if res else None
        self.db.add(
            AITrace(
                organization_id=self.trace.org.id,
                conversation_id=self.trace.conversation_id,
                agent_id=self.trace.agent_id,
                request_id=current_request_id(),
                provider=provider.name,
                model=model,
                prompt_version=PROMPT_VERSION,
                operation=op,
                tools=[],
                latency_ms=latency,
                input_tokens=in_t,
                output_tokens=out_t,
                status=status,
                error=error,
            )
        )
        metrics.inc("llm_calls_total", provider=provider.name, op=op, status=status)
        metrics.observe("llm_call", latency / 1000, provider=provider.name)
        if in_t or out_t:
            price = MODEL_PRICING.get(model or "", (3.0, 15.0))
            cost = int(in_t * price[0] + out_t * price[1])  # tokens * $/1M = micro-dollars
            record_usage(
                self.db,
                self.trace.org.id,
                "llm_tokens",
                in_t + out_t,
                cost_micros=cost,
                provider=provider.name,
                model=model,
                conversation_id=self.trace.conversation_id,
                agent_id=self.trace.agent_id,
            )

    def _providers(self) -> list[LLMProvider]:
        return [p for p in (self.primary, self.fallback) if p is not None]

    def extract(self, system: str, messages: list[ChatMessage], model_cls: type[T], tool_name: str = "record_extraction") -> T | None:
        """Structured extraction with validation + one repair attempt. Returns None when no provider
        produced valid output (callers must degrade safely; malformed output is never executed)."""
        schema = model_cls.model_json_schema()
        for provider in self._providers():
            if provider.is_sandbox:
                return None
            msgs = list(messages)
            for attempt in range(self.MAX_ATTEMPTS):
                start = time.perf_counter()
                try:
                    res = provider.tool_call(
                        system, msgs, tool_name, schema, model=get_settings().anthropic_model_fast, max_tokens=get_settings().llm_max_tokens
                    )
                except LLMError as exc:
                    self._record(provider, "extract", None, start, "error", str(exc))
                    if exc.transient and attempt + 1 < self.MAX_ATTEMPTS:
                        time.sleep(0.4 * (attempt + 1))
                        continue
                    break
                try:
                    if res.tool_input is None:
                        raise ValueError("no tool input")
                    parsed = model_cls.model_validate(res.tool_input)
                    self._record(provider, "extract", res, start, "ok", None)
                    return parsed
                except (ValidationError, ValueError) as exc:
                    self._record(provider, "extract", res, start, "invalid", str(exc)[:500])
                    msgs = msgs + [
                        ChatMessage("assistant", json.dumps(res.tool_input or {})[:2000]),
                        ChatMessage("user", f"That output was invalid: {str(exc)[:300]}. Call the tool again with valid values."),
                    ]
        return None

    def translate(self, text: str, target_language: str) -> str | None:
        """Translate untrusted customer text (as data) for understanding. Returns None if no real provider
        is available or the output fails validation (callers fall back to deterministic multilingual NLU)."""
        from app.ai.prompts import translate_system, wrap

        for provider in self._providers():
            if provider.is_sandbox:
                return None
            start = time.perf_counter()
            try:
                res = provider.generate(
                    translate_system(target_language),
                    [ChatMessage("user", wrap("customer_message", text))],
                    model=get_settings().anthropic_model_fast,
                    max_tokens=400,
                )
            except LLMError as exc:
                self._record(provider, "translate", None, start, "error", str(exc))
                continue
            out = (res.text or "").strip()
            digits_in = re.findall(r"\d", text)
            if not out or len(out) > 4 * len(text) + 40 or sorted(re.findall(r"\d", out)) != sorted(digits_in):
                self._record(provider, "translate", res, start, "invalid", "translation failed validation")
                continue
            self._record(provider, "translate", res, start, "ok", None)
            return out
        return None

    def answer(self, system: str, question: str, knowledge: str) -> str | None:
        from app.ai.prompts import wrap

        for provider in self._providers():
            if provider.is_sandbox:
                return None
            for attempt in range(self.MAX_ATTEMPTS):
                start = time.perf_counter()
                try:
                    res = provider.generate(
                        system, [ChatMessage("user", wrap("business_knowledge", knowledge) + "\n\n" + wrap("customer_message", question))], max_tokens=300
                    )
                except LLMError as exc:
                    self._record(provider, "answer", None, start, "error", str(exc))
                    if exc.transient and attempt + 1 < self.MAX_ATTEMPTS:
                        time.sleep(0.4 * (attempt + 1))
                        continue
                    break
                text = (res.text or "").strip()
                if not text:
                    self._record(provider, "answer", res, start, "invalid", "empty answer")
                    break
                if "NO_ANSWER" in text:
                    self._record(provider, "answer", res, start, "ok", None)
                    return ""
                if not grounded(text, knowledge):
                    self._record(provider, "answer", res, start, "ungrounded", "answer contained figures not present in knowledge")
                    return None
                self._record(provider, "answer", res, start, "ok", None)
                return text
        return None


_FIGURE = re.compile(r"\$\s?\d[\d,]*(?:\.\d+)?|\b\d+(?:\.\d+)?\s?%|\b\d{3}[-.\s]\d{3}[-.\s]\d{4}\b")


def grounded(answer: str, knowledge: str) -> bool:
    """Reject answers containing money amounts, percentages or phone numbers that do not appear
    verbatim in the retrieved business knowledge (hallucination guard)."""
    norm_k = re.sub(r"\s", "", knowledge)
    for m in _FIGURE.findall(answer):
        if re.sub(r"\s", "", m) not in norm_k:
            return False
    return True
