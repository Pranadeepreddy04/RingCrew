"""Deterministic language understanding: field extraction, intent signals, slot choice parsing.

This always runs (with or without an LLM). Deterministic formats (phone, email, ZIP) are
parsed here and validated; the LLM, when configured, only fills gaps and is validated against
the same field definitions."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from app.ai import i18n
from app.industry import PackField, ResolvedPack

PHONE_RE = re.compile(r"(?<!\d)(?:\+?1[\s.-]?)?\(?([2-9]\d{2})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})(?!\d)")
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
ZIP_RE = re.compile(r"(?<![\d-])(\d{5})(?:-\d{4})?(?![\d])")
NAME_INTRO_RE = re.compile(r"\b(?:my name is|my name's|name is|this is|i am|i'm|im|it's|its)\s+([A-Za-z][A-Za-z'\-]+(?:\s+[A-Za-z][A-Za-z'\-]+){0,3})", re.I)
QUESTION_START = re.compile(r"^\s*(what|whats|what's|do|does|how|when|where|are|is|can you|could you|which|why|who|will|would|should|any|have you|got)\b", re.I)
NOT_NAME_WORDS = {
    "having",
    "looking",
    "interested",
    "calling",
    "wondering",
    "trying",
    "not",
    "just",
    "in",
    "at",
    "from",
    "the",
    "a",
    "an",
    "here",
    "good",
    "fine",
    "ok",
    "okay",
    "sure",
    "yes",
    "no",
    "yeah",
    "yep",
    "nope",
    "leaking",
    "sorry",
    "thanks",
    "thank",
    "hi",
    "hello",
    "pretty",
    "soon",
    "asap",
    "urgent",
    "today",
    "tomorrow",
    "whenever",
    "flexible",
    "house",
    "home",
    "commercial",
    "residential",
    "my",
    "our",
    "it",
    "its",
    "is",
    "what",
    "why",
    "how",
    "when",
    "where",
    "can",
    "could",
    "please",
    "help",
    "roof",
    "repair",
    "emergency",
    "none",
    "idk",
    "unknown",
    "maybe",
    "later",
    "now",
    "next",
    "week",
    "morning",
    "afternoon",
    "evening",
}
STOP_WORDS = {"STOP", "STOPALL", "UNSUBSCRIBE", "CANCEL", "END", "QUIT", "REVOKE", "OPTOUT"}
START_WORDS = {"START", "UNSTOP", "YES"}
HELP_WORDS = {"HELP", "INFO"}

INJECTION_PATTERNS = [
    r"ignore (all |your |the |any )?(previous|prior|above|earlier) (instructions|rules|prompts?)",
    r"disregard (all |your |the )?(previous|prior|above)? ?(instructions|rules)",
    r"(system|developer|hidden) prompt",
    r"\bapi[\s_-]?keys?\b",
    r"\b(access|auth|bearer) tokens?\b",
    r"(reveal|show|print|repeat|tell me).{0,25}(your )?(instructions|configuration|config|prompt)",
    r"(show|give|tell|list|send).{0,40}(other|another|all|every) (customer|client|user|business|compan)",
    r"you are now",
    r"act as (an? )?(admin|developer|system)",
    r"jailbreak",
    r"\bdan mode\b",
    r"without (checking|verifying)",
    r"(pretend|say) (that )?(it'?s|the appointment is) (booked|confirmed)",
]
_INJ = re.compile("|".join(INJECTION_PATTERNS), re.I)

WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
WEEKDAY_ABBR = {"mon": 0, "tue": 1, "tues": 1, "wed": 2, "thu": 3, "thur": 3, "thurs": 3, "fri": 4, "sat": 5, "sun": 6}
ORDINALS = {"first": 0, "1st": 0, "second": 1, "2nd": 1, "third": 2, "3rd": 2, "last": -1}


def normalize_phone(raw: str) -> str | None:
    m = PHONE_RE.search(raw)
    if not m:
        return None
    return f"+1{m.group(1)}{m.group(2)}{m.group(3)}"


def _has_kw(text: str, kw: str) -> bool:
    return re.search(r"(?<![a-z0-9])" + re.escape(kw.lower()) + r"(?![a-z0-9])", text) is not None


def match_enum(text: str, options: dict[str, list[str]]) -> str | None:
    t = text.lower()
    best: tuple[int, str] | None = None
    for value, kws in options.items():
        cands = ([value.replace("_", " ")] if len(value) >= 5 else []) + kws
        for kw in cands:
            if _has_kw(t, kw) and (best is None or len(kw) > best[0]):
                best = (len(kw), value)
    return best[1] if best else None


def looks_like_question(text: str) -> bool:
    return "?" in text or bool(QUESTION_START.match(text)) or bool(i18n.QUESTION_RX.search(text))


def detect_injection(text: str) -> bool:
    return bool(_INJ.search(text))


def contains_any(text: str, keywords: list[str]) -> str | None:
    t = text.lower()
    for kw in keywords:
        if _has_kw(t, kw):
            return kw
    return None


def clean_name(raw: str) -> str | None:
    words = [w for w in re.split(r"\s+", raw.strip().strip(".,!")) if w]
    if not words or len(words) > 4:
        return None
    if all(w.isascii() for w in words) and any(w.lower().strip(".") in NOT_NAME_WORDS for w in words):
        return None
    letter = r"[^\W\d_]"
    if not all(re.fullmatch(rf"{letter}(?:{letter}|['\-])*\.?", w) for w in words):
        return None
    if any(w.lower() in i18n.NOT_NAME_ALL for w in words):
        return None
    return " ".join(w[:1].upper() + w[1:] if w.isascii() else w for w in words)


@dataclass
class Extraction:
    fields: dict[str, Any] = field(default_factory=dict)
    is_question: bool = False
    booking_signal: bool = False


def extract_fields(text: str, pack: ResolvedPack, asked: str | None, lang: str = "en") -> Extraction:
    ex = Extraction(is_question=looks_like_question(text))
    t = text.strip()
    low = t.lower()
    phones = list(PHONE_RE.finditer(t))
    if phones:
        ex.fields["phone"] = normalize_phone(phones[0].group(0))
    stripped = PHONE_RE.sub(" ", t)
    em = EMAIL_RE.search(stripped)
    if em:
        ex.fields["email"] = em.group(0).lower()
        stripped = stripped.replace(em.group(0), " ")
    z = ZIP_RE.search(stripped)
    if z:
        ex.fields["zip"] = z.group(1)
    nm = NAME_INTRO_RE.search(t)
    if nm:
        cand = clean_name(re.split(r"[,.!?;]| and | my | phone| number", nm.group(1), flags=re.I)[0])
        if cand and (nm.group(0).lower().startswith(("my name", "name is")) or asked == "name"):
            ex.fields["name"] = cand
    if "name" not in ex.fields:
        nm2 = i18n.NAME_INTRO_RX.search(t)
        if nm2:
            cand = clean_name(re.split(r"\s+(?:y|et|at|và|و)\s+|[，,]", nm2.group(1).strip())[0])
            if cand:
                ex.fields["name"] = cand
    for f in pack.fields:
        if not f.enabled or f.key in ex.fields:
            continue
        if f.type == "enum" and f.options:
            v = match_enum(low, f.options)
            if v is None and lang != "en":
                v = i18n.match_option(t, f.key)
                if v not in f.options:
                    v = None
            if v:
                ex.fields[f.key] = v
        elif f.type == "bool" and f.true_keywords and contains_any(low, f.true_keywords):
            ex.fields[f.key] = True
        elif f.type == "bool" and lang != "en" and f.key in i18n.BOOL_TRUE and i18n.contains(t, i18n.BOOL_TRUE[f.key]):
            ex.fields[f.key] = True
        elif f.type == "text" and f.pattern:
            m = re.search(f.pattern, t, re.I)
            if m:
                ex.fields[f.key] = m.group(0)
    # direct answer to the question we just asked
    if asked and asked not in ex.fields:
        af = pack.field(asked)
        if af is not None:
            v = _answer_for(af, t)
            if v is not None:
                ex.fields[asked] = v
    ex.booking_signal = contains_any(low, pack.booking_keywords) is not None or (lang != "en" and i18n.contains(t, i18n.BOOKING.get(lang, [])) is not None)
    return ex


WORD_DIGITS = {
    "zero": "0",
    "oh": "0",
    "one": "1",
    "two": "2",
    "three": "3",
    "four": "4",
    "five": "5",
    "six": "6",
    "seven": "7",
    "eight": "8",
    "nine": "9",
    # es / fr / tl / vi spoken digits
    "cero": "0",
    "uno": "1",
    "dos": "2",
    "tres": "3",
    "cuatro": "4",
    "cinco": "5",
    "seis": "6",
    "siete": "7",
    "ocho": "8",
    "nueve": "9",
    "zéro": "0",
    "un": "1",
    "deux": "2",
    "trois": "3",
    "quatre": "4",
    "cinq": "5",
    "sept": "7",
    "huit": "8",
    "neuf": "9",
    "isa": "1",
    "dalawa": "2",
    "tatlo": "3",
    "apat": "4",
    "lima": "5",
    "anim": "6",
    "pito": "7",
    "walo": "8",
    "siyam": "9",
    "không": "0",
    "một": "1",
    "hai": "2",
    "ba": "3",
    "bốn": "4",
    "năm": "5",
    "sáu": "6",
    "bảy": "7",
    "tám": "8",
    "chín": "9",
}
_CJK_DIGITS = str.maketrans("零〇一二三四五六七八九٠١٢٣٤٥٦٧٨٩", "001234567890123456789")


def _spoken_digits(text: str) -> str:
    """'7 6 2 0 1', 'seven six two oh one', 'siete seis…', '七六二零一' (speech recognition output) → '76201'."""
    words = re.findall(r"[^\W\d_]+|\d", text.lower().translate(_CJK_DIGITS))
    return "".join(WORD_DIGITS.get(w, w if w.isdigit() else "") for w in words)


def _answer_for(f: PackField, text: str) -> Any:
    t = text.strip()
    if f.type == "zip":
        d = _spoken_digits(t)
        return d if len(d) == 5 else None
    if f.type == "phone":
        d = _spoken_digits(t)
        return normalize_phone(d) if len(d) in (10, 11) else None
    if f.type == "name":
        return clean_name(re.sub(r"^(it'?s|i'?m|this is|my name is|name is)\s+", "", t, flags=re.I))
    if f.type == "text":
        if len(t) >= 2 and not looks_like_question(t):
            return t[:300]
        return None
    if f.type == "bool":
        if re.match(r"^(yes|yeah|yep|yup|correct|it is|there is|sure)\b", t, re.I) or i18n.YES_RX.match(t):
            return True
        if re.match(r"^(no|nope|nah|not really|there isn'?t)\b", t, re.I) or i18n.NO_RX.match(t):
            return False
    return None


def validate_field(f: PackField, value: Any) -> Any:
    """Validate an LLM-proposed value against the field definition. Returns None if invalid."""
    if value is None:
        return None
    if f.type == "phone":
        return normalize_phone(str(value))
    if f.type == "email":
        m = EMAIL_RE.fullmatch(str(value).strip())
        return m.group(0).lower() if m else None
    if f.type == "zip":
        return str(value) if re.fullmatch(r"\d{5}", str(value).strip()) else None
    if f.type == "enum":
        return value if value in f.options else None
    if f.type == "bool":
        return value if isinstance(value, bool) else None
    if f.type == "name":
        return clean_name(str(value))
    if f.type == "text":
        v = str(value).strip()
        return v[:300] if v else None
    return None


# ------------------------------------------------------------------ slot choice


@dataclass
class DatePreference:
    weekday: int | None = None
    relative_days: int | None = None
    part_of_day: str | None = None  # morning|afternoon|evening
    next_week: bool = False


def parse_date_preference(text: str) -> DatePreference | None:
    t = text.lower()
    pref = DatePreference()
    found = False
    for i, names in enumerate(zip(*[i18n.WEEKDAYS[k] for k in i18n.WEEKDAYS], strict=True)):
        alts = list(names) + (i18n.WEEKDAY_ALT["zh"][i] if i < 7 else [])
        if i18n.contains(text, alts):
            pref.weekday, found = i, True
    if i18n.contains(text, i18n.RELATIVE["today"]):
        pref.relative_days, found = 0, True
    tomorrow = i18n.contains(text, i18n.RELATIVE["tomorrow"])
    if tomorrow and not re.search(r"(por|de|en) la mañana", t) or (tomorrow and t.count("mañana") > 1):
        pref.relative_days, found = 1, True
    for part, words in i18n.PARTS.items():
        if i18n.contains(text, words):
            pref.part_of_day, found = part, True
    if re.search(r"\btoday\b", t):
        pref.relative_days, found = 0, True
    if re.search(r"\btomorrow\b", t):
        pref.relative_days, found = 1, True
    for i, d in enumerate(WEEKDAYS):
        if re.search(rf"\b{d}\b", t):
            pref.weekday, found = i, True
    if pref.weekday is None:
        for ab, i in WEEKDAY_ABBR.items():
            if re.search(rf"\b{ab}\b", t):
                pref.weekday, found = i, True
    for part in ("morning", "afternoon", "evening"):
        if part in t:
            pref.part_of_day, found = part, True
    if "next week" in t:
        pref.next_week, found = True, True
    return pref if found else None


TIME_RE = re.compile(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?\b", re.I)


def match_slot_choice(text: str, slots: list[dict[str, Any]], tz: Any) -> int | None:
    """Map a customer's reply to one of the offered slots. Returns an index or None."""
    t = text.lower().strip()
    if not slots:
        return None
    m = re.fullmatch(r"(?:option\s*)?#?\s*([1-9])\.?", t)
    if m:
        idx = int(m.group(1)) - 1
        return idx if idx < len(slots) else None
    for word, idx in ORDINALS.items():
        if re.search(rf"\b{word}\b", t) and ("one" in t or "option" in t or "time" in t or "slot" in t or len(t.split()) <= 3):
            return idx if idx >= 0 and idx < len(slots) else (len(slots) - 1 if idx == -1 else None)
    for idx, words in i18n.ORDINALS.items():
        if i18n.contains(text, sorted(words, key=len, reverse=True)) and idx < len(slots):
            return idx
    starts = [datetime.fromisoformat(s["start"]).astimezone(tz) for s in slots]
    cands = list(range(len(slots)))
    pref = parse_date_preference(t)
    if pref and pref.weekday is not None:
        cands = [i for i in cands if starts[i].weekday() == pref.weekday]
    tm = None
    for mt in TIME_RE.finditer(t):
        hour = int(mt.group(1))
        minute = int(mt.group(2) or 0)
        ampm = (mt.group(3) or "").replace(".", "").lower()
        if hour > 12 or (not ampm and not mt.group(2) and hour > 12):
            continue
        if ampm == "pm" and hour < 12:
            hour += 12
        if ampm == "am" and hour == 12:
            hour = 0
        if not ampm and 1 <= hour <= 6:
            hour += 12  # "at 2" in a business context means 2 PM
        tm = (hour, minute)
    if tm:
        cands = [i for i in cands if (starts[i].hour, starts[i].minute) == tm]
    if pref and pref.part_of_day:
        rng = {"morning": (0, 12), "afternoon": (12, 17), "evening": (17, 24)}[pref.part_of_day]
        cands = [i for i in cands if rng[0] <= starts[i].hour < rng[1]]
    if (pref or tm) and len(cands) == 1:
        return cands[0]
    if (pref or tm) and len(cands) > 1 and tm:
        return cands[0]
    if (re.fullmatch(r"(yes|yeah|yep|sure|ok|okay|sounds good|that works|perfect)[.! ]*", t) or i18n.YES_RX.match(text)) and len(slots) == 1:
        return 0
    return None


def wants_other_times(text: str) -> bool:
    if i18n.OTHER_TIMES_RX.search(text):
        return True
    return bool(
        re.search(
            r"\b(none|neither|other|another|different|later|earlier|don'?t work|doesn'?t work|can'?t make|not available|busy then|anything else)\b",
            text.lower(),
        )
    )


def extract_first_name(name: str | None, lang: str = "en") -> str:
    first = (name or "").split(" ")[0]
    if first and not first.isascii() and lang in ("zh", "vi"):
        return name or first  # Chinese names are not split; Vietnamese address by given name is last word
    return first or i18n.t("there", lang)
