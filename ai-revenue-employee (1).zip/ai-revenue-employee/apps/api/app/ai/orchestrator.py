"""AI Orchestrator — the conversation engine behind every channel (spec §14, §43, §44, §72, §73).

Customer → Channel adapter → Conversation service → Policy layer → Orchestrator
→ (LLM-assisted) understanding → Knowledge retrieval → Tool selection → Tool validation/execution
→ Response composed from *confirmed* tool results → Events/analytics.

Reasoning is separated from execution: understanding may use an LLM, but every action goes
through `tools.execute`, and every customer-facing claim about an action is generated from the
actual tool result."""

from __future__ import annotations

import re
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Literal
from zoneinfo import ZoneInfo

from pydantic import BaseModel, Field, create_model
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai import i18n, nlu, tools
from app.ai.llm import ChatMessage, LLMGateway, TraceCtx
from app.ai.prompts import PROMPT_VERSION, answer_system, extraction_system, wrap
from app.industry import PackField, ResolvedPack, resolve_pack
from app.models import AIAgent, BusinessProfile, Conversation, Customer, Message, Organization
from app.observability import Timer, metrics
from app.services import billing, crm
from app.services.common import emit_event, utcnow
from app.services.knowledge import Hit

NO_INFO = i18n.t("no_info", "en")
BOOKING_FAILED = i18n.t("booking_failed", "en")
PRICE_Q = re.compile(r"\b(price|prices|pricing|cost|costs|cheap|cheapest|how much|rate|rates|charge|fee|fees|estimate cost|quote)\b|\$", re.I)
SCHEDULING_Q = re.compile(
    r"\b(come out|come by|someone (?:come|out)|available|availability|openings?|schedule|appointment|book|today|tomorrow|this week|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b",
    re.I,
)
HOURS_Q = re.compile(r"\b(hours|open|close|closing|opening)\b", re.I)
AREA_Q = re.compile(r"\b(service|serve|servicing|cover|come to|work in|area|areas)\b", re.I)
LOCATION_Q = re.compile(r"\b(where are you|address|located|location)\b", re.I)
PHONE_Q = re.compile(r"\b(phone number|call you|your number)\b", re.I)
SERVICES_Q = re.compile(r"\bwhat (services|kind of (work|services)|do you (do|offer))\b", re.I)
RESCHEDULE_Q = re.compile(r"\b(reschedule|re-schedule|change (my|the) (appointment|time)|move (my|the) appointment|different time)\b", re.I)
CANCEL_Q = re.compile(r"\b(cancel (my|the)? ?(appointment|inspection|visit|estimate|consultation)?|call it off)\b", re.I)
YES = re.compile(r"^\s*(yes|yeah|yep|yup|correct|please do|do it|confirm|sure)\b", re.I)
NO = re.compile(r"^\s*(no|nope|nah|don'?t|keep it|never mind)\b", re.I)
THANKS = re.compile(r"^\s*(thanks|thank you|thx|ty|great|perfect|awesome|ok|okay|cool)\W*$", re.I)
GREETING = re.compile(r"^\s*(hi|hello|hey|good (morning|afternoon|evening)|yo)\W*$", re.I)
DAY_NAMES = {"mon": "Monday", "tue": "Tuesday", "wed": "Wednesday", "thu": "Thursday", "fri": "Friday", "sat": "Saturday", "sun": "Sunday"}


@dataclass
class TurnResult:
    reply: str | None
    handoff: bool = False
    transfer_to: str | None = None
    end_call: bool = False
    actions: list[dict[str, Any]] = field(default_factory=list)


class _Understanding(BaseModel):
    intent: Literal["question", "book_service", "choose_time", "reschedule", "cancel", "human", "smalltalk", "other"]
    fields: dict[str, Any] = Field(default_factory=dict)
    question: str | None = None


def _llm_schema(pack: ResolvedPack) -> type[BaseModel]:
    props: dict[str, Any] = {}
    for f in pack.fields:
        if not f.enabled:
            continue
        if f.type == "enum":
            props[f.key] = (Literal[tuple(f.options)] | None, None)  # type: ignore[valid-type]
        elif f.type == "bool":
            props[f.key] = (bool | None, None)
        else:
            props[f.key] = (str | None, None)
    fields_model = create_model("ExtractedFields", **props)  # type: ignore[call-overload]
    return create_model(
        "Understanding",
        intent=(Literal["question", "book_service", "choose_time", "reschedule", "cancel", "human", "smalltalk", "other"], ...),
        fields=(fields_model, Field(default_factory=fields_model)),
        question=(str | None, None),
    )


class Orchestrator:
    def __init__(self, db: Session, org: Organization, agent: AIAgent, conv: Conversation) -> None:
        self.db, self.org, self.agent, self.conv = db, org, agent, conv
        profile = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == org.id))
        if profile is None:
            raise RuntimeError(f"organization {org.id} has no business profile")
        self.profile: BusinessProfile = profile
        self.pack = resolve_pack(agent.industry_template_key, db, agent.pack_overrides)
        self.tz = ZoneInfo(org.timezone)
        self.st: dict[str, Any] = dict(conv.state or {})
        self.st.setdefault("fields", {})
        self.st.setdefault("stage", "open")
        self.ctx = tools.ToolContext(db, org, agent, conv, self.profile, self.pack)
        self.gw = LLMGateway(db, TraceCtx(org=org, conversation_id=conv.id, agent_id=agent.id))
        self.parts: list[str] = []
        self.result = TurnResult(reply=None)
        self._turn_was_question = False
        self._turn_booking_signal = False
        self.lang: str = conv.language or agent.language or "en"
        self.en: str = ""  # English rendering of the current customer message (LLM translation when available)

    # ------------------------------------------------------------------ helpers
    @property
    def fields(self) -> dict[str, Any]:
        return self.st["fields"]  # type: ignore[no-any-return]

    def say(self, text: str) -> None:
        if text:
            # "8:00 a. m." at the end of a sentence would otherwise produce "a. m.."
            self.parts.append(re.sub(r"(?<!\.)\.\.(?!\.)", ".", text.strip()))

    def call(self, tool: str, /, **args: Any) -> tools.ToolResult:
        return tools.execute(self.ctx, tool, args)

    def first_name(self) -> str:
        return nlu.extract_first_name(self.fields.get("name"), self.lang)

    def t(self, key: str, **kw: Any) -> str:
        return i18n.t(key, self.lang, **kw)

    def appt(self, article: bool = False) -> str:
        return i18n.appt_label(self.pack.appointment_label, self.lang, article=article)

    def slots_text(self, slots: list[dict[str, Any]]) -> str:
        return i18n.slot_prompt([datetime.fromisoformat(x["start"]) for x in slots], self.tz, self.lang)

    def when(self, iso: str) -> str:
        return i18n.format_when(datetime.fromisoformat(iso), self.tz, self.lang)

    def _either(self, en_rx: re.Pattern[str], local_rx: re.Pattern[str] | None, text: str) -> bool:
        return bool(en_rx.search(self.en) or en_rx.search(text) or (local_rx is not None and local_rx.search(text)))

    def _field_prompt(self, f: PackField) -> str:
        if self.lang != "en":
            loc = i18n.field_prompt(self.pack.key, f.key, self.lang, f.label)
            if loc:
                return loc
        if f.prompt:
            return f.prompt
        if f.type == "enum" and f.options:
            opts = [o.replace("_", " ") for o in f.options]
            return f"What's the {f.label.lower()} — " + ", ".join(opts[:-1]) + f", or {opts[-1]}?"
        return f"Could you share the {f.label.lower()}?"

    # ------------------------------------------------------------------ entry
    def handle(self, text: str) -> TurnResult:
        timer = Timer().__enter__()
        text = (text or "").strip()[:2000]
        allowed = list(self.agent.languages or [self.agent.language or "en"])
        self.lang = i18n.choose_language(text, self.conv.language or self.st.get("lang"), allowed, self.agent.language or "en")
        self.conv.language = self.st["lang"] = self.lang
        self.en = text
        if self.lang != "en" and text and not self.gw.is_sandbox:
            self.en = self.gw.translate(text, "English") or text
        try:
            self._handle(text)
        finally:
            self.conv.state = self.st
            reply = " ".join(p for p in self.parts if p).strip() or None
            if self.conv.channel == "voice" and reply:
                reply = re.sub(r"\s*—\s*", ", ", reply)
            self.result.reply = reply
            self.result.actions = self.ctx.log
            metrics.observe("ai_turn", time.perf_counter() - timer.start, channel=self.conv.channel)
        return self.result

    def _handle(self, text: str) -> None:
        if self.conv.handoff_active:
            self._passive_capture(text)
            return
        ent = billing.entitlements(self.db, self.org)
        offline = self.agent.status != "active" and not self.conv.is_test
        if (not ent["usable"] and not self.conv.is_test) or offline:
            self.say(self.t("offline", org=self.org.name))
            self.call("request_human_help", reason="ai_employee_offline", summary=text[:300])
            self.result.handoff = True
            return
        if self.conv.channel != "test" and not billing.within_limit(self.db, self.org, "conversation", 0):
            self.say(self.t("limit", org=self.org.name))
            self.call("request_human_help", reason="usage_limit_reached", summary=text[:300])
            self.result.handoff = True
            return
        if not text:
            self.say(self.t("not_caught"))
            return
        if self._policy(text):
            return
        ex = self._understand(text)
        if ex.get("_intent") == "human":
            self._handoff("customer_requested_human", text[:200])
            return
        stage = self.st["stage"]
        if stage in ("offering", "rescheduling") and self._handle_slot_reply(text, ex):
            return
        if stage == "confirm_cancel":
            self._handle_cancel_confirmation(text)
            return
        if self.st.get("appointment_id") or stage == "booked":
            if self._either(RESCHEDULE_Q, i18n.RESCHEDULE_RX, text) or ex.get("_intent") == "reschedule":
                self._start_reschedule(text)
                return
            if self._either(CANCEL_Q, i18n.CANCEL_RX, text) or ex.get("_intent") == "cancel":
                self.st["stage"] = "confirm_cancel"
                self.say(self.t("confirm_cancel"))
                return
        booking = self.st.get("intent") == "book_service"
        if not booking and (ex.get("_booking") or ex.get("_intent") in ("book_service", "choose_time") or self._has_qualification_signal()):
            if stage != "booked":
                self.st["intent"] = "book_service"
                booking = True
        self._turn_was_question = bool(ex.get("_question"))
        self._turn_booking_signal = bool(ex.get("_booking"))
        if ex.get("_question"):
            self._answer_question(text, booking)
        pref = nlu.parse_date_preference(text) or (nlu.parse_date_preference(self.en) if self.en != text else None)
        if pref and booking:
            self.st["date_pref"] = asdict(pref)
        if booking and self.st["stage"] not in ("booked", "handed_off", "out_of_area_done", "awaiting_team"):
            self._progress_booking()
            return
        if not self.parts:
            if THANKS.match(text) or i18n.THANKS_RX.match(text):
                self.say(self.t("welcome"))
            elif GREETING.match(text) or i18n.GREET_RX.match(text) or (not self.fields and not ex.get("_question")):
                self.say(self.t("greet", org=self.org.name, appt=self.appt(), appt_a=self.appt(article=True)))
            else:
                self.say(self.t("help_menu", org=self.org.name, appt=self.appt(), appt_a=self.appt(article=True)))

    # ------------------------------------------------------------------ policy layer
    def _policy(self, text: str) -> bool:
        low, en_low = text.lower(), self.en.lower()
        if nlu.detect_injection(text) or nlu.detect_injection(self.en):
            emit_event(self.db, self.org.id, "ai.injection_blocked", channel=self.conv.channel, conversation_id=self.conv.id, is_test=self.conv.is_test)
            self.say(self.t("injection", org=self.org.name))
            self._reprompt()
            return True
        local_emergency = i18n.contains(text, i18n.EMERGENCY_ALL)
        emergency = nlu.contains_any(low, self.pack.emergency_keywords) or nlu.contains_any(en_low, self.pack.emergency_keywords) or local_emergency
        if emergency:
            self.fields["urgency"] = "emergency" if (f := self.pack.field("urgency")) and "emergency" in f.options else self.fields.get("urgency")
            gas = emergency in ("gas leak", "smell gas", "carbon monoxide") or emergency in i18n.GAS
            self.say(self.t("gas" if gas else "danger"))
            if self.profile.emergency_instructions:
                self.say(self.profile.emergency_instructions)
            self._handoff("emergency", f"Customer reported: {text[:200]}")
            return True
        if (
            nlu.contains_any(low, self.pack.human_keywords)
            or nlu.contains_any(en_low, self.pack.human_keywords)
            or (self.lang != "en" and i18n.contains(text, i18n.HUMAN.get(self.lang, [])))
        ):
            self._handoff("customer_requested_human", text[:200])
            return True
        if (
            nlu.contains_any(low, self.pack.complaint_keywords)
            or nlu.contains_any(en_low, self.pack.complaint_keywords)
            or (self.lang != "en" and i18n.contains(text, i18n.COMPLAINT.get(self.lang, [])))
        ):
            self.say(self.t("complaint"))
            self._handoff("complaint", text[:300], announce=False)
            return True
        return False

    def _handoff(self, reason: str, summary: str, announce: bool = True) -> None:
        self._capture_contact_if_possible()
        res = self.call("transfer_to_human", reason=reason, summary=summary)
        self.result.handoff = True
        self.st["stage"] = "handed_off"
        if res.ok and res.data.get("transfer_to"):
            self.result.transfer_to = res.data["transfer_to"]
            if announce:
                self.say(self.t("transferring"))
            return
        if announce:
            self.say(self.t("team_will_reach"))
        if not (self.fields.get("phone") or self.fields.get("email")) and self.conv.channel == "web":
            self.say(self.t("ask_phone_for_team"))

    def _capture_contact_if_possible(self) -> None:
        if self.conv.lead_id or not (self.fields.get("phone") or self.fields.get("email")):
            return
        self._create_lead(qualified=False)

    def _passive_capture(self, text: str) -> None:
        """During human takeover the AI stays silent but still records contact details the customer types."""
        ex = nlu.extract_fields(text, self.pack, None, self.lang)
        changed = False
        for k in ("phone", "email", "name"):
            if ex.fields.get(k) and not self.fields.get(k):
                self.fields[k] = ex.fields[k]
                changed = True
        if changed and self.conv.customer_id is None and (self.fields.get("phone") or self.fields.get("email")):
            customer = crm.find_or_create_customer(
                self.db, self.org.id, phone=self.fields.get("phone"), email=self.fields.get("email"), name=self.fields.get("name")
            )
            self.conv.customer_id = customer.id

    def _reprompt(self) -> None:
        if self.st["stage"] in ("offering", "rescheduling") and self.st.get("offered_slots"):
            self.say(self.t("next_openings", slots=self.slots_text(self.st["offered_slots"])))
        elif self.st.get("asked") and (f := self.pack.field(self.st["asked"])):
            self.say(self._field_prompt(f))

    # ------------------------------------------------------------------ understanding
    def _understand(self, text: str) -> dict[str, Any]:
        asked = self.st.get("asked")
        ex = nlu.extract_fields(text, self.pack, asked, self.lang)
        if self.en != text:  # LLM translation available: also run the English keyword extractor on it
            ex_en = nlu.extract_fields(self.en, self.pack, asked, "en")
            for k, v in ex_en.fields.items():
                if k == "name" and "name" in ex.fields:
                    continue
                ex.fields.setdefault(k, v)
            ex.is_question = ex.is_question or ex_en.is_question
            ex.booking_signal = ex.booking_signal or ex_en.booking_signal
        out: dict[str, Any] = {"_question": ex.is_question, "_booking": ex.booking_signal}
        llm_fields: dict[str, Any] = {}
        if not self.gw.is_sandbox:
            schema_fields = [{"key": f.key, "type": f.type, "label": f.label, "options": list(f.options) or None} for f in self.pack.fields if f.enabled]
            history = self._recent_history(6)
            model = _llm_schema(self.pack)
            parsed = self.gw.extract(
                extraction_system(self.org.name, self.pack.name, schema_fields, asked),
                [ChatMessage("user", wrap("conversation", history) + "\n\n" + wrap("customer_message", text))],
                model,
            )
            if parsed is not None:
                data = parsed.model_dump()
                out["_intent"] = data.get("intent")
                if data.get("intent") == "question":
                    out["_question"] = True
                llm_fields = {k: v for k, v in (data.get("fields") or {}).items() if v is not None}
        merged: dict[str, Any] = dict(ex.fields)
        for k, v in llm_fields.items():
            f = self.pack.field(k)
            if f is None or not f.enabled or k in merged:
                continue
            valid = nlu.validate_field(f, v)
            if valid is not None:
                merged[k] = valid
        svc = self.pack.field("service_requested")
        if svc and svc.type == "text" and "service_requested" not in merged and "service_requested" not in self.fields and ex.booking_signal and not asked:
            merged["service_requested"] = text[:300]
        for k, v in merged.items():
            if k == "phone" and self.fields.get("phone") and asked != "phone":
                continue
            self.fields[k] = v
        out["_extracted"] = list(merged)
        return out

    def _recent_history(self, n: int) -> str:
        rows = self.db.scalars(
            select(Message)
            .where(Message.conversation_id == self.conv.id, Message.role.in_(("customer", "ai", "human")))
            .order_by(Message.created_at.desc())
            .limit(n)
        ).all()
        return "\n".join(f"{'Customer' if m.role == 'customer' else 'Business'}: {m.content[:400]}" for m in reversed(rows))

    def _has_qualification_signal(self) -> bool:
        contact = {"name", "phone", "email"}
        return any(k not in contact for k in self.fields) and any((f := self.pack.field(k)) is not None and f.required for k in self.fields if k not in contact)

    # ------------------------------------------------------------------ questions
    def _answer_question(self, text: str, booking: bool) -> None:
        info = self._business_info_answer(text)
        if info:
            self.say(info)
            return
        if booking and (SCHEDULING_Q.search(self.en) or nlu.parse_date_preference(text)) and not PRICE_Q.search(self.en):
            return  # handled by the booking flow (real availability)
        answer = self._knowledge_answer(text)
        if answer:
            self.say(answer)
            return
        if booking and self._turn_booking_signal and (i18n.REQUEST_RX.search(text) or i18n.REQUEST_RX.search(self.en)):
            return  # "Can someone come inspect it?" is a service request; the booking flow answers it
        self.say(self.t("no_info"))
        unanswered = int(self.st.get("unanswered", 0)) + 1
        self.st["unanswered"] = unanswered
        if unanswered == 1:
            self.call("create_task", title="Customer question the AI could not answer", description=text[:1000], priority="low")

    def _business_info_answer(self, text: str) -> str | None:
        p = self.profile
        z = nlu.ZIP_RE.search(nlu.PHONE_RE.sub(" ", text))
        if z and (AREA_Q.search(self.en) or AREA_Q.search(text) or nlu.looks_like_question(text)):
            res = self.call("check_service_area", zip=z.group(1))
            if res.data.get("configured") is False:
                return None
            if res.ok:
                self.st["service_area_ok"] = True
                return self.t("area_yes", zip=z.group(1))
            self.st["service_area_ok"] = False
            return self.t("area_no", zip=z.group(1))
        if self._either(HOURS_Q, i18n.HOURS_RX, text):
            self.call("get_business_information", topic="hours")
            return self.t("hours", hours=self._format_hours())
        if self._either(LOCATION_Q, i18n.LOCATION_RX, text) and p.address:
            return self.t("located", address=p.address)
        if PHONE_Q.search(self.en) and p.phone:
            return self.t("reach_us", phone=p.phone)
        if self._either(SERVICES_Q, i18n.SERVICES_RX, text):
            res = self.call("get_business_information", topic="services")
            if res.ok and res.data.get("services"):
                return self.t("we_offer", list=i18n.join_list(list(res.data["services"]), self.lang))
        return None

    def _format_hours(self) -> str:
        hours = self.profile.hours or {}
        chunks = []
        for idx, key in enumerate(("mon", "tue", "wed", "thu", "fri", "sat", "sun")):
            ranges = hours.get(key) or []
            desc = self.t("and").join(f"{self._fmt_t(a)}–{self._fmt_t(b)}" for a, b in ranges) if ranges else self.t("closed")
            chunks.append((i18n.day_name(idx, self.lang) if self.lang != "en" else DAY_NAMES[key], desc))
        # collapse consecutive days with identical hours
        out: list[str] = []
        i = 0
        while i < len(chunks):
            j = i
            while j + 1 < len(chunks) and chunks[j + 1][1] == chunks[i][1]:
                j += 1
            label = chunks[i][0] if i == j else f"{chunks[i][0]}–{chunks[j][0]}"
            out.append(f"{label} {chunks[i][1]}")
            i = j + 1
        return self.t("list_sep").join(out)

    def _fmt_t(self, hhmm: str) -> str:
        t = datetime.strptime(hhmm, "%H:%M")
        if self.lang != "en":
            return i18n.clock(t.hour, t.minute, self.lang)
        return t.strftime("%I:%M %p").lstrip("0").replace(":00 ", " ")

    def _knowledge_answer(self, text: str) -> str | None:
        res = self.call("search_business_knowledge", query=text)
        if not res.ok and self.en != text:
            res = self.call("search_business_knowledge", query=self.en)
        if not res.ok:
            return None
        hits: list[Hit] = res.data["hits"]
        is_price = bool(PRICE_Q.search(self.en) or PRICE_Q.search(text))
        good: list[Hit] = []
        for h in hits:
            coverage_ok = h.coverage >= 0.66 or (h.source_kind == "faq" and h.coverage >= 0.5)
            if not coverage_ok:
                continue
            if is_price and not re.search(r"\$|\bprice|\bpricing|\bcost|\bfee|\bcharge|\brates?\b", h.content, re.I):
                continue
            good.append(h)
        if not good:
            return None
        knowledge_text = "\n\n---\n\n".join(h.content for h in good[:3])
        language = i18n.LANGS[self.lang]["name"]
        llm = self.gw.answer(answer_system(self.org.name, self.agent.name, self.agent.tone, language), text, knowledge_text)
        if llm == "":
            return None
        if llm:
            return llm
        answer = _extractive(good[0], self.en)
        # Without an LLM we can only quote approved knowledge verbatim, so it must already be in the customer's language.
        written_in, _ = i18n.detect(answer)
        if self.lang != "en" and written_in not in (self.lang, None):
            return None
        if self.lang == "en" and written_in not in ("en", None):
            return None
        return answer

    # ------------------------------------------------------------------ booking flow
    def _next_missing(self) -> PackField | None:
        for key in self.pack.collection_order:
            f = self.pack.field(key)
            if f and f.enabled and f.required and self.fields.get(key) in (None, ""):
                return f
        return None

    def _progress_booking(self) -> None:
        z = self.fields.get("zip")
        if z and "service_area_ok" not in self.st:
            res = self.call("check_service_area", zip=z)
            self.st["service_area_ok"] = None if res.data.get("configured") is False else bool(res.ok)
            if self.st["service_area_ok"] is False:
                self.say(self.t("area_no", zip=z))
        missing = self._next_missing()
        if missing is not None:
            if self.st.get("asked") == missing.key:
                if not self._turn_was_question:
                    self.st["ask_count"] = int(self.st.get("ask_count", 0)) + 1
            else:
                self.st["asked"], self.st["ask_count"] = missing.key, 1
            if self.st["ask_count"] >= 4:
                if missing.type in ("enum", "text", "bool"):
                    self.fields[missing.key] = "unspecified"
                    self.st["asked"], self.st["ask_count"] = None, 0
                    return self._progress_booking()
                self.say(self.t("trouble"))
                self._handoff("repeated_ai_failure", f"Could not collect {missing.label}")
                self.conv.ai_failures += 1
                return
            prompt = self._field_prompt(missing)
            if self.st["ask_count"] > 1 and missing.key in ("phone", "zip", "name"):
                prompt = self.t(f"retry_{missing.key}")
            if missing.key == "phone" and self.conv.channel == "web" and self.st["ask_count"] == 1:
                prompt += self.t("sms_disclosure")
            self.say(prompt)
            return
        self.st["asked"] = None
        out_of_area = self.st.get("service_area_ok") is False
        lead_res = self._create_lead(qualified=not out_of_area)
        if not lead_res.ok:
            self.say(self.t("passed_to_team"))
            self._handoff("lead_creation_failed", "Lead could not be saved automatically", announce=False)
            return
        if out_of_area:
            self.st["stage"] = "out_of_area_done"
            self.say(self.t("out_of_area_done", name=self.first_name()))
            return
        if "schedule_appointments" not in (self.agent.capabilities or []):
            self.st["stage"] = "booked"
            self.say(self.t("no_scheduling", name=self.first_name(), appt=self.appt()))
            return
        self._offer_slots(intro=True)

    def _create_lead(self, qualified: bool) -> tools.ToolResult:
        f = self.fields
        qual = {k: v for k, v in f.items() if k not in ("name", "phone", "email")}
        consent = {"web": "web_chat_disclosure", "sms": "inbound_sms"}.get(self.conv.channel)
        if self.conv.channel == "voice" and ((self.org.settings or {}).get("consent") or {}).get("voice_callers_transactional_sms"):
            consent = "voice_call_business_policy"
        service = f.get("service_requested")
        if service and (sf := self.pack.field("service_requested")) and sf.type == "enum":
            service = f"{self.pack.name} {str(service).replace('_', ' ')}"
        res = self.call(
            "create_lead",
            name=f.get("name"),
            phone=f.get("phone"),
            email=f.get("email"),
            zip=f.get("zip"),
            service=service,
            qualification=qual,
            qualified=qualified,
            urgency=f.get("urgency") if isinstance(f.get("urgency"), str) else None,
            summary=self._summary(),
            consent_source=consent,
        )
        if res.ok:
            self.st["lead_id"] = res.data["lead_id"]
        self.conv.summary = self._summary()
        return res

    def _summary(self) -> str:
        f = self.fields
        bits = []
        if f.get("service_requested"):
            bits.append(str(f["service_requested"]).replace("_", " "))
        for key in ("system", "property_type", "timeline"):
            if f.get(key):
                bits.append(str(f[key]).replace("_", " "))
        if f.get("zip"):
            bits.append(f"ZIP {f['zip']}")
        if f.get("urgency"):
            bits.append(f"urgency: {f['urgency']}")
        flags = [fld.label.lower() for fld in self.pack.fields if fld.type == "bool" and f.get(fld.key) is True]
        if flags:
            bits.append(", ".join(flags))
        return f"{self.pack.name} request — " + "; ".join(bits) if bits else f"{self.pack.name} inquiry"

    def _offer_slots(self, intro: bool = False, pref_override: dict[str, Any] | None = None, retaken: bool = False) -> None:
        pref = pref_override if pref_override is not None else (self.st.get("date_pref") or {})
        res = self.call("check_calendar", **{k: v for k, v in pref.items() if v not in (None, False)})
        if not res.ok:
            if res.error == "calendar_unavailable":
                self.say(self.t("calendar_down", name=self.first_name()))
                self.call("create_task", title="Schedule appointment manually (calendar unavailable)", description=self._summary(), priority="high")
            else:
                self.say(self.t("no_availability", name=self.first_name(), appt=self.appt()))
                self.call("create_task", title="No availability — schedule manually", description=self._summary(), priority="high")
            self.st["stage"] = "booked" if self.st["stage"] == "rescheduling" else "awaiting_team"
            return
        slots = res.data["slots"]
        self.st["offered_slots"] = slots
        if self.st["stage"] != "rescheduling":
            self.st["stage"] = "offering"
        prefix = ""
        if retaken:
            prefix = self.t("retaken")
        elif pref and not res.data.get("matched_preference"):
            prefix = self.t("no_pref_match")
        if intro:
            prefix += self.t("thanks_name", name=self.first_name())
        key = "reschedule_openings" if self.st["stage"] == "rescheduling" else "openings"
        self.say(prefix + self.t(key, appt=self.appt(), slots=self.slots_text(slots)))

    def _handle_slot_reply(self, text: str, ex: dict[str, Any]) -> bool:
        offered = self.st.get("offered_slots") or []
        idx = nlu.match_slot_choice(text, offered, self.tz)
        if idx is not None:
            chosen = offered[idx]
            if self.st["stage"] == "rescheduling":
                self._do_reschedule(chosen)
            else:
                self._do_book(chosen)
            return True
        pref = nlu.parse_date_preference(text)
        if nlu.wants_other_times(text) or nlu.wants_other_times(self.en) or pref:
            if not pref:
                # show later openings than those already offered
                last = max(datetime.fromisoformat(s["start"]) for s in offered) if offered else None
                self.st["date_pref"] = {}
                res = self.call("check_calendar", limit=5)
                if res.ok and last:
                    later = [s for s in res.data["slots"] if datetime.fromisoformat(s["start"]) > last][:3]
                    if later:
                        self.st["offered_slots"] = later
                        self.say(self.t("other_openings", slots=self.slots_text(later)))
                        return True
            p = asdict(pref) if pref else {}
            self.st["date_pref"] = p
            self._offer_slots(pref_override=p)
            return True
        if ex.get("_question"):
            self._answer_question(text, True)
            self.say(self.t("and_for_appt", slots=self.slots_text(offered)))
            return True
        if CANCEL_Q.search(self.en) or NO.match(text) or i18n.NO_RX.match(text):
            self.say(self.t("another_day"))
            return True
        self.say(self.t("which_time", slots=self.slots_text(offered)))
        return True

    def _do_book(self, chosen: dict[str, Any]) -> None:
        res = self.call("book_appointment", slot_start=chosen["start"])
        if res.ok:
            self.st["stage"] = "booked"
            self.st["appointment_id"] = res.data["appointment_id"]
            self.st.pop("offered_slots", None)
            when = self.when(chosen["start"])
            appt = self.appt()
            msg = self.t("booked", name=self.first_name(), appt=appt, appt_cap=appt[:1].upper() + appt[1:], when=when)
            if self.conv.channel != "sms" and self.fields.get("phone") and crm.org_sending_number(self.db, self.org.id) is not None:
                sms = self.call("send_sms", purpose="confirmation", body=self.t("conf_sms", org=self.org.name, appt=appt, when=when))
                if sms.ok and sms.data.get("delivered_for_real"):
                    msg += self.t("texted")
            msg += self.t("anything_else")
            self.say(msg)
            return
        if res.error == "slot_unavailable":
            self._offer_slots(retaken=True)
            return
        self.say(self.t("booking_failed"))
        self._handoff("booking_failed", f"Booking failed ({res.error}) for {chosen.get('label')}", announce=False)

    def _start_reschedule(self, text: str) -> None:
        pref = nlu.parse_date_preference(text)
        self.st["stage"] = "rescheduling"
        self._offer_slots(pref_override=asdict(pref) if pref else {})

    def _do_reschedule(self, chosen: dict[str, Any]) -> None:
        res = self.call("reschedule_appointment", new_start=chosen["start"])
        if res.ok:
            self.st["stage"] = "booked"
            self.st.pop("offered_slots", None)
            self.say(self.t("rescheduled", when=self.when(chosen["start"])))
        elif res.error == "slot_unavailable":
            self._offer_slots(retaken=True)
        else:
            self.say(self.t("reschedule_failed"))
            self._handoff("reschedule_failed", str(res.error), announce=False)

    def _handle_cancel_confirmation(self, text: str) -> None:
        if YES.match(text) or i18n.YES_RX.match(text):
            res = self.call("cancel_appointment", confirmed=True)
            self.st["stage"] = "open" if res.ok else "booked"
            if res.ok:
                self.st.pop("appointment_id", None)
                self.say(self.t("cancelled"))
            else:
                self.say(self.t("cancel_failed"))
                self._handoff("cancel_failed", str(res.error), announce=False)
        elif NO.match(text) or i18n.NO_RX.match(text):
            self.st["stage"] = "booked"
            self.say(self.t("kept"))
        else:
            self.say(self.t("yes_or_no"))


def _extractive(hit: Hit, question: str) -> str:
    content = hit.content
    if content.startswith("Q:") and "\nA:" in content:
        return content.split("\nA:", 1)[1].strip()[:600]
    q_terms = {w[:5] for w in re.findall(r"[a-z]{3,}", question.lower())} - {
        "what",
        "your",
        "does",
        "have",
        "with",
        "about",
        "there",
        "which",
        "would",
        "could",
    }
    sentences = re.split(r"(?<=[.!?])\s+", content.replace("\n", " "))
    scored = [(sum(1 for w in re.findall(r"[a-z]{3,}", s.lower()) if w[:5] in q_terms), i, s) for i, s in enumerate(sentences)]
    best = sorted([x for x in scored if x[0] > 0], key=lambda x: (-x[0], x[1]))[:2]
    if not best:
        return content[:400]
    return " ".join(s for _, _, s in sorted(best, key=lambda x: x[1])).strip()[:600]


# ------------------------------------------------------------------ conversation service


def greeting_for(org: Organization, agent: AIAgent, language: str | None) -> str:
    """The agent's greeting in the requested language: owner-written per-language greeting, the owner's main
    greeting when it is the agent's default language, otherwise the translated default greeting."""
    lang = language or agent.language or "en"
    custom = (agent.greetings or {}).get(lang)
    if custom:
        return str(custom)
    if lang == (agent.language or "en"):
        return agent.greeting
    return i18n.t("greeting_default", lang, org=org.name, agent=agent.name)


def start_conversation(
    db: Session,
    org: Organization,
    agent: AIAgent,
    channel: str,
    *,
    contact: str | None = None,
    external_id: str | None = None,
    is_test: bool = False,
    customer: Customer | None = None,
    greet: bool = True,
    language: str | None = None,
) -> Conversation:
    allowed = list(agent.languages or [agent.language or "en"])
    language = language if language in allowed else None
    conv = Conversation(
        organization_id=org.id,
        agent_id=agent.id,
        channel=channel,
        contact_address=contact,
        external_id=external_id,
        is_test=is_test,
        customer_id=customer.id if customer else None,
        state={"fields": {"phone": contact} if contact and channel in ("sms", "voice") else {}, "stage": "open"},
        language=language,
    )
    db.add(conv)
    db.flush()
    if greet:
        db.add(Message(organization_id=org.id, conversation_id=conv.id, role="ai", content=greeting_for(org, agent, language), meta={"greeting": True}))
    emit_event(db, org.id, "conversation.started", channel=channel, conversation_id=conv.id, agent_id=agent.id, is_test=is_test)
    if not is_test and not org.is_demo:
        billing.record_usage(db, org.id, "conversation", 1, channel=channel, agent_id=agent.id, conversation_id=conv.id)
    return conv


def process_customer_message(
    db: Session, org: Organization, agent: AIAgent, conv: Conversation, text: str, *, provider_message_id: str | None = None
) -> tuple[Message, TurnResult, Message | None]:
    """Store the customer's message, run the orchestrator, store the AI reply. Caller commits."""
    received_at = utcnow()
    cmsg = Message(
        organization_id=org.id,
        conversation_id=conv.id,
        role="customer",
        content=text[:4000],
        provider_message_id=provider_message_id,
        meta={"channel": conv.channel},
    )
    db.add(cmsg)
    db.flush()
    conv.last_message_at = received_at
    if conv.status == "resolved":
        conv.status = "open"
    result = Orchestrator(db, org, agent, conv).handle(text)
    reply_msg = None
    if result.reply:
        reply_msg = Message(
            organization_id=org.id,
            conversation_id=conv.id,
            role="ai",
            content=result.reply,
            meta={"prompt_version": PROMPT_VERSION, "actions": [a["tool"] for a in result.actions]},
        )
        db.add(reply_msg)
        if conv.first_response_ms is None:
            conv.first_response_ms = int((utcnow() - received_at).total_seconds() * 1000) or 1
            emit_event(
                db,
                org.id,
                "conversation.first_response",
                channel=conv.channel,
                conversation_id=conv.id,
                data={"ms": conv.first_response_ms},
                is_test=conv.is_test,
            )
        conv.last_message_at = utcnow()
    return cmsg, result, reply_msg
