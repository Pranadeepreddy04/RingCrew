"""Permission-controlled, schema-validated tools (spec §14, §43, §73, §88).

The AI layer can only *propose* these typed actions. Every call is validated (schema, tenant,
agent capability, resource ownership, business rules, consent) and executed by the backend,
which returns the actual result. Tenant scope always comes from the server-side context,
never from tool arguments."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Literal
from zoneinfo import ZoneInfo

from pydantic import BaseModel, Field, ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.nlu import DatePreference
from app.industry import ResolvedPack
from app.models import AIAgent, Appointment, BusinessProfile, Conversation, Customer, Lead, Message, Organization, Service, Task
from app.observability import metrics
from app.services import crm, knowledge, scheduling
from app.services.common import emit_event, utcnow

CAPABILITIES = [
    "answer_calls",
    "answer_sms",
    "web_chat",
    "capture_leads",
    "qualify_leads",
    "schedule_appointments",
    "collect_quote_info",
    "follow_up",
    "send_reminders",
    "transfer_calls",
    "answer_faqs",
]


@dataclass
class ToolContext:
    db: Session
    org: Organization
    agent: AIAgent
    conversation: Conversation
    profile: BusinessProfile
    pack: ResolvedPack
    log: list[dict[str, Any]] = field(default_factory=list)

    @property
    def tz(self) -> ZoneInfo:
        return ZoneInfo(self.org.timezone)


@dataclass
class ToolResult:
    ok: bool
    data: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    message: str | None = None


@dataclass
class ToolDef:
    name: str
    input: type[BaseModel]
    capability: str | None
    handler: Callable[[ToolContext, Any], ToolResult]
    high_impact: bool = False
    log_args: bool = True


REGISTRY: dict[str, ToolDef] = {}


def tool(name: str, input_model: type[BaseModel], capability: str | None, *, high_impact: bool = False, log_args: bool = True):
    def deco(fn: Callable[[ToolContext, Any], ToolResult]) -> Callable[[ToolContext, Any], ToolResult]:
        REGISTRY[name] = ToolDef(name, input_model, capability, fn, high_impact, log_args)
        return fn

    return deco


def execute(ctx: ToolContext, name: str, args: dict[str, Any]) -> ToolResult:
    td = REGISTRY.get(name)
    if td is None:
        return _log(ctx, name, args, ToolResult(False, error="unknown_tool"), log_args=False)
    if td.capability and td.capability not in (ctx.agent.capabilities or []):
        return _log(ctx, name, args, ToolResult(False, error="capability_disabled", message=f"{td.capability} is not enabled for this AI employee"))
    try:
        parsed = td.input.model_validate(args)
    except ValidationError as exc:
        return _log(ctx, name, args, ToolResult(False, error="invalid_arguments", message=str(exc.errors()[:3])))
    if ctx.conversation.is_test and name in SIDE_EFFECT_TOOLS:
        return _log(ctx, name, args if td.log_args else {}, _simulate(ctx, name, parsed))
    try:
        result = td.handler(ctx, parsed)
    except Exception as exc:  # tool failures are reported, never masked as success
        metrics.inc("ai_tool_calls_total", tool=name, status="exception")
        return _log(ctx, name, args, ToolResult(False, error="tool_exception", message=exc.__class__.__name__))
    return _log(ctx, name, args if td.log_args else {}, result)


_REDACT = {"phone", "email", "name", "address"}

SIDE_EFFECT_TOOLS = {
    "create_lead",
    "update_lead",
    "update_crm",
    "book_appointment",
    "reschedule_appointment",
    "cancel_appointment",
    "send_sms",
    "create_task",
    "request_human_help",
    "transfer_to_human",
    "create_quote_request",
    "request_photo",
}


def _simulate(ctx: ToolContext, name: str, a: Any) -> ToolResult:
    """Test/demo conversations: validate exactly like production, but perform no side effects (dry run)."""
    dry = {"dry_run": True}
    if name in ("book_appointment", "reschedule_appointment"):
        start = a.slot_start if name == "book_appointment" else a.new_start
        if not _require_offered(ctx, start):
            return ToolResult(False, error="slot_not_offered")
        return ToolResult(True, {**dry, "appointment_id": "dry-run", "label": scheduling.format_when(start, ctx.tz), "duplicate": False})
    if name == "create_lead" and not (a.phone or a.email):
        return ToolResult(False, error="contact_required")
    if name in ("request_human_help", "transfer_to_human"):
        ctx.conversation.handoff_active = True
        ctx.conversation.status = "needs_human"
        ctx.conversation.handoff_reason = a.reason
        return ToolResult(True, {**dry, "task_id": "dry-run", "transfer_to": None})
    if name == "send_sms":
        return ToolResult(True, {**dry, "delivered_for_real": False})
    return ToolResult(True, {**dry, "lead_id": "dry-run", "customer_id": None, "created": True, "task_id": "dry-run", "appointment_id": "dry-run"})


def _log(ctx: ToolContext, name: str, args: dict[str, Any], result: ToolResult, log_args: bool = True) -> ToolResult:
    safe_args = {k: ("[redacted]" if k in _REDACT else v) for k, v in args.items()} if log_args else {}
    entry = {"tool": name, "ok": result.ok, "error": result.error, "args": _jsonable(safe_args)}
    ctx.log.append(entry)
    metrics.inc("ai_tool_calls_total", tool=name, status="ok" if result.ok else (result.error or "error"))
    summary = TOOL_SUMMARY.get(name, name.replace("_", " "))
    ctx.db.add(
        Message(
            organization_id=ctx.org.id,
            conversation_id=ctx.conversation.id,
            role="tool",
            content=f"{summary}: {'success' if result.ok else 'failed — ' + (result.error or 'error')}",
            meta={
                "tool": name,
                "ok": result.ok,
                "error": result.error,
                "args": entry["args"],
                "result": _jsonable({k: v for k, v in result.data.items() if k not in ("hits",)}),
            },
        )
    )
    if not result.ok and result.error not in ("no_results", "outside_service_area"):
        emit_event(
            ctx.db,
            ctx.org.id,
            "ai.tool_failed",
            channel=ctx.conversation.channel,
            conversation_id=ctx.conversation.id,
            agent_id=ctx.agent.id,
            data={"tool": name, "error": result.error},
            is_test=ctx.conversation.is_test,
        )
    return result


def _jsonable(v: Any) -> Any:
    if isinstance(v, dict):
        return {k: _jsonable(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    if isinstance(v, (datetime,)):
        return v.isoformat()
    if isinstance(v, uuid.UUID):
        return str(v)
    return v


TOOL_SUMMARY = {
    "search_business_knowledge": "Searched business knowledge",
    "get_business_information": "Looked up business information",
    "check_service_area": "Checked service area",
    "create_lead": "Created/updated lead",
    "update_lead": "Updated lead",
    "check_calendar": "Checked calendar availability",
    "book_appointment": "Booked appointment",
    "reschedule_appointment": "Rescheduled appointment",
    "cancel_appointment": "Cancelled appointment",
    "send_sms": "Sent SMS",
    "create_task": "Created staff task",
    "transfer_to_human": "Transferred to human",
    "request_human_help": "Requested human help",
    "create_quote_request": "Created quote request",
    "request_photo": "Requested photos",
    "update_crm": "Synced CRM",
}

# ------------------------------------------------------------------ knowledge / info


class SearchIn(BaseModel):
    query: str = Field(min_length=1, max_length=500)


@tool("search_business_knowledge", SearchIn, "answer_faqs")
def _search(ctx: ToolContext, a: SearchIn) -> ToolResult:
    hits = knowledge.search(ctx.db, ctx.org.id, a.query)
    if not hits:
        return ToolResult(False, error="no_results")
    return ToolResult(True, {"hits": hits, "top": [h.as_dict() for h in hits[:3]]})


class InfoIn(BaseModel):
    topic: Literal["hours", "service_area", "contact", "services", "all"]


@tool("get_business_information", InfoIn, None)
def _info(ctx: ToolContext, a: InfoIn) -> ToolResult:
    p = ctx.profile
    services = ctx.db.scalars(select(Service.name).where(Service.organization_id == ctx.org.id, Service.active.is_(True)).order_by(Service.name)).all()
    return ToolResult(
        True,
        {
            "hours": p.hours,
            "service_area_zips": p.service_area_zips,
            "service_area_description": p.service_area_description,
            "phone": p.phone,
            "address": p.address,
            "services": list(services),
            "timezone": ctx.org.timezone,
        },
    )


class AreaIn(BaseModel):
    zip: str = Field(pattern=r"^\d{5}$")


@tool("check_service_area", AreaIn, None)
def _area(ctx: ToolContext, a: AreaIn) -> ToolResult:
    zips = ctx.profile.service_area_zips or []
    if not zips:
        return ToolResult(True, {"in_area": None, "configured": False})
    return (
        ToolResult(True, {"in_area": a.zip in zips, "configured": True})
        if a.zip in zips
        else ToolResult(False, {"in_area": False, "configured": True}, error="outside_service_area")
    )


# ------------------------------------------------------------------ CRM


class LeadIn(BaseModel):
    name: str | None = Field(default=None, max_length=200)
    phone: str | None = Field(default=None, pattern=r"^\+1\d{10}$")
    email: str | None = Field(default=None, max_length=320)
    zip: str | None = Field(default=None, pattern=r"^\d{5}$")
    service: str | None = Field(default=None, max_length=300)
    qualification: dict[str, Any] = Field(default_factory=dict)
    qualified: bool = False
    urgency: str | None = Field(default=None, max_length=20)
    summary: str | None = Field(default=None, max_length=2000)
    consent_source: str | None = Field(default=None, max_length=100)


@tool("create_lead", LeadIn, "capture_leads", log_args=False)
def _create_lead(ctx: ToolContext, a: LeadIn) -> ToolResult:
    if not (a.phone or a.email):
        return ToolResult(False, error="contact_required", message="A phone number or email is required")
    customer = crm.find_or_create_customer(ctx.db, ctx.org.id, phone=a.phone, email=a.email, name=a.name, zip_code=a.zip)
    ctx.conversation.customer_id = customer.id
    if a.consent_source and a.phone and not customer.sms_opted_out:
        if not crm.has_sms_consent(ctx.db, customer):
            crm.record_consent(ctx.db, customer, "sms", "transactional", "granted", a.consent_source)
    channel = ctx.conversation.channel
    source = {"web": "ai_web_chat", "sms": "ai_sms", "voice": "ai_phone", "test": "ai_test"}.get(channel, "ai_" + channel)
    lead, created = crm.create_or_update_lead(
        ctx.db,
        ctx.org,
        customer=customer,
        conversation=ctx.conversation,
        agent=ctx.agent,
        source=source,
        channel=channel,
        service=a.service,
        qualification=a.qualification,
        qualified=a.qualified,
        urgency=a.urgency,
        summary=a.summary,
    )
    return ToolResult(True, {"lead_id": str(lead.id), "customer_id": str(customer.id), "created": created})


class UpdateLeadIn(BaseModel):
    qualification: dict[str, Any] = Field(default_factory=dict)
    summary: str | None = Field(default=None, max_length=2000)


@tool("update_lead", UpdateLeadIn, "capture_leads")
def _update_lead(ctx: ToolContext, a: UpdateLeadIn) -> ToolResult:
    lead = _conv_lead(ctx)
    if lead is None:
        return ToolResult(False, error="no_lead")
    lead.qualification = {**(lead.qualification or {}), **a.qualification}
    if a.summary:
        lead.summary = a.summary
    lead.last_activity_at = utcnow()
    return ToolResult(True, {"lead_id": str(lead.id)})


def _conv_lead(ctx: ToolContext) -> Lead | None:
    if not ctx.conversation.lead_id:
        return None
    return ctx.db.scalar(select(Lead).where(Lead.id == ctx.conversation.lead_id, Lead.organization_id == ctx.org.id))


@tool("update_crm", UpdateLeadIn, "capture_leads")
def _update_crm(ctx: ToolContext, a: UpdateLeadIn) -> ToolResult:
    res = _update_lead(ctx, a)
    if res.ok:
        from app.services.common import enqueue_job

        enqueue_job(ctx.db, "crm.sync_lead", {"lead_id": res.data["lead_id"]}, org_id=ctx.org.id)
    return res


# ------------------------------------------------------------------ scheduling


class CalendarIn(BaseModel):
    weekday: int | None = Field(default=None, ge=0, le=6)
    relative_days: int | None = Field(default=None, ge=0, le=60)
    part_of_day: Literal["morning", "afternoon", "evening"] | None = None
    next_week: bool = False
    limit: int = Field(default=3, ge=1, le=5)


@tool("check_calendar", CalendarIn, "schedule_appointments")
def _check_calendar(ctx: ToolContext, a: CalendarIn) -> ToolResult:
    pref = (
        DatePreference(a.weekday, a.relative_days, a.part_of_day, a.next_week)
        if any((a.weekday is not None, a.relative_days is not None, a.part_of_day, a.next_week))
        else None
    )
    try:
        slots = scheduling.available_slots(ctx.db, ctx.org, ctx.profile)
    except scheduling.AvailabilityError as exc:
        return ToolResult(False, error="calendar_unavailable", message=str(exc))
    offer, matched = scheduling.pick_offer(slots, ctx.tz, pref, a.limit)
    if not offer:
        return ToolResult(False, error="no_availability")
    return ToolResult(True, {"slots": [s.as_dict(ctx.tz) for s in offer], "matched_preference": matched})


class BookIn(BaseModel):
    slot_start: datetime


def _require_offered(ctx: ToolContext, start: datetime) -> bool:
    """High-impact validation: the AI may only book a slot the backend actually offered in this conversation."""
    offered = (ctx.conversation.state or {}).get("offered_slots", [])
    return any(datetime.fromisoformat(s["start"]) == start for s in offered)


@tool("book_appointment", BookIn, "schedule_appointments", high_impact=True)
def _book(ctx: ToolContext, a: BookIn) -> ToolResult:
    if ctx.org.is_demo:
        return ToolResult(False, error="demo_mode", message="Bookings are disabled in demo mode")
    if not _require_offered(ctx, a.slot_start):
        return ToolResult(False, error="slot_not_offered")
    lead = _conv_lead(ctx)
    customer = ctx.db.get(Customer, ctx.conversation.customer_id) if ctx.conversation.customer_id else None
    if lead is None or customer is None or customer.organization_id != ctx.org.id:
        return ToolResult(False, error="lead_required")
    fields = (ctx.conversation.state or {}).get("fields", {})
    notes = "\n".join(f"{k.replace('_', ' ').capitalize()}: {v}" for k, v in fields.items() if k not in ("name", "phone", "email"))
    res = scheduling.book(
        ctx.db,
        ctx.org,
        ctx.profile,
        customer=customer,
        start=a.slot_start,
        service=f"{ctx.pack.appointment_label.capitalize()} — {lead.service or ctx.pack.default_service}",
        source=lead.source,
        idempotency_key=f"conv:{ctx.conversation.id}:{a.slot_start.isoformat()}",
        lead_id=lead.id,
        conversation_id=ctx.conversation.id,
        notes=notes,
        location=f"ZIP {fields.get('zip')}" if fields.get("zip") else None,
    )
    if not res.ok or res.appointment is None:
        return ToolResult(False, error=res.error_code, message=res.message)
    appt = res.appointment
    if not res.duplicate:
        if lead.status in ("new", "contacted", "qualified"):
            lead.status = "appointment"
        lead.last_activity_at = utcnow()
        crm.stop_workflow_runs(ctx.db, lead_id=lead.id, reason="appointment_booked")
        emit_event(
            ctx.db,
            ctx.org.id,
            "appointment.created",
            channel=ctx.conversation.channel,
            conversation_id=ctx.conversation.id,
            lead_id=lead.id,
            agent_id=ctx.agent.id,
            data={"appointment_id": str(appt.id), "by": "ai"},
            webhook_payload={
                "appointment_id": str(appt.id),
                "lead_id": str(lead.id),
                "start_at": appt.start_at.isoformat(),
                "end_at": appt.end_at.isoformat(),
                "service": appt.service,
                "customer_id": str(customer.id),
            },
            is_test=ctx.conversation.is_test,
        )
        if not ctx.conversation.is_test:
            from app.services.automation import start_workflows
            from app.services.common import notify

            notify(
                ctx.db,
                ctx.org.id,
                "appointment.created",
                f"Appointment booked: {customer.name or customer.phone}",
                f"{appt.service} — {scheduling.format_when(appt.start_at, ctx.tz)}",
                f"/app/appointments?id={appt.id}",
            )
            start_workflows(ctx.db, ctx.org, "appointment.created", customer=customer, lead=lead, appointment=appt)
    return ToolResult(
        True,
        {
            "appointment_id": str(appt.id),
            "start": appt.start_at.isoformat(),
            "label": scheduling.format_when(appt.start_at, ctx.tz),
            "duplicate": res.duplicate,
        },
    )


def _conv_appointment(ctx: ToolContext) -> Appointment | None:
    aid = (ctx.conversation.state or {}).get("appointment_id")
    if aid:
        return ctx.db.scalar(select(Appointment).where(Appointment.id == uuid.UUID(aid), Appointment.organization_id == ctx.org.id))
    if ctx.conversation.customer_id:
        return crm.upcoming_appointment(ctx.db, ctx.org.id, ctx.conversation.customer_id)
    return None


class RescheduleIn(BaseModel):
    new_start: datetime


@tool("reschedule_appointment", RescheduleIn, "schedule_appointments", high_impact=True)
def _reschedule(ctx: ToolContext, a: RescheduleIn) -> ToolResult:
    appt = _conv_appointment(ctx)
    if appt is None:
        return ToolResult(False, error="no_appointment")
    if not _require_offered(ctx, a.new_start):
        return ToolResult(False, error="slot_not_offered")
    res = scheduling.reschedule(ctx.db, ctx.org, ctx.profile, appt, a.new_start)
    if not res.ok:
        return ToolResult(False, error=res.error_code, message=res.message)
    emit_event(
        ctx.db,
        ctx.org.id,
        "appointment.rescheduled",
        conversation_id=ctx.conversation.id,
        lead_id=appt.lead_id,
        webhook_payload={"appointment_id": str(appt.id), "start_at": appt.start_at.isoformat()},
        is_test=ctx.conversation.is_test,
    )
    return ToolResult(True, {"appointment_id": str(appt.id), "label": scheduling.format_when(appt.start_at, ctx.tz)})


class CancelIn(BaseModel):
    confirmed: bool


@tool("cancel_appointment", CancelIn, "schedule_appointments", high_impact=True)
def _cancel(ctx: ToolContext, a: CancelIn) -> ToolResult:
    if not a.confirmed:
        return ToolResult(False, error="confirmation_required")
    appt = _conv_appointment(ctx)
    if appt is None:
        return ToolResult(False, error="no_appointment")
    res = scheduling.cancel(ctx.db, ctx.org, appt)
    if not res.ok:
        return ToolResult(False, error=res.error_code, message=res.message)
    crm.stop_workflow_runs(ctx.db, appointment_id=appt.id, reason="appointment_cancelled")
    emit_event(
        ctx.db,
        ctx.org.id,
        "appointment.cancelled",
        conversation_id=ctx.conversation.id,
        lead_id=appt.lead_id,
        webhook_payload={"appointment_id": str(appt.id)},
        is_test=ctx.conversation.is_test,
    )
    if not ctx.conversation.is_test:
        from app.services.common import notify

        notify(ctx.db, ctx.org.id, "appointment.cancelled", "Appointment cancelled by customer", appt.service, f"/app/appointments?id={appt.id}")
    return ToolResult(True, {"appointment_id": str(appt.id)})


# ------------------------------------------------------------------ communication & handoff


class SmsIn(BaseModel):
    body: str = Field(min_length=1, max_length=640)
    purpose: Literal["confirmation", "reply"]


@tool("send_sms", SmsIn, None)
def _send_sms(ctx: ToolContext, a: SmsIn) -> ToolResult:
    if not ({"answer_sms", "send_reminders", "follow_up"} & set(ctx.agent.capabilities or [])):
        return ToolResult(False, error="capability_disabled")
    customer = ctx.db.get(Customer, ctx.conversation.customer_id) if ctx.conversation.customer_id else None
    if customer is None:
        return ToolResult(False, error="no_customer")
    r = crm.send_sms(ctx.db, ctx.org, customer, a.body, purpose=a.purpose, idempotency_key=f"conv:{ctx.conversation.id}:{a.purpose}")
    if not r.ok:
        return ToolResult(False, error=r.error or "send_failed")
    return ToolResult(True, {"provider": r.provider, "status": r.status, "delivered_for_real": r.provider != "sandbox"})


class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    description: str | None = Field(default=None, max_length=4000)
    priority: Literal["low", "normal", "high"] = "normal"


@tool("create_task", TaskIn, None)
def _task(ctx: ToolContext, a: TaskIn) -> ToolResult:
    t = Task(
        organization_id=ctx.org.id,
        kind="general",
        title=a.title,
        description=a.description,
        priority=a.priority,
        conversation_id=ctx.conversation.id,
        lead_id=ctx.conversation.lead_id,
        customer_id=ctx.conversation.customer_id,
    )
    ctx.db.add(t)
    ctx.db.flush()
    return ToolResult(True, {"task_id": str(t.id)})


class HandoffIn(BaseModel):
    reason: str = Field(min_length=2, max_length=60)
    summary: str | None = Field(default=None, max_length=2000)


@tool("request_human_help", HandoffIn, None)
def _handoff(ctx: ToolContext, a: HandoffIn) -> ToolResult:
    task = crm.start_handoff(ctx.db, ctx.org, ctx.conversation, a.reason, summary=a.summary, details=(ctx.conversation.state or {}).get("fields", {}))
    return ToolResult(True, {"task_id": str(task.id)})


@tool("transfer_to_human", HandoffIn, None)
def _transfer(ctx: ToolContext, a: HandoffIn) -> ToolResult:
    res = _handoff(ctx, a)
    number = ctx.profile.escalation_phone or ctx.profile.phone
    can_transfer = ctx.conversation.channel == "voice" and "transfer_calls" in (ctx.agent.capabilities or []) and bool(number)
    res.data["transfer_to"] = number if can_transfer else None
    return res


class QuoteIn(BaseModel):
    details: str = Field(min_length=3, max_length=4000)


@tool("create_quote_request", QuoteIn, "collect_quote_info")
def _quote(ctx: ToolContext, a: QuoteIn) -> ToolResult:
    lead = _conv_lead(ctx)
    if lead is None:
        return ToolResult(False, error="lead_required")
    t = Task(
        organization_id=ctx.org.id,
        kind="quote",
        title=f"Prepare estimate: {lead.service or 'request'}",
        description=a.details,
        conversation_id=ctx.conversation.id,
        lead_id=lead.id,
        customer_id=lead.customer_id,
        priority="normal",
    )
    ctx.db.add(t)
    ctx.db.flush()
    return ToolResult(True, {"task_id": str(t.id)})


class PhotoIn(BaseModel):
    note: str | None = Field(default=None, max_length=300)


@tool("request_photo", PhotoIn, "collect_quote_info")
def _photo(ctx: ToolContext, a: PhotoIn) -> ToolResult:
    from app.services.files import upload_token

    token = upload_token(ctx.org.id, ctx.conversation.id)
    return ToolResult(True, {"upload_token": token, "expires_in": 86400})


def slot_prompt(slots: list[dict[str, Any]]) -> str:
    labels = [s["label"] for s in slots]
    if len(labels) == 1:
        return f"{labels[0]}. Does that work for you?"
    joined = ", ".join(labels[:-1]) + f", or {labels[-1]}"
    return f"{joined}. Which works best?"
