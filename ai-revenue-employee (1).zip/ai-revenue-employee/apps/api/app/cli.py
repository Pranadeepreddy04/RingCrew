"""Operator CLI.

python -m app.cli bootstrap                 # idempotent: sync industry packs + plans (safe in production)
python -m app.cli seed-demo                 # development only: demo businesses with fake data
python -m app.cli create-superadmin EMAIL   # prompts for password
python -m app.cli gen-key                   # prints a new ENCRYPTION_KEY
python -m app.cli check-config              # validates configuration for the current APP_ENV
"""

from __future__ import annotations

import getpass
import random
import sys
import uuid
from datetime import datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from cryptography.fernet import Fernet
from sqlalchemy import func, select

from app.ai import i18n
from app.config import get_settings
from app.db import SessionLocal
from app.industry import sync_packs_to_db
from app.models import (
    AIAgent,
    Appointment,
    BusinessProfile,
    Conversation,
    Customer,
    CustomerConsent,
    Event,
    KnowledgeSource,
    Lead,
    Membership,
    Message,
    Organization,
    PhoneNumber,
    Service,
    User,
)
from app.security import hash_password, new_token
from app.services import billing
from app.services.common import utcnow
from app.services.knowledge import index_source

DEMO_PASSWORD = "DemoPass!2026"


def bootstrap() -> None:
    with SessionLocal() as db:
        n = sync_packs_to_db(db)
        billing.seed_plans(db)
        db.commit()
        print(f"bootstrap: {n} industry templates synced; plans ensured")


def create_superadmin(email: str, password: str | None = None) -> None:
    password = password or getpass.getpass("Password: ")
    if len(password) < 12:
        sys.exit("Password must be at least 12 characters")
    with SessionLocal() as db:
        u = db.scalar(select(User).where(func.lower(User.email) == email.lower()))
        if u is None:
            u = User(email=email.lower(), name="Platform Admin", password_hash=hash_password(password), email_verified_at=utcnow())
            db.add(u)
        u.is_superadmin = True
        u.password_hash = hash_password(password)
        db.commit()
        print(f"superadmin ready: {email}")


FIRST = [
    "James",
    "Maria",
    "Robert",
    "Linda",
    "Michael",
    "Patricia",
    "David",
    "Jennifer",
    "Daniel",
    "Elizabeth",
    "Chris",
    "Sarah",
    "Kevin",
    "Laura",
    "Brian",
    "Nancy",
]
LAST = ["Carter", "Nguyen", "Brooks", "Patel", "Reyes", "Foster", "Hughes", "Price", "Bennett", "Coleman", "Russell", "Griffin", "Hayes", "Myers", "Ford"]

DEMOS: list[dict[str, Any]] = [
    {
        "name": "Mike's Roofing",
        "industry": "roofing",
        "email": "mike@mikes-roofing.example.com",
        "agent": "Sarah",
        "zips": ["76201", "76205", "76207", "76209", "76210", "76226"],
        "services": [
            ("Roof repair", "Leak repair, missing shingles, flashing and storm damage repair."),
            ("Roof replacement", "Full tear-off and replacement with architectural shingles."),
            ("Roof inspection", "Free 45-minute inspection with photos and a written report."),
        ],
        "faqs": [
            ("Do you offer free inspections?", "Yes — roof inspections are free and take about 45 minutes. We send photos and a written report."),
            (
                "Do you work with insurance companies?",
                "Yes. We can document storm damage and meet your insurance adjuster on site. We do not file claims on your behalf.",
            ),
            ("Are you licensed and insured?", "Yes, we are fully insured and carry general liability and workers' compensation coverage."),
            ("Do you offer financing?", "Yes, financing is available on approved credit for replacements. Ask the inspector for details."),
            ("What warranty do you offer?", "Replacements include a 10-year workmanship warranty in addition to the manufacturer's shingle warranty."),
        ],
        "value": (4000_00, 18000_00),
        "service_words": ["Roof leak / storm damage", "Roof replacement", "Hail damage inspection", "Missing shingles repair"],
    },
    {
        "name": "CoolAir HVAC",
        "industry": "hvac",
        "email": "owner@coolair-hvac.example.com",
        "agent": "Alex",
        "zips": ["75001", "75006", "75007", "75010"],
        "services": [
            ("AC repair", "Diagnosis and repair of central air and heat pump systems."),
            ("Furnace repair", "Gas and electric furnace diagnosis and repair."),
            ("Maintenance plan", "Twice-yearly tune-ups with priority scheduling."),
        ],
        "faqs": [
            ("Do you charge a service call fee?", "Yes, our diagnostic visit is $89, which is waived if you approve the repair."),
            ("Do you offer maintenance plans?", "Yes — our Comfort Plan includes two tune-ups per year and priority scheduling."),
        ],
        "value": (200_00, 9000_00),
        "service_words": ["AC not cooling", "Furnace not heating", "Maintenance tune-up", "System replacement estimate"],
    },
    {
        "name": "Rapid Plumbing",
        "industry": "plumbing",
        "email": "owner@rapid-plumbing.example.com",
        "agent": "Emma",
        "zips": ["76101", "76102", "76103", "76104"],
        "services": [
            ("Drain cleaning", "Kitchen, bathroom and main-line drain clearing."),
            ("Water heater service", "Repair and replacement of tank and tankless water heaters."),
            ("Leak repair", "Pipe, fixture and slab leak repair."),
        ],
        "faqs": [
            ("Do you offer emergency service?", "Yes, we offer 24/7 emergency service for active leaks and sewer backups."),
            ("Do you install tankless water heaters?", "Yes, we install and service tankless water heaters from major brands."),
        ],
        "value": (150_00, 5000_00),
        "service_words": ["Clogged kitchen drain", "Water heater leaking", "Burst pipe", "Toilet running"],
    },
]


def seed_demo() -> None:
    if get_settings().app_env == "production":
        sys.exit("Refusing to seed demo data in production")
    bootstrap()
    rnd = random.Random(42)
    from app.routers.organizations import DEFAULT_HOURS, default_workflows

    with SessionLocal() as db:
        for d in DEMOS:
            if db.scalar(select(Organization.id).where(Organization.name == d["name"], Organization.is_demo.is_(False))):
                print(f"skip existing {d['name']}")
                continue
            user = db.scalar(select(User).where(User.email == d["email"]))
            if user is None:
                user = User(
                    email=d["email"],
                    name=d["name"].split("'")[0].split(" ")[0] + " (demo owner)",
                    password_hash=hash_password(DEMO_PASSWORD),
                    email_verified_at=utcnow(),
                )
                db.add(user)
                db.flush()
            tz = ZoneInfo("America/Chicago")
            org = Organization(
                name=d["name"],
                slug=d["name"].lower().replace("'", "").replace(" ", "-") + "-" + uuid.uuid4().hex[:4],
                industry=d["industry"],
                timezone="America/Chicago",
                onboarding_step=9,
                onboarding_completed_at=utcnow(),
                settings={
                    "pipeline_stages": ["new", "contacted", "qualified", "appointment", "estimate", "won", "lost"],
                    "recording": {"enabled": False, "consent_configured": False},
                    "ai": {"allow_fallback_provider": False},
                },
            )
            db.add(org)
            db.flush()
            db.add(Membership(organization_id=org.id, user_id=user.id, role="owner"))
            profile = BusinessProfile(
                organization_id=org.id,
                website=None,
                phone="+19405550100",
                address="100 Demo St, Denton, TX 76201",
                description=f"{d['name']} is a family-owned {d['industry']} company serving North Texas since 2009.",
                service_area_zips=d["zips"],
                hours=DEFAULT_HOURS,
                emergency_instructions="For emergencies call +1 940-555-0199 anytime.",
                escalation_phone="+19405550199",
            )
            db.add(profile)
            for wf in default_workflows(org.id):
                db.add(wf)
            billing.start_trial(db, org)
            for name, desc in d["services"]:
                db.add(Service(organization_id=org.id, name=name, description=desc))
            db.flush()
            from app.routers.organizations import _sync_services_knowledge, sync_profile_knowledge

            _sync_services_knowledge(db, org.id)
            sync_profile_knowledge(db, org.id, profile)
            src = KnowledgeSource(organization_id=org.id, kind="faq", title="Frequently asked questions", content="")
            db.add(src)
            db.flush()
            index_source(db, src, faqs=[{"question": q, "answer": a} for q, a in d["faqs"]])
            agent = AIAgent(
                organization_id=org.id,
                name=d["agent"],
                role="receptionist",
                status="active",
                languages=list(i18n.LANGUAGE_ORDER),
                activated_at=utcnow(),
                greeting=f"Hi, thanks for contacting {org.name}! I'm {d['agent']}, the AI assistant. How can I help you today?",
                capabilities=[
                    "web_chat",
                    "answer_calls",
                    "answer_sms",
                    "answer_faqs",
                    "capture_leads",
                    "qualify_leads",
                    "schedule_appointments",
                    "transfer_calls",
                    "follow_up",
                    "send_reminders",
                    "collect_quote_info",
                ],
                industry_template_key=d["industry"],
                widget_token="wt_" + new_token(24),
            )
            db.add(agent)
            db.flush()
            db.add(PhoneNumber(organization_id=org.id, number=f"+1555{rnd.randint(1000000, 9999999)}", provider="sandbox", agent_id=agent.id))
            # historical fake activity (all names/numbers are fictitious; 555 numbers)
            stages = ["new", "contacted", "qualified", "appointment", "estimate", "won", "lost"]
            now = utcnow()
            for _i in range(28):
                created = now - timedelta(days=rnd.randint(0, 27), hours=rnd.randint(0, 20))
                cust = Customer(
                    organization_id=org.id,
                    name=f"{rnd.choice(FIRST)} {rnd.choice(LAST)}",
                    phone=f"+1555{rnd.randint(1000000, 9999999)}",
                    zip=rnd.choice(d["zips"]),
                    created_at=created,
                )
                db.add(cust)
                db.flush()
                db.add(
                    CustomerConsent(
                        organization_id=org.id, customer_id=cust.id, channel="sms", purpose="transactional", status="granted", source="seed_web_chat_disclosure"
                    )
                )
                channel = rnd.choice(["web", "voice", "voice", "sms"])
                conv = Conversation(
                    organization_id=org.id,
                    customer_id=cust.id,
                    agent_id=agent.id,
                    channel=channel,
                    status="resolved",
                    summary=rnd.choice(d["service_words"]),
                    state={"stage": "booked"},
                    first_response_ms=rnd.randint(900, 3500),
                    created_at=created,
                    last_message_at=created + timedelta(minutes=6),
                    contact_address=cust.phone,
                )
                db.add(conv)
                db.flush()
                svc = rnd.choice(d["service_words"])
                db.add(Message(organization_id=org.id, conversation_id=conv.id, role="ai", content=agent.greeting, created_at=created))
                db.add(
                    Message(
                        organization_id=org.id,
                        conversation_id=conv.id,
                        role="customer",
                        content=f"Hi, I need help — {svc.lower()}.",
                        created_at=created + timedelta(seconds=20),
                    )
                )
                db.add(
                    Message(
                        organization_id=org.id,
                        conversation_id=conv.id,
                        role="ai",
                        content="I can help with that. What's the ZIP code where the work is needed?",
                        created_at=created + timedelta(seconds=22),
                    )
                )
                status = rnd.choices(stages, weights=[3, 2, 3, 4, 2, 3, 1])[0]
                est = rnd.randint(*d["value"]) // 100 * 100
                lead = Lead(
                    organization_id=org.id,
                    customer_id=cust.id,
                    conversation_id=conv.id,
                    agent_id=agent.id,
                    source={"web": "ai_web_chat", "voice": "ai_phone", "sms": "ai_sms"}[channel],
                    channel=channel,
                    service=svc,
                    status=status,
                    is_qualified=status not in ("new", "lost"),
                    qualification={"zip": cust.zip, "property_type": "residential"},
                    urgency=rnd.choice(["soon", "flexible", "emergency"]),
                    estimated_value_cents=est,
                    actual_revenue_cents=int(est * rnd.uniform(0.8, 1.1)) // 100 * 100 if status == "won" else None,
                    attribution_source="ai",
                    attribution_confidence="direct",
                    summary=f"{svc}; ZIP {cust.zip}",
                    created_at=created,
                    last_activity_at=created,
                    idempotency_key=f"seed:{conv.id}",
                )
                db.add(lead)
                db.flush()
                conv.lead_id = lead.id
                db.add(Event(organization_id=org.id, type="conversation.started", channel=channel, conversation_id=conv.id, created_at=created))
                db.add(Event(organization_id=org.id, type="lead.created", channel=channel, lead_id=lead.id, created_at=created))
                if lead.is_qualified:
                    db.add(Event(organization_id=org.id, type="lead.qualified", channel=channel, lead_id=lead.id, created_at=created))
                if status in ("appointment", "estimate", "won"):
                    day = (created + timedelta(days=rnd.randint(1, 6))).astimezone(tz).date()
                    if day.weekday() >= 5:
                        day += timedelta(days=7 - day.weekday())
                    if status == "appointment":
                        day = (now + timedelta(days=rnd.randint(1, 10))).astimezone(tz).date()
                        if day.weekday() >= 5:
                            day += timedelta(days=7 - day.weekday())
                    start = datetime.combine(day, time(rnd.choice([8, 9, 10, 11, 13, 14, 15])), tzinfo=tz)
                    appt = Appointment(
                        organization_id=org.id,
                        customer_id=cust.id,
                        lead_id=lead.id,
                        conversation_id=conv.id,
                        service=svc,
                        resource="default",
                        start_at=start,
                        end_at=start + timedelta(minutes=60),
                        timezone="America/Chicago",
                        status="scheduled" if start > now else "completed",
                        source=lead.source,
                        idempotency_key=f"seed:{lead.id}",
                    )
                    try:
                        with db.begin_nested():
                            db.add(appt)
                            db.flush()
                    except Exception:
                        continue
                    db.add(Event(organization_id=org.id, type="appointment.created", channel=channel, lead_id=lead.id, created_at=created))
                if status == "won":
                    db.add(Event(organization_id=org.id, type="lead.won", lead_id=lead.id, created_at=created + timedelta(days=3)))
                if rnd.random() < 0.12:
                    db.add(Event(organization_id=org.id, type="conversation.escalated", channel=channel, conversation_id=conv.id, created_at=created))
            db.commit()
            print(f"seeded {org.name}: owner {d['email']} / {DEMO_PASSWORD}  widget token {agent.widget_token}")


def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        return
    cmd = sys.argv[1]
    if cmd == "bootstrap":
        bootstrap()
    elif cmd == "seed-demo":
        seed_demo()
    elif cmd == "create-superadmin":
        create_superadmin(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)
    elif cmd == "gen-key":
        print(Fernet.generate_key().decode())
    elif cmd == "check-config":
        get_settings()
        print(f"configuration OK for APP_ENV={get_settings().app_env}")
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
