"""Application configuration with strict validation per environment (spec §66, §93)."""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

Env = Literal["development", "test", "staging", "production"]


class ConfigError(RuntimeError):
    """Raised at startup when configuration is unsafe or incomplete."""


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: Env = "development"
    app_name: str = "AI Revenue Employee"
    public_web_url: str = "http://localhost:3000"
    public_api_url: str = "http://localhost:8000"
    cors_origins: str = "http://localhost:3000"

    database_url: str = "postgresql+psycopg://postgres:postgres@localhost:5432/are_dev"
    redis_url: str | None = None

    # Auth
    secret_key: str = Field(default="dev-insecure-secret-change-me-0000000000000000")
    encryption_key: str | None = None  # Fernet key (urlsafe base64, 32 bytes)
    session_ttl_hours: int = 24 * 7
    require_email_verification: bool = False
    cookie_secure: bool = False
    google_oauth_client_id: str | None = None
    google_oauth_client_secret: str | None = None

    # AI
    primary_llm_provider: Literal["anthropic", "sandbox"] = "sandbox"
    fallback_llm_provider: Literal["anthropic", "sandbox", "none"] = "none"
    anthropic_api_key: str | None = None
    anthropic_model: str = "claude-sonnet-4-5"
    anthropic_model_fast: str = "claude-haiku-4-5"
    llm_timeout_seconds: float = 20.0
    llm_max_tokens: int = 800

    # Providers
    sms_provider: Literal["twilio", "sandbox"] = "sandbox"
    voice_provider: Literal["twilio", "sandbox"] = "sandbox"
    twilio_account_sid: str | None = None
    twilio_auth_token: str | None = None
    twilio_messaging_service_sid: str | None = None

    # Speech recognition for the voice agent (phone media streams and browser voice).
    #   twilio    -> Twilio <Gather input="speech"> recognizes each turn (no extra server).
    #   vibevoice -> audio is streamed to a self-hosted Microsoft VibeVoice-ASR-Streaming server
    #                (python demo/vibevoice_asr_streaming_fastapi_demo.py, needs a GPU) for en/es/zh/fr;
    #                other languages fall back to Twilio speech recognition.
    #   sandbox   -> deterministic fake recognizer, for tests only.
    voice_asr_provider: Literal["twilio", "vibevoice", "sandbox"] = "twilio"
    vibevoice_asr_url: str | None = None  # e.g. http://gpu-box:7870  (ws://.../ws/asr is derived)
    vibevoice_hotwords: str = ""  # comma-separated context words (business names, product terms)
    vibevoice_timeout_seconds: float = 10.0
    # Languages routed to VibeVoice (the rest use Twilio speech recognition). Extend after verifying accuracy.
    vibevoice_languages: str = "en,es,zh,fr"
    voice_endpoint_silence_ms: int = 700

    email_provider: Literal["smtp", "sandbox"] = "sandbox"
    smtp_host: str | None = None
    smtp_port: int = 587
    smtp_username: str | None = None
    smtp_password: str | None = None
    email_from: str = "AI Revenue Employee <no-reply@example.com>"

    billing_provider: Literal["stripe", "sandbox"] = "sandbox"
    stripe_secret_key: str | None = None
    stripe_webhook_secret: str | None = None

    google_calendar_client_id: str | None = None
    google_calendar_client_secret: str | None = None

    storage_dir: str = "./.storage"
    max_upload_bytes: int = 10 * 1024 * 1024

    # Explicit, documented escape hatch (spec §93)
    allow_sandbox_providers_in_production: bool = False

    sentry_dsn: str | None = None
    log_level: str = "INFO"

    @field_validator("database_url")
    @classmethod
    def _normalize_db(cls, v: str) -> str:
        # Managed Postgres providers (Render, Heroku, Neon…) hand out postgres:// URLs; SQLAlchemy needs the driver name.
        for prefix in ("postgres://", "postgresql://"):
            if v.startswith(prefix):
                return "postgresql+psycopg://" + v[len(prefix) :]
        return v

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @model_validator(mode="after")
    def _validate(self) -> "Settings":
        if self.app_env in ("production", "staging"):
            problems: list[str] = []
            if self.secret_key.startswith("dev-insecure") or len(self.secret_key) < 32:
                problems.append("SECRET_KEY must be a random value of at least 32 characters")
            if not self.encryption_key:
                problems.append("ENCRYPTION_KEY is required (generate with: python -m app.cli gen-key)")
            if not self.cookie_secure:
                problems.append("COOKIE_SECURE must be true")
            if self.app_env == "production" and not self.allow_sandbox_providers_in_production:
                sandboxed = [
                    name
                    for name, val in (
                        ("PRIMARY_LLM_PROVIDER", self.primary_llm_provider),
                        ("SMS_PROVIDER", self.sms_provider),
                        ("VOICE_PROVIDER", self.voice_provider),
                        ("EMAIL_PROVIDER", self.email_provider),
                        ("BILLING_PROVIDER", self.billing_provider),
                    )
                    if val == "sandbox"
                ]
                if sandboxed:
                    problems.append(
                        "Sandbox providers are not allowed in production: "
                        + ", ".join(sandboxed)
                        + " (set ALLOW_SANDBOX_PROVIDERS_IN_PRODUCTION=true only for a documented soft launch)"
                    )
            if self.primary_llm_provider == "anthropic" and not self.anthropic_api_key:
                problems.append("ANTHROPIC_API_KEY required when PRIMARY_LLM_PROVIDER=anthropic")
            if "twilio" in (self.sms_provider, self.voice_provider) and not (self.twilio_account_sid and self.twilio_auth_token):
                problems.append("TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN required for Twilio providers")
            if self.voice_asr_provider == "vibevoice" and not self.vibevoice_asr_url:
                problems.append("VIBEVOICE_ASR_URL required when VOICE_ASR_PROVIDER=vibevoice")
            if self.voice_asr_provider == "sandbox" and self.app_env == "production" and not self.allow_sandbox_providers_in_production:
                problems.append("VOICE_ASR_PROVIDER=sandbox is not allowed in production")
            if self.billing_provider == "stripe" and not (self.stripe_secret_key and self.stripe_webhook_secret):
                problems.append("STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET required for Stripe billing")
            if self.email_provider == "smtp" and not self.smtp_host:
                problems.append("SMTP_HOST required for SMTP email")
            if problems:
                raise ConfigError("Invalid configuration:\n  - " + "\n  - ".join(problems))
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
