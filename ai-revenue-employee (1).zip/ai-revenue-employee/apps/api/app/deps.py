"""Request dependencies: authentication, CSRF, tenant resolution and RBAC (spec §4, §5, §45)."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import datetime, timezone

from fastapi import Depends, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.errors import AppError, forbidden
from app.models import Membership, Organization, User, UserSession
from app.security import sha256_hex

SESSION_COOKIE = "are_session"
CSRF_COOKIE = "are_csrf"
SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}

ROLE_PERMISSIONS: dict[str, set[str]] = {
    "owner": {
        "org.manage",
        "billing.manage",
        "team.manage",
        "integrations.manage",
        "agents.manage",
        "knowledge.manage",
        "workflows.manage",
        "leads.read",
        "leads.write",
        "customers.read",
        "customers.write",
        "conversations.read",
        "conversations.write",
        "appointments.read",
        "appointments.write",
        "analytics.read",
        "tasks.write",
        "privacy.manage",
        "webhooks.manage",
    },
    "manager": {
        "agents.manage",
        "knowledge.manage",
        "workflows.manage",
        "leads.read",
        "leads.write",
        "customers.read",
        "customers.write",
        "conversations.read",
        "conversations.write",
        "appointments.read",
        "appointments.write",
        "analytics.read",
        "tasks.write",
    },
    "staff": {
        "leads.read",
        "leads.write",
        "customers.read",
        "customers.write",
        "conversations.read",
        "conversations.write",
        "appointments.read",
        "appointments.write",
        "tasks.write",
    },
    "readonly": {"analytics.read"},
}
ROLES = tuple(ROLE_PERMISSIONS)


@dataclass
class AuthContext:
    user: User
    session: UserSession


@dataclass
class OrgContext:
    user: User
    org: Organization
    role: str
    session: UserSession

    @property
    def org_id(self) -> uuid.UUID:
        return self.org.id

    def can(self, permission: str) -> bool:
        return permission in ROLE_PERMISSIONS.get(self.role, set())


def _extract_token(request: Request) -> tuple[str | None, bool]:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip(), False
    return request.cookies.get(SESSION_COOKIE), True


def get_auth(request: Request, db: Session = Depends(get_db)) -> AuthContext:
    token, via_cookie = _extract_token(request)
    if not token:
        raise AppError(401, "unauthorized", "Authentication required")
    sess = db.scalar(select(UserSession).where(UserSession.token_hash == sha256_hex(token)))
    now = datetime.now(timezone.utc)
    if not sess or sess.revoked_at is not None or sess.expires_at <= now:
        raise AppError(401, "session_expired", "Your session has expired. Please sign in again.")
    user = db.get(User, sess.user_id)
    if not user or not user.is_active:
        raise AppError(401, "account_disabled", "This account is disabled")
    if via_cookie and request.method not in SAFE_METHODS:
        header = request.headers.get("x-csrf-token")
        if not header or header != sess.csrf_token:
            raise AppError(403, "csrf_failed", "CSRF token missing or invalid")
    request.state.user_id = str(user.id)
    return AuthContext(user=user, session=sess)


def get_org_ctx(request: Request, auth: AuthContext = Depends(get_auth), db: Session = Depends(get_db)) -> OrgContext:
    raw = request.headers.get("x-organization-id")
    q = (
        select(Membership, Organization)
        .join(Organization, Organization.id == Membership.organization_id)
        .where(Membership.user_id == auth.user.id, Organization.deleted_at.is_(None))
    )
    if raw:
        try:
            org_id = uuid.UUID(raw)
        except ValueError:
            raise AppError(400, "bad_organization", "Invalid organization id") from None
        q = q.where(Organization.id == org_id)
    row = db.execute(q.order_by(Membership.created_at)).first()
    if not row:
        raise AppError(403, "no_organization", "You are not a member of this organization")
    membership, org = row
    if org.status == "suspended" and not auth.user.is_superadmin:
        raise AppError(403, "organization_suspended", "This organization is suspended")
    request.state.org_id = str(org.id)
    return OrgContext(user=auth.user, org=org, role=membership.role, session=auth.session)


def require(permission: str):
    def _dep(ctx: OrgContext = Depends(get_org_ctx)) -> OrgContext:
        if not ctx.can(permission):
            raise forbidden()
        return ctx

    return _dep


def require_superadmin(auth: AuthContext = Depends(get_auth)) -> AuthContext:
    if not auth.user.is_superadmin:
        raise forbidden("Platform administrator access required")
    return auth
