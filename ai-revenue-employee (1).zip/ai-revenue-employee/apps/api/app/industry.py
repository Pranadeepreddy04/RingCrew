"""Industry Pack engine: configuration-driven industry behaviour (spec §15).

Packs live in packages/industry-config/packs/*.json, are synced into `industry_templates`
(editable by platform admins), and can be further overridden per tenant via
`ai_agents.pack_overrides`. The core engine never branches on industry names."""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import IndustryTemplate

PACKS_DIR = Path(__file__).resolve().parents[3] / "packages" / "industry-config" / "packs"
FIELD_TYPES = {"text", "enum", "zip", "phone", "email", "name", "bool"}


class PackError(ValueError):
    pass


@dataclass
class PackField:
    key: str
    label: str
    type: str
    required: bool
    prompt: str | None = None
    options: dict[str, list[str]] = field(default_factory=dict)
    true_keywords: list[str] = field(default_factory=list)
    pattern: str | None = None
    enabled: bool = True


@dataclass
class ResolvedPack:
    key: str
    name: str
    category: str
    status: str
    version: int
    appointment_label: str
    default_service: str
    booking_keywords: list[str]
    fields: list[PackField]
    collection_order: list[str]
    human_keywords: list[str]
    complaint_keywords: list[str]
    emergency_keywords: list[str]
    safety_rules: list[str]
    eval_cases: list[dict[str, Any]]

    def field(self, key: str) -> PackField | None:
        return next((f for f in self.fields if f.key == key), None)

    @property
    def required_keys(self) -> list[str]:
        return [k for k in self.collection_order if (f := self.field(k)) and f.required and f.enabled]


def load_file_packs() -> dict[str, dict[str, Any]]:
    packs: dict[str, dict[str, Any]] = {}
    for p in sorted(PACKS_DIR.glob("*.json")):
        data = json.loads(p.read_text())
        packs[data["key"]] = data
    return packs


def _raw_configs(db: Session | None) -> dict[str, dict[str, Any]]:
    configs = load_file_packs()
    if db is not None:
        for t in db.scalars(select(IndustryTemplate)).all():
            cfg = dict(t.config)
            cfg["status"] = t.status
            cfg["version"] = t.version
            configs[t.key] = cfg
    return configs


def _merge(raw: dict[str, Any], configs: dict[str, dict[str, Any]], depth: int = 0) -> dict[str, Any]:
    if depth > 3:
        raise PackError("Pack inheritance too deep")
    parent_key = raw.get("extends")
    if not parent_key:
        return copy.deepcopy(raw)
    if parent_key not in configs:
        raise PackError(f"Unknown base pack {parent_key}")
    base = _merge(configs[parent_key], configs, depth + 1)
    out = copy.deepcopy(base)
    for k, v in raw.items():
        if k in {"field_overrides", "extra_fields", "extra_booking_keywords", "safety_rules_extra", "extends"}:
            continue
        out[k] = copy.deepcopy(v)
    fields = {f["key"]: f for f in out.get("fields", [])}
    for key, patch in (raw.get("field_overrides") or {}).items():
        if key not in fields:
            raise PackError(f"field_overrides references unknown field {key}")
        fields[key] = {**fields[key], **patch}
    for extra in raw.get("extra_fields") or []:
        fields[extra["key"]] = extra
    out["fields"] = list(fields.values())
    out["booking_keywords"] = list(base.get("booking_keywords", [])) + list(raw.get("extra_booking_keywords", []))
    out["safety_rules"] = list(base.get("safety_rules", [])) + list(raw.get("safety_rules_extra", []))
    if "collection_order" not in raw:
        order = list(base.get("collection_order", []))
        # required extra fields get asked right after service_requested
        for extra in raw.get("extra_fields") or []:
            if extra.get("required") and extra["key"] not in order:
                order.insert(1, extra["key"])
        out["collection_order"] = order
    return out


def resolve_pack(key: str, db: Session | None = None, overrides: dict[str, Any] | None = None) -> ResolvedPack:
    configs = _raw_configs(db)
    if key not in configs or key.startswith("_"):
        raise PackError(f"Unknown industry pack '{key}'")
    cfg = _merge(configs[key], configs)
    field_patches: dict[str, dict[str, Any]] = (overrides or {}).get("fields", {})
    fields: list[PackField] = []
    for f in cfg.get("fields", []):
        if f.get("type") not in FIELD_TYPES:
            raise PackError(f"Field {f.get('key')} has invalid type {f.get('type')}")
        patch = field_patches.get(f["key"], {})
        enabled = bool(patch.get("enabled", f.get("enabled_by_default", True)))
        required = bool(patch.get("required", f.get("required", False))) and enabled
        if f["key"] in ("name", "phone"):
            enabled, required = True, True  # contact capture is always required for a lead
        fields.append(
            PackField(
                key=f["key"],
                label=f.get("label", f["key"]),
                type=f["type"],
                required=required,
                prompt=patch.get("prompt") or f.get("prompt"),
                options=f.get("options") or {},
                true_keywords=f.get("true_keywords") or [],
                pattern=f.get("pattern"),
                enabled=enabled,
            )
        )
    order = list(cfg.get("collection_order", []))
    for f in fields:
        if f.required and f.key not in order:
            order.insert(max(len(order) - 2, 0), f.key)
    esc = cfg.get("escalation", {})
    return ResolvedPack(
        key=cfg["key"],
        name=cfg["name"],
        category=cfg.get("category", "home_services"),
        status=cfg.get("status", "active"),
        version=int(cfg.get("version", 1)),
        appointment_label=cfg.get("appointment_label", "appointment"),
        default_service=cfg.get("default_service", "Appointment"),
        booking_keywords=[k.lower() for k in cfg.get("booking_keywords", [])],
        fields=fields,
        collection_order=order,
        human_keywords=[k.lower() for k in esc.get("human_keywords", [])],
        complaint_keywords=[k.lower() for k in esc.get("complaint_keywords", [])],
        emergency_keywords=[k.lower() for k in esc.get("emergency_keywords", [])],
        safety_rules=cfg.get("safety_rules", []),
        eval_cases=cfg.get("eval_cases", []),
    )


def list_packs(db: Session | None = None) -> list[dict[str, Any]]:
    out = []
    for key, cfg in sorted(_raw_configs(db).items()):
        if key.startswith("_"):
            continue
        out.append(
            {
                "key": key,
                "name": cfg.get("name", key),
                "category": cfg.get("category", "home_services"),
                "status": cfg.get("status", "active"),
                "disabled_reason": cfg.get("disabled_reason"),
            }
        )
    return out


def sync_packs_to_db(db: Session) -> int:
    """Insert packs from files that are missing in the DB; bump when the file version is newer."""
    n = 0
    existing = {t.key: t for t in db.scalars(select(IndustryTemplate)).all()}
    for key, cfg in load_file_packs().items():
        t = existing.get(key)
        status = cfg.get("status", "active")
        if t is None:
            db.add(
                IndustryTemplate(
                    key=key,
                    name=cfg.get("name", key),
                    category=cfg.get("category", "home_services"),
                    status=status,
                    version=int(cfg.get("version", 1)),
                    config=cfg,
                )
            )
            n += 1
        elif int(cfg.get("version", 1)) > t.version:
            t.config, t.version, t.name = cfg, int(cfg.get("version", 1)), cfg.get("name", key)
            n += 1
    return n
