from __future__ import annotations

import logging
import time
from typing import Any

from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from sqlalchemy import text

from app.config import get_settings
from app.db import engine
from app.errors import install_error_handlers
from app.observability import configure_logging, metrics, new_request_id, set_request_id

log = logging.getLogger("app")


def _reset_request_id(token: Any) -> None:
    from app.observability import _request_id

    try:
        _request_id.reset(token)
    except ValueError:  # token created in a different context (streaming responses)
        _request_id.set(None)


def create_app() -> FastAPI:
    settings = get_settings()  # raises ConfigError on unsafe production config (spec §93)
    configure_logging(settings.log_level)
    app = FastAPI(
        title="AI Revenue Employee API",
        version="1.0.0",
        openapi_url="/api/v1/openapi.json",
        docs_url="/api/docs",
        redoc_url=None,
    )
    install_error_handlers(app)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origin_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def request_context(request: Request, call_next: Any) -> Response:
        rid = request.headers.get("x-request-id") or new_request_id()
        rid = rid[:64]
        token = set_request_id(rid)
        request.state.request_id = rid
        start = time.perf_counter()
        try:
            response: Response = await call_next(request)
        finally:
            _reset_request_id(token)
        elapsed = time.perf_counter() - start
        route = request.scope.get("route")
        path = getattr(route, "path", "unmatched")
        metrics.inc("http_requests_total", method=request.method, path=path, status=str(response.status_code))
        metrics.observe("http_request", elapsed, path=path)
        response.headers["X-Request-ID"] = rid
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        if not request.url.path.startswith(("/widget", "/api/v1/public")):
            response.headers["X-Frame-Options"] = "DENY"
        if settings.cookie_secure:
            response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if response.status_code >= 500:
            log.error("request_failed", extra={"path": path, "status": response.status_code})
        return response

    from app.routers import (
        admin,
        agents,
        analytics,
        appointments,
        auth,
        billing,
        conversations,
        customers,
        integrations,
        knowledge,
        leads,
        organizations,
        public,
        voice_sms,
        voice_stream,
        workflows,
    )

    for r in (
        auth,
        organizations,
        agents,
        knowledge,
        public,
        conversations,
        leads,
        customers,
        appointments,
        analytics,
        workflows,
        integrations,
        billing,
        admin,
        voice_sms,
        voice_stream,
    ):
        app.include_router(r.router, prefix="/api/v1")

    @app.get("/healthz", include_in_schema=False)
    def healthz() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/readyz", include_in_schema=False)
    def readyz() -> Response:
        try:
            with engine.connect() as c:
                c.execute(text("SELECT 1"))
            return PlainTextResponse("ready")
        except Exception:
            return PlainTextResponse("database unavailable", status_code=503)

    @app.get("/metrics", include_in_schema=False)
    def prom() -> Response:
        return PlainTextResponse(metrics.render(), media_type="text/plain; version=0.0.4")

    from app.routers.public import widget_js

    app.add_api_route("/widget.js", widget_js, methods=["GET"], include_in_schema=False)
    return app


app = create_app()
