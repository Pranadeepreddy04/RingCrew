"""Structured logging, request/correlation IDs, and in-process metrics (spec §52, §98)."""

from __future__ import annotations

import contextvars
import json
import logging
import sys
import time
import uuid
from collections import defaultdict
from threading import Lock
from typing import Any

_request_id: contextvars.ContextVar[str | None] = contextvars.ContextVar("request_id", default=None)


def current_request_id() -> str | None:
    return _request_id.get()


def set_request_id(value: str | None) -> contextvars.Token[str | None]:
    return _request_id.set(value)


class JsonFormatter(logging.Formatter):
    RESERVED = set(vars(logging.makeLogRecord({})).keys()) | {"message", "asctime"}

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
            "request_id": current_request_id(),
        }
        for k, v in record.__dict__.items():
            if k not in self.RESERVED and not k.startswith("_"):
                payload[k] = v
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers[:] = [handler]
    root.setLevel(level)
    logging.getLogger("uvicorn.access").setLevel("WARNING")


class Metrics:
    """Minimal thread-safe counters/latency tracker exposed at /metrics (Prometheus text format)."""

    def __init__(self) -> None:
        self._lock = Lock()
        self.counters: dict[str, float] = defaultdict(float)
        self.latency_sum: dict[str, float] = defaultdict(float)
        self.latency_count: dict[str, int] = defaultdict(int)

    def inc(self, name: str, value: float = 1.0, **labels: str) -> None:
        key = name + _labels(labels)
        with self._lock:
            self.counters[key] += value

    def observe(self, name: str, seconds: float, **labels: str) -> None:
        key = name + _labels(labels)
        with self._lock:
            self.latency_sum[key] += seconds
            self.latency_count[key] += 1

    def render(self) -> str:
        with self._lock:
            lines = [f"{k} {v}" for k, v in sorted(self.counters.items())]
            for k, s in sorted(self.latency_sum.items()):
                base, _, lbl = k.partition("{")
                suffix = ("{" + lbl) if lbl else ""
                lines.append(f"{base}_seconds_sum{suffix} {s}")
                lines.append(f"{base}_seconds_count{suffix} {self.latency_count[k]}")
        return "\n".join(lines) + "\n"


def _labels(labels: dict[str, str]) -> str:
    if not labels:
        return ""
    inner = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
    return "{" + inner + "}"


metrics = Metrics()


def new_request_id() -> str:
    return uuid.uuid4().hex


class Timer:
    def __enter__(self) -> "Timer":
        self.start = time.perf_counter()
        return self

    def __exit__(self, *exc: object) -> None:
        self.elapsed = time.perf_counter() - self.start

    @property
    def ms(self) -> int:
        return int(getattr(self, "elapsed", time.perf_counter() - self.start) * 1000)
