"""Streaming speech recognition (ASR) providers for the voice agent.

VibeVoice-ASR-Streaming (Microsoft, MIT licence) is a self-hosted model server
(``python demo/vibevoice_asr_streaming_fastapi_demo.py --model_path <ckpt>``, port 7870, GPU required).
Its protocol, which this client follows exactly:

* ``GET  /config``  -> ``{"sample_rate": 24000, "chunk_seconds": …}``
* ``WS   /ws/asr``  -> first a JSON text frame ``{"context_info": "hotwords", "temperature": 0, "max_tokens": 256}``,
  then binary frames of little-endian float32 mono PCM at ``sample_rate``.
  The server answers ``{"chunks": n, "text": "<cumulative transcript>"}`` as audio is decoded.
  Sending the text frame ``"end"`` flushes the remaining audio and returns ``{"done": true, "text": …, "total_chunks": n}``.
  Errors arrive as ``{"error": "…"}``.

One ASR session is opened per caller utterance (voice activity detection decides where an utterance starts and ends),
so every turn gets a clean, fully flushed final transcript and the model's context does not grow without bound.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
from collections import deque
from collections.abc import Awaitable, Callable
from typing import Any, Protocol

import httpx
import numpy as np

from app.ai import i18n
from app.config import get_settings

log = logging.getLogger(__name__)


class ASRError(RuntimeError):
    pass


def resample(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    """Linear-interpolation resampler (8 kHz telephone / 16–48 kHz browser audio -> the model's rate)."""
    if sr_in == sr_out or len(x) == 0:
        return x.astype(np.float32, copy=False)
    n_out = max(1, int(round(len(x) * sr_out / sr_in)))
    t_in = np.arange(len(x), dtype=np.float64) / sr_in
    t_out = np.arange(n_out, dtype=np.float64) / sr_out
    return np.interp(t_out, t_in, x).astype(np.float32)


class ASRSession(Protocol):
    partial: str
    on_partial: Callable[[str], Awaitable[None]] | None

    async def send_audio(self, pcm: np.ndarray, sample_rate: int) -> None: ...

    async def finish(self) -> str: ...

    async def close(self) -> None: ...


class ASRProvider(Protocol):
    name: str

    def supports(self, language: str) -> bool: ...

    async def open(self, *, language: str, hotwords: str = "") -> ASRSession: ...


# ------------------------------------------------------------------ VibeVoice


class VibeVoiceSession:
    def __init__(self, ws: Any, sample_rate: int, timeout: float) -> None:
        self.ws = ws
        self.sample_rate = sample_rate
        self.timeout = timeout
        self.partial = ""
        self.on_partial: Callable[[str], Awaitable[None]] | None = None
        self.final: str | None = None
        self.error: str | None = None
        self._done = asyncio.Event()
        self._reader = asyncio.create_task(self._read())
        self.samples_sent = 0

    async def _read(self) -> None:
        try:
            async for raw in self.ws:
                if isinstance(raw, bytes):
                    continue
                msg = json.loads(raw)
                if "error" in msg:
                    self.error = str(msg["error"])[:300]
                    break
                if "text" in msg:
                    text = str(msg["text"]).strip()
                    if text != self.partial and not msg.get("done"):
                        self.partial = text
                        if self.on_partial is not None:
                            with contextlib.suppress(Exception):
                                await self.on_partial(text)
                    self.partial = text
                if msg.get("done"):
                    self.final = self.partial
                    break
        except Exception as e:  # connection dropped
            self.error = self.error or f"{type(e).__name__}: {e}"[:300]
        finally:
            self._done.set()

    async def send_audio(self, pcm: np.ndarray, sample_rate: int) -> None:
        if self._done.is_set():
            raise ASRError(self.error or "ASR session closed")
        data = resample(np.asarray(pcm, dtype=np.float32), sample_rate, self.sample_rate)
        self.samples_sent += len(data)
        await self.ws.send(data.astype("<f4").tobytes())
        await asyncio.sleep(0)  # let the reader deliver any transcript update

    async def finish(self) -> str:
        if not self._done.is_set():
            with contextlib.suppress(Exception):
                await self.ws.send("end")
            try:
                await asyncio.wait_for(self._done.wait(), timeout=self.timeout)
            except TimeoutError:
                self.error = self.error or "timeout waiting for final transcript"
        await self.close()
        if self.final is None and self.error:
            log.warning("vibevoice asr: %s", self.error)
            if not self.partial:
                raise ASRError(self.error)
        return (self.final if self.final is not None else self.partial).strip()

    async def close(self) -> None:
        with contextlib.suppress(Exception):
            await self.ws.close()
        if not self._reader.done():
            self._reader.cancel()
            with contextlib.suppress(BaseException):
                await self._reader


class VibeVoiceASR:
    """Client for a self-hosted VibeVoice-ASR-Streaming server."""

    name = "vibevoice"
    _config_cache: dict[str, dict[str, Any]] = {}

    def __init__(self, base_url: str | None = None, hotwords: str | None = None, timeout: float | None = None) -> None:
        s = get_settings()
        url = (base_url or s.vibevoice_asr_url or "").rstrip("/")
        if not url:
            raise ASRError("VIBEVOICE_ASR_URL is not configured")
        self.http_url = url if url.startswith("http") else "http://" + url
        self.ws_url = self.http_url.replace("https://", "wss://", 1).replace("http://", "ws://", 1) + "/ws/asr"
        self.hotwords = s.vibevoice_hotwords if hotwords is None else hotwords
        self.timeout = timeout or s.vibevoice_timeout_seconds
        # languages routed to VibeVoice; others use Twilio (phone) or the browser's recognizer (web)
        self.languages = frozenset(x.strip() for x in s.vibevoice_languages.split(",") if x.strip() in i18n.LANGS)

    def supports(self, language: str) -> bool:
        return language in self.languages

    async def server_config(self) -> dict[str, Any]:
        cached = self._config_cache.get(self.http_url)
        if cached:
            return cached
        async with httpx.AsyncClient(timeout=self.timeout) as c:
            r = await c.get(self.http_url + "/config")
            r.raise_for_status()
            cfg = r.json()
        if not isinstance(cfg.get("sample_rate"), int):
            raise ASRError("VibeVoice /config did not return a sample_rate")
        self._config_cache[self.http_url] = cfg
        return cfg

    async def health(self) -> dict[str, Any]:
        try:
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get(self.http_url + "/healthz")
                return {"ok": r.status_code == 200 and r.json().get("status") == "ok", "status": r.json().get("status")}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}"}

    async def open(self, *, language: str, hotwords: str = "") -> VibeVoiceSession:
        import websockets

        cfg = await self.server_config()
        context = ", ".join(x for x in (self.hotwords.strip(), hotwords.strip()) if x)[:500]
        try:
            ws = await asyncio.wait_for(websockets.connect(self.ws_url, max_size=2**22, open_timeout=self.timeout), timeout=self.timeout)
        except Exception as e:
            raise ASRError(f"cannot connect to VibeVoice ASR: {type(e).__name__}") from e
        await ws.send(json.dumps({"context_info": context or None, "temperature": 0, "max_tokens": 256}))
        return VibeVoiceSession(ws, int(cfg["sample_rate"]), self.timeout)


# ------------------------------------------------------------------ sandbox (tests / local dev without a GPU)


class SandboxSession:
    def __init__(self, text: str) -> None:
        self._text = text
        self.partial = ""
        self.on_partial: Callable[[str], Awaitable[None]] | None = None
        self.seconds = 0.0

    async def send_audio(self, pcm: np.ndarray, sample_rate: int) -> None:
        self.seconds += len(pcm) / sample_rate
        words = self._text.split()
        partial = " ".join(words[: max(1, int(self.seconds * 3))]) if words else ""
        if partial != self.partial:
            self.partial = partial
            if self.on_partial is not None:
                await self.on_partial(partial)

    async def finish(self) -> str:
        return self._text

    async def close(self) -> None:
        return None


class SandboxASR:
    """Deterministic recognizer: returns queued transcripts in order (tests push into ``SandboxASR.script``)."""

    name = "sandbox"
    script: deque[str] = deque()

    def supports(self, language: str) -> bool:
        return True

    async def open(self, *, language: str, hotwords: str = "") -> SandboxSession:
        return SandboxSession(self.script.popleft() if self.script else "")


def get_asr_provider() -> ASRProvider | None:
    """The streaming recognizer, or None when Twilio's own speech recognition (<Gather>) is used."""
    p = get_settings().voice_asr_provider
    if p == "vibevoice":
        return VibeVoiceASR()
    if p == "sandbox":
        return SandboxASR()
    return None
