"""Calendar provider abstraction (spec §30, §36). The internal calendar (appointments table,
protected by a Postgres exclusion constraint) is always the system of record; external calendars
are consulted for busy time and receive events when connected."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Protocol
from urllib.parse import urlencode

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Integration
from app.security import decrypt, encrypt
from app.services.common import utcnow


class CalendarError(Exception):
    """External calendar unavailable/failed. Never treated as success."""


@dataclass
class BusyInterval:
    start: datetime
    end: datetime


class ExternalCalendar(Protocol):
    name: str

    def busy(self, start: datetime, end: datetime) -> list[BusyInterval]: ...

    def create_event(self, *, summary: str, description: str, start: datetime, end: datetime, tz: str, idempotency_key: str) -> str: ...

    def delete_event(self, event_id: str) -> None: ...

    def update_event(self, event_id: str, *, start: datetime, end: datetime, tz: str) -> None: ...

    def health(self) -> bool: ...


GOOGLE_SCOPES = "https://www.googleapis.com/auth/calendar.events https://www.googleapis.com/auth/calendar.freebusy"
GOOGLE_API = "https://www.googleapis.com/calendar/v3"


def google_auth_url(state: str) -> str:
    s = get_settings()
    if not (s.google_calendar_client_id and s.google_calendar_client_secret):
        raise CalendarError("Google Calendar is not configured (GOOGLE_CALENDAR_CLIENT_ID/SECRET)")
    return "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(
        {
            "client_id": s.google_calendar_client_id,
            "redirect_uri": f"{s.public_api_url}/api/v1/integrations/google-calendar/callback",
            "response_type": "code",
            "access_type": "offline",
            "prompt": "consent",
            "scope": GOOGLE_SCOPES,
            "state": state,
        }
    )


def google_exchange_code(code: str) -> dict[str, Any]:
    s = get_settings()
    r = httpx.post(
        "https://oauth2.googleapis.com/token",
        data={
            "code": code,
            "client_id": s.google_calendar_client_id,
            "client_secret": s.google_calendar_client_secret,
            "redirect_uri": f"{s.public_api_url}/api/v1/integrations/google-calendar/callback",
            "grant_type": "authorization_code",
        },
        timeout=15,
    )
    if r.status_code != 200:
        raise CalendarError(f"Google token exchange failed ({r.status_code})")
    data = r.json()
    if not data.get("refresh_token"):
        raise CalendarError("Google did not return a refresh token; remove the app from your Google account and reconnect")
    return {
        "refresh_token": data["refresh_token"],
        "access_token": data["access_token"],
        "expires_at": (utcnow() + timedelta(seconds=int(data.get("expires_in", 3600)) - 60)).isoformat(),
    }


class GoogleCalendar:
    name = "google"

    def __init__(self, db: Session, integration: Integration) -> None:
        self.db = db
        self.integration = integration
        self.creds: dict[str, Any] = json.loads(decrypt(integration.credentials_encrypted or ""))
        self.calendar_id = integration.config.get("calendar_id", "primary")

    def _token(self) -> str:
        exp = datetime.fromisoformat(self.creds.get("expires_at", "1970-01-01T00:00:00+00:00"))
        if exp > utcnow():
            return str(self.creds["access_token"])
        s = get_settings()
        r = httpx.post(
            "https://oauth2.googleapis.com/token",
            data={
                "client_id": s.google_calendar_client_id,
                "client_secret": s.google_calendar_client_secret,
                "refresh_token": self.creds["refresh_token"],
                "grant_type": "refresh_token",
            },
            timeout=15,
        )
        if r.status_code != 200:
            self.integration.status = "error"
            self.integration.last_error = "Token refresh failed — reconnect Google Calendar"
            raise CalendarError("Google token refresh failed")
        data = r.json()
        self.creds["access_token"] = data["access_token"]
        self.creds["expires_at"] = (utcnow() + timedelta(seconds=int(data.get("expires_in", 3600)) - 60)).isoformat()
        self.integration.credentials_encrypted = encrypt(json.dumps(self.creds))
        return str(data["access_token"])

    def _req(self, method: str, path: str, **kw: Any) -> httpx.Response:
        try:
            r = httpx.request(method, GOOGLE_API + path, headers={"Authorization": f"Bearer {self._token()}"}, timeout=10, **kw)
        except httpx.HTTPError as exc:
            raise CalendarError(f"Google Calendar unreachable: {exc.__class__.__name__}") from exc
        if r.status_code >= 400 and r.status_code != 410:
            raise CalendarError(f"Google Calendar error {r.status_code}")
        self.integration.last_sync_at = utcnow()
        self.integration.status = "connected"
        self.integration.last_error = None
        return r

    def busy(self, start: datetime, end: datetime) -> list[BusyInterval]:
        r = self._req("POST", "/freeBusy", json={"timeMin": start.isoformat(), "timeMax": end.isoformat(), "items": [{"id": self.calendar_id}]})
        cal = r.json().get("calendars", {}).get(self.calendar_id, {})
        if cal.get("errors"):
            raise CalendarError("Google Calendar freebusy returned errors")
        return [
            BusyInterval(datetime.fromisoformat(b["start"].replace("Z", "+00:00")), datetime.fromisoformat(b["end"].replace("Z", "+00:00")))
            for b in cal.get("busy", [])
        ]

    def create_event(self, *, summary: str, description: str, start: datetime, end: datetime, tz: str, idempotency_key: str) -> str:
        # Google event ids: base32hex chars, 5-1024 long; deterministic id makes creation idempotent.
        event_id = "are" + "".join(c for c in idempotency_key.lower() if c in "0123456789abcdefghijklmnopqrstuv")[:60]
        r = self._req(
            "POST",
            f"/calendars/{self.calendar_id}/events",
            json={
                "id": event_id,
                "summary": summary,
                "description": description,
                "start": {"dateTime": start.isoformat(), "timeZone": tz},
                "end": {"dateTime": end.isoformat(), "timeZone": tz},
            },
        )
        if r.status_code == 409:  # already created by a previous attempt
            return event_id
        return str(r.json()["id"])

    def delete_event(self, event_id: str) -> None:
        self._req("DELETE", f"/calendars/{self.calendar_id}/events/{event_id}")

    def update_event(self, event_id: str, *, start: datetime, end: datetime, tz: str) -> None:
        self._req(
            "PATCH",
            f"/calendars/{self.calendar_id}/events/{event_id}",
            json={"start": {"dateTime": start.isoformat(), "timeZone": tz}, "end": {"dateTime": end.isoformat(), "timeZone": tz}},
        )

    def health(self) -> bool:
        try:
            self._req("GET", f"/calendars/{self.calendar_id}")
            return True
        except CalendarError:
            return False


class SandboxCalendar:
    """Development/test external calendar. Holds busy blocks in memory; can simulate outages."""

    name = "sandbox"
    busy_blocks: list[BusyInterval] = []
    fail = False
    events: dict[str, dict[str, Any]] = {}

    def __init__(self, db: Session | None = None, integration: Integration | None = None) -> None:
        pass

    def _check(self) -> None:
        if SandboxCalendar.fail:
            raise CalendarError("Sandbox calendar simulated outage")

    def busy(self, start: datetime, end: datetime) -> list[BusyInterval]:
        self._check()
        return [b for b in SandboxCalendar.busy_blocks if b.start < end and b.end > start]

    def create_event(self, *, summary: str, description: str, start: datetime, end: datetime, tz: str, idempotency_key: str) -> str:
        self._check()
        eid = f"sandbox-{idempotency_key}"
        SandboxCalendar.events[eid] = {"summary": summary, "start": start, "end": end}
        return eid

    def delete_event(self, event_id: str) -> None:
        self._check()
        SandboxCalendar.events.pop(event_id, None)

    def update_event(self, event_id: str, *, start: datetime, end: datetime, tz: str) -> None:
        self._check()
        if event_id in SandboxCalendar.events:
            SandboxCalendar.events[event_id].update(start=start, end=end)

    def health(self) -> bool:
        return not SandboxCalendar.fail


def external_calendar(db: Session, org_id: Any) -> ExternalCalendar | None:
    integ = db.scalar(
        select(Integration).where(Integration.organization_id == org_id, Integration.kind == "calendar", Integration.status.in_(("connected", "error")))
    )
    if integ is None:
        return None
    if integ.provider == "google":
        return GoogleCalendar(db, integ)
    if integ.provider == "sandbox":
        return SandboxCalendar(db, integ)
    return None
