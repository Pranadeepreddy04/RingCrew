"""CRM adapters (spec §36). Business logic never lives in the adapter; the adapter only maps
our lead/customer records onto the external system."""

from __future__ import annotations

import json
from typing import Any, Protocol

import httpx

from app.models import Customer, Integration, Lead
from app.security import decrypt


class CRMError(Exception):
    def __init__(self, message: str, retryable: bool = False) -> None:
        super().__init__(message)
        self.retryable = retryable


class CRMAdapter(Protocol):
    name: str

    def health(self) -> bool: ...

    def upsert_lead(self, lead: Lead, customer: Customer) -> dict[str, str]: ...


class HubSpotAdapter:
    """HubSpot via a private-app access token (scopes: crm.objects.contacts.write, crm.objects.deals.write)."""

    name = "hubspot"
    API = "https://api.hubapi.com"

    def __init__(self, integration: Integration) -> None:
        self.integration = integration
        self.token = json.loads(decrypt(integration.credentials_encrypted or ""))["access_token"]

    def _req(self, method: str, path: str, **kw: Any) -> dict[str, Any]:
        try:
            r = httpx.request(method, self.API + path, headers={"Authorization": f"Bearer {self.token}"}, timeout=15, **kw)
        except httpx.HTTPError as exc:
            raise CRMError(f"HubSpot unreachable: {exc.__class__.__name__}", retryable=True) from exc
        if r.status_code in (429,) or r.status_code >= 500:
            raise CRMError(f"HubSpot temporary error {r.status_code}", retryable=True)
        if r.status_code == 401:
            raise CRMError("HubSpot token rejected — reconnect HubSpot")
        if r.status_code >= 400 and r.status_code != 409:
            raise CRMError(f"HubSpot error {r.status_code}: {r.text[:200]}")
        return r.json() if r.content else {}

    def health(self) -> bool:
        try:
            self._req("GET", "/crm/v3/objects/contacts", params={"limit": 1})
            return True
        except CRMError:
            return False

    def upsert_lead(self, lead: Lead, customer: Customer) -> dict[str, str]:
        ext = dict((lead.qualification or {}).get("_external", {}))
        first, _, last = (customer.name or "").partition(" ")
        props = {"firstname": first, "lastname": last, "phone": customer.phone or "", "zip": customer.zip or ""}
        if customer.email:
            props["email"] = customer.email
        contact_id = ext.get("hubspot_contact_id")
        if contact_id:
            self._req("PATCH", f"/crm/v3/objects/contacts/{contact_id}", json={"properties": props})
        else:
            res = self._req("POST", "/crm/v3/objects/contacts", json={"properties": props})
            contact_id = res.get("id") or ""
        deal_props = {
            "dealname": f"{lead.service or 'Service request'} — {customer.name or customer.phone}",
            "pipeline": "default",
            "dealstage": "appointmentscheduled" if lead.status == "appointment" else "qualifiedtobuy" if lead.is_qualified else "appointmentscheduled",
            "description": lead.summary or "",
        }
        if lead.estimated_value_cents:
            deal_props["amount"] = str(lead.estimated_value_cents / 100)
        deal_id = ext.get("hubspot_deal_id")
        if deal_id:
            self._req("PATCH", f"/crm/v3/objects/deals/{deal_id}", json={"properties": deal_props})
        else:
            payload: dict[str, Any] = {"properties": deal_props}
            if contact_id:
                payload["associations"] = [{"to": {"id": contact_id}, "types": [{"associationCategory": "HUBSPOT_DEFINED", "associationTypeId": 3}]}]
            deal_id = self._req("POST", "/crm/v3/objects/deals", json=payload).get("id") or ""
        return {"hubspot_contact_id": str(contact_id), "hubspot_deal_id": str(deal_id)}


def crm_adapter(integration: Integration) -> CRMAdapter | None:
    if integration.provider == "hubspot":
        return HubSpotAdapter(integration)
    return None
