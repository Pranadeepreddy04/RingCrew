"""Email provider abstraction. SMTP is the real adapter; the sandbox provider only records
messages in `outbound_emails` with status `sandbox_not_sent` and never claims delivery."""

from __future__ import annotations

import smtplib
import ssl
import uuid
from email.message import EmailMessage
from typing import Protocol

from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import OutboundEmail


class EmailResult:
    def __init__(self, ok: bool, provider: str, status: str, error: str | None = None) -> None:
        self.ok, self.provider, self.status, self.error = ok, provider, status, error


class EmailProvider(Protocol):
    name: str

    def send(self, to: str, subject: str, body: str) -> EmailResult: ...


class SandboxEmailProvider:
    name = "sandbox"

    def send(self, to: str, subject: str, body: str) -> EmailResult:
        return EmailResult(True, self.name, "sandbox_not_sent")


class SmtpEmailProvider:
    name = "smtp"

    def send(self, to: str, subject: str, body: str) -> EmailResult:
        s = get_settings()
        msg = EmailMessage()
        msg["From"] = s.email_from
        msg["To"] = to
        msg["Subject"] = subject
        msg.set_content(body)
        try:
            with smtplib.SMTP(s.smtp_host or "", s.smtp_port, timeout=15) as smtp:
                smtp.starttls(context=ssl.create_default_context())
                if s.smtp_username:
                    smtp.login(s.smtp_username, s.smtp_password or "")
                smtp.send_message(msg)
            return EmailResult(True, self.name, "sent")
        except Exception as exc:  # map all transport errors to a failed result
            return EmailResult(False, self.name, "failed", str(exc)[:500])


def get_email_provider() -> EmailProvider:
    return SmtpEmailProvider() if get_settings().email_provider == "smtp" else SandboxEmailProvider()


def send_email(db: Session, to: str, subject: str, body: str, org_id: uuid.UUID | None = None) -> EmailResult:
    provider = get_email_provider()
    result = provider.send(to, subject, body)
    db.add(
        OutboundEmail(
            organization_id=org_id,
            to_address=to,
            subject=subject,
            body=body,
            provider=provider.name,
            status=result.status,
            error=result.error,
        )
    )
    return result
