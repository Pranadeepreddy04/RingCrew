"""SMS and voice provider abstractions (spec §10, §11, §91). Twilio is the real adapter;
the sandbox adapters never contact a carrier and label every result as sandbox."""

from __future__ import annotations

import base64
import hashlib
import hmac
from dataclasses import dataclass
from typing import Any, Protocol
from xml.sax.saxutils import escape

import httpx

from app.config import get_settings


@dataclass
class SendResult:
    ok: bool
    provider: str
    provider_message_id: str | None
    status: str
    error: str | None = None
    retryable: bool = False


class SmsProvider(Protocol):
    name: str
    is_sandbox: bool

    def send(self, *, from_number: str, to: str, body: str, status_callback: str | None = None) -> SendResult: ...

    def verify_webhook(self, url: str, params: dict[str, str], signature: str | None) -> bool: ...


def twilio_signature(auth_token: str, url: str, params: dict[str, str]) -> str:
    data = url + "".join(k + params[k] for k in sorted(params))
    return base64.b64encode(hmac.new(auth_token.encode(), data.encode(), hashlib.sha1).digest()).decode()


TWILIO_RETRYABLE = {20429, 20500, 20503, 30001, 30008}


class TwilioSms:
    name = "twilio"
    is_sandbox = False

    def __init__(self) -> None:
        s = get_settings()
        self.sid, self.token, self.msid = s.twilio_account_sid or "", s.twilio_auth_token or "", s.twilio_messaging_service_sid

    def send(self, *, from_number: str, to: str, body: str, status_callback: str | None = None) -> SendResult:
        data: dict[str, str] = {"To": to, "Body": body}
        if self.msid:
            data["MessagingServiceSid"] = self.msid
        else:
            data["From"] = from_number
        if status_callback:
            data["StatusCallback"] = status_callback
        try:
            r = httpx.post(f"https://api.twilio.com/2010-04-01/Accounts/{self.sid}/Messages.json", data=data, auth=(self.sid, self.token), timeout=15)
        except httpx.HTTPError as exc:
            return SendResult(False, self.name, None, "failed", f"network: {exc.__class__.__name__}", retryable=True)
        body_json: dict[str, Any] = r.json() if r.headers.get("content-type", "").startswith("application/json") else {}
        if r.status_code >= 400:
            code = int(body_json.get("code") or 0)
            return SendResult(
                False,
                self.name,
                None,
                "failed",
                f"twilio {code}: {body_json.get('message', r.text[:200])}",
                retryable=code in TWILIO_RETRYABLE or r.status_code >= 500,
            )
        return SendResult(True, self.name, body_json.get("sid"), body_json.get("status", "queued"))

    def verify_webhook(self, url: str, params: dict[str, str], signature: str | None) -> bool:
        if not signature or not self.token:
            return False
        return hmac.compare_digest(twilio_signature(self.token, url, params), signature)


class SandboxSms:
    name = "sandbox"
    is_sandbox = True
    outbox: list[dict[str, str]] = []
    fail_next: int = 0
    counter = 0

    def send(self, *, from_number: str, to: str, body: str, status_callback: str | None = None) -> SendResult:
        if SandboxSms.fail_next > 0:
            SandboxSms.fail_next -= 1
            return SendResult(False, self.name, None, "failed", "sandbox simulated delivery failure", retryable=True)
        SandboxSms.counter += 1
        mid = f"SMsandbox{SandboxSms.counter:08d}"
        SandboxSms.outbox.append({"from": from_number, "to": to, "body": body, "id": mid})
        return SendResult(True, self.name, mid, "sandbox_not_delivered")

    def verify_webhook(self, url: str, params: dict[str, str], signature: str | None) -> bool:
        # Sandbox webhooks are signed with SECRET_KEY-derived token so tests exercise the same path.
        return bool(signature) and hmac.compare_digest(twilio_signature(sandbox_webhook_token(), url, params), signature or "")


def sandbox_webhook_token() -> str:
    return hashlib.sha256(("sandbox-webhook:" + get_settings().secret_key).encode()).hexdigest()


def get_sms_provider() -> SmsProvider:
    return TwilioSms() if get_settings().sms_provider == "twilio" else SandboxSms()


# ------------------------------------------------------------------ voice


class VoiceProvider(Protocol):
    name: str
    is_sandbox: bool

    def verify_webhook(self, url: str, params: dict[str, str], signature: str | None) -> bool: ...

    def say_and_gather(self, text: str, action_url: str, *, voice: str | None, language: str, record: bool = False) -> str: ...

    def say_and_stream(
        self, text: str, stream_url: str, params: dict[str, str], keepalive_url: str, *, voice: str | None, language: str, record: bool = False
    ) -> str: ...

    def say_and_wait(self, text: str, keepalive_url: str, *, voice: str | None, language: str) -> str: ...

    def language_menu(self, intro: str, options: list[tuple[str, str]], action_url: str, *, voice: str | None, language: str) -> str: ...

    def transfer(self, text: str, to_number: str, *, voice: str | None, language: str) -> str: ...

    def hangup(self, text: str, *, voice: str | None, language: str) -> str: ...

    def update_call(self, call_id: str, twiml: str) -> bool: ...

    def provision_number(self, area_code: str, voice_url: str, sms_url: str) -> str: ...

    def get_call_status(self, call_id: str) -> dict[str, Any]: ...


def _say(text: str, voice: str | None, language: str) -> str:
    """<Say> with the voice and language code for one of the supported conversation languages."""
    from app.ai import i18n

    v, tts_lang = i18n.voice_for(language if language in i18n.LANGS else "en", voice)
    return f'<Say voice="{escape(v)}" language="{escape(tts_lang)}">{escape(text)}</Say>'


def _asr_lang(language: str) -> str:
    from app.ai import i18n

    return str(i18n.LANGS.get(language, i18n.LANGS["en"])["twilio_asr"])


XML_HEAD = '<?xml version="1.0" encoding="UTF-8"?><Response>'


class TwilioVoice:
    name = "twilio"
    is_sandbox = False

    def __init__(self) -> None:
        s = get_settings()
        self.sid, self.token = s.twilio_account_sid or "", s.twilio_auth_token or ""

    def verify_webhook(self, url: str, params: dict[str, str], signature: str | None) -> bool:
        if not signature or not self.token:
            return False
        return hmac.compare_digest(twilio_signature(self.token, url, params), signature)

    def say_and_gather(self, text: str, action_url: str, *, voice: str | None, language: str, record: bool = False) -> str:
        """Twilio recognizes the caller's speech (<Gather input="speech">) in the conversation language."""
        rec = "<Start><Recording/></Start>" if record else ""
        return (
            f"{XML_HEAD}{rec}"
            f'<Gather input="speech" action="{escape(action_url)}" method="POST" speechTimeout="auto" timeout="6" language="{_asr_lang(language)}" actionOnEmptyResult="true">'
            f"{_say(text, voice, language)}</Gather></Response>"
        )

    def say_and_stream(
        self, text: str, stream_url: str, params: dict[str, str], keepalive_url: str, *, voice: str | None, language: str, record: bool = False
    ) -> str:
        """Fork the caller's audio to our media-stream socket (VibeVoice ASR), speak, then hold the line.
        Replies are pushed later by updating the live call (``update_call``); <Start><Stream> keeps running across updates."""
        rec = "<Start><Recording/></Start>" if record else ""
        p = "".join(f'<Parameter name="{escape(k)}" value="{escape(v)}"/>' for k, v in params.items())
        return (
            f'{XML_HEAD}{rec}<Start><Stream url="{escape(stream_url)}" track="inbound_track">{p}</Stream></Start>'
            f'{_say(text, voice, language)}<Pause length="20"/><Redirect method="POST">{escape(keepalive_url)}</Redirect></Response>'
        )

    def say_and_wait(self, text: str, keepalive_url: str, *, voice: str | None, language: str) -> str:
        say = _say(text, voice, language) if text else ""
        return f'{XML_HEAD}{say}<Pause length="20"/><Redirect method="POST">{escape(keepalive_url)}</Redirect></Response>'

    def language_menu(self, intro: str, options: list[tuple[str, str]], action_url: str, *, voice: str | None, language: str) -> str:
        """Press-a-digit language choice; each option is spoken in its own language and voice."""
        lines = "".join(_say(prompt, voice if code == language else None, code) for code, prompt in options)
        return (
            f'{XML_HEAD}<Gather input="dtmf" numDigits="1" timeout="5" action="{escape(action_url)}" method="POST" actionOnEmptyResult="true">'
            f"{_say(intro, voice, language)}{lines}</Gather></Response>"
        )

    def transfer(self, text: str, to_number: str, *, voice: str | None, language: str) -> str:
        from app.ai import i18n

        return (
            f"{XML_HEAD}{_say(text, voice, language)}"
            f'<Dial timeout="25">{escape(to_number)}</Dial>'
            f"{_say(i18n.t('voice_no_one', language), voice, language)}</Response>"
        )

    def hangup(self, text: str, *, voice: str | None, language: str) -> str:
        return f"{XML_HEAD}{_say(text, voice, language)}<Hangup/></Response>"

    def update_call(self, call_id: str, twiml: str) -> bool:
        r = httpx.post(
            f"https://api.twilio.com/2010-04-01/Accounts/{self.sid}/Calls/{call_id}.json",
            data={"Twiml": twiml},
            auth=(self.sid, self.token),
            timeout=10,
        )
        return r.status_code < 300

    def provision_number(self, area_code: str, voice_url: str, sms_url: str) -> str:
        base = f"https://api.twilio.com/2010-04-01/Accounts/{self.sid}"
        with httpx.Client(auth=(self.sid, self.token), timeout=20) as c:
            avail = c.get(f"{base}/AvailablePhoneNumbers/US/Local.json", params={"AreaCode": area_code, "SmsEnabled": "true", "VoiceEnabled": "true"})
            nums = avail.json().get("available_phone_numbers", []) if avail.status_code == 200 else []
            if not nums:
                raise RuntimeError("No numbers available for that area code")
            r = c.post(f"{base}/IncomingPhoneNumbers.json", data={"PhoneNumber": nums[0]["phone_number"], "VoiceUrl": voice_url, "SmsUrl": sms_url})
            if r.status_code >= 400:
                raise RuntimeError(f"Twilio provisioning failed: {r.text[:200]}")
            return str(r.json()["phone_number"])

    def get_call_status(self, call_id: str) -> dict[str, Any]:
        r = httpx.get(f"https://api.twilio.com/2010-04-01/Accounts/{self.sid}/Calls/{call_id}.json", auth=(self.sid, self.token), timeout=10)
        return r.json() if r.status_code == 200 else {"status": "unknown"}


class SandboxVoice(TwilioVoice):
    """Produces the same TwiML so the full call flow is testable, but cannot place/receive real calls."""

    name = "sandbox"
    is_sandbox = True

    def __init__(self) -> None:
        self.sid, self.token = "", sandbox_webhook_token()

    def provision_number(self, area_code: str, voice_url: str, sms_url: str) -> str:
        import random

        return f"+1{area_code}555{random.randint(1000, 9999)}"

    def get_call_status(self, call_id: str) -> dict[str, Any]:
        return {"status": "sandbox"}

    updates: list[tuple[str, str]] = []  # (call_sid, twiml) — what a real call would have been updated with

    def update_call(self, call_id: str, twiml: str) -> bool:
        SandboxVoice.updates.append((call_id, twiml))
        return True


def get_voice_provider() -> VoiceProvider:
    return TwilioVoice() if get_settings().voice_provider == "twilio" else SandboxVoice()
