"""Fixed-window rate limiting. Uses Redis when REDIS_URL is configured (multi-instance safe),
otherwise an in-process store (single instance / development)."""

from __future__ import annotations

import time
from threading import Lock

from fastapi import Request

from app.config import get_settings
from app.errors import AppError

_mem: dict[str, tuple[int, float]] = {}
_lock = Lock()
_redis = None


def _get_redis():  # type: ignore[no-untyped-def]
    global _redis
    url = get_settings().redis_url
    if not url:
        return None
    if _redis is None:
        import redis

        _redis = redis.Redis.from_url(url, socket_timeout=0.5)
    return _redis


def hit(key: str, limit: int, window_seconds: int) -> bool:
    """Return True if allowed."""
    if get_settings().app_env == "test" and not key.startswith("test:"):
        return True
    r = _get_redis()
    bucket = f"rl:{key}:{int(time.time() // window_seconds)}"
    if r is not None:
        try:
            n = r.incr(bucket)
            if n == 1:
                r.expire(bucket, window_seconds)
            return int(n) <= limit
        except Exception:  # Redis outage must not take the API down; fall back to memory
            pass
    now = time.time()
    with _lock:
        count, exp = _mem.get(bucket, (0, now + window_seconds))
        if exp < now:
            count, exp = 0, now + window_seconds
        count += 1
        _mem[bucket] = (count, exp)
        if len(_mem) > 50000:
            for k in [k for k, (_, e) in _mem.items() if e < now]:
                _mem.pop(k, None)
    return count <= limit


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def enforce(request: Request, scope: str, limit: int, window_seconds: int = 60, key: str | None = None) -> None:
    k = f"{scope}:{key or client_ip(request)}"
    if not hit(k, limit, window_seconds):
        raise AppError(429, "rate_limited", "Too many requests. Please slow down and try again shortly.")
