"""Platform administration (spec §49, §98). Every mutating action and every impersonation is audited."""

from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import AuthContext, require_superadmin
from app.errors import AppError, bad_request, not_found
from app.industry import PackError, list_packs, resolve_pack
from app.models import (
    AITrace,
    AuditLog,
    Conversation,
    Event,
    FeatureFlag,
    IndustryTemplate,
    Integration,
    Job,
    Lead,
    Membership,
    Message,
    Organization,
    Plan,
    Subscription,
    UsageRecord,
    User,
    UserSession,
    WebhookDelivery,
    WorkflowRun,
)
from app.observability import metrics
from app.ratelimit import client_ip
from app.services.common import audit, utcnow

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/overview")
def overview(auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> dict[str, Any]:
    since = utcnow() - timedelta(days=30)
    subs = db.execute(select(Subscription.status, func.count()).group_by(Subscription.status)).all()
    mrr = (
        db.scalar(
            select(func.coalesce(func.sum(Plan.price_cents), 0))
            .select_from(Subscription)
            .join(Plan, Plan.id == Subscription.plan_id)
            .where(Subscription.status == "active")
        )
        or 0
    )
    usage = db.execute(
        select(UsageRecord.kind, func.sum(UsageRecord.quantity), func.sum(UsageRecord.cost_micros))
        .where(UsageRecord.created_at >= since)
        .group_by(UsageRecord.kind)
    ).all()
    return {
        "organizations": db.scalar(select(func.count()).select_from(Organization).where(Organization.deleted_at.is_(None), Organization.is_demo.is_(False))),
        "demo_organizations": db.scalar(
            select(func.count()).select_from(Organization).where(Organization.is_demo.is_(True), Organization.deleted_at.is_(None))
        ),
        "users": db.scalar(select(func.count()).select_from(User)),
        "subscriptions": {s: int(n) for s, n in subs},
        "mrr_cents": int(mrr),
        "usage_30d": {k: {"quantity": int(q or 0), "estimated_cost_usd": round(int(c or 0) / 1e6, 2)} for k, q, c in usage},
        "failed_jobs": db.scalar(select(func.count()).select_from(Job).where(Job.status == "failed")),
        "queued_jobs": db.scalar(select(func.count()).select_from(Job).where(Job.status == "queued")),
        "failed_webhooks": db.scalar(select(func.count()).select_from(WebhookDelivery).where(WebhookDelivery.status == "failed")),
        "failed_workflow_runs": db.scalar(select(func.count()).select_from(WorkflowRun).where(WorkflowRun.status == "failed")),
        "integration_errors": db.scalar(select(func.count()).select_from(Integration).where(Integration.status == "error")),
        "ai_errors_24h": db.scalar(select(func.count()).select_from(AITrace).where(AITrace.created_at >= utcnow() - timedelta(days=1), AITrace.status != "ok")),
        "leads_30d": db.scalar(select(func.count()).select_from(Lead).where(Lead.created_at >= since)),
    }


@router.get("/organizations")
def orgs(q: str | None = None, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    query = (
        select(Organization, Subscription, Plan)
        .outerjoin(Subscription, Subscription.organization_id == Organization.id)
        .outerjoin(Plan, Plan.id == Subscription.plan_id)
    )
    if q:
        query = query.where(Organization.name.ilike(f"%{q[:100]}%"))
    rows = db.execute(query.order_by(Organization.created_at.desc()).limit(200)).all()
    return [
        {
            "id": str(o.id),
            "name": o.name,
            "industry": o.industry,
            "status": o.status,
            "is_demo": o.is_demo,
            "deleted": o.deleted_at is not None,
            "plan": p.key if p else None,
            "subscription_status": s.status if s else None,
            "created_at": o.created_at.isoformat(),
        }
        for o, s, p in rows
    ]


class OrgStatusIn(BaseModel):
    status: str = Field(pattern="^(active|suspended)$")
    reason: str = Field(min_length=3, max_length=300)


@router.post("/organizations/{org_id}/status")
def set_org_status(
    org_id: uuid.UUID, body: OrgStatusIn, request: Request, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)
) -> dict[str, bool]:
    o = db.get(Organization, org_id)
    if o is None:
        raise not_found("Organization")
    o.status = body.status
    audit(
        db,
        f"admin.organization_{body.status}",
        org_id=o.id,
        actor_user_id=auth.user.id,
        actor_type="admin",
        data={"reason": body.reason},
        ip=client_ip(request),
    )
    db.commit()
    return {"ok": True}


@router.get("/users")
def users(q: str | None = None, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    query = select(User)
    if q:
        query = query.where(User.email.ilike(f"%{q[:100]}%"))
    return [
        {
            "id": str(u.id),
            "email": u.email,
            "name": u.name,
            "is_active": u.is_active,
            "is_superadmin": u.is_superadmin,
            "last_login_at": u.last_login_at.isoformat() if u.last_login_at else None,
        }
        for u in db.scalars(query.order_by(User.created_at.desc()).limit(200))
    ]


class UserStatusIn(BaseModel):
    is_active: bool


@router.post("/users/{user_id}/status")
def set_user_status(
    user_id: uuid.UUID, body: UserStatusIn, request: Request, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)
) -> dict[str, bool]:
    u = db.get(User, user_id)
    if u is None:
        raise not_found("User")
    if u.id == auth.user.id:
        raise bad_request("You cannot disable your own account")
    u.is_active = body.is_active
    if not body.is_active:
        db.execute(UserSession.__table__.update().where(UserSession.user_id == u.id, UserSession.revoked_at.is_(None)).values(revoked_at=utcnow()))  # type: ignore[attr-defined]
    audit(
        db,
        "admin.user_status",
        org_id=None,
        actor_user_id=auth.user.id,
        actor_type="admin",
        target_type="user",
        target_id=u.id,
        data={"is_active": body.is_active},
        ip=client_ip(request),
    )
    db.commit()
    return {"ok": True}


class ImpersonateIn(BaseModel):
    user_id: uuid.UUID
    reason: str = Field(min_length=10, max_length=500)


@router.post("/impersonate")
def impersonate(
    body: ImpersonateIn, request: Request, response: Response, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)
) -> dict[str, Any]:
    """Starts a 1-hour session as the target user, clearly flagged in the UI and fully audited."""
    target = db.get(User, body.user_id)
    if target is None or not target.is_active:
        raise not_found("User")
    if target.is_superadmin:
        raise AppError(403, "forbidden", "Cannot impersonate another administrator")
    from app.routers.auth import _user_out, start_session

    orgs: list[uuid.UUID | None] = [m.organization_id for m in db.scalars(select(Membership).where(Membership.user_id == target.id))]
    for oid in orgs or [None]:
        audit(
            db,
            "admin.impersonation_started",
            org_id=oid,
            actor_user_id=auth.user.id,
            actor_type="admin",
            target_type="user",
            target_id=target.id,
            data={"reason": body.reason},
            ip=client_ip(request),
        )
    sess, _ = start_session(db, response, request, target, impersonator=auth.user.id)
    db.commit()
    return _user_out(db, target, sess)


class PlanIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    price_cents: int = Field(ge=0, le=10_000_000)
    features: list[str]
    limits: dict[str, int]
    provider_price_id: str | None = Field(default=None, max_length=120)
    active: bool = True


@router.get("/plans")
def plans(auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    return [
        {
            "key": p.key,
            "name": p.name,
            "price_cents": p.price_cents,
            "features": p.features,
            "limits": p.limits,
            "provider_price_id": p.provider_price_id,
            "active": p.active,
        }
        for p in db.scalars(select(Plan).order_by(Plan.sort_order))
    ]


@router.put("/plans/{key}")
def put_plan(key: str, body: PlanIn, request: Request, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> dict[str, bool]:
    p = db.scalar(select(Plan).where(Plan.key == key))
    if p is None:
        p = Plan(key=key[:40], sort_order=99, **body.model_dump())
        db.add(p)
    else:
        for k, v in body.model_dump().items():
            setattr(p, k, v)
    audit(db, "admin.plan_updated", org_id=None, actor_user_id=auth.user.id, actor_type="admin", data={"key": key, **body.model_dump()}, ip=client_ip(request))
    db.commit()
    return {"ok": True}


@router.get("/industry-templates")
def templates(auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    stored = {t.key: t for t in db.scalars(select(IndustryTemplate))}
    return [
        {**p, "version": stored[p["key"]].version if p["key"] in stored else None, "config": stored[p["key"]].config if p["key"] in stored else None}
        for p in list_packs(db)
    ]


class TemplateIn(BaseModel):
    status: str = Field(pattern="^(active|beta|disabled)$")
    config: dict[str, Any] | None = None


@router.put("/industry-templates/{key}")
def put_template(
    key: str, body: TemplateIn, request: Request, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)
) -> dict[str, Any]:
    t = db.scalar(select(IndustryTemplate).where(IndustryTemplate.key == key))
    if t is None:
        raise not_found("Industry template")
    if t.category == "regulated" and body.status == "active":
        raise AppError(400, "compliance_required", "Regulated industry templates cannot be activated until compliance work is complete")
    old = (t.status, t.config)
    t.status = body.status
    if body.config is not None:
        t.config = {**body.config, "key": key}
        t.version += 1
    try:
        resolve_pack(key, db)
    except PackError as exc:
        t.status, t.config = old
        raise bad_request(f"Invalid template: {exc}") from None
    audit(
        db,
        "admin.template_updated",
        org_id=None,
        actor_user_id=auth.user.id,
        actor_type="admin",
        data={"key": key, "status": body.status},
        ip=client_ip(request),
    )
    db.commit()
    return {"ok": True, "version": t.version}


class FlagIn(BaseModel):
    key: str = Field(min_length=2, max_length=80, pattern=r"^[a-z0-9_.-]+$")
    enabled: bool
    organization_id: uuid.UUID | None = None
    description: str | None = Field(default=None, max_length=300)


@router.get("/feature-flags")
def flags(auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    return [
        {
            "id": str(f.id),
            "key": f.key,
            "enabled": f.enabled,
            "organization_id": str(f.organization_id) if f.organization_id else None,
            "description": f.description,
        }
        for f in db.scalars(select(FeatureFlag).order_by(FeatureFlag.key))
    ]


@router.put("/feature-flags")
def put_flag(body: FlagIn, request: Request, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> dict[str, bool]:
    f = db.scalar(
        select(FeatureFlag).where(
            FeatureFlag.key == body.key,
            FeatureFlag.organization_id.is_(body.organization_id) if body.organization_id is None else FeatureFlag.organization_id == body.organization_id,
        )
    )
    if f is None:
        f = FeatureFlag(key=body.key, organization_id=body.organization_id)
        db.add(f)
    f.enabled, f.description = body.enabled, body.description or f.description
    audit(
        db,
        "admin.flag_updated",
        org_id=body.organization_id,
        actor_user_id=auth.user.id,
        actor_type="admin",
        data=body.model_dump(mode="json"),
        ip=client_ip(request),
    )
    db.commit()
    return {"ok": True}


@router.get("/jobs")
def jobs(status: str = "failed", auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    return [
        {
            "id": str(j.id),
            "kind": j.kind,
            "status": j.status,
            "attempts": j.attempts,
            "last_error": j.last_error,
            "organization_id": str(j.organization_id) if j.organization_id else None,
            "run_at": j.run_at.isoformat(),
            "created_at": j.created_at.isoformat(),
        }
        for j in db.scalars(select(Job).where(Job.status == status).order_by(Job.created_at.desc()).limit(200))
    ]


@router.post("/jobs/{job_id}/retry")
def retry_job(job_id: uuid.UUID, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> dict[str, bool]:
    j = db.get(Job, job_id)
    if j is None:
        raise not_found("Job")
    j.status, j.run_at, j.attempts, j.locked_at = "queued", utcnow(), 0, None
    audit(db, "admin.job_retried", org_id=j.organization_id, actor_user_id=auth.user.id, actor_type="admin", target_type="job", target_id=j.id)
    db.commit()
    return {"ok": True}


@router.get("/integrations/health")
def integration_health(auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.execute(
        select(Integration, Organization.name).join(Organization, Organization.id == Integration.organization_id).order_by(Integration.status.desc()).limit(300)
    ).all()
    return [
        {
            "organization": name,
            "kind": i.kind,
            "provider": i.provider,
            "status": i.status,
            "last_error": i.last_error,
            "last_sync_at": i.last_sync_at.isoformat() if i.last_sync_at else None,
        }
        for i, name in rows
    ]


@router.get("/audit-logs")
def audit_logs(org_id: uuid.UUID | None = None, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    q = select(AuditLog)
    if org_id:
        q = q.where(AuditLog.organization_id == org_id)
    return [
        {
            "id": str(a.id),
            "action": a.action,
            "actor_type": a.actor_type,
            "actor_user_id": str(a.actor_user_id) if a.actor_user_id else None,
            "organization_id": str(a.organization_id) if a.organization_id else None,
            "target": f"{a.target_type}:{a.target_id}" if a.target_type else None,
            "data": a.data,
            "ip": a.ip,
            "request_id": a.request_id,
            "created_at": a.created_at.isoformat(),
        }
        for a in db.scalars(q.order_by(AuditLog.created_at.desc()).limit(300))
    ]


@router.get("/conversations/{conversation_id}/investigate")
def investigate(conversation_id: uuid.UUID, auth: AuthContext = Depends(require_superadmin), db: Session = Depends(get_db)) -> dict[str, Any]:
    """Answers 'Why didn't this customer get an appointment?' — full ordered trace of one conversation."""
    c = db.get(Conversation, conversation_id)
    if c is None:
        raise not_found("Conversation")
    audit(
        db,
        "admin.conversation_investigated",
        org_id=c.organization_id,
        actor_user_id=auth.user.id,
        actor_type="admin",
        target_type="conversation",
        target_id=c.id,
    )
    db.commit()
    timeline: list[dict[str, Any]] = []
    for m in db.scalars(select(Message).where(Message.conversation_id == c.id)):
        timeline.append(
            {"at": m.created_at.isoformat(), "kind": "message" if m.role != "tool" else "tool", "role": m.role, "content": m.content, "meta": m.meta}
        )
    for t in db.scalars(select(AITrace).where(AITrace.conversation_id == c.id)):
        timeline.append(
            {
                "at": t.created_at.isoformat(),
                "kind": "ai_call",
                "provider": t.provider,
                "model": t.model,
                "operation": t.operation,
                "status": t.status,
                "latency_ms": t.latency_ms,
                "error": t.error,
                "prompt_version": t.prompt_version,
                "request_id": t.request_id,
            }
        )
    for e in db.scalars(select(Event).where(Event.conversation_id == c.id)):
        timeline.append({"at": e.created_at.isoformat(), "kind": "event", "type": e.type, "data": e.data})
    timeline.sort(key=lambda x: x["at"])
    st = c.state or {}
    return {
        "conversation_id": str(c.id),
        "organization_id": str(c.organization_id),
        "channel": c.channel,
        "status": c.status,
        "stage": st.get("stage"),
        "handoff_reason": c.handoff_reason,
        "collected_fields": sorted((st.get("fields") or {}).keys()),
        "outcome": "appointment_booked" if st.get("appointment_id") else ("handed_off" if c.handoff_active else st.get("stage")),
        "timeline": timeline,
    }


@router.get("/metrics")
def admin_metrics(auth: AuthContext = Depends(require_superadmin)) -> Response:
    return Response(metrics.render(), media_type="text/plain")
