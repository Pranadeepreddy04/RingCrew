"""AI employees: CRUD, activation, industry-pack overrides, and the owner test environment (spec §7 steps 4–9, §8)."""

from __future__ import annotations

import re
import uuid
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai import i18n
from app.ai.orchestrator import process_customer_message, start_conversation
from app.ai.tools import CAPABILITIES
from app.db import get_db
from app.deps import OrgContext, get_org_ctx, require
from app.errors import AppError, bad_request, not_found
from app.industry import PackError, resolve_pack
from app.models import AIAgent, BusinessProfile, Conversation, KnowledgeSource, Message, PhoneNumber
from app.security import new_token
from app.services import billing
from app.services.common import audit, emit_event, utcnow
from app.services.serializers import agent_out, conversation_out, message_out

router = APIRouter(prefix="/agents", tags=["ai-employees"])

ROLES = ("receptionist", "lead_qualifier", "appointment_setter", "follow_up", "sales_assistant", "customer_service", "review_assistant")
TONES = ("friendly", "professional", "warm", "concise")
ROLE_DEFAULT_CAPS = {
    "receptionist": ["web_chat", "answer_calls", "answer_sms", "answer_faqs", "capture_leads", "qualify_leads", "schedule_appointments", "transfer_calls"],
    "lead_qualifier": ["web_chat", "answer_sms", "answer_faqs", "capture_leads", "qualify_leads", "collect_quote_info"],
    "appointment_setter": ["web_chat", "answer_sms", "answer_calls", "capture_leads", "schedule_appointments", "send_reminders"],
    "follow_up": ["answer_sms", "follow_up", "send_reminders", "capture_leads"],
    "sales_assistant": ["web_chat", "answer_faqs", "capture_leads", "qualify_leads", "collect_quote_info", "schedule_appointments"],
    "customer_service": ["web_chat", "answer_sms", "answer_calls", "answer_faqs", "transfer_calls"],
    "review_assistant": ["send_reminders"],
}


def validate_tone(v: str) -> str:
    if v not in TONES:
        raise ValueError(f"tone must be one of {TONES}")
    return v


def validate_caps(v: list[str] | None) -> list[str] | None:
    if v is not None:
        bad = [c for c in v if c not in CAPABILITIES]
        if bad:
            raise ValueError(f"Unknown capabilities: {bad}")
        return sorted(set(v))
    return v


def _validate_languages(v: list[str] | None) -> list[str] | None:
    if v is None:
        return v
    out: list[str] = []
    for code in v:
        code = code.strip().lower()
        if code not in i18n.SUPPORTED:
            raise ValueError(f"Unsupported language {code!r}; supported: {sorted(i18n.SUPPORTED)}")
        if code not in out:
            out.append(code)
    if not out:
        raise ValueError("At least one language is required")
    return out


def _validate_greetings(v: dict[str, str] | None) -> dict[str, str] | None:
    if v is None:
        return v
    out: dict[str, str] = {}
    for code, text in v.items():
        if code not in i18n.SUPPORTED:
            raise ValueError(f"Unsupported greeting language {code!r}")
        text = (text or "").strip()
        if len(text) > 500:
            raise ValueError("Greeting must be 500 characters or fewer")
        if text:
            out[code] = text
    return out


class AgentIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    role: str = "receptionist"
    greeting: str | None = Field(default=None, max_length=500)
    tone: str = "friendly"
    language: str = Field(default="en", pattern=r"^[a-z]{2}(-[A-Z]{2})?$")
    languages: list[str] | None = Field(default=None, max_length=7)
    greetings: dict[str, str] | None = None
    voice: str | None = Field(default=None, max_length=60)
    capabilities: list[str] | None = None
    widget_settings: dict[str, Any] | None = None

    @field_validator("role")
    @classmethod
    def _role(cls, v: str) -> str:
        if v not in ROLES:
            raise ValueError(f"role must be one of {ROLES}")
        return v

    @field_validator("tone")
    @classmethod
    def _tone(cls, v: str) -> str:
        return validate_tone(v)

    @field_validator("capabilities")
    @classmethod
    def _caps(cls, v: list[str] | None) -> list[str] | None:
        return validate_caps(v)

    @field_validator("languages")
    @classmethod
    def _langs(cls, v: list[str] | None) -> list[str] | None:
        return _validate_languages(v)

    @field_validator("greetings")
    @classmethod
    def _greets(cls, v: dict[str, str] | None) -> dict[str, str] | None:
        return _validate_greetings(v)


class AgentPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    greeting: str | None = Field(default=None, min_length=1, max_length=500)
    tone: str | None = None
    language: str | None = Field(default=None, pattern=r"^[a-z]{2}(-[A-Z]{2})?$")
    languages: list[str] | None = Field(default=None, max_length=7)
    greetings: dict[str, str] | None = None
    voice: str | None = Field(default=None, max_length=60)
    capabilities: list[str] | None = None
    widget_settings: dict[str, Any] | None = None

    @field_validator("tone")
    @classmethod
    def _tone(cls, v: str | None) -> str | None:
        return validate_tone(v) if v is not None else v

    @field_validator("capabilities")
    @classmethod
    def _caps(cls, v: list[str] | None) -> list[str] | None:
        return validate_caps(v)

    @field_validator("languages")
    @classmethod
    def _langs(cls, v: list[str] | None) -> list[str] | None:
        return _validate_languages(v)

    @field_validator("greetings")
    @classmethod
    def _greets(cls, v: dict[str, str] | None) -> dict[str, str] | None:
        return _validate_greetings(v)


WIDGET_KEYS = {"position", "welcome_message", "logo_url", "primary_color", "title"}


def _clean_widget(ws: dict[str, Any]) -> dict[str, Any]:
    out = {k: v for k, v in ws.items() if k in WIDGET_KEYS and isinstance(v, str) and len(v) <= 500}
    if "position" in out and out["position"] not in ("bottom-right", "bottom-left"):
        raise bad_request("position must be bottom-right or bottom-left")
    if "primary_color" in out and not re.fullmatch(r"#[0-9a-fA-F]{6}", out["primary_color"]):
        raise bad_request("primary_color must be a hex color like #1f6feb")
    if "logo_url" in out and not out["logo_url"].startswith("https://"):
        raise bad_request("logo_url must be an https URL")
    return out


def _get(db: Session, ctx: OrgContext, agent_id: uuid.UUID) -> AIAgent:
    a = db.scalar(select(AIAgent).where(AIAgent.id == agent_id, AIAgent.organization_id == ctx.org_id, AIAgent.deleted_at.is_(None)))
    if a is None:
        raise not_found("AI employee")
    return a


@router.get("")
def list_agents(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    rows = db.scalars(select(AIAgent).where(AIAgent.organization_id == ctx.org_id, AIAgent.deleted_at.is_(None)).order_by(AIAgent.created_at)).all()
    return [agent_out(a, include_widget=ctx.can("agents.manage")) for a in rows]


@router.post("", status_code=201)
def create_agent(body: AgentIn, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    if not billing.count_limit_ok(db, ctx.org, "agents"):
        raise AppError(402, "plan_limit", "Your plan's AI employee limit has been reached. Upgrade to add more AI employees.")
    try:
        pack = resolve_pack(ctx.org.industry, db)
    except PackError:
        raise bad_request("Organization industry is not configured") from None
    greeting = body.greeting or f"Hi, thanks for contacting {ctx.org.name}! I'm {body.name}. How can I help you today?"
    a = AIAgent(
        organization_id=ctx.org_id,
        name=body.name.strip(),
        role=body.role,
        greeting=greeting,
        tone=body.tone,
        language=body.languages[0] if body.languages else body.language,
        languages=body.languages or [body.language if body.language in i18n.SUPPORTED else "en"],
        greetings=body.greetings or {},
        voice=body.voice,
        capabilities=body.capabilities if body.capabilities is not None else ROLE_DEFAULT_CAPS[body.role],
        industry_template_key=pack.key,
        widget_token="wt_" + new_token(24),
        widget_settings=_clean_widget(body.widget_settings or {}),
        status="draft",
    )
    db.add(a)
    db.flush()
    if ctx.org.onboarding_step < 5:
        ctx.org.onboarding_step = 5
    audit(db, "agent.created", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="agent", target_id=a.id)
    db.commit()
    return agent_out(a)


@router.get("/{agent_id}")
def get_agent(agent_id: uuid.UUID, ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    return agent_out(_get(db, ctx, agent_id), include_widget=ctx.can("agents.manage"))


@router.patch("/{agent_id}")
def patch_agent(agent_id: uuid.UUID, body: AgentPatch, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    data = body.model_dump(exclude_unset=True)
    if "widget_settings" in data and data["widget_settings"] is not None:
        data["widget_settings"] = _clean_widget(data["widget_settings"])
    if data.get("languages"):
        # The primary language is the first one; keep it in sync for older readers.
        data["language"] = data["languages"][0]
    elif data.get("language") and data["language"] in i18n.SUPPORTED and data["language"] not in (a.languages or []):
        data["languages"] = [data["language"], *[x for x in (a.languages or []) if x != data["language"]]]
    for k, v in data.items():
        if v is not None:
            setattr(a, k, v)
    audit(db, "agent.updated", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="agent", target_id=a.id, data={"fields": list(data)})
    db.commit()
    return agent_out(a)


@router.delete("/{agent_id}")
def delete_agent(agent_id: uuid.UUID, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    a = _get(db, ctx, agent_id)
    a.deleted_at, a.status = utcnow(), "paused"
    a.widget_token = "revoked_" + new_token(24)
    db.execute(PhoneNumber.__table__.update().where(PhoneNumber.agent_id == a.id).values(agent_id=None))  # type: ignore[attr-defined]
    audit(db, "agent.deleted", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="agent", target_id=a.id)
    db.commit()
    return {"ok": True}


def activation_checks(db: Session, ctx: OrgContext, a: AIAgent) -> list[dict[str, Any]]:
    profile = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == ctx.org_id))
    has_hours = bool(profile and any((profile.hours or {}).get(d) for d in ("mon", "tue", "wed", "thu", "fri", "sat", "sun")))
    has_knowledge = bool(db.scalar(select(KnowledgeSource.id).where(KnowledgeSource.organization_id == ctx.org_id).limit(1)))
    tested = bool(
        db.scalar(
            select(Conversation.id).where(Conversation.organization_id == ctx.org_id, Conversation.agent_id == a.id, Conversation.is_test.is_(True)).limit(1)
        )
    )
    ent = billing.entitlements(db, ctx.org)
    has_number = bool(db.scalar(select(PhoneNumber.id).where(PhoneNumber.organization_id == ctx.org_id).limit(1)))
    pack = resolve_pack(a.industry_template_key, db)
    return [
        {"key": "industry_enabled", "ok": pack.status != "disabled", "blocking": True, "label": "Industry template is enabled"},
        {"key": "subscription", "ok": bool(ent["usable"]), "blocking": True, "label": "Active trial or subscription"},
        {
            "key": "business_hours",
            "ok": has_hours or "schedule_appointments" not in a.capabilities,
            "blocking": True,
            "label": "Business hours set (needed for scheduling)",
        },
        {"key": "knowledge", "ok": has_knowledge, "blocking": False, "label": "Business knowledge added"},
        {"key": "tested", "ok": tested, "blocking": False, "label": "Tested in the test environment"},
        {
            "key": "phone_number",
            "ok": has_number or not ({"answer_calls", "answer_sms"} & set(a.capabilities)),
            "blocking": False,
            "label": "Phone number connected (for calls/SMS)",
        },
    ]


@router.get("/{agent_id}/activation-checks")
def get_activation_checks(agent_id: uuid.UUID, ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    return activation_checks(db, ctx, _get(db, ctx, agent_id))


@router.post("/{agent_id}/activate")
def activate(agent_id: uuid.UUID, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    blocking = [c for c in activation_checks(db, ctx, a) if c["blocking"] and not c["ok"]]
    if blocking:
        raise AppError(400, "activation_blocked", "Complete the required steps before activating", details=blocking)
    a.status, a.activated_at = "active", utcnow()
    if not ctx.org.onboarding_completed_at:
        ctx.org.onboarding_completed_at = utcnow()
        ctx.org.onboarding_step = 9
    emit_event(db, ctx.org_id, "agent.activated", agent_id=a.id)
    audit(db, "agent.activated", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="agent", target_id=a.id)
    db.commit()
    return agent_out(a)


@router.post("/{agent_id}/pause")
def pause(agent_id: uuid.UUID, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    a.status = "paused"
    audit(db, "agent.paused", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="agent", target_id=a.id)
    db.commit()
    return agent_out(a)


@router.post("/{agent_id}/rotate-widget-token")
def rotate_widget(agent_id: uuid.UUID, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    a.widget_token = "wt_" + new_token(24)
    audit(db, "agent.widget_token_rotated", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="agent", target_id=a.id)
    db.commit()
    return agent_out(a)


@router.get("/{agent_id}/pack")
def agent_pack(agent_id: uuid.UUID, ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    p = resolve_pack(a.industry_template_key, db, a.pack_overrides)
    return {
        "key": p.key,
        "name": p.name,
        "appointment_label": p.appointment_label,
        "collection_order": p.collection_order,
        "fields": [
            {
                "key": f.key,
                "label": f.label,
                "type": f.type,
                "required": f.required,
                "enabled": f.enabled,
                "prompt": f.prompt,
                "options": list(f.options),
                "locked": f.key in ("name", "phone"),
            }
            for f in p.fields
        ],
        "overrides": a.pack_overrides,
    }


class PackOverridesIn(BaseModel):
    fields: dict[str, dict[str, Any]]


@router.put("/{agent_id}/pack")
def put_pack(agent_id: uuid.UUID, body: PackOverridesIn, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    base = resolve_pack(a.industry_template_key, db)
    clean: dict[str, dict[str, Any]] = {}
    for key, patch in body.fields.items():
        if base.field(key) is None:
            raise bad_request(f"Unknown field {key}")
        c: dict[str, Any] = {}
        for k in ("enabled", "required"):
            if k in patch:
                c[k] = bool(patch[k])
        if "prompt" in patch and patch["prompt"]:
            c["prompt"] = str(patch["prompt"])[:300]
        clean[key] = c
    a.pack_overrides = {"fields": clean}
    audit(db, "agent.pack_updated", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="agent", target_id=a.id)
    db.commit()
    return agent_pack(agent_id, ctx, db)


# ------------------------------------------------------------------ test environment (dry run)


class TestStartIn(BaseModel):
    language: str | None = Field(default=None, max_length=10)


@router.post("/{agent_id}/test/conversations", status_code=201)
def test_start(
    agent_id: uuid.UUID, body: TestStartIn | None = None, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    conv = start_conversation(db, ctx.org, a, "test", is_test=True, language=(body.language if body else None))
    db.commit()
    msgs = db.scalars(select(Message).where(Message.conversation_id == conv.id).order_by(Message.created_at)).all()
    return {"conversation": conversation_out(conv), "messages": [message_out(m) for m in msgs]}


class TestMessageIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)
    simulate_channel: str = Field(default="web", pattern="^(web|voice|sms)$")


@router.post("/{agent_id}/test/conversations/{conversation_id}/messages")
def test_message(
    agent_id: uuid.UUID, conversation_id: uuid.UUID, body: TestMessageIn, ctx: OrgContext = Depends(require("agents.manage")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    a = _get(db, ctx, agent_id)
    conv = db.scalar(
        select(Conversation)
        .where(Conversation.id == conversation_id, Conversation.organization_id == ctx.org_id, Conversation.agent_id == a.id, Conversation.is_test.is_(True))
        .with_for_update()
    )
    if conv is None:
        raise not_found("Test conversation")
    conv.channel = "test" if body.simulate_channel == "web" else body.simulate_channel
    _, result, reply = process_customer_message(db, ctx.org, a, conv, body.text)
    conv.channel = "test"
    db.commit()
    return {
        "reply": result.reply,
        "handoff": result.handoff,
        "transfer_to": result.transfer_to,
        "actions": result.actions,
        "state": {k: v for k, v in (conv.state or {}).items() if not k.startswith("_")},
        "conversation": conversation_out(conv),
    }
