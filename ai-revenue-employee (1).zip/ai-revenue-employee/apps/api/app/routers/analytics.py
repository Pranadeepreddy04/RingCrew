"""Dashboard and analytics (spec §33, §35, §57, §71). Estimated opportunity value is always reported
separately from customer-confirmed revenue, and figures are labeled as attribution (not causation)."""

from __future__ import annotations

from datetime import date, datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends
from sqlalchemy import and_, case, func, select
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import OrgContext, get_org_ctx, require
from app.errors import bad_request
from app.models import AIAgent, AITrace, Appointment, Call, Conversation, Event, Lead, Notification, Task, UsageRecord
from app.services.common import utcnow
from app.services.serializers import agent_out, appointment_out, conversation_out, lead_out, task_out

router = APIRouter(tags=["analytics"])


def _range(ctx: OrgContext, start: date | None, end: date | None) -> tuple[datetime, datetime, ZoneInfo]:
    tz = ZoneInfo(ctx.org.timezone)
    today = utcnow().astimezone(tz).date()
    end = end or today
    start = start or end - timedelta(days=29)
    if start > end or (end - start).days > 366:
        raise bad_request("Invalid date range (max 1 year)")
    return datetime.combine(start, time.min, tzinfo=tz), datetime.combine(end + timedelta(days=1), time.min, tzinfo=tz), tz


def _count_events(db: Session, org_id: Any, types: list[str], s: datetime, e: datetime) -> dict[str, int]:
    rows = db.execute(
        select(Event.type, func.count())
        .where(Event.organization_id == org_id, Event.type.in_(types), Event.created_at >= s, Event.created_at < e)
        .group_by(Event.type)
    ).all()
    out = {t: 0 for t in types}
    out.update({t: int(n) for t, n in rows})
    return out


def _metrics(db: Session, ctx: OrgContext, s: datetime, e: datetime) -> dict[str, Any]:
    oid = ctx.org_id
    ev = _count_events(
        db,
        oid,
        [
            "conversation.started",
            "lead.created",
            "lead.qualified",
            "appointment.created",
            "appointment.cancelled",
            "appointment.no_show",
            "appointment.completed",
            "followup.sent",
            "conversation.escalated",
            "ai.tool_failed",
            "lead.won",
            "sms.sent",
            "sms.failed",
            "ai.injection_blocked",
        ],
        s,
        e,
    )
    calls = db.execute(
        select(
            func.count(),
            func.count().filter(Call.answered.is_(True)),
            func.count().filter(Call.answered.is_(False)),
            func.coalesce(func.sum(Call.duration_seconds), 0),
        ).where(Call.organization_id == oid, Call.created_at >= s, Call.created_at < e)
    ).one()
    resp = db.execute(
        select(func.avg(Conversation.first_response_ms), func.percentile_cont(0.5).within_group(Conversation.first_response_ms)).where(
            Conversation.organization_id == oid,
            Conversation.is_test.is_(False),
            Conversation.created_at >= s,
            Conversation.created_at < e,
            Conversation.first_response_ms.isnot(None),
        )
    ).one()
    ai_leads = (
        select(Lead)
        .where(Lead.organization_id == oid, Lead.deleted_at.is_(None), Lead.created_at >= s, Lead.created_at < e, Lead.source.like("ai_%"))
        .subquery()
    )
    money = db.execute(
        select(
            func.count(),
            func.coalesce(func.sum(ai_leads.c.estimated_value_cents), 0),
            func.count().filter(ai_leads.c.status == "won"),
            func.coalesce(func.sum(case((ai_leads.c.status == "won", ai_leads.c.actual_revenue_cents), else_=0)), 0),
        )
    ).one()
    ai_failures = (
        db.scalar(
            select(func.count())
            .select_from(AITrace)
            .where(AITrace.organization_id == oid, AITrace.created_at >= s, AITrace.created_at < e, AITrace.status.in_(("error", "invalid", "ungrounded")))
        )
        or 0
    )
    cost = db.execute(
        select(UsageRecord.kind, func.coalesce(func.sum(UsageRecord.quantity), 0), func.coalesce(func.sum(UsageRecord.cost_micros), 0))
        .where(UsageRecord.organization_id == oid, UsageRecord.created_at >= s, UsageRecord.created_at < e)
        .group_by(UsageRecord.kind)
    ).all()
    conversations = ev["conversation.started"]
    return {
        "conversations": conversations,
        "calls": int(calls[0]),
        "answered_calls": int(calls[1]),
        "abandoned_calls": int(calls[2]),
        "voice_minutes": round(int(calls[3] or 0) / 60, 1),
        "leads": ev["lead.created"],
        "qualified_leads": ev["lead.qualified"],
        "appointments": ev["appointment.created"],
        "cancellations": ev["appointment.cancelled"],
        "no_shows": ev["appointment.no_show"],
        "completed_appointments": ev["appointment.completed"],
        "follow_ups": ev["followup.sent"],
        "human_handoffs": ev["conversation.escalated"],
        "handoff_rate": round(ev["conversation.escalated"] / conversations, 3) if conversations else None,
        "conversions_won": ev["lead.won"],
        "ai_failures": int(ai_failures),
        "tool_failures": ev["ai.tool_failed"],
        "sms_sent": ev["sms.sent"],
        "sms_failed": ev["sms.failed"],
        "prompt_injection_attempts_blocked": ev["ai.injection_blocked"],
        "avg_first_response_ms": int(resp[0]) if resp[0] else None,
        "median_first_response_ms": int(resp[1]) if resp[1] else None,
        "ai_handled_leads": int(money[0]),
        "estimated_opportunity_value_cents": int(money[1]),
        "won_ai_leads": int(money[2]),
        "confirmed_revenue_cents": int(money[3]),
        "usage": {k: {"quantity": int(q), "estimated_cost_usd": round(int(c) / 1e6, 4)} for k, q, c in cost},
        "attribution_note": "Values describe leads handled by AI employees (attribution), not proof that the AI caused the outcome. "
        "Estimated opportunity value is not revenue; confirmed revenue is only what your team recorded on won leads.",
    }


@router.get("/dashboard")
def dashboard(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    tz = ZoneInfo(ctx.org.timezone)
    today = utcnow().astimezone(tz).date()
    s, e = datetime.combine(today, time.min, tzinfo=tz), datetime.combine(today + timedelta(days=1), time.min, tzinfo=tz)
    agents = db.scalars(select(AIAgent).where(AIAgent.organization_id == ctx.org_id, AIAgent.deleted_at.is_(None)).order_by(AIAgent.created_at)).all()
    out: dict[str, Any] = {
        "today": _metrics(db, ctx, s, e),
        "agents": [agent_out(a, include_widget=False) for a in agents],
        "timezone": ctx.org.timezone,
        "role": ctx.role,
    }
    if ctx.can("conversations.read"):
        convs = (
            db.scalars(
                select(Conversation)
                .where(Conversation.organization_id == ctx.org_id, Conversation.is_test.is_(False))
                .order_by(Conversation.last_message_at.desc())
                .limit(8)
            )
            .unique()
            .all()
        )
        out["recent_conversations"] = [conversation_out(c) for c in convs]
    if ctx.can("leads.read"):
        stages = (ctx.org.settings or {}).get("pipeline_stages", [])
        counts = dict(
            db.execute(select(Lead.status, func.count()).where(Lead.organization_id == ctx.org_id, Lead.deleted_at.is_(None)).group_by(Lead.status)).all()
        )
        out["pipeline"] = [{"stage": st, "count": int(counts.get(st, 0))} for st in stages]
        new_q = (
            db.scalars(select(Lead).where(Lead.organization_id == ctx.org_id, Lead.deleted_at.is_(None)).order_by(Lead.created_at.desc()).limit(6))
            .unique()
            .all()
        )
        out["recent_leads"] = [lead_out(x) for x in new_q]
        tasks = db.scalars(select(Task).where(Task.organization_id == ctx.org_id, Task.status == "open").order_by(Task.created_at.desc()).limit(8)).all()
        out["tasks"] = [task_out(t) for t in tasks]
    if ctx.can("appointments.read"):
        appts = (
            db.scalars(
                select(Appointment)
                .where(Appointment.organization_id == ctx.org_id, Appointment.start_at >= utcnow(), Appointment.status.in_(("scheduled", "confirmed")))
                .order_by(Appointment.start_at)
                .limit(6)
            )
            .unique()
            .all()
        )
        out["upcoming_appointments"] = [appointment_out(a) for a in appts]
    return out


@router.get("/analytics")
def analytics(
    start: date | None = None, end: date | None = None, ctx: OrgContext = Depends(require("analytics.read")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    s, e, tz = _range(ctx, start, end)
    oid = ctx.org_id
    local_day = func.date(func.timezone(ctx.org.timezone, Event.created_at))
    rows = db.execute(
        select(local_day, Event.type, func.count())
        .where(
            Event.organization_id == oid,
            Event.created_at >= s,
            Event.created_at < e,
            Event.type.in_(("lead.created", "appointment.created", "conversation.started", "conversation.escalated")),
        )
        .group_by(local_day, Event.type)
    ).all()
    series: dict[str, dict[str, int]] = {}
    d = s.date()
    while d < e.date():
        series[d.isoformat()] = {"leads": 0, "appointments": 0, "conversations": 0, "handoffs": 0}
        d += timedelta(days=1)
    key = {"lead.created": "leads", "appointment.created": "appointments", "conversation.started": "conversations", "conversation.escalated": "handoffs"}
    for day, t, n in rows:
        if day.isoformat() in series:
            series[day.isoformat()][key[t]] = int(n)
    by_source = db.execute(
        select(Lead.source, func.count(), func.count().filter(Lead.status == "won"))
        .where(Lead.organization_id == oid, Lead.deleted_at.is_(None), Lead.created_at >= s, Lead.created_at < e)
        .group_by(Lead.source)
    ).all()
    by_channel = db.execute(
        select(Conversation.channel, func.count(), func.count().filter(Conversation.handoff_reason.isnot(None)))
        .where(Conversation.organization_id == oid, Conversation.is_test.is_(False), Conversation.created_at >= s, Conversation.created_at < e)
        .group_by(Conversation.channel)
    ).all()
    reasons = db.execute(
        select(Conversation.handoff_reason, func.count())
        .where(
            Conversation.organization_id == oid,
            Conversation.is_test.is_(False),
            Conversation.created_at >= s,
            Conversation.created_at < e,
            Conversation.handoff_reason.isnot(None),
        )
        .group_by(Conversation.handoff_reason)
    ).all()
    m = _metrics(db, ctx, s, e)
    missed_recovered = (
        db.scalar(
            select(func.count())
            .select_from(Call)
            .where(
                Call.organization_id == oid,
                Call.created_at >= s,
                Call.created_at < e,
                Call.answered.is_(True),
                and_(func.extract("hour", func.timezone(ctx.org.timezone, Call.created_at)).notin_(range(8, 17))),
            )
        )
        or 0
    )
    return {
        "range": {"start": s.date().isoformat(), "end": (e.date() - timedelta(days=1)).isoformat(), "timezone": ctx.org.timezone},
        "metrics": m,
        "series": [{"date": k, **v} for k, v in series.items()],
        "funnel": [
            {"stage": "Conversations", "count": m["conversations"]},
            {"stage": "Leads", "count": m["leads"]},
            {"stage": "Qualified", "count": m["qualified_leads"]},
            {"stage": "Appointments", "count": m["appointments"]},
            {"stage": "Won", "count": m["conversions_won"]},
        ],
        "by_source": [{"source": src, "leads": int(n), "won": int(w)} for src, n, w in by_source],
        "by_channel": [{"channel": ch, "conversations": int(n), "handoffs": int(h)} for ch, n, h in by_channel],
        "handoff_reasons": [{"reason": r, "count": int(n)} for r, n in reasons],
        "after_hours_calls_answered": int(missed_recovered),
        "after_hours_note": "Calls answered by the AI outside 8am–5pm local time — calls that would typically go to voicemail.",
    }


@router.get("/notifications")
def notifications(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.scalars(select(Notification).where(Notification.organization_id == ctx.org_id).order_by(Notification.created_at.desc()).limit(30)).all()
    unread = db.scalar(select(func.count()).select_from(Notification).where(Notification.organization_id == ctx.org_id, Notification.read_at.is_(None))) or 0
    return {
        "unread": int(unread),
        "items": [
            {
                "id": str(n.id),
                "type": n.type,
                "title": n.title,
                "body": n.body,
                "link": n.link,
                "read": n.read_at is not None,
                "created_at": n.created_at.isoformat(),
            }
            for n in rows
        ],
    }


@router.post("/notifications/read-all")
def read_all(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, bool]:
    db.execute(Notification.__table__.update().where(Notification.organization_id == ctx.org_id, Notification.read_at.is_(None)).values(read_at=utcnow()))  # type: ignore[attr-defined]
    db.commit()
    return {"ok": True}
