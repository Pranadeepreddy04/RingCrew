"""Appointments: availability, manual booking, status changes, reschedule/cancel (spec §30)."""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Depends, Header
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import OrgContext, require
from app.errors import AppError, bad_request, not_found
from app.models import Appointment, BusinessProfile, Customer, Lead
from app.services import crm, scheduling
from app.services.common import audit, emit_event, notify, utcnow
from app.services.serializers import appointment_out

router = APIRouter(prefix="/appointments", tags=["appointments"])
STATUSES = ("scheduled", "confirmed", "completed", "cancelled", "no_show")


def _profile(db: Session, ctx: OrgContext) -> BusinessProfile:
    p = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == ctx.org_id))
    if p is None:
        raise not_found("Business profile")
    return p


@router.get("")
def list_appointments(
    start: datetime | None = None,
    end: datetime | None = None,
    status: str | None = None,
    ctx: OrgContext = Depends(require("appointments.read")),
    db: Session = Depends(get_db),
) -> list[dict[str, Any]]:
    q = select(Appointment).where(Appointment.organization_id == ctx.org_id)
    q = q.where(Appointment.start_at >= (start or utcnow() - timedelta(days=30)))
    q = q.where(Appointment.start_at <= (end or utcnow() + timedelta(days=90)))
    if status:
        q = q.where(Appointment.status == status)
    return [appointment_out(a) for a in db.scalars(q.order_by(Appointment.start_at).limit(1000)).unique()]


@router.get("/availability")
def availability(days: int = 14, ctx: OrgContext = Depends(require("appointments.read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    profile = _profile(db, ctx)
    tz = ZoneInfo(ctx.org.timezone)
    try:
        slots = scheduling.available_slots(db, ctx.org, profile, window_end=utcnow() + timedelta(days=max(1, min(days, 60))))
    except scheduling.AvailabilityError as exc:
        raise AppError(503, "calendar_unavailable", f"Connected calendar is unavailable: {exc}") from None
    return {"timezone": ctx.org.timezone, "duration_minutes": profile.appointment_duration_minutes, "slots": [s.as_dict(tz) for s in slots[:300]]}


@router.get("/{appointment_id}")
def get_appointment(appointment_id: uuid.UUID, ctx: OrgContext = Depends(require("appointments.read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    return appointment_out(_get(db, ctx, appointment_id))


def _get(db: Session, ctx: OrgContext, aid: uuid.UUID, lock: bool = False) -> Appointment:
    q = select(Appointment).where(Appointment.id == aid, Appointment.organization_id == ctx.org_id)
    a = db.scalar(q.with_for_update() if lock else q)
    if a is None:
        raise not_found("Appointment")
    return a


class BookIn(BaseModel):
    customer_id: uuid.UUID
    lead_id: uuid.UUID | None = None
    start: datetime
    service: str = Field(min_length=1, max_length=200)
    duration_minutes: int | None = Field(default=None, ge=15, le=480)
    location: str | None = Field(default=None, max_length=500)
    notes: str | None = Field(default=None, max_length=4000)


@router.post("", status_code=201)
def create_appointment(
    body: BookIn, idempotency_key: str | None = Header(default=None), ctx: OrgContext = Depends(require("appointments.write")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    customer = db.scalar(select(Customer).where(Customer.id == body.customer_id, Customer.organization_id == ctx.org_id, Customer.deleted_at.is_(None)))
    if customer is None:
        raise not_found("Customer")
    lead = None
    if body.lead_id:
        lead = db.scalar(select(Lead).where(Lead.id == body.lead_id, Lead.organization_id == ctx.org_id))
        if lead is None:
            raise not_found("Lead")
    if body.start.tzinfo is None:
        raise bad_request("start must include a timezone offset")
    res = scheduling.book(
        db,
        ctx.org,
        _profile(db, ctx),
        customer=customer,
        start=body.start,
        service=body.service,
        source="staff",
        idempotency_key=f"staff:{idempotency_key or uuid.uuid4()}",
        lead_id=lead.id if lead else None,
        notes=body.notes,
        location=body.location,
        duration_minutes=body.duration_minutes,
    )
    if not res.ok or res.appointment is None:
        db.rollback()
        code = 409 if res.error_code == "slot_unavailable" else 503
        raise AppError(code, res.error_code or "booking_failed", res.message or "Could not book appointment")
    a = res.appointment
    if not res.duplicate:
        if lead and lead.status in ("new", "contacted", "qualified"):
            lead.status = "appointment"
        emit_event(
            db,
            ctx.org_id,
            "appointment.created",
            lead_id=lead.id if lead else None,
            data={"appointment_id": str(a.id), "by": "staff"},
            webhook_payload={"appointment_id": str(a.id), "start_at": a.start_at.isoformat(), "service": a.service},
        )
        from app.services.automation import start_workflows

        start_workflows(db, ctx.org, "appointment.created", customer=customer, lead=lead, appointment=a)
        if lead:
            crm.stop_workflow_runs(db, lead_id=lead.id, reason="appointment_booked")
        audit(db, "appointment.created", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="appointment", target_id=a.id)
    db.commit()
    db.refresh(a)
    return appointment_out(a)


class StatusIn(BaseModel):
    status: str


@router.post("/{appointment_id}/status")
def set_status(
    appointment_id: uuid.UUID, body: StatusIn, ctx: OrgContext = Depends(require("appointments.write")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    if body.status not in STATUSES:
        raise bad_request(f"status must be one of {STATUSES}")
    a = _get(db, ctx, appointment_id, lock=True)
    if body.status == "cancelled":
        res = scheduling.cancel(db, ctx.org, a)
        if not res.ok:
            raise AppError(409 if res.error_code == "not_active" else 503, res.error_code or "cancel_failed", res.message or "Could not cancel")
        crm.stop_workflow_runs(db, appointment_id=a.id, reason="appointment_cancelled")
        emit_event(db, ctx.org_id, "appointment.cancelled", lead_id=a.lead_id, webhook_payload={"appointment_id": str(a.id)})
        notify(
            db,
            ctx.org_id,
            "appointment.cancelled",
            f"Appointment cancelled: {a.customer.name if a.customer else ''}",
            a.service,
            f"/app/appointments?id={a.id}",
        )
    else:
        if a.status == "cancelled":
            raise AppError(409, "cancelled", "Cancelled appointments cannot change status; book a new one")
        a.status = body.status
        if body.status == "no_show":
            emit_event(db, ctx.org_id, "appointment.no_show", lead_id=a.lead_id)
        if body.status == "completed":
            emit_event(db, ctx.org_id, "appointment.completed", lead_id=a.lead_id)
            if a.customer:
                from app.services.automation import start_workflows

                lead = db.get(Lead, a.lead_id) if a.lead_id else None
                start_workflows(db, ctx.org, "appointment.completed", customer=a.customer, lead=lead, appointment=a)
    audit(
        db, "appointment.status_changed", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="appointment", target_id=a.id, data={"status": body.status}
    )
    db.commit()
    return appointment_out(a)


class RescheduleIn(BaseModel):
    start: datetime


@router.post("/{appointment_id}/reschedule")
def reschedule(
    appointment_id: uuid.UUID, body: RescheduleIn, ctx: OrgContext = Depends(require("appointments.write")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    if body.start.tzinfo is None:
        raise bad_request("start must include a timezone offset")
    a = _get(db, ctx, appointment_id, lock=True)
    res = scheduling.reschedule(db, ctx.org, _profile(db, ctx), a, body.start)
    if not res.ok:
        db.rollback()
        raise AppError(
            409 if res.error_code in ("slot_unavailable", "not_active") else 503, res.error_code or "reschedule_failed", res.message or "Could not reschedule"
        )
    emit_event(db, ctx.org_id, "appointment.rescheduled", lead_id=a.lead_id, webhook_payload={"appointment_id": str(a.id), "start_at": a.start_at.isoformat()})
    audit(db, "appointment.rescheduled", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="appointment", target_id=a.id)
    db.commit()
    return appointment_out(a)
