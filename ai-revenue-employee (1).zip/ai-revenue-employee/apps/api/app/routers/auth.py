"""Authentication: email/password, verification, reset, sessions, Google sign-in (spec §6, §84)."""

from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Any
from urllib.parse import urlencode

import httpx
from fastapi import APIRouter, Depends, Request, Response
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, EmailStr, Field, field_validator
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db
from app.deps import CSRF_COOKIE, SESSION_COOKIE, AuthContext, get_auth
from app.errors import AppError, bad_request
from app.models import EmailToken, Invitation, Membership, Organization, User, UserSession
from app.providers.email import send_email
from app.ratelimit import client_ip, enforce
from app.security import (
    dummy_verify,
    hash_password,
    new_token,
    sha256_hex,
    signed_expiring,
    verify_expiring,
    verify_password,
)
from app.services.common import audit, utcnow

router = APIRouter(prefix="/auth", tags=["auth"])


def check_password_strength(v: str) -> str:
    if len(v) < 10:
        raise ValueError("Password must be at least 10 characters")
    if v.isdigit() or v.isalpha():
        raise ValueError("Password must contain letters and numbers or symbols")
    return v


class PasswordMixin(BaseModel):
    @field_validator("password", check_fields=False)
    @classmethod
    def _strong(cls, v: str) -> str:
        return check_password_strength(v)


class SignupIn(PasswordMixin):
    name: str = Field(min_length=1, max_length=200)
    email: EmailStr
    password: str = Field(max_length=200)


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(max_length=200)


class TokenIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)


class EmailIn(BaseModel):
    email: EmailStr


class ResetConfirmIn(PasswordMixin):
    token: str = Field(min_length=10, max_length=200)
    password: str = Field(max_length=200)


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(max_length=200)

    @field_validator("new_password")
    @classmethod
    def _strong(cls, v: str) -> str:
        return check_password_strength(v)


class AcceptInviteIn(BaseModel):
    token: str
    name: str | None = Field(default=None, max_length=200)
    password: str | None = Field(default=None, max_length=200)


def _user_out(db: Session, user: User, sess: UserSession) -> dict[str, Any]:
    rows = db.execute(
        select(Membership, Organization)
        .join(Organization, Organization.id == Membership.organization_id)
        .where(Membership.user_id == user.id, Organization.deleted_at.is_(None))
        .order_by(Membership.created_at)
    ).all()
    return {
        "user": {
            "id": str(user.id),
            "email": user.email,
            "name": user.name,
            "email_verified": user.email_verified_at is not None,
            "is_superadmin": user.is_superadmin,
        },
        "organizations": [
            {
                "id": str(o.id),
                "name": o.name,
                "role": m.role,
                "industry": o.industry,
                "onboarding_completed": o.onboarding_completed_at is not None,
                "onboarding_step": o.onboarding_step,
                "is_demo": o.is_demo,
            }
            for m, o in rows
        ],
        "csrf_token": sess.csrf_token,
        "impersonating": sess.impersonator_user_id is not None,
    }


def start_session(db: Session, response: Response, request: Request, user: User, impersonator: uuid.UUID | None = None) -> tuple[UserSession, str]:
    s = get_settings()
    token = new_token()
    sess = UserSession(
        user_id=user.id,
        token_hash=sha256_hex(token),
        csrf_token=new_token(24),
        expires_at=utcnow() + timedelta(hours=s.session_ttl_hours if not impersonator else 1),
        ip=client_ip(request),
        user_agent=(request.headers.get("user-agent") or "")[:400],
        impersonator_user_id=impersonator,
    )
    db.add(sess)
    user.last_login_at = utcnow()
    max_age = int((sess.expires_at - utcnow()).total_seconds())
    response.set_cookie(SESSION_COOKIE, token, httponly=True, secure=s.cookie_secure, samesite="lax", max_age=max_age, path="/")
    response.set_cookie(CSRF_COOKIE, sess.csrf_token, httponly=False, secure=s.cookie_secure, samesite="lax", max_age=max_age, path="/")
    return sess, token


def _issue_email_token(db: Session, user: User, purpose: str, hours: int) -> str:
    token = new_token()
    db.add(EmailToken(user_id=user.id, purpose=purpose, token_hash=sha256_hex(token), expires_at=utcnow() + timedelta(hours=hours)))
    return token


def _send_verification(db: Session, user: User) -> None:
    token = _issue_email_token(db, user, "verify", 48)
    link = f"{get_settings().public_web_url}/verify-email?token={token}"
    send_email(db, user.email, "Verify your email", f"Hi {user.name},\n\nConfirm your email address:\n{link}\n")


def _find_user(db: Session, email: str) -> User | None:
    return db.scalar(select(User).where(func.lower(User.email) == email.lower()))


@router.post("/signup", status_code=201)
def signup(body: SignupIn, request: Request, response: Response, db: Session = Depends(get_db)) -> dict[str, Any]:
    enforce(request, "signup", 10, 3600)
    if _find_user(db, body.email):
        raise AppError(409, "email_taken", "An account with this email already exists")
    user = User(email=body.email.lower(), name=body.name.strip(), password_hash=hash_password(body.password))
    db.add(user)
    db.flush()
    _send_verification(db, user)
    audit(db, "user.signup", org_id=None, actor_user_id=user.id, target_type="user", target_id=user.id, ip=client_ip(request))
    sess, _ = start_session(db, response, request, user)
    db.commit()
    return _user_out(db, user, sess)


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)) -> dict[str, Any]:
    enforce(request, "login-ip", 20, 300)
    enforce(request, "login-email", 10, 300, key=body.email.lower())
    user = _find_user(db, body.email)
    if not user:
        dummy_verify()
        raise AppError(401, "invalid_credentials", "Incorrect email or password")
    if not verify_password(body.password, user.password_hash):
        audit(db, "user.login_failed", org_id=None, actor_user_id=user.id, ip=client_ip(request))
        db.commit()
        raise AppError(401, "invalid_credentials", "Incorrect email or password")
    if not user.is_active:
        raise AppError(403, "account_disabled", "This account is disabled. Contact support.")
    if get_settings().require_email_verification and not user.email_verified_at:
        raise AppError(403, "email_not_verified", "Please verify your email before signing in")
    sess, _ = start_session(db, response, request, user)
    audit(db, "user.login", org_id=None, actor_user_id=user.id, ip=client_ip(request))
    db.commit()
    return _user_out(db, user, sess)


@router.post("/logout")
def logout(response: Response, auth: AuthContext = Depends(get_auth), db: Session = Depends(get_db)) -> dict[str, bool]:
    auth.session.revoked_at = utcnow()
    db.commit()
    response.delete_cookie(SESSION_COOKIE, path="/")
    response.delete_cookie(CSRF_COOKIE, path="/")
    return {"ok": True}


@router.get("/me")
def me(auth: AuthContext = Depends(get_auth), db: Session = Depends(get_db)) -> dict[str, Any]:
    return _user_out(db, auth.user, auth.session)


def _consume_token(db: Session, token: str, purpose: str) -> EmailToken:
    et = db.scalar(select(EmailToken).where(EmailToken.token_hash == sha256_hex(token), EmailToken.purpose == purpose))
    if not et or et.used_at is not None or et.expires_at <= utcnow():
        raise bad_request("This link is invalid or has expired", "invalid_token")
    et.used_at = utcnow()
    return et


@router.post("/verify-email")
def verify_email(body: TokenIn, db: Session = Depends(get_db)) -> dict[str, bool]:
    et = _consume_token(db, body.token, "verify")
    user = db.get(User, et.user_id)
    assert user is not None
    user.email_verified_at = utcnow()
    db.commit()
    return {"ok": True}


@router.post("/resend-verification")
def resend_verification(request: Request, auth: AuthContext = Depends(get_auth), db: Session = Depends(get_db)) -> dict[str, bool]:
    enforce(request, "resend-verify", 5, 3600, key=str(auth.user.id))
    if not auth.user.email_verified_at:
        _send_verification(db, auth.user)
        db.commit()
    return {"ok": True}


@router.post("/password-reset/request")
def password_reset_request(body: EmailIn, request: Request, db: Session = Depends(get_db)) -> dict[str, bool]:
    enforce(request, "pw-reset", 5, 3600)
    user = _find_user(db, body.email)
    if user and user.is_active:
        token = _issue_email_token(db, user, "reset", 1)
        link = f"{get_settings().public_web_url}/reset-password?token={token}"
        send_email(db, user.email, "Reset your password", f"Reset your password (valid for 1 hour):\n{link}\n\nIf you did not request this, ignore this email.")
        audit(db, "user.password_reset_requested", org_id=None, actor_user_id=user.id, ip=client_ip(request))
        db.commit()
    return {"ok": True}  # identical response whether or not the account exists


@router.post("/password-reset/confirm")
def password_reset_confirm(body: ResetConfirmIn, db: Session = Depends(get_db)) -> dict[str, bool]:
    et = _consume_token(db, body.token, "reset")
    user = db.get(User, et.user_id)
    assert user is not None
    user.password_hash = hash_password(body.password)
    db.execute(update(UserSession).where(UserSession.user_id == user.id, UserSession.revoked_at.is_(None)).values(revoked_at=utcnow()))
    audit(db, "user.password_reset", org_id=None, actor_user_id=user.id)
    db.commit()
    return {"ok": True}


@router.post("/password/change")
def change_password(body: ChangePasswordIn, auth: AuthContext = Depends(get_auth), db: Session = Depends(get_db)) -> dict[str, bool]:
    if not verify_password(body.current_password, auth.user.password_hash):
        raise AppError(400, "invalid_password", "Current password is incorrect")
    auth.user.password_hash = hash_password(body.new_password)
    db.execute(
        update(UserSession)
        .where(UserSession.user_id == auth.user.id, UserSession.id != auth.session.id, UserSession.revoked_at.is_(None))
        .values(revoked_at=utcnow())
    )
    audit(db, "user.password_changed", org_id=None, actor_user_id=auth.user.id)
    db.commit()
    return {"ok": True}


@router.get("/invitations/{token}")
def invitation_info(token: str, db: Session = Depends(get_db)) -> dict[str, Any]:
    inv = db.scalar(select(Invitation).where(Invitation.token_hash == sha256_hex(token)))
    if not inv or inv.accepted_at or inv.revoked_at or inv.expires_at <= utcnow():
        raise bad_request("This invitation is invalid or has expired", "invalid_token")
    org = db.get(Organization, inv.organization_id)
    return {"email": inv.email, "role": inv.role, "organization_name": org.name if org else "", "has_account": _find_user(db, inv.email) is not None}


@router.post("/invitations/accept")
def accept_invitation(body: AcceptInviteIn, request: Request, response: Response, db: Session = Depends(get_db)) -> dict[str, Any]:
    inv = db.scalar(select(Invitation).where(Invitation.token_hash == sha256_hex(body.token)).with_for_update())
    if not inv or inv.accepted_at or inv.revoked_at or inv.expires_at <= utcnow():
        raise bad_request("This invitation is invalid or has expired", "invalid_token")
    user = _find_user(db, inv.email)
    if user:
        # existing account must authenticate with its password
        if not body.password or not verify_password(body.password, user.password_hash):
            raise AppError(401, "invalid_credentials", "Enter the password for your existing account")
    else:
        if not body.name or not body.password:
            raise bad_request("Name and password are required to create your account")
        try:
            check_password_strength(body.password)
        except ValueError as exc:
            raise bad_request(str(exc), "weak_password") from None
        user = User(email=inv.email.lower(), name=body.name, password_hash=hash_password(body.password), email_verified_at=utcnow())
        db.add(user)
        db.flush()
    exists = db.scalar(select(Membership).where(Membership.organization_id == inv.organization_id, Membership.user_id == user.id))
    if not exists:
        db.add(Membership(organization_id=inv.organization_id, user_id=user.id, role=inv.role))
    inv.accepted_at = utcnow()
    audit(db, "team.invitation_accepted", org_id=inv.organization_id, actor_user_id=user.id, target_type="invitation", target_id=inv.id)
    sess, _ = start_session(db, response, request, user)
    db.commit()
    return _user_out(db, user, sess)


# ------------------------------------------------------------------ Google sign-in (optional)


@router.get("/google/status")
def google_status() -> dict[str, bool]:
    s = get_settings()
    return {"enabled": bool(s.google_oauth_client_id and s.google_oauth_client_secret)}


@router.get("/google/start")
def google_start() -> RedirectResponse:
    s = get_settings()
    if not (s.google_oauth_client_id and s.google_oauth_client_secret):
        raise AppError(501, "google_not_configured", "Google sign-in is not configured on this server")
    state = signed_expiring(new_token(12), "google-oauth", 600)
    params = {
        "client_id": s.google_oauth_client_id,
        "redirect_uri": f"{s.public_api_url}/api/v1/auth/google/callback",
        "response_type": "code",
        "scope": "openid email profile",
        "state": state,
        "prompt": "select_account",
    }
    resp = RedirectResponse("https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(params))
    resp.set_cookie("are_oauth_state", state, httponly=True, secure=s.cookie_secure, samesite="lax", max_age=600)
    return resp


@router.get("/google/callback")
def google_callback(request: Request, code: str, state: str, db: Session = Depends(get_db)) -> RedirectResponse:
    s = get_settings()
    if state != request.cookies.get("are_oauth_state") or not verify_expiring(state, "google-oauth"):
        raise bad_request("Invalid sign-in state", "invalid_state")
    with httpx.Client(timeout=10) as client:
        tok = client.post(
            "https://oauth2.googleapis.com/token",
            data={
                "code": code,
                "client_id": s.google_oauth_client_id,
                "client_secret": s.google_oauth_client_secret,
                "redirect_uri": f"{s.public_api_url}/api/v1/auth/google/callback",
                "grant_type": "authorization_code",
            },
        )
        if tok.status_code != 200:
            raise AppError(502, "google_error", "Google sign-in failed")
        info = client.get(
            "https://openidconnect.googleapis.com/v1/userinfo",
            headers={"Authorization": f"Bearer {tok.json()['access_token']}"},
        ).json()
    if not info.get("email_verified"):
        raise bad_request("Your Google email is not verified")
    user = db.scalar(select(User).where(User.google_sub == info["sub"])) or _find_user(db, info["email"])
    if not user:
        user = User(email=info["email"].lower(), name=info.get("name") or info["email"], google_sub=info["sub"], email_verified_at=utcnow())
        db.add(user)
        db.flush()
    elif not user.google_sub:
        user.google_sub = info["sub"]
    if not user.is_active:
        raise AppError(403, "account_disabled", "This account is disabled")
    resp = RedirectResponse(f"{s.public_web_url}/app")
    start_session(db, resp, request, user)
    db.commit()
    return resp
