"""Billing: plans, checkout, plan changes, cancellation, invoices, usage, Stripe webhooks (spec §47, §97).
Entitlements are always computed on the backend from the stored subscription."""

from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db
from app.deps import OrgContext, get_org_ctx, require
from app.errors import AppError, bad_request, not_found
from app.models import InboundWebhookEvent, Invoice, Plan
from app.services import billing
from app.services.common import audit, utcnow

router = APIRouter(tags=["billing"])


def _plan_out(p: Plan) -> dict[str, Any]:
    return {
        "key": p.key,
        "name": p.name,
        "price_cents": p.price_cents,
        "interval": p.interval,
        "features": p.features,
        "limits": p.limits,
        "purchasable": get_settings().billing_provider == "sandbox" or bool(p.provider_price_id),
    }


@router.get("/plans")
def public_plans(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    return [_plan_out(p) for p in db.scalars(select(Plan).where(Plan.active.is_(True)).order_by(Plan.sort_order)).all()]


@router.get("/billing")
def billing_overview(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    sub = billing.get_subscription(db, ctx.org_id)
    usage = {k: billing.usage_this_month(db, ctx.org_id, k) for k in ("conversation", "sms", "voice_minutes", "llm_tokens")}
    invoices = (
        db.scalars(select(Invoice).where(Invoice.organization_id == ctx.org_id).order_by(Invoice.created_at.desc()).limit(24)).all()
        if ctx.can("billing.manage")
        else []
    )
    return {
        "provider": get_settings().billing_provider,
        "is_sandbox": get_settings().billing_provider == "sandbox",
        "subscription": {
            "plan": _plan_out(sub.plan),
            "status": sub.status,
            "trial_ends_at": sub.trial_ends_at.isoformat() if sub.trial_ends_at else None,
            "current_period_end": sub.current_period_end.isoformat() if sub.current_period_end else None,
            "cancel_at_period_end": sub.cancel_at_period_end,
            "usable": billing.subscription_is_usable(sub),
        }
        if sub
        else None,
        "entitlements": billing.entitlements(db, ctx.org),
        "usage_this_month": usage,
        "plans": public_plans(db),
        "invoices": [
            {
                "id": str(i.id),
                "amount_cents": i.amount_cents,
                "status": i.status,
                "hosted_url": i.hosted_url,
                "period_end": i.period_end.isoformat() if i.period_end else None,
                "created_at": i.created_at.isoformat(),
            }
            for i in invoices
        ],
    }


class PlanIn(BaseModel):
    plan: str


def _plan(db: Session, key: str) -> Plan:
    p = db.scalar(select(Plan).where(Plan.key == key, Plan.active.is_(True)))
    if p is None:
        raise not_found("Plan")
    return p


@router.post("/billing/checkout")
def checkout(body: PlanIn, ctx: OrgContext = Depends(require("billing.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    plan = _plan(db, body.plan)
    sub = billing.get_subscription(db, ctx.org_id)
    if sub and sub.status == "active" and sub.provider_subscription_id:
        raise AppError(409, "already_subscribed", "You already have an active subscription — change plans instead")
    res = billing.get_billing_provider().checkout(db, ctx.org, plan, ctx.user.email)
    audit(db, "billing.checkout_started", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"plan": plan.key, "mode": res["mode"]})
    db.commit()
    return res


@router.post("/billing/change-plan")
def change_plan(body: PlanIn, ctx: OrgContext = Depends(require("billing.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    plan = _plan(db, body.plan)
    sub = billing.get_subscription(db, ctx.org_id)
    if sub is None or sub.status not in ("active", "past_due"):
        raise AppError(400, "no_active_subscription", "Subscribe first")
    if sub.plan_id == plan.id:
        raise bad_request("You're already on that plan")
    # Downgrade guard: current usage must fit the new plan's hard limits.
    from sqlalchemy import func

    from app.models import AIAgent, Membership

    agents = db.scalar(select(func.count()).select_from(AIAgent).where(AIAgent.organization_id == ctx.org_id, AIAgent.deleted_at.is_(None))) or 0
    members = db.scalar(select(func.count()).select_from(Membership).where(Membership.organization_id == ctx.org_id)) or 0
    if agents > plan.limits.get("agents", 999) or members > plan.limits.get("team_members", 999):
        raise AppError(
            409,
            "downgrade_blocked",
            f"Reduce to {plan.limits.get('agents')} AI employees and {plan.limits.get('team_members')} team members before switching to {plan.name}",
        )
    billing.get_billing_provider().change_plan(db, sub, plan)
    audit(db, "billing.plan_changed", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"plan": plan.key})
    db.commit()
    return billing_overview(ctx, db)


@router.post("/billing/cancel")
def cancel(ctx: OrgContext = Depends(require("billing.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    sub = billing.get_subscription(db, ctx.org_id)
    if sub is None or sub.status not in ("active", "past_due", "trialing"):
        raise AppError(400, "no_active_subscription", "No active subscription")
    if sub.status == "trialing" and not sub.provider_subscription_id:
        sub.status = "canceled"
    else:
        billing.get_billing_provider().cancel(db, sub)
    audit(db, "billing.cancel_requested", org_id=ctx.org_id, actor_user_id=ctx.user.id)
    db.commit()
    return billing_overview(ctx, db)


@router.post("/billing/resume")
def resume(ctx: OrgContext = Depends(require("billing.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    sub = billing.get_subscription(db, ctx.org_id)
    if sub is None or not sub.cancel_at_period_end:
        raise bad_request("Nothing to resume")
    billing.get_billing_provider().resume(db, sub)
    db.commit()
    return billing_overview(ctx, db)


@router.post("/billing/portal")
def portal(ctx: OrgContext = Depends(require("billing.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    sub = billing.get_subscription(db, ctx.org_id)
    url = billing.get_billing_provider().portal(db, sub) if sub else None
    if not url:
        raise AppError(400, "portal_unavailable", "The billing portal is available after you subscribe with a card")
    return {"url": url}


class SimulateIn(BaseModel):
    event: str


@router.post("/billing/sandbox/simulate")
def simulate(body: SimulateIn, ctx: OrgContext = Depends(require("billing.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    """Development/test only: drive sandbox subscriptions through renewal/failure/recovery/trial-expiry."""
    if get_settings().billing_provider != "sandbox" or get_settings().app_env not in ("development", "test"):
        raise AppError(404, "not_found", "Not available")
    sub = billing.get_subscription(db, ctx.org_id)
    if sub is None:
        raise bad_request("No subscription")
    now = utcnow()
    if body.event == "renewal":
        sub.current_period_end = (sub.current_period_end or now) + timedelta(days=30)
        db.add(
            Invoice(
                organization_id=ctx.org_id,
                provider_invoice_id=f"sandbox_in_{uuid.uuid4().hex[:12]}",
                amount_cents=sub.plan.price_cents,
                status="paid",
                period_start=now,
                period_end=sub.current_period_end,
            )
        )
    elif body.event == "payment_failed":
        sub.status = "past_due"
        db.add(Invoice(organization_id=ctx.org_id, provider_invoice_id=f"sandbox_in_{uuid.uuid4().hex[:12]}", amount_cents=sub.plan.price_cents, status="open"))
    elif body.event == "payment_recovered":
        sub.status = "active"
        for inv in db.scalars(select(Invoice).where(Invoice.organization_id == ctx.org_id, Invoice.status == "open")).all():
            inv.status = "paid"
    elif body.event == "trial_expired":
        sub.trial_ends_at = now - timedelta(minutes=1)
    elif body.event == "period_ended":
        if sub.cancel_at_period_end:
            sub.status = "canceled"
        sub.current_period_end = now - timedelta(days=PAST_DUE_GRACE + 1)
    else:
        raise bad_request("Unknown event")
    db.commit()
    return billing_overview(ctx, db)


PAST_DUE_GRACE = billing.PAST_DUE_GRACE_DAYS


@router.post("/webhooks/stripe", include_in_schema=False)
async def stripe_webhook(request: Request, db: Session = Depends(get_db)) -> dict[str, str]:
    secret = get_settings().stripe_webhook_secret
    if not secret:
        raise AppError(503, "billing_not_configured", "Stripe webhooks are not configured")
    payload = await request.body()
    event = billing.verify_stripe_signature(payload, request.headers.get("stripe-signature", ""), secret)
    try:
        db.add(InboundWebhookEvent(provider="stripe", external_id=event["id"], event_type=event.get("type")))
        db.flush()
    except IntegrityError:
        db.rollback()
        return {"status": "duplicate_ignored"}
    result = billing.apply_stripe_event(db, event)
    db.commit()
    return {"status": result}
