"""Unified conversation inbox with human takeover (spec §34)."""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import OrgContext, require
from app.errors import AppError, bad_request, not_found
from app.models import Appointment, Call, Conversation, Customer, Lead, Message, StoredFile, Task
from app.services import crm, files
from app.services.common import audit, emit_event, utcnow
from app.services.serializers import appointment_out, conversation_out, lead_out, message_out, task_out

router = APIRouter(prefix="/conversations", tags=["inbox"])
FILTERS = {"all", "phone", "sms", "web", "needs_human", "unresolved", "completed", "test"}


@router.get("")
def list_conversations(
    filter: str = "all",
    q: str | None = None,
    page: int = 1,
    page_size: int = 25,
    ctx: OrgContext = Depends(require("conversations.read")),
    db: Session = Depends(get_db),
) -> dict[str, Any]:
    if filter not in FILTERS:
        raise bad_request("Unknown filter")
    page_size = max(1, min(page_size, 100))
    base = select(Conversation).where(Conversation.organization_id == ctx.org_id)
    base = base.where(Conversation.is_test.is_(filter == "test"))
    if filter == "phone":
        base = base.where(Conversation.channel == "voice")
    elif filter in ("sms", "web"):
        base = base.where(Conversation.channel == filter)
    elif filter == "needs_human":
        base = base.where(Conversation.status == "needs_human")
    elif filter == "unresolved":
        base = base.where(Conversation.status != "resolved")
    elif filter == "completed":
        base = base.where(Conversation.status == "resolved")
    if q:
        like = f"%{q.strip()[:100]}%"
        base = base.outerjoin(Customer, Customer.id == Conversation.customer_id).where(
            or_(Customer.name.ilike(like), Customer.phone.ilike(like), Customer.email.ilike(like), Conversation.summary.ilike(like))
        )
    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    rows = db.scalars(base.order_by(Conversation.last_message_at.desc()).offset((page - 1) * page_size).limit(page_size)).unique().all()
    previews: dict[uuid.UUID, str] = {}
    if rows:
        sub = (
            select(
                Message.conversation_id,
                Message.content,
                func.row_number().over(partition_by=Message.conversation_id, order_by=Message.created_at.desc()).label("rn"),
            )
            .where(Message.conversation_id.in_([r.id for r in rows]), Message.role.in_(("customer", "ai", "human")))
            .subquery()
        )
        previews = {r.conversation_id: r.content for r in db.execute(select(sub.c.conversation_id, sub.c.content).where(sub.c.rn == 1))}
    return {"items": [{**conversation_out(c), "preview": (previews.get(c.id) or "")[:160]} for c in rows], "total": total, "page": page, "page_size": page_size}


def _get(db: Session, ctx: OrgContext, cid: uuid.UUID, lock: bool = False) -> Conversation:
    q = select(Conversation).where(Conversation.id == cid, Conversation.organization_id == ctx.org_id)
    if lock:
        q = q.with_for_update()
    c = db.scalar(q)
    if c is None:
        raise not_found("Conversation")
    return c


@router.get("/{conversation_id}")
def get_conversation(conversation_id: uuid.UUID, ctx: OrgContext = Depends(require("conversations.read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    c = _get(db, ctx, conversation_id)
    msgs = db.scalars(select(Message).where(Message.conversation_id == c.id).order_by(Message.created_at)).all()
    lead = db.scalar(select(Lead).where(Lead.id == c.lead_id, Lead.organization_id == ctx.org_id)) if c.lead_id else None
    appts = db.scalars(select(Appointment).where(Appointment.conversation_id == c.id, Appointment.organization_id == ctx.org_id)).all()
    tasks = db.scalars(select(Task).where(Task.conversation_id == c.id, Task.organization_id == ctx.org_id).order_by(Task.created_at)).all()
    call = db.scalar(select(Call).where(Call.conversation_id == c.id))
    fls = db.scalars(select(StoredFile).where(StoredFile.conversation_id == c.id, StoredFile.organization_id == ctx.org_id)).all()
    return {
        **conversation_out(c),
        "messages": [message_out(m) for m in msgs],
        "lead": lead_out(lead) if lead else None,
        "appointments": [appointment_out(a) for a in appts],
        "tasks": [task_out(t) for t in tasks],
        "call": {
            "status": call.status,
            "duration_seconds": call.duration_seconds,
            "from": call.from_number,
            "recording_enabled": call.recording_enabled,
            "transferred_to": call.transferred_to,
        }
        if call
        else None,
        "files": [
            {
                "id": str(f.id),
                "filename": f.filename,
                "content_type": f.content_type,
                "size_bytes": f.size_bytes,
                "download_url": f"/api/v1/conversations/files/{f.id}/download?token={files.download_token(f.id)}",
            }
            for f in fls
        ],
    }


@router.post("/{conversation_id}/takeover")
def takeover(conversation_id: uuid.UUID, ctx: OrgContext = Depends(require("conversations.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    c = _get(db, ctx, conversation_id, lock=True)
    c.handoff_active, c.handoff_user_id, c.status = True, ctx.user.id, "needs_human"
    c.handoff_reason = c.handoff_reason or "staff_takeover"
    if c.customer_id:
        crm.stop_workflow_runs(db, customer_id=c.customer_id, reason="human_takeover")
    db.add(Message(organization_id=ctx.org_id, conversation_id=c.id, role="system", content=f"{ctx.user.name} took over the conversation"))
    audit(db, "conversation.takeover", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="conversation", target_id=c.id)
    db.commit()
    return conversation_out(c)


@router.post("/{conversation_id}/return-to-ai")
def return_to_ai(conversation_id: uuid.UUID, ctx: OrgContext = Depends(require("conversations.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    c = _get(db, ctx, conversation_id, lock=True)
    c.handoff_active, c.handoff_user_id, c.status, c.handoff_reason = False, None, "open", None
    st = dict(c.state or {})
    if st.get("stage") == "handed_off":
        st["stage"] = "booked" if st.get("appointment_id") else "open"
    c.state = st
    db.add(Message(organization_id=ctx.org_id, conversation_id=c.id, role="system", content=f"{ctx.user.name} returned the conversation to the AI"))
    audit(db, "conversation.returned_to_ai", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="conversation", target_id=c.id)
    db.commit()
    return conversation_out(c)


@router.post("/{conversation_id}/resolve")
def resolve(conversation_id: uuid.UUID, ctx: OrgContext = Depends(require("conversations.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    c = _get(db, ctx, conversation_id, lock=True)
    c.status = "resolved"
    for t in db.scalars(select(Task).where(Task.conversation_id == c.id, Task.kind == "handoff", Task.status == "open")).all():
        t.status, t.completed_at = "done", utcnow()
    db.commit()
    return conversation_out(c)


class StaffMessageIn(BaseModel):
    text: str = Field(min_length=1, max_length=1600)


@router.post("/{conversation_id}/messages")
def staff_message(
    conversation_id: uuid.UUID, body: StaffMessageIn, ctx: OrgContext = Depends(require("conversations.write")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    c = _get(db, ctx, conversation_id, lock=True)
    if not c.handoff_active:
        raise AppError(409, "takeover_required", "Take over the conversation before replying, so the AI stops responding")
    if c.channel == "voice":
        raise AppError(400, "voice_conversation", "Call the customer back to continue a phone conversation")
    if c.channel == "sms":
        customer = db.get(Customer, c.customer_id) if c.customer_id else None
        if customer is None:
            raise bad_request("No customer on this conversation")
        from app.services.crm import send_sms

        res = send_sms(db, ctx.org, customer, body.text, purpose="reply", conversation=c, author="human")
        if not res.ok:
            db.commit()
            raise AppError(502, "sms_failed", f"Message not sent: {res.error}")
        msg = db.scalars(select(Message).where(Message.conversation_id == c.id).order_by(Message.created_at.desc()).limit(1)).first()
        if msg:
            msg.author_user_id = ctx.user.id
    else:
        msg = Message(organization_id=ctx.org_id, conversation_id=c.id, role="human", content=body.text, author_user_id=ctx.user.id)
        db.add(msg)
        c.last_message_at = utcnow()
    emit_event(db, ctx.org_id, "conversation.human_reply", channel=c.channel, conversation_id=c.id, is_test=c.is_test)
    db.commit()
    return {"ok": True, "message": message_out(msg) if msg else None}


@router.get("/files/{file_id}/download")
def download(file_id: uuid.UUID, token: str, ctx: OrgContext = Depends(require("conversations.read")), db: Session = Depends(get_db)) -> Response:
    if files.parse_download_token(token) != file_id:
        raise AppError(403, "invalid_download_token", "Invalid download link")
    f = db.scalar(select(StoredFile).where(StoredFile.id == file_id, StoredFile.organization_id == ctx.org_id))
    if f is None:
        raise not_found("File")
    data = files.get_storage().get(f.storage_key)
    return Response(
        data,
        media_type=f.content_type,
        headers={
            "Content-Disposition": f'attachment; filename="{f.filename.replace(chr(34), "")}"',
            "X-Content-Type-Options": "nosniff",
            "Cache-Control": "private, no-store",
        },
    )
