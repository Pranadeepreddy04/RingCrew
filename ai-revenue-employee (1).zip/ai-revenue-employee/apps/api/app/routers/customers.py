"""Customer records, duplicate detection/merge, consent and privacy deletion (spec §29, §46)."""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import delete, func, or_, select
from sqlalchemy.orm import Session

from app.ai.nlu import normalize_phone
from app.db import get_db
from app.deps import OrgContext, require
from app.errors import AppError, bad_request, not_found
from app.models import Appointment, Conversation, Customer, CustomerConsent, Lead, Message, StoredFile
from app.services import crm
from app.services.common import audit, utcnow
from app.services.serializers import appointment_out, customer_out, lead_out

router = APIRouter(prefix="/customers", tags=["customers"])


def _get(db: Session, ctx: OrgContext, cid: uuid.UUID) -> Customer:
    c = db.scalar(select(Customer).where(Customer.id == cid, Customer.organization_id == ctx.org_id, Customer.deleted_at.is_(None)))
    if c is None:
        raise not_found("Customer")
    return c


@router.get("")
def list_customers(
    q: str | None = None, page: int = 1, page_size: int = 50, ctx: OrgContext = Depends(require("customers.read")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    page_size = max(1, min(page_size, 200))
    base = select(Customer).where(Customer.organization_id == ctx.org_id, Customer.deleted_at.is_(None))
    if q:
        like = f"%{q.strip()[:100]}%"
        base = base.where(or_(Customer.name.ilike(like), Customer.phone.ilike(like), Customer.email.ilike(like)))
    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    rows = db.scalars(base.order_by(Customer.created_at.desc()).offset((page - 1) * page_size).limit(page_size)).all()
    return {"items": [customer_out(c) for c in rows], "total": total, "page": page, "page_size": page_size}


@router.get("/duplicates")
def duplicates(ctx: OrgContext = Depends(require("customers.read")), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    groups: list[dict[str, Any]] = []
    for col in (Customer.phone, Customer.email, func.lower(Customer.name)):
        rows = db.execute(
            select(col, func.array_agg(Customer.id))
            .where(Customer.organization_id == ctx.org_id, Customer.deleted_at.is_(None), col.isnot(None))
            .group_by(col)
            .having(func.count() > 1)
            .limit(50)
        ).all()
        for value, ids in rows:
            groups.append({"match": str(value), "customers": [customer_out(c) for c in db.scalars(select(Customer).where(Customer.id.in_(ids)))]})
    return groups


@router.get("/{customer_id}")
def get_customer(customer_id: uuid.UUID, ctx: OrgContext = Depends(require("customers.read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    c = _get(db, ctx, customer_id)
    oid = ctx.org_id
    leads = db.scalars(select(Lead).where(Lead.customer_id == c.id, Lead.organization_id == oid, Lead.deleted_at.is_(None))).unique().all()
    appts = (
        db.scalars(select(Appointment).where(Appointment.customer_id == c.id, Appointment.organization_id == oid).order_by(Appointment.start_at.desc()))
        .unique()
        .all()
    )
    convs = (
        db.scalars(
            select(Conversation).where(Conversation.customer_id == c.id, Conversation.organization_id == oid).order_by(Conversation.last_message_at.desc())
        )
        .unique()
        .all()
    )
    consents = db.scalars(
        select(CustomerConsent).where(CustomerConsent.customer_id == c.id, CustomerConsent.organization_id == oid).order_by(CustomerConsent.recorded_at.desc())
    ).all()
    fls = db.scalars(select(StoredFile).where(StoredFile.customer_id == c.id, StoredFile.organization_id == oid)).all()
    timeline = sorted(
        [{"type": "lead", "at": x.created_at.isoformat(), "text": f"Lead created — {x.service or 'request'} ({x.status})", "id": str(x.id)} for x in leads]
        + [{"type": "appointment", "at": a.created_at.isoformat(), "text": f"{a.service} — {a.status}", "id": str(a.id)} for a in appts]
        + [{"type": "conversation", "at": v.created_at.isoformat(), "text": f"{v.channel} conversation — {v.status}", "id": str(v.id)} for v in convs]
        + [
            {"type": "consent", "at": k.recorded_at.isoformat(), "text": f"{k.channel} {k.purpose} consent {k.status} ({k.source})", "id": str(k.id)}
            for k in consents
        ],
        key=lambda e: e["at"],
        reverse=True,
    )
    return {
        **customer_out(c),
        "leads": [lead_out(x) for x in leads],
        "appointments": [appointment_out(a) for a in appts],
        "conversations": [{"id": str(v.id), "channel": v.channel, "status": v.status, "last_message_at": v.last_message_at.isoformat()} for v in convs],
        "consents": [
            {"channel": k.channel, "purpose": k.purpose, "status": k.status, "source": k.source, "recorded_at": k.recorded_at.isoformat()} for k in consents
        ],
        "files": [{"id": str(f.id), "filename": f.filename} for f in fls],
        "timeline": timeline,
    }


class CustomerIn(BaseModel):
    name: str | None = Field(default=None, max_length=200)
    phone: str | None = Field(default=None, max_length=32)
    email: EmailStr | None = None
    address: str | None = Field(default=None, max_length=500)
    zip: str | None = Field(default=None, pattern=r"^\d{5}$")
    notes: str | None = Field(default=None, max_length=10000)
    tags: list[str] | None = Field(default=None, max_length=30)
    communication_preferences: dict[str, Any] | None = None


def _norm_phone(v: str | None) -> str | None:
    if not v:
        return None
    p = normalize_phone(v)
    if not p:
        raise bad_request("Invalid US phone number", "invalid_phone")
    return p


@router.post("", status_code=201)
def create_customer(body: CustomerIn, ctx: OrgContext = Depends(require("customers.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    phone = _norm_phone(body.phone)
    if not (phone or body.email or body.name):
        raise bad_request("Provide at least a name, phone or email")
    c = Customer(
        organization_id=ctx.org_id,
        name=body.name,
        phone=phone,
        email=body.email.lower() if body.email else None,
        address=body.address,
        zip=body.zip,
        notes=body.notes,
        tags=[t.strip()[:40] for t in body.tags or [] if t.strip()],
        communication_preferences=body.communication_preferences or {},
    )
    db.add(c)
    db.flush()
    audit(db, "customer.created", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="customer", target_id=c.id)
    db.commit()
    return customer_out(c)


@router.patch("/{customer_id}")
def patch_customer(
    customer_id: uuid.UUID, body: CustomerIn, ctx: OrgContext = Depends(require("customers.write")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    c = _get(db, ctx, customer_id)
    data = body.model_dump(exclude_unset=True)
    if "phone" in data:
        data["phone"] = _norm_phone(data["phone"])
    if "email" in data and data["email"]:
        data["email"] = data["email"].lower()
    if "tags" in data and data["tags"] is not None:
        data["tags"] = [t.strip()[:40] for t in data["tags"] if t.strip()]
    for k, v in data.items():
        setattr(c, k, v)
    audit(db, "customer.updated", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="customer", target_id=c.id, data={"fields": list(data)})
    db.commit()
    return customer_out(c)


class MergeIn(BaseModel):
    duplicate_id: uuid.UUID


@router.post("/{customer_id}/merge")
def merge(customer_id: uuid.UUID, body: MergeIn, ctx: OrgContext = Depends(require("customers.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    keep, dup = _get(db, ctx, customer_id), _get(db, ctx, body.duplicate_id)
    if keep.id == dup.id:
        raise bad_request("Cannot merge a customer into itself")
    crm.merge_customers(db, ctx.org_id, keep, dup)
    audit(db, "customer.merged", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="customer", target_id=keep.id, data={"merged": str(dup.id)})
    db.commit()
    return customer_out(keep)


class ConsentIn(BaseModel):
    sms_opted_out: bool
    source: str = Field(default="staff_update", max_length=100)


@router.post("/{customer_id}/sms-consent")
def set_consent(
    customer_id: uuid.UUID, body: ConsentIn, ctx: OrgContext = Depends(require("customers.write")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    c = _get(db, ctx, customer_id)
    if body.sms_opted_out:
        crm.opt_out(db, c, f"{body.source} by {ctx.user.email}")
    else:
        # Re-subscribing requires the customer's own request; staff must record where it came from.
        if body.source == "staff_update":
            raise AppError(400, "consent_source_required", "Describe how the customer asked to receive texts again (e.g. 'customer texted START')")
        crm.opt_in(db, c, f"{body.source} (recorded by {ctx.user.email})")
    db.commit()
    return customer_out(c)


@router.delete("/{customer_id}")
def delete_customer(customer_id: uuid.UUID, ctx: OrgContext = Depends(require("customers.write")), db: Session = Depends(get_db)) -> dict[str, bool]:
    """Privacy deletion request: anonymize PII, redact message content, delete files; keep de-identified aggregates."""
    if ctx.role not in ("owner", "manager"):
        raise AppError(403, "forbidden", "Only owners and managers can process deletion requests")
    c = _get(db, ctx, customer_id)
    conv_ids = [cid for (cid,) in db.execute(select(Conversation.id).where(Conversation.customer_id == c.id, Conversation.organization_id == ctx.org_id))]
    if conv_ids:
        db.execute(Message.__table__.update().where(Message.conversation_id.in_(conv_ids)).values(content="[redacted — customer deletion request]", meta={}))  # type: ignore[attr-defined]
        db.execute(Conversation.__table__.update().where(Conversation.id.in_(conv_ids)).values(summary=None, state={}, contact_address=None))  # type: ignore[attr-defined]
    from app.services.files import get_storage

    for f in db.scalars(select(StoredFile).where(StoredFile.customer_id == c.id, StoredFile.organization_id == ctx.org_id)).all():
        try:
            p = get_storage()
            if hasattr(p, "_path"):
                p._path(f.storage_key).unlink(missing_ok=True)  # type: ignore[attr-defined]
        except Exception:
            pass
        db.delete(f)
    db.execute(Lead.__table__.update().where(Lead.customer_id == c.id).values(summary=None, qualification={}))  # type: ignore[attr-defined]
    crm.stop_workflow_runs(db, customer_id=c.id, reason="opted_out")
    c.name, c.phone, c.email, c.address, c.zip, c.notes, c.tags = "Deleted customer", None, None, None, None, None, []
    c.sms_opted_out, c.deleted_at = True, utcnow()
    db.execute(delete(CustomerConsent).where(CustomerConsent.customer_id == c.id))
    audit(db, "privacy.customer_deleted", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="customer", target_id=c.id)
    db.commit()
    return {"ok": True}
