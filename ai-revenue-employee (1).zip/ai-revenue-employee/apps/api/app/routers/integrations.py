"""Integration setup: calendar, phone/SMS numbers, CRM, outgoing webhooks (spec §36, §38, §92).
Secrets are encrypted at rest and never returned after storage."""

from __future__ import annotations

import ipaddress
import json
import socket
import uuid
from typing import Any
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.nlu import normalize_phone
from app.config import get_settings
from app.db import get_db
from app.deps import OrgContext, get_auth, require
from app.errors import AppError, bad_request, conflict, not_found
from app.models import AIAgent, Integration, Membership, PhoneNumber, WebhookDelivery, WebhookEndpoint
from app.providers.calendar import CalendarError, SandboxCalendar, external_calendar, google_auth_url, google_exchange_code
from app.providers.crm import HubSpotAdapter
from app.providers.messaging import get_sms_provider, get_voice_provider
from app.security import encrypt, new_token, signed_expiring, verify_expiring
from app.services import billing
from app.services.common import audit, enqueue_job, utcnow

router = APIRouter(prefix="/integrations", tags=["integrations"])


def _integ_out(i: Integration | None) -> dict[str, Any] | None:
    if i is None:
        return None
    return {
        "id": str(i.id),
        "provider": i.provider,
        "status": i.status,
        "config": i.config,
        "last_sync_at": i.last_sync_at.isoformat() if i.last_sync_at else None,
        "last_error": i.last_error,
        "connected_at": i.created_at.isoformat(),
        "has_credentials": bool(i.credentials_encrypted),
    }


@router.get("")
def catalog(ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    s = get_settings()
    integ = {(i.kind, i.provider): i for i in db.scalars(select(Integration).where(Integration.organization_id == ctx.org_id)).all()}
    numbers = db.scalars(select(PhoneNumber).where(PhoneNumber.organization_id == ctx.org_id)).all()
    sandbox_ok = s.app_env in ("development", "test")
    return {
        "calendar": [
            {
                "provider": "google",
                "name": "Google Calendar",
                "available": bool(s.google_calendar_client_id and s.google_calendar_client_secret),
                "requires": "GOOGLE_CALENDAR_CLIENT_ID / GOOGLE_CALENDAR_CLIENT_SECRET on the server",
                "permissions": ["See when you're busy (free/busy)", "Create, update and delete events the AI books"],
                "connection": _integ_out(integ.get(("calendar", "google"))),
            },
            {
                "provider": "sandbox",
                "name": "Sandbox calendar (development only)",
                "available": sandbox_ok,
                "requires": "APP_ENV=development/test",
                "permissions": ["Simulated busy times — no real calendar"],
                "connection": _integ_out(integ.get(("calendar", "sandbox"))),
            },
            {
                "provider": "microsoft",
                "name": "Microsoft 365 Calendar",
                "available": False,
                "requires": "Not implemented yet (adapter interface ready)",
                "permissions": [],
                "connection": None,
            },
        ],
        "phone": {
            "provider": get_sms_provider().name,
            "is_sandbox": get_sms_provider().is_sandbox,
            "voice_provider": get_voice_provider().name,
            "sms_on_plan": billing.has_feature(db, ctx.org, "sms"),
            "voice_on_plan": billing.has_feature(db, ctx.org, "voice"),
            "numbers": [
                {
                    "id": str(n.id),
                    "number": n.number,
                    "provider": n.provider,
                    "agent_id": str(n.agent_id) if n.agent_id else None,
                    "sms_enabled": n.sms_enabled,
                    "voice_enabled": n.voice_enabled,
                }
                for n in numbers
            ],
            "webhook_urls": {
                "voice": f"{s.public_api_url}/api/v1/webhooks/voice/incoming",
                "sms": f"{s.public_api_url}/api/v1/webhooks/sms/incoming",
                "sms_status": f"{s.public_api_url}/api/v1/webhooks/sms/status",
            },
        },
        "crm": [
            {
                "provider": "hubspot",
                "name": "HubSpot",
                "available": True,
                "requires": "A HubSpot private-app access token",
                "permissions": ["Create and update contacts", "Create and update deals"],
                "connection": _integ_out(integ.get(("crm", "hubspot"))),
            },
            {
                "provider": "salesforce",
                "name": "Salesforce",
                "available": False,
                "requires": "Not implemented yet (adapter interface ready)",
                "permissions": [],
                "connection": None,
            },
        ],
        "email": {"provider": s.email_provider, "is_sandbox": s.email_provider == "sandbox"},
        "payments": {"provider": s.billing_provider, "is_sandbox": s.billing_provider == "sandbox"},
    }


# ------------------------------------------------------------------ calendar


@router.get("/google-calendar/connect")
def google_connect(ctx: OrgContext = Depends(require("integrations.manage"))) -> dict[str, str]:
    state = signed_expiring(f"{ctx.org_id}:{ctx.user.id}:{new_token(8)}", "gcal", 600)
    try:
        return {"url": google_auth_url(state)}
    except CalendarError as exc:
        raise AppError(501, "google_calendar_not_configured", str(exc)) from None


@router.get("/google-calendar/callback")
def google_callback(request: Request, code: str, state: str, db: Session = Depends(get_db)) -> RedirectResponse:
    auth = get_auth(request, db)  # must be the same signed-in user who started the flow
    value = verify_expiring(state, "gcal")
    if not value:
        raise bad_request("Invalid or expired connection attempt", "invalid_state")
    org_id, user_id, _ = value.split(":")
    if str(auth.user.id) != user_id:
        raise AppError(403, "forbidden", "Signed-in user does not match the connection request")
    m = db.scalar(select(Membership).where(Membership.organization_id == uuid.UUID(org_id), Membership.user_id == auth.user.id))
    if m is None or m.role != "owner":
        raise AppError(403, "forbidden", "Only owners can connect integrations")
    web = get_settings().public_web_url
    try:
        creds = google_exchange_code(code)
    except CalendarError as exc:
        return RedirectResponse(f"{web}/app/integrations?error={str(exc)[:100]}")
    _upsert(db, uuid.UUID(org_id), "calendar", "google", {"calendar_id": "primary"}, creds)
    audit(db, "integration.connected", org_id=uuid.UUID(org_id), actor_user_id=auth.user.id, data={"provider": "google_calendar"})
    db.commit()
    return RedirectResponse(f"{web}/app/integrations?connected=google")


def _upsert(db: Session, org_id: uuid.UUID, kind: str, provider: str, config: dict[str, Any], creds: dict[str, Any] | None) -> Integration:
    others = db.scalars(select(Integration).where(Integration.organization_id == org_id, Integration.kind == kind, Integration.provider != provider)).all()
    for o in others:
        if kind == "calendar":
            o.status = "disconnected"
    i = db.scalar(select(Integration).where(Integration.organization_id == org_id, Integration.kind == kind, Integration.provider == provider))
    if i is None:
        i = Integration(organization_id=org_id, kind=kind, provider=provider)
        db.add(i)
    i.config, i.status, i.last_error = config, "connected", None
    i.credentials_encrypted = encrypt(json.dumps(creds)) if creds else None
    i.last_sync_at = utcnow()
    db.flush()
    return i


@router.post("/sandbox-calendar/connect")
def sandbox_calendar(ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    if get_settings().app_env not in ("development", "test"):
        raise AppError(400, "sandbox_not_allowed", "Sandbox integrations are only available in development")
    i = _upsert(db, ctx.org_id, "calendar", "sandbox", {"label": "Sandbox calendar"}, None)
    db.commit()
    return _integ_out(i) or {}


@router.post("/{integration_id}/test")
def test_integration(integration_id: uuid.UUID, ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    i = _get(db, ctx, integration_id)
    ok = False
    if i.kind == "calendar":
        cal = external_calendar(db, ctx.org_id)
        ok = bool(cal and cal.health())
    elif i.kind == "crm" and i.provider == "hubspot":
        ok = HubSpotAdapter(i).health()
    i.status = "connected" if ok else "error"
    i.last_error = None if ok else "Health check failed"
    if ok:
        i.last_sync_at = utcnow()
    db.commit()
    return {"ok": ok, **(_integ_out(i) or {})}


def _get(db: Session, ctx: OrgContext, iid: uuid.UUID) -> Integration:
    i = db.scalar(select(Integration).where(Integration.id == iid, Integration.organization_id == ctx.org_id))
    if i is None:
        raise not_found("Integration")
    return i


@router.delete("/{integration_id}")
def disconnect(integration_id: uuid.UUID, ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    i = _get(db, ctx, integration_id)
    db.delete(i)
    audit(db, "integration.disconnected", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"kind": i.kind, "provider": i.provider})
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ CRM


class HubSpotIn(BaseModel):
    access_token: str = Field(min_length=10, max_length=500)


@router.post("/hubspot/connect")
def hubspot_connect(body: HubSpotIn, ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    i = _upsert(db, ctx.org_id, "crm", "hubspot", {}, {"access_token": body.access_token})
    ok = HubSpotAdapter(i).health()
    if not ok:
        db.rollback()
        raise AppError(400, "invalid_credentials", "HubSpot rejected that token or could not be reached. Check the token and its scopes.")
    audit(db, "integration.connected", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"provider": "hubspot"})
    db.commit()
    return _integ_out(i) or {}


# ------------------------------------------------------------------ phone numbers


class NumberIn(BaseModel):
    mode: str = Field(pattern="^(provision|existing)$")
    area_code: str | None = Field(default=None, pattern=r"^\d{3}$")
    number: str | None = None
    agent_id: uuid.UUID | None = None


@router.post("/phone-numbers", status_code=201)
def add_number(body: NumberIn, ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    if not (billing.has_feature(db, ctx.org, "sms") or billing.has_feature(db, ctx.org, "voice")):
        raise AppError(402, "plan_required", "Phone and SMS require the Growth plan or higher")
    s = get_settings()
    voice = get_voice_provider()
    if body.mode == "provision":
        if not body.area_code:
            raise bad_request("area_code is required")
        try:
            number = voice.provision_number(
                body.area_code, f"{s.public_api_url}/api/v1/webhooks/voice/incoming", f"{s.public_api_url}/api/v1/webhooks/sms/incoming"
            )
        except RuntimeError as exc:
            raise AppError(502, "provisioning_failed", str(exc)) from None
    else:
        number = normalize_phone(body.number or "") or ""
        if not number:
            raise bad_request("Enter a valid US phone number that is already on the platform's telephony account", "invalid_phone")
    if db.scalar(select(PhoneNumber.id).where(PhoneNumber.number == number)):
        raise conflict("That number is already connected to a business", "number_in_use")
    if body.agent_id and not db.scalar(select(AIAgent.id).where(AIAgent.id == body.agent_id, AIAgent.organization_id == ctx.org_id)):
        raise not_found("AI employee")
    agent_id = body.agent_id or db.scalar(
        select(AIAgent.id).where(AIAgent.organization_id == ctx.org_id, AIAgent.deleted_at.is_(None)).order_by(AIAgent.created_at).limit(1)
    )
    pn = PhoneNumber(organization_id=ctx.org_id, number=number, provider=voice.name, agent_id=agent_id)
    db.add(pn)
    audit(db, "phone_number.added", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"number": number, "mode": body.mode})
    db.commit()
    return {
        "id": str(pn.id),
        "number": pn.number,
        "provider": pn.provider,
        "agent_id": str(pn.agent_id) if pn.agent_id else None,
        "is_sandbox": voice.is_sandbox,
    }


class NumberPatch(BaseModel):
    agent_id: uuid.UUID | None = None
    sms_enabled: bool | None = None
    voice_enabled: bool | None = None


@router.patch("/phone-numbers/{number_id}")
def patch_number(
    number_id: uuid.UUID, body: NumberPatch, ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)
) -> dict[str, bool]:
    pn = db.scalar(select(PhoneNumber).where(PhoneNumber.id == number_id, PhoneNumber.organization_id == ctx.org_id))
    if pn is None:
        raise not_found("Phone number")
    if body.agent_id:
        if not db.scalar(select(AIAgent.id).where(AIAgent.id == body.agent_id, AIAgent.organization_id == ctx.org_id)):
            raise not_found("AI employee")
        pn.agent_id = body.agent_id
    if body.sms_enabled is not None:
        pn.sms_enabled = body.sms_enabled
    if body.voice_enabled is not None:
        pn.voice_enabled = body.voice_enabled
    db.commit()
    return {"ok": True}


@router.delete("/phone-numbers/{number_id}")
def remove_number(number_id: uuid.UUID, ctx: OrgContext = Depends(require("integrations.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    pn = db.scalar(select(PhoneNumber).where(PhoneNumber.id == number_id, PhoneNumber.organization_id == ctx.org_id))
    if pn is None:
        raise not_found("Phone number")
    db.delete(pn)
    audit(db, "phone_number.removed", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"number": pn.number})
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ outgoing webhooks


def _assert_public_url(url: str) -> None:
    p = urlparse(url)
    if p.scheme != "https" and get_settings().app_env not in ("development", "test"):
        raise bad_request("Webhook URLs must use https")
    if p.scheme not in ("http", "https") or not p.hostname:
        raise bad_request("Invalid URL")
    if get_settings().app_env in ("development", "test"):
        return
    try:
        for info in socket.getaddrinfo(p.hostname, p.port or 443):
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
                raise bad_request("Webhook URL must be publicly reachable")
    except socket.gaierror:
        raise bad_request("Webhook host could not be resolved") from None


class WebhookIn(BaseModel):
    url: str = Field(min_length=8, max_length=1000)
    events: list[str] = Field(default_factory=list)


@router.get("/webhooks")
def list_webhooks(ctx: OrgContext = Depends(require("webhooks.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    from app.services.common import OUTGOING_WEBHOOK_EVENTS

    eps = db.scalars(select(WebhookEndpoint).where(WebhookEndpoint.organization_id == ctx.org_id).order_by(WebhookEndpoint.created_at)).all()
    deliveries = db.scalars(
        select(WebhookDelivery).where(WebhookDelivery.organization_id == ctx.org_id).order_by(WebhookDelivery.created_at.desc()).limit(50)
    ).all()
    return {
        "endpoints": [{"id": str(e.id), "url": e.url, "events": e.events, "active": e.active} for e in eps],
        "available_events": sorted(OUTGOING_WEBHOOK_EVENTS),
        "enabled_on_plan": billing.has_feature(db, ctx.org, "webhooks"),
        "deliveries": [
            {
                "id": str(d.id),
                "event_type": d.event_type,
                "status": d.status,
                "attempts": d.attempts,
                "response_code": d.response_code,
                "last_error": d.last_error,
                "created_at": d.created_at.isoformat(),
            }
            for d in deliveries
        ],
    }


@router.post("/webhooks", status_code=201)
def add_webhook(body: WebhookIn, ctx: OrgContext = Depends(require("webhooks.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    from app.services.common import OUTGOING_WEBHOOK_EVENTS

    billing.require_feature(db, ctx.org, "webhooks")
    _assert_public_url(body.url)
    bad = [e for e in body.events if e not in OUTGOING_WEBHOOK_EVENTS]
    if bad:
        raise bad_request(f"Unknown events: {bad}")
    secret = "whsec_" + new_token(24)
    ep = WebhookEndpoint(organization_id=ctx.org_id, url=body.url, events=body.events, secret_encrypted=encrypt(secret))
    db.add(ep)
    audit(db, "webhook.created", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"url": body.url})
    db.commit()
    return {"id": str(ep.id), "url": ep.url, "events": ep.events, "secret": secret, "note": "Store this signing secret now — it will not be shown again."}


@router.delete("/webhooks/{endpoint_id}")
def delete_webhook(endpoint_id: uuid.UUID, ctx: OrgContext = Depends(require("webhooks.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    ep = db.scalar(select(WebhookEndpoint).where(WebhookEndpoint.id == endpoint_id, WebhookEndpoint.organization_id == ctx.org_id))
    if ep is None:
        raise not_found("Webhook endpoint")
    db.delete(ep)
    db.commit()
    return {"ok": True}


@router.post("/webhooks/{endpoint_id}/test")
def test_webhook(endpoint_id: uuid.UUID, ctx: OrgContext = Depends(require("webhooks.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    ep = db.scalar(select(WebhookEndpoint).where(WebhookEndpoint.id == endpoint_id, WebhookEndpoint.organization_id == ctx.org_id))
    if ep is None:
        raise not_found("Webhook endpoint")
    d = WebhookDelivery(
        organization_id=ctx.org_id,
        endpoint_id=ep.id,
        event_type="webhook.test",
        payload={"id": str(uuid.uuid4()), "type": "webhook.test", "created_at": utcnow().isoformat(), "data": {"message": "Test delivery"}},
    )
    db.add(d)
    db.flush()
    enqueue_job(db, "webhook.deliver", {"delivery_id": str(d.id)}, org_id=ctx.org_id)
    db.commit()
    return {"ok": True}


_ = SandboxCalendar
