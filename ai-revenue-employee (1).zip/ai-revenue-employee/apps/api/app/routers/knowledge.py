"""Knowledge base management (spec §13, §7 step 7). All sources are tenant-scoped and only
owner/manager-approved content is used for answers."""

from __future__ import annotations

import io
import uuid
from typing import Any

from fastapi import APIRouter, Depends, File, Form, UploadFile
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import OrgContext, get_org_ctx, require
from app.errors import AppError, not_found
from app.models import KnowledgeChunk, KnowledgeSource
from app.services import knowledge as kn
from app.services.common import audit

router = APIRouter(prefix="/knowledge", tags=["knowledge"])
EDITABLE_KINDS = {"faq", "manual", "policy", "document", "website"}


def _src_out(s: KnowledgeSource, chunks: int | None = None) -> dict[str, Any]:
    return {
        "id": str(s.id),
        "kind": s.kind,
        "title": s.title,
        "url": s.url,
        "status": s.status,
        "error": s.error,
        "approved": s.approved,
        "content": s.content,
        "characters": len(s.content or ""),
        "chunks": chunks,
        "updated_at": s.updated_at.isoformat() if s.updated_at else None,
    }


@router.get("/sources")
def list_sources(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    counts = dict(
        db.execute(select(KnowledgeChunk.source_id, func.count()).where(KnowledgeChunk.organization_id == ctx.org_id).group_by(KnowledgeChunk.source_id)).all()
    )
    rows = db.scalars(select(KnowledgeSource).where(KnowledgeSource.organization_id == ctx.org_id).order_by(KnowledgeSource.created_at.desc())).all()
    return [_src_out(s, counts.get(s.id, 0)) for s in rows]


class FAQ(BaseModel):
    question: str = Field(min_length=3, max_length=500)
    answer: str = Field(min_length=1, max_length=3000)


class FAQSetIn(BaseModel):
    title: str = Field(default="Frequently asked questions", max_length=300)
    faqs: list[FAQ] = Field(min_length=1, max_length=200)


@router.post("/faqs", status_code=201)
def add_faqs(body: FAQSetIn, ctx: OrgContext = Depends(require("knowledge.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    src = KnowledgeSource(organization_id=ctx.org_id, kind="faq", title=body.title, content="")
    db.add(src)
    db.flush()
    kn.index_source(db, src, faqs=[f.model_dump() for f in body.faqs])
    src.url = None
    audit(db, "knowledge.faqs_added", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="knowledge_source", target_id=src.id)
    db.commit()
    return _src_out(src, len(body.faqs))


@router.put("/faqs/{source_id}")
def replace_faqs(source_id: uuid.UUID, body: FAQSetIn, ctx: OrgContext = Depends(require("knowledge.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    src = _get(db, ctx, source_id)
    if src.kind != "faq":
        raise AppError(400, "wrong_kind", "Not an FAQ source")
    src.title = body.title
    kn.index_source(db, src, faqs=[f.model_dump() for f in body.faqs])
    db.commit()
    return _src_out(src, len(body.faqs))


@router.get("/faqs/{source_id}")
def get_faqs(source_id: uuid.UUID, ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    src = _get(db, ctx, source_id)
    chunks = db.scalars(select(KnowledgeChunk).where(KnowledgeChunk.source_id == src.id).order_by(KnowledgeChunk.position)).all()
    faqs = []
    for c in chunks:
        if c.content.startswith("Q:") and "\nA:" in c.content:
            q, a = c.content[2:].split("\nA:", 1)
            faqs.append({"question": q.strip(), "answer": a.strip()})
    return {"id": str(src.id), "title": src.title, "faqs": faqs}


class TextSourceIn(BaseModel):
    kind: str = Field(default="manual", pattern="^(manual|policy)$")
    title: str = Field(min_length=1, max_length=300)
    content: str = Field(min_length=1, max_length=200_000)


@router.post("/sources", status_code=201)
def add_text(body: TextSourceIn, ctx: OrgContext = Depends(require("knowledge.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    src = KnowledgeSource(organization_id=ctx.org_id, kind=body.kind, title=body.title, content=body.content)
    db.add(src)
    db.flush()
    kn.index_source(db, src)
    audit(db, "knowledge.source_added", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="knowledge_source", target_id=src.id)
    db.commit()
    return _src_out(src)


class SourcePatch(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=300)
    content: str | None = Field(default=None, min_length=1, max_length=200_000)
    approved: bool | None = None


def _get(db: Session, ctx: OrgContext, source_id: uuid.UUID) -> KnowledgeSource:
    s = db.scalar(select(KnowledgeSource).where(KnowledgeSource.id == source_id, KnowledgeSource.organization_id == ctx.org_id))
    if s is None:
        raise not_found("Knowledge source")
    return s


@router.get("/sources/{source_id}")
def get_source(source_id: uuid.UUID, ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    return _src_out(_get(db, ctx, source_id))


@router.patch("/sources/{source_id}")
def patch_source(
    source_id: uuid.UUID, body: SourcePatch, ctx: OrgContext = Depends(require("knowledge.manage")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    s = _get(db, ctx, source_id)
    if s.kind in ("profile", "service") and body.content is not None:
        raise AppError(400, "managed_source", "Edit this in Business settings or Services instead")
    if body.title is not None:
        s.title = body.title
    if body.approved is not None:
        s.approved = body.approved
    if body.content is not None and s.kind != "faq":
        s.content = body.content
        kn.index_source(db, s)
    audit(db, "knowledge.source_updated", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="knowledge_source", target_id=s.id)
    db.commit()
    return _src_out(s)


@router.delete("/sources/{source_id}")
def delete_source(source_id: uuid.UUID, ctx: OrgContext = Depends(require("knowledge.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    s = _get(db, ctx, source_id)
    if s.kind in ("profile", "service"):
        raise AppError(400, "managed_source", "This source is managed from Business settings / Services")
    db.delete(s)
    audit(db, "knowledge.source_deleted", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="knowledge_source", target_id=source_id)
    db.commit()
    return {"ok": True}


MAX_DOC_BYTES = 5 * 1024 * 1024


def _extract_document(filename: str, data: bytes) -> str:
    name = filename.lower()
    if name.endswith((".txt", ".md")):
        return data.decode("utf-8", errors="replace")
    if name.endswith(".pdf"):
        if not data.startswith(b"%PDF-"):
            raise AppError(415, "type_mismatch", "The file is not a valid PDF")
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(data))
        if len(reader.pages) > 200:
            raise AppError(413, "too_many_pages", "PDFs are limited to 200 pages")
        return "\n\n".join((p.extract_text() or "") for p in reader.pages)
    if name.endswith(".docx"):
        if not data.startswith(b"PK"):
            raise AppError(415, "type_mismatch", "The file is not a valid .docx")
        import docx

        d = docx.Document(io.BytesIO(data))
        return "\n\n".join(p.text for p in d.paragraphs)
    raise AppError(415, "unsupported_type", "Upload a .txt, .md, .pdf or .docx file")


@router.post("/documents", status_code=201)
async def upload_document(
    title: str = Form(default=""), file: UploadFile = File(...), ctx: OrgContext = Depends(require("knowledge.manage")), db: Session = Depends(get_db)
) -> dict[str, Any]:
    data = await file.read(MAX_DOC_BYTES + 1)
    if len(data) > MAX_DOC_BYTES:
        raise AppError(413, "file_too_large", "Documents must be 5 MB or smaller")
    try:
        text = _extract_document(file.filename or "", data)
    except AppError:
        raise
    except Exception:
        raise AppError(422, "unreadable_document", "We couldn't read text from that document") from None
    text = kn.sanitize(text)
    if len(text) < 20:
        raise AppError(422, "no_text", "No readable text found (scanned documents are not supported yet)")
    src = KnowledgeSource(organization_id=ctx.org_id, kind="document", title=(title or file.filename or "Document")[:300], content=text)
    db.add(src)
    db.flush()
    kn.index_source(db, src)
    audit(db, "knowledge.document_uploaded", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="knowledge_source", target_id=src.id)
    db.commit()
    return _src_out(src)


@router.get("/search")
def search(q: str, ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    return [h.as_dict() for h in kn.search(db, ctx.org_id, q, limit=5)]
