"""Lightweight CRM: leads pipeline (kanban/table/detail) and staff tasks (spec §28)."""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.ai.nlu import normalize_phone
from app.db import get_db
from app.deps import OrgContext, require
from app.errors import bad_request, not_found
from app.models import Appointment, Customer, Lead, Membership, Task
from app.services import crm
from app.services.common import audit, emit_event, utcnow
from app.services.serializers import appointment_out, lead_out, task_out

router = APIRouter(tags=["leads"])


@router.get("/leads")
def list_leads(
    status: str | None = None,
    qualified: bool | None = None,
    source: str | None = None,
    q: str | None = None,
    page: int = 1,
    page_size: int = 50,
    ctx: OrgContext = Depends(require("leads.read")),
    db: Session = Depends(get_db),
) -> dict[str, Any]:
    page_size = max(1, min(page_size, 200))
    base = select(Lead).where(Lead.organization_id == ctx.org_id, Lead.deleted_at.is_(None))
    if status:
        base = base.where(Lead.status == status)
    if qualified is not None:
        base = base.where(Lead.is_qualified.is_(qualified))
    if source:
        base = base.where(Lead.source == source)
    if q:
        like = f"%{q.strip()[:100]}%"
        base = base.join(Customer, Customer.id == Lead.customer_id).where(
            or_(Customer.name.ilike(like), Customer.phone.ilike(like), Customer.email.ilike(like), Lead.service.ilike(like))
        )
    total = db.scalar(select(func.count()).select_from(base.subquery())) or 0
    rows = db.scalars(base.order_by(Lead.created_at.desc()).offset((page - 1) * page_size).limit(page_size)).unique().all()
    appts = _next_appts(db, ctx, [r.id for r in rows])
    return {
        "items": [{**lead_out(x), "appointment": appts.get(x.id)} for x in rows],
        "total": total,
        "page": page,
        "page_size": page_size,
        "stages": (ctx.org.settings or {}).get("pipeline_stages", []),
    }


def _next_appts(db: Session, ctx: OrgContext, lead_ids: list[uuid.UUID]) -> dict[uuid.UUID, dict[str, Any]]:
    if not lead_ids:
        return {}
    rows = db.scalars(
        select(Appointment)
        .where(Appointment.organization_id == ctx.org_id, Appointment.lead_id.in_(lead_ids), Appointment.status.in_(("scheduled", "confirmed", "completed")))
        .order_by(Appointment.start_at)
    ).all()
    out: dict[uuid.UUID, dict[str, Any]] = {}
    for a in rows:
        if a.lead_id and a.lead_id not in out:
            out[a.lead_id] = {"id": str(a.id), "start_at": a.start_at.isoformat(), "status": a.status}
    return out


@router.get("/leads/board")
def board(ctx: OrgContext = Depends(require("leads.read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    stages = (ctx.org.settings or {}).get("pipeline_stages", [])
    rows = (
        db.scalars(select(Lead).where(Lead.organization_id == ctx.org_id, Lead.deleted_at.is_(None)).order_by(Lead.last_activity_at.desc()).limit(500))
        .unique()
        .all()
    )
    appts = _next_appts(db, ctx, [r.id for r in rows])
    cols: dict[str, list[dict[str, Any]]] = {s: [] for s in stages}
    for x in rows:
        cols.setdefault(x.status, []).append({**lead_out(x), "appointment": appts.get(x.id)})
    return {"stages": stages, "columns": cols}


def _get(db: Session, ctx: OrgContext, lead_id: uuid.UUID) -> Lead:
    x = db.scalar(select(Lead).where(Lead.id == lead_id, Lead.organization_id == ctx.org_id, Lead.deleted_at.is_(None)))
    if x is None:
        raise not_found("Lead")
    return x


@router.get("/leads/{lead_id}")
def get_lead(lead_id: uuid.UUID, ctx: OrgContext = Depends(require("leads.read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    x = _get(db, ctx, lead_id)
    appts = db.scalars(select(Appointment).where(Appointment.lead_id == x.id, Appointment.organization_id == ctx.org_id).order_by(Appointment.start_at)).all()
    tasks = db.scalars(select(Task).where(Task.lead_id == x.id, Task.organization_id == ctx.org_id).order_by(Task.created_at.desc())).all()
    return {
        **lead_out(x),
        "appointments": [appointment_out(a) for a in appts],
        "tasks": [task_out(t) for t in tasks],
        "stages": (ctx.org.settings or {}).get("pipeline_stages", []),
    }


class LeadCreateIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    phone: str | None = Field(default=None, max_length=32)
    email: EmailStr | None = None
    service: str | None = Field(default=None, max_length=300)
    source: str = Field(default="manual", max_length=40)
    estimated_value_cents: int | None = Field(default=None, ge=0)
    notes: str | None = Field(default=None, max_length=4000)


@router.post("/leads", status_code=201)
def create_lead(body: LeadCreateIn, ctx: OrgContext = Depends(require("leads.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    phone = normalize_phone(body.phone) if body.phone else None
    if body.phone and not phone:
        raise bad_request("Invalid US phone number", "invalid_phone")
    if not (phone or body.email):
        raise bad_request("Phone or email is required")
    customer = crm.find_or_create_customer(db, ctx.org_id, phone=phone, email=body.email, name=body.name)
    lead = Lead(
        organization_id=ctx.org_id,
        customer_id=customer.id,
        source=body.source,
        channel="manual",
        service=body.service,
        status="new",
        estimated_value_cents=body.estimated_value_cents,
        summary=body.notes,
        attribution_source=body.source,
        attribution_confidence="unknown",
    )
    db.add(lead)
    db.flush()
    emit_event(
        db,
        ctx.org_id,
        "lead.created",
        channel="manual",
        lead_id=lead.id,
        data={"source": body.source, "qualified": False},
        webhook_payload={"lead_id": str(lead.id), "source": body.source},
    )
    audit(db, "lead.created", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="lead", target_id=lead.id)
    db.commit()
    db.refresh(lead)
    return lead_out(lead)


class LeadPatch(BaseModel):
    status: str | None = None
    assigned_user_id: uuid.UUID | None = None
    unassign: bool = False
    service: str | None = Field(default=None, max_length=300)
    summary: str | None = Field(default=None, max_length=4000)
    estimated_value_cents: int | None = Field(default=None, ge=0)
    actual_revenue_cents: int | None = Field(default=None, ge=0)


@router.patch("/leads/{lead_id}")
def patch_lead(lead_id: uuid.UUID, body: LeadPatch, ctx: OrgContext = Depends(require("leads.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    x = _get(db, ctx, lead_id)
    if body.status:
        crm.set_lead_status(db, ctx.org, x, body.status, ctx.user.id)
    if body.assigned_user_id:
        if not db.scalar(select(Membership.id).where(Membership.organization_id == ctx.org_id, Membership.user_id == body.assigned_user_id)):
            raise bad_request("Assignee is not on this team")
        x.assigned_user_id = body.assigned_user_id
    if body.unassign:
        x.assigned_user_id = None
    for k in ("service", "summary", "estimated_value_cents"):
        v = getattr(body, k)
        if v is not None:
            setattr(x, k, v)
    if body.actual_revenue_cents is not None:
        x.actual_revenue_cents = body.actual_revenue_cents
        emit_event(db, ctx.org_id, "lead.revenue_recorded", lead_id=x.id, data={"cents": body.actual_revenue_cents})
    x.last_activity_at = utcnow()
    audit(
        db,
        "lead.updated",
        org_id=ctx.org_id,
        actor_user_id=ctx.user.id,
        target_type="lead",
        target_id=x.id,
        data=body.model_dump(exclude_none=True, mode="json"),
    )
    db.commit()
    db.refresh(x)
    return lead_out(x)


@router.delete("/leads/{lead_id}")
def delete_lead(lead_id: uuid.UUID, ctx: OrgContext = Depends(require("leads.write")), db: Session = Depends(get_db)) -> dict[str, bool]:
    x = _get(db, ctx, lead_id)
    x.deleted_at = utcnow()
    crm.stop_workflow_runs(db, lead_id=x.id, reason="lead_closed", only_conditions=False)
    audit(db, "lead.deleted", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="lead", target_id=x.id)
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ tasks


@router.get("/tasks")
def list_tasks(status: str = "open", ctx: OrgContext = Depends(require("leads.read")), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    q = select(Task).where(Task.organization_id == ctx.org_id)
    if status in ("open", "done"):
        q = q.where(Task.status == status)
    order = {"high": 0, "normal": 1, "low": 2}
    rows = db.scalars(q.order_by(Task.created_at.desc()).limit(200)).all()
    return [task_out(t) for t in sorted(rows, key=lambda t: (order.get(t.priority, 1), -t.created_at.timestamp()))]


class TaskPatch(BaseModel):
    status: str | None = Field(default=None, pattern="^(open|done)$")
    assigned_user_id: uuid.UUID | None = None


@router.patch("/tasks/{task_id}")
def patch_task(task_id: uuid.UUID, body: TaskPatch, ctx: OrgContext = Depends(require("tasks.write")), db: Session = Depends(get_db)) -> dict[str, Any]:
    t = db.scalar(select(Task).where(Task.id == task_id, Task.organization_id == ctx.org_id))
    if t is None:
        raise not_found("Task")
    if body.status:
        t.status = body.status
        t.completed_at = utcnow() if body.status == "done" else None
    if body.assigned_user_id:
        if not db.scalar(select(Membership.id).where(Membership.organization_id == ctx.org_id, Membership.user_id == body.assigned_user_id)):
            raise bad_request("Assignee is not on this team")
        t.assigned_user_id = body.assigned_user_id
    db.commit()
    return task_out(t)
