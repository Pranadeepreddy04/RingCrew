"""Organizations, onboarding, business profile, services, team, privacy export/deletion."""

from __future__ import annotations

import re
import uuid
from datetime import timedelta
from typing import Any
from zoneinfo import available_timezones

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, EmailStr, Field, field_validator
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db
from app.deps import ROLES, AuthContext, OrgContext, get_auth, get_org_ctx, require
from app.errors import AppError, bad_request, not_found
from app.industry import PackError, list_packs, resolve_pack
from app.models import (
    AIAgent,
    Appointment,
    BusinessProfile,
    Conversation,
    Customer,
    Invitation,
    KnowledgeSource,
    Lead,
    Membership,
    Message,
    Organization,
    Service,
    Task,
    User,
    Workflow,
)
from app.providers.email import send_email
from app.ratelimit import client_ip
from app.security import new_token, sha256_hex
from app.services import billing
from app.services.common import audit, utcnow
from app.services.knowledge import import_website, index_source
from app.services.serializers import org_out, profile_out, service_out

router = APIRouter(tags=["organizations"])

DEFAULT_HOURS = {d: [["08:00", "17:00"]] for d in ("mon", "tue", "wed", "thu", "fri")} | {"sat": [], "sun": []}
DEFAULT_PIPELINE = ["new", "contacted", "qualified", "appointment", "estimate", "won", "lost"]
_HHMM = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def default_workflows(org_id: uuid.UUID) -> list[Workflow]:
    return [
        Workflow(
            organization_id=org_id,
            name="New lead follow-up (no appointment yet)",
            trigger="lead.created",
            steps=[
                {
                    "delay_minutes": 60,
                    "channel": "sms",
                    "template": "Hi {first_name}, this is {agent_name} with {business_name}. Thanks for reaching out about {service}. "
                    "Would you like to set up a time? Just reply here. Reply STOP to opt out.",
                },
                {
                    "delay_minutes": 1440,
                    "channel": "sms",
                    "template": "Hi {first_name}, following up from {business_name} — we'd be glad to help with {service}. "
                    "Reply with a good day for a visit. Reply STOP to opt out.",
                },
            ],
            stop_conditions=["appointment_booked", "customer_replied", "opted_out", "lead_closed", "human_takeover"],
            quiet_hours={"start": "20:00", "end": "08:00"},
            max_attempts=2,
            active=True,
        ),
        Workflow(
            organization_id=org_id,
            name="Appointment reminder",
            trigger="appointment.created",
            steps=[
                {
                    "before_appointment_minutes": 1440,
                    "channel": "sms",
                    "template": "Reminder from {business_name}: your appointment ({service}) is scheduled for {appointment_time}. "
                    "Reply here if you need to reschedule. Reply STOP to opt out.",
                }
            ],
            stop_conditions=["appointment_cancelled", "opted_out"],
            quiet_hours={"start": "20:00", "end": "08:00"},
            max_attempts=1,
            active=True,
        ),
    ]


def validate_zips(v: list[str]) -> list[str]:
    out = []
    for z in v:
        z = z.strip()
        if not re.fullmatch(r"\d{5}", z):
            raise ValueError(f"Invalid ZIP code: {z}")
        out.append(z)
    return sorted(set(out))


class OrgCreateIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    industry: str
    website: str | None = Field(default=None, max_length=500)
    phone: str | None = Field(default=None, max_length=32)
    address: str | None = Field(default=None, max_length=500)
    timezone: str = "America/Chicago"
    service_area_zips: list[str] = Field(default_factory=list, max_length=500)
    employees_count: str | None = Field(default=None, max_length=20)

    @field_validator("timezone")
    @classmethod
    def _tz(cls, v: str) -> str:
        if v not in available_timezones():
            raise ValueError("Unknown timezone")
        return v

    @field_validator("service_area_zips")
    @classmethod
    def _zips(cls, v: list[str]) -> list[str]:
        return validate_zips(v)


def _slug(db: Session, name: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:60] or "business"
    slug = base
    while db.scalar(select(Organization.id).where(Organization.slug == slug)):
        slug = f"{base}-{uuid.uuid4().hex[:6]}"
    return slug


def create_organization(db: Session, user: User | None, body: OrgCreateIn, *, is_demo: bool = False) -> Organization:
    try:
        pack = resolve_pack(body.industry, db)
    except PackError:
        raise bad_request("Unknown industry", "invalid_industry") from None
    if pack.status == "disabled":
        raise AppError(400, "industry_disabled", f"{pack.name} is not available yet. It requires additional compliance work before launch.")
    org = Organization(
        name=body.name.strip(),
        slug=_slug(db, body.name),
        industry=pack.key,
        timezone=body.timezone,
        is_demo=is_demo,
        demo_expires_at=utcnow() + timedelta(hours=24) if is_demo else None,
        onboarding_step=3,
        settings={
            "pipeline_stages": DEFAULT_PIPELINE,
            "recording": {"enabled": False, "consent_configured": False},
            "ai": {"allow_fallback_provider": False},
            "notification_prefs": {},
        },
    )
    db.add(org)
    db.flush()
    if user is not None:
        db.add(Membership(organization_id=org.id, user_id=user.id, role="owner"))
    db.add(
        BusinessProfile(
            organization_id=org.id,
            website=body.website,
            phone=body.phone,
            address=body.address,
            employees_count=body.employees_count,
            service_area_zips=body.service_area_zips,
            hours=DEFAULT_HOURS,
        )
    )
    for wf in default_workflows(org.id):
        db.add(wf)
    if not is_demo:
        billing.seed_plans(db)
        billing.start_trial(db, org)
    return org


@router.get("/industries")
def industries(db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    return list_packs(db)


@router.get("/industries/{key}")
def industry_detail(key: str, db: Session = Depends(get_db)) -> dict[str, Any]:
    try:
        p = resolve_pack(key, db)
    except PackError:
        raise not_found("Industry") from None
    return {
        "key": p.key,
        "name": p.name,
        "status": p.status,
        "appointment_label": p.appointment_label,
        "default_service": p.default_service,
        "fields": [
            {"key": f.key, "label": f.label, "type": f.type, "required": f.required, "enabled": f.enabled, "prompt": f.prompt, "options": list(f.options)}
            for f in p.fields
        ],
        "collection_order": p.collection_order,
    }


@router.get("/timezones")
def timezones() -> list[str]:
    return sorted(t for t in available_timezones() if "/" in t and not t.startswith(("Etc/", "SystemV/")))


@router.post("/organizations", status_code=201)
def create_org(body: OrgCreateIn, request: Request, auth: AuthContext = Depends(get_auth), db: Session = Depends(get_db)) -> dict[str, Any]:
    if get_settings().require_email_verification and not auth.user.email_verified_at:
        raise AppError(403, "email_not_verified", "Verify your email before creating a business")
    org = create_organization(db, auth.user, body)
    audit(db, "organization.created", org_id=org.id, actor_user_id=auth.user.id, target_type="organization", target_id=org.id, ip=client_ip(request))
    db.commit()
    return org_out(org)


@router.get("/organizations/current")
def current_org(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    profile = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == ctx.org_id))
    services = db.scalars(select(Service).where(Service.organization_id == ctx.org_id).order_by(Service.name)).all()
    return {
        **org_out(ctx.org),
        "role": ctx.role,
        "profile": profile_out(profile) if profile else None,
        "services": [service_out(s) for s in services],
        "entitlements": billing.entitlements(db, ctx.org),
    }


class OrgPatchIn(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    timezone: str | None = None
    pipeline_stages: list[str] | None = Field(default=None, min_length=2, max_length=15)
    recording_enabled: bool | None = None
    recording_consent_configured: bool | None = None
    allow_fallback_provider: bool | None = None
    notification_prefs: dict[str, bool] | None = None
    usage_limits: dict[str, int] | None = None

    @field_validator("timezone")
    @classmethod
    def _tz(cls, v: str | None) -> str | None:
        if v is not None and v not in available_timezones():
            raise ValueError("Unknown timezone")
        return v


@router.patch("/organizations/current")
def patch_org(body: OrgPatchIn, ctx: OrgContext = Depends(require("org.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    org = ctx.org
    settings = dict(org.settings or {})
    if body.name:
        org.name = body.name.strip()
    if body.timezone:
        org.timezone = body.timezone
    if body.pipeline_stages is not None:
        stages = [re.sub(r"[^a-z0-9_]+", "_", s.lower()).strip("_") for s in body.pipeline_stages]
        if "won" not in stages or "lost" not in stages or len(set(stages)) != len(stages) or "" in stages:
            raise bad_request("Pipeline must contain unique stages including 'won' and 'lost'")
        settings["pipeline_stages"] = stages
    rec = dict(settings.get("recording") or {})
    if body.recording_consent_configured is not None:
        rec["consent_configured"] = body.recording_consent_configured
    if body.recording_enabled is not None:
        if body.recording_enabled and not rec.get("consent_configured"):
            raise bad_request("Confirm your recording consent/disclosure configuration before enabling call recording", "recording_consent_required")
        rec["enabled"] = body.recording_enabled
    settings["recording"] = rec
    if body.allow_fallback_provider is not None:
        settings["ai"] = {**(settings.get("ai") or {}), "allow_fallback_provider": body.allow_fallback_provider}
    if body.notification_prefs is not None:
        settings["notification_prefs"] = {"email": body.notification_prefs}
    if body.usage_limits is not None:
        settings["usage_limits"] = {k: max(0, int(v)) for k, v in body.usage_limits.items() if k in billing.USAGE_LIMIT_KEYS.values()}
    org.settings = settings
    audit(db, "organization.updated", org_id=org.id, actor_user_id=ctx.user.id, data=body.model_dump(exclude_none=True))
    db.commit()
    return org_out(org)


class HoursValidator(BaseModel):
    hours: dict[str, list[list[str]]]

    @field_validator("hours")
    @classmethod
    def _hours(cls, v: dict[str, list[list[str]]]) -> dict[str, list[list[str]]]:
        days = {"mon", "tue", "wed", "thu", "fri", "sat", "sun"}
        for day, ranges in v.items():
            if day not in days:
                raise ValueError(f"Unknown day {day}")
            for r in ranges:
                if len(r) != 2 or not all(_HHMM.match(x) for x in r) or r[0] >= r[1]:
                    raise ValueError(f"Invalid hours for {day}: {r}")
        return {d: v.get(d, []) for d in days}


class ProfileIn(BaseModel):
    website: str | None = Field(default=None, max_length=500)
    phone: str | None = Field(default=None, max_length=32)
    address: str | None = Field(default=None, max_length=500)
    description: str | None = Field(default=None, max_length=5000)
    employees_count: str | None = Field(default=None, max_length=20)
    service_area_zips: list[str] | None = None
    service_area_description: str | None = Field(default=None, max_length=2000)
    hours: dict[str, list[list[str]]] | None = None
    appointment_duration_minutes: int | None = Field(default=None, ge=15, le=480)
    booking_lead_time_hours: int | None = Field(default=None, ge=0, le=168)
    booking_horizon_days: int | None = Field(default=None, ge=1, le=90)
    emergency_instructions: str | None = Field(default=None, max_length=3000)
    escalation_rules: str | None = Field(default=None, max_length=3000)
    escalation_phone: str | None = Field(default=None, max_length=32)
    pricing_info: str | None = Field(default=None, max_length=10000)
    policies: str | None = Field(default=None, max_length=10000)


PROFILE_KNOWLEDGE = {
    "description": "About the business",
    "pricing_info": "Pricing",
    "policies": "Policies",
    "emergency_instructions": "Emergency instructions",
    "service_area_description": "Service area",
}


def sync_profile_knowledge(db: Session, org_id: uuid.UUID, profile: BusinessProfile) -> None:
    """Business-profile text is first-class approved knowledge; keep 'manual' sources in sync."""
    for attr, title in PROFILE_KNOWLEDGE.items():
        value = getattr(profile, attr)
        src = db.scalar(
            select(KnowledgeSource).where(KnowledgeSource.organization_id == org_id, KnowledgeSource.kind == "profile", KnowledgeSource.title == title)
        )
        if not value:
            if src:
                db.delete(src)
            continue
        if src is None:
            src = KnowledgeSource(organization_id=org_id, kind="profile", title=title, content=value)
            db.add(src)
            db.flush()
        src.content = value
        index_source(db, src)


@router.put("/organizations/current/profile")
def put_profile(body: ProfileIn, ctx: OrgContext = Depends(require("org.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    profile = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == ctx.org_id))
    if profile is None:
        raise not_found("Business profile")
    data = body.model_dump(exclude_unset=True)
    if "hours" in data and data["hours"] is not None:
        data["hours"] = HoursValidator(hours=data["hours"]).hours
    if "service_area_zips" in data and data["service_area_zips"] is not None:
        try:
            data["service_area_zips"] = validate_zips(data["service_area_zips"])
        except ValueError as exc:
            raise bad_request(str(exc), "invalid_zip") from None
    for k, v in data.items():
        setattr(profile, k, v)
    sync_profile_knowledge(db, ctx.org_id, profile)
    audit(db, "business_profile.updated", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"fields": list(data)})
    db.commit()
    return profile_out(profile)


class OnboardingIn(BaseModel):
    step: int = Field(ge=1, le=9)
    completed: bool = False


@router.post("/organizations/current/onboarding")
def onboarding_progress(body: OnboardingIn, ctx: OrgContext = Depends(require("org.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    ctx.org.onboarding_step = max(ctx.org.onboarding_step, body.step)
    if body.completed:
        ctx.org.onboarding_completed_at = ctx.org.onboarding_completed_at or utcnow()
    db.commit()
    return org_out(ctx.org)


class ImportIn(BaseModel):
    url: str = Field(min_length=4, max_length=500)
    confirm: bool


@router.post("/organizations/current/import-website")
def import_site(body: ImportIn, request: Request, ctx: OrgContext = Depends(require("knowledge.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    if not body.confirm:
        raise bad_request("Please confirm that we may read your public website", "confirmation_required")
    from app.ratelimit import enforce

    enforce(request, "import-site", 10, 3600, key=str(ctx.org_id))
    result = import_website(body.url)
    created = []
    for page in result["pages"]:
        if not page["text"]:
            continue
        src = KnowledgeSource(organization_id=ctx.org_id, kind="website", title=page["title"] or page["url"], url=page["url"], content=page["text"])
        db.add(src)
        db.flush()
        index_source(db, src)
        created.append({"id": str(src.id), "title": src.title, "url": src.url, "characters": len(src.content)})
    profile = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == ctx.org_id))
    if profile and not profile.description and result["description"]:
        profile.description = result["description"]
        sync_profile_knowledge(db, ctx.org_id, profile)
    audit(db, "knowledge.website_imported", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"url": body.url, "pages": len(created)})
    db.commit()
    return {"description": result["description"], "sources": created}


# ------------------------------------------------------------------ services


class ServiceIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str | None = Field(default=None, max_length=3000)
    duration_minutes: int | None = Field(default=None, ge=15, le=480)
    active: bool = True


def _sync_services_knowledge(db: Session, org_id: uuid.UUID) -> None:
    services = db.scalars(select(Service).where(Service.organization_id == org_id, Service.active.is_(True)).order_by(Service.name)).all()
    src = db.scalar(select(KnowledgeSource).where(KnowledgeSource.organization_id == org_id, KnowledgeSource.kind == "service"))
    content = "\n\n".join(f"Service: {s.name}. {s.description or ''}".strip() for s in services)
    if not content:
        if src:
            db.delete(src)
        return
    if src is None:
        src = KnowledgeSource(organization_id=org_id, kind="service", title="Services offered", content=content)
        db.add(src)
        db.flush()
    src.content = "Services we offer: " + ", ".join(s.name for s in services) + ".\n\n" + content
    index_source(db, src)


@router.post("/services", status_code=201)
def create_service(body: ServiceIn, ctx: OrgContext = Depends(require("org.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    s = Service(organization_id=ctx.org_id, **body.model_dump())
    db.add(s)
    db.flush()
    _sync_services_knowledge(db, ctx.org_id)
    db.commit()
    return service_out(s)


@router.put("/services/{service_id}")
def update_service(service_id: uuid.UUID, body: ServiceIn, ctx: OrgContext = Depends(require("org.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    s = db.scalar(select(Service).where(Service.id == service_id, Service.organization_id == ctx.org_id))
    if not s:
        raise not_found("Service")
    for k, v in body.model_dump().items():
        setattr(s, k, v)
    _sync_services_knowledge(db, ctx.org_id)
    db.commit()
    return service_out(s)


@router.delete("/services/{service_id}")
def delete_service(service_id: uuid.UUID, ctx: OrgContext = Depends(require("org.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    s = db.scalar(select(Service).where(Service.id == service_id, Service.organization_id == ctx.org_id))
    if not s:
        raise not_found("Service")
    db.delete(s)
    db.flush()
    _sync_services_knowledge(db, ctx.org_id)
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ team


class InviteIn(BaseModel):
    email: EmailStr
    role: str

    @field_validator("role")
    @classmethod
    def _role(cls, v: str) -> str:
        if v not in ROLES or v == "owner":
            raise ValueError("Role must be manager, staff or readonly")
        return v


@router.get("/team")
def team(ctx: OrgContext = Depends(get_org_ctx), db: Session = Depends(get_db)) -> dict[str, Any]:
    members = db.scalars(select(Membership).where(Membership.organization_id == ctx.org_id).order_by(Membership.created_at)).all()
    invites = (
        db.scalars(
            select(Invitation).where(
                Invitation.organization_id == ctx.org_id, Invitation.accepted_at.is_(None), Invitation.revoked_at.is_(None), Invitation.expires_at > utcnow()
            )
        ).all()
        if ctx.can("team.manage")
        else []
    )
    return {
        "members": [
            {
                "id": str(m.id),
                "user_id": str(m.user_id),
                "name": m.user.name,
                "email": m.user.email,
                "role": m.role,
                "is_active": m.user.is_active,
                "is_you": m.user_id == ctx.user.id,
            }
            for m in members
        ],
        "invitations": [{"id": str(i.id), "email": i.email, "role": i.role, "expires_at": i.expires_at.isoformat()} for i in invites],
    }


@router.post("/team/invitations", status_code=201)
def invite(body: InviteIn, ctx: OrgContext = Depends(require("team.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    if not billing.count_limit_ok(db, ctx.org, "team_members"):
        raise AppError(402, "plan_limit", "Your plan's team member limit has been reached. Upgrade to add more people.")
    already = db.scalar(
        select(Membership)
        .join(User, User.id == Membership.user_id)
        .where(Membership.organization_id == ctx.org_id, func.lower(User.email) == body.email.lower())
    )
    if already:
        raise AppError(409, "already_member", "That person is already on your team")
    token = new_token()
    inv = Invitation(
        organization_id=ctx.org_id,
        email=body.email.lower(),
        role=body.role,
        token_hash=sha256_hex(token),
        invited_by_user_id=ctx.user.id,
        expires_at=utcnow() + timedelta(days=7),
    )
    db.add(inv)
    link = f"{get_settings().public_web_url}/invite?token={token}"
    send_email(
        db,
        body.email,
        f"You're invited to {ctx.org.name}",
        f"{ctx.user.name} invited you to join {ctx.org.name} on AI Revenue Employee as {body.role}.\n\nAccept: {link}\n\nThis link expires in 7 days.",
        ctx.org_id,
    )
    audit(db, "team.invited", org_id=ctx.org_id, actor_user_id=ctx.user.id, data={"email": body.email, "role": body.role})
    db.commit()
    out = {"id": str(inv.id), "email": inv.email, "role": inv.role}
    if get_settings().app_env in ("development", "test"):
        out["dev_accept_link"] = link  # convenience in sandbox environments only
    return out


@router.delete("/team/invitations/{invitation_id}")
def revoke_invite(invitation_id: uuid.UUID, ctx: OrgContext = Depends(require("team.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    inv = db.scalar(select(Invitation).where(Invitation.id == invitation_id, Invitation.organization_id == ctx.org_id))
    if not inv:
        raise not_found("Invitation")
    inv.revoked_at = utcnow()
    db.commit()
    return {"ok": True}


class RoleIn(BaseModel):
    role: str

    @field_validator("role")
    @classmethod
    def _role(cls, v: str) -> str:
        if v not in ROLES:
            raise ValueError("Invalid role")
        return v


def _owner_count(db: Session, org_id: uuid.UUID) -> int:
    return int(db.scalar(select(func.count()).select_from(Membership).where(Membership.organization_id == org_id, Membership.role == "owner")) or 0)


@router.patch("/team/members/{membership_id}")
def change_role(membership_id: uuid.UUID, body: RoleIn, ctx: OrgContext = Depends(require("team.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    m = db.scalar(select(Membership).where(Membership.id == membership_id, Membership.organization_id == ctx.org_id))
    if not m:
        raise not_found("Team member")
    if m.role == "owner" and body.role != "owner" and _owner_count(db, ctx.org_id) <= 1:
        raise bad_request("A business must have at least one owner")
    m.role = body.role
    audit(db, "team.role_changed", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="membership", target_id=m.id, data={"role": body.role})
    db.commit()
    return {"ok": True}


@router.delete("/team/members/{membership_id}")
def remove_member(membership_id: uuid.UUID, ctx: OrgContext = Depends(require("team.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    m = db.scalar(select(Membership).where(Membership.id == membership_id, Membership.organization_id == ctx.org_id))
    if not m:
        raise not_found("Team member")
    if m.role == "owner" and _owner_count(db, ctx.org_id) <= 1:
        raise bad_request("A business must have at least one owner")
    db.delete(m)
    audit(db, "team.member_removed", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="user", target_id=m.user_id)
    db.commit()
    return {"ok": True}


# ------------------------------------------------------------------ privacy (spec §46)


@router.get("/organizations/current/export")
def export_org(ctx: OrgContext = Depends(require("privacy.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    from app.services.serializers import appointment_out, customer_out, lead_out, message_out

    oid = ctx.org_id
    audit(db, "privacy.tenant_export", org_id=oid, actor_user_id=ctx.user.id)
    db.commit()
    return {
        "organization": org_out(ctx.org),
        "customers": [customer_out(c) for c in db.scalars(select(Customer).where(Customer.organization_id == oid))],
        "leads": [lead_out(x) for x in db.scalars(select(Lead).where(Lead.organization_id == oid))],
        "appointments": [appointment_out(x) for x in db.scalars(select(Appointment).where(Appointment.organization_id == oid))],
        "conversations": [
            {
                "id": str(c.id),
                "channel": c.channel,
                "status": c.status,
                "created_at": c.created_at.isoformat(),
                "messages": [message_out(m) for m in db.scalars(select(Message).where(Message.conversation_id == c.id).order_by(Message.created_at))],
            }
            for c in db.scalars(select(Conversation).where(Conversation.organization_id == oid))
        ],
        "knowledge_sources": [
            {"id": str(s.id), "kind": s.kind, "title": s.title, "content": s.content}
            for s in db.scalars(select(KnowledgeSource).where(KnowledgeSource.organization_id == oid))
        ],
        "tasks": [{"id": str(t.id), "title": t.title, "status": t.status} for t in db.scalars(select(Task).where(Task.organization_id == oid))],
        "agents": [{"id": str(a.id), "name": a.name, "role": a.role} for a in db.scalars(select(AIAgent).where(AIAgent.organization_id == oid))],
    }


class DeleteOrgIn(BaseModel):
    confirm_name: str


@router.delete("/organizations/current")
def delete_org(body: DeleteOrgIn, ctx: OrgContext = Depends(require("org.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    if body.confirm_name.strip() != ctx.org.name:
        raise bad_request("Type the exact business name to confirm deletion", "confirmation_mismatch")
    ctx.org.deleted_at = utcnow()
    ctx.org.status = "deleted"
    db.execute(
        AIAgent.__table__.update().where(AIAgent.organization_id == ctx.org_id).values(status="paused")  # type: ignore[attr-defined]
    )
    audit(db, "organization.deleted", org_id=ctx.org_id, actor_user_id=ctx.user.id)
    # Hard purge of tenant data is performed by the retention job after the grace period.
    from app.services.common import enqueue_job

    enqueue_job(db, "tenant.purge", {"organization_id": str(ctx.org_id)}, org_id=None, run_at=utcnow() + timedelta(days=30), dedupe_key=f"purge-{ctx.org_id}")
    db.commit()
    return {"ok": True}


def purge_tenant(db: Session, org_id: uuid.UUID) -> None:
    org = db.get(Organization, org_id)
    if org is None or org.deleted_at is None:
        return
    db.execute(delete(Organization).where(Organization.id == org_id))  # FK cascades remove tenant rows
