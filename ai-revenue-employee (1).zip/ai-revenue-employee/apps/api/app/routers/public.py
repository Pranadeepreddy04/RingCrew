"""Public (unauthenticated) endpoints: website chat widget, customer uploads, personalized demo.

Public widget tokens identify an AI employee and grant *only* the ability to hold a conversation
with it; they never grant access to any administrative API (spec §12)."""

from __future__ import annotations

import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, Header, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai import i18n
from app.ai.orchestrator import process_customer_message, start_conversation
from app.config import get_settings
from app.db import get_db
from app.errors import AppError, not_found
from app.models import AIAgent, Conversation, Message, Organization, StoredFile
from app.ratelimit import client_ip, enforce
from app.security import sign, verify_signature
from app.services import billing, files
from app.services.common import audit, emit_event, utcnow
from app.services.serializers import public_message_out

router = APIRouter(prefix="/public", tags=["public"])
WIDGET_JS = Path(__file__).resolve().parents[1] / "static" / "widget.js"
SMS_DISCLOSURE = "By sharing your phone number you agree we may text you about your request. Msg & data rates may apply. Reply STOP to opt out."


def _agent_by_token(db: Session, token: str) -> tuple[AIAgent, Organization]:
    a = db.scalar(select(AIAgent).where(AIAgent.widget_token == token, AIAgent.deleted_at.is_(None)))
    if a is None:
        raise not_found("Chat widget")
    org = db.get(Organization, a.organization_id)
    if org is None or org.deleted_at is not None or org.status != "active":
        raise not_found("Chat widget")
    if org.is_demo and org.demo_expires_at and org.demo_expires_at < utcnow():
        raise AppError(410, "demo_expired", "This demo has expired")
    return a, org


def _visitor_token(conv_id: uuid.UUID) -> str:
    return f"{conv_id}.{sign(str(conv_id), 'visitor')}"


def _conv_for_visitor(db: Session, conversation_id: uuid.UUID, token: str | None) -> Conversation:
    if not token or "." not in token:
        raise AppError(401, "visitor_token_required", "Missing visitor token")
    cid, sig = token.split(".", 1)
    if cid != str(conversation_id) or not verify_signature(cid, sig, "visitor"):
        raise AppError(403, "invalid_visitor_token", "Invalid visitor token")
    conv = db.get(Conversation, conversation_id)
    if conv is None or conv.channel not in ("web",):
        raise not_found("Conversation")
    return conv


def _online(db: Session, a: AIAgent, org: Organization) -> bool:
    return a.status == "active" and (org.is_demo or bool(billing.entitlements(db, org)["usable"]))


def _voice_input() -> dict[str, Any]:
    s = get_settings()
    if s.voice_asr_provider != "vibevoice":
        return {"asr": "browser", "vibevoice_languages": []}
    return {"asr": "vibevoice", "vibevoice_languages": sorted(x.strip() for x in s.vibevoice_languages.split(",") if x.strip() in i18n.LANGS)}


@router.get("/widget/{token}/config")
def widget_config(token: str, request: Request, db: Session = Depends(get_db)) -> dict[str, Any]:
    enforce(request, "widget-config", 120)
    a, org = _agent_by_token(db, token)
    ws = a.widget_settings or {}
    return {
        "agent_name": a.name,
        "business_name": org.name,
        "greeting": ws.get("welcome_message") or a.greeting,
        "online": _online(db, a, org),
        "position": ws.get("position", "bottom-right"),
        "primary_color": ws.get("primary_color", "#1f5eff"),
        "logo_url": ws.get("logo_url"),
        "title": ws.get("title") or f"Chat with {org.name}",
        "is_demo": org.is_demo,
        "sms_disclosure": SMS_DISCLOSURE,
        "uploads_enabled": "collect_quote_info" in (a.capabilities or []),
        "languages": [
            {"code": c, "name": i18n.LANGS[c]["name"], "native": i18n.LANGS[c]["native"], "bcp47": i18n.LANGS[c]["bcp47"], "rtl": c in i18n.RTL}
            for c in (a.languages or [a.language or "en"])
            if c in i18n.LANGS
        ],
        "default_language": (a.languages or [a.language or "en"])[0],
        "voice_input": _voice_input(),
    }


class WidgetStartIn(BaseModel):
    language: str | None = Field(default=None, max_length=10)


@router.post("/widget/{token}/conversations", status_code=201)
def widget_start(token: str, request: Request, body: WidgetStartIn | None = None, db: Session = Depends(get_db)) -> dict[str, Any]:
    enforce(request, "widget-start", 20)
    a, org = _agent_by_token(db, token)
    if "web_chat" not in (a.capabilities or []) and not org.is_demo:
        raise AppError(403, "web_chat_disabled", "Website chat is not enabled for this AI employee")
    conv = start_conversation(db, org, a, "web", is_test=org.is_demo, language=(body.language if body else None))
    greeting = db.scalar(select(Message).where(Message.conversation_id == conv.id))
    primary = conv.language in (None, a.language) and not (a.greetings or {}).get(conv.language or "")
    if greeting and primary and (a.widget_settings or {}).get("welcome_message"):
        greeting.content = a.widget_settings["welcome_message"]
    db.commit()
    msgs = db.scalars(select(Message).where(Message.conversation_id == conv.id, Message.role.in_(("ai", "human"))).order_by(Message.created_at)).all()
    return {
        "conversation_id": str(conv.id),
        "visitor_token": _visitor_token(conv.id),
        "language": conv.language or a.language or "en",
        "messages": [public_message_out(m) for m in msgs],
    }


class VisitorMessageIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


@router.post("/conversations/{conversation_id}/messages")
def visitor_message(
    conversation_id: uuid.UUID, body: VisitorMessageIn, request: Request, x_visitor_token: str | None = Header(default=None), db: Session = Depends(get_db)
) -> dict[str, Any]:
    enforce(request, "widget-msg-ip", 60)
    enforce(request, "widget-msg-conv", 30, key=str(conversation_id))
    checked = _conv_for_visitor(db, conversation_id, x_visitor_token)
    conv = db.scalar(select(Conversation).where(Conversation.id == checked.id).with_for_update())  # serialize turns per conversation
    if conv is None:
        raise not_found("Conversation")
    org = db.get(Organization, conv.organization_id)
    agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
    if org is None or agent is None or agent.deleted_at is not None:
        raise not_found("Conversation")
    cmsg, result, reply = process_customer_message(db, org, agent, conv, body.text)
    db.commit()
    out = [public_message_out(reply)] if reply else []
    return {
        "messages": out,
        "handoff": result.handoff or conv.handoff_active,
        "customer_message_id": str(cmsg.id),
        "language": conv.language or agent.language or "en",
    }


@router.get("/conversations/{conversation_id}/messages")
def visitor_poll(
    conversation_id: uuid.UUID,
    request: Request,
    after: datetime | None = None,
    x_visitor_token: str | None = Header(default=None),
    db: Session = Depends(get_db),
) -> dict[str, Any]:
    enforce(request, "widget-poll", 120)
    conv = _conv_for_visitor(db, conversation_id, x_visitor_token)
    q = select(Message).where(Message.conversation_id == conv.id, Message.role.in_(("ai", "human", "customer")))
    if after:
        q = q.where(Message.created_at > after)
    msgs = db.scalars(q.order_by(Message.created_at).limit(200)).all()
    return {"messages": [public_message_out(m) for m in msgs], "handoff": conv.handoff_active}


@router.get("/conversations/{conversation_id}/upload-token")
def visitor_upload_token(conversation_id: uuid.UUID, x_visitor_token: str | None = Header(default=None), db: Session = Depends(get_db)) -> dict[str, str]:
    conv = _conv_for_visitor(db, conversation_id, x_visitor_token)
    return {"upload_token": files.upload_token(conv.organization_id, conv.id)}


@router.post("/uploads", status_code=201)
async def public_upload(
    request: Request, upload_token: str = Header(alias="x-upload-token"), file: UploadFile = File(...), db: Session = Depends(get_db)
) -> dict[str, Any]:
    enforce(request, "upload", 20, 600)
    org_id, conv_id = files.parse_upload_token(upload_token)
    conv = db.scalar(select(Conversation).where(Conversation.id == conv_id, Conversation.organization_id == org_id))
    if conv is None:
        raise not_found("Conversation")
    data = await file.read(get_settings().max_upload_bytes + 1)
    ctype = (file.content_type or "").lower()
    files.validate_upload(ctype, data)
    key = files.new_storage_key(org_id, file.filename or "upload")
    files.get_storage().put(key, data, ctype)
    sf = StoredFile(
        organization_id=org_id,
        customer_id=conv.customer_id,
        conversation_id=conv.id,
        storage_key=key,
        filename=(file.filename or "upload")[:300],
        content_type=ctype,
        size_bytes=len(data),
        sha256=files.sha256(data),
        scan_status=files.scan_for_malware(data),
        uploaded_via="widget",
    )
    db.add(sf)
    db.add(Message(organization_id=org_id, conversation_id=conv.id, role="customer", content=f"[Uploaded file: {sf.filename}]", meta={"file_id": str(sf.id)}))
    db.flush()
    emit_event(db, org_id, "file.uploaded", channel=conv.channel, conversation_id=conv.id, is_test=conv.is_test)
    db.commit()
    return {"id": str(sf.id), "filename": sf.filename, "size_bytes": sf.size_bytes}


# ------------------------------------------------------------------ personalized demo (spec §48)


class DemoIn(BaseModel):
    business_name: str = Field(min_length=2, max_length=120)
    industry: str = Field(min_length=2, max_length=60)
    website: str | None = Field(default=None, max_length=300)


@router.post("/demo", status_code=201)
def create_demo(body: DemoIn, request: Request, db: Session = Depends(get_db)) -> dict[str, Any]:
    enforce(request, "demo-create", 5, 3600)
    from app.models import BusinessProfile, KnowledgeSource
    from app.routers.agents import ROLE_DEFAULT_CAPS
    from app.routers.organizations import OrgCreateIn, create_organization, sync_profile_knowledge
    from app.security import new_token
    from app.services import knowledge as kn

    org = create_organization(db, None, OrgCreateIn(name=body.business_name, industry=body.industry, website=body.website), is_demo=True)
    profile = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == org.id))
    imported = 0
    if body.website:
        try:
            result = kn.import_website(body.website, max_pages=3)
            for page in result["pages"]:
                if page["text"]:
                    src = KnowledgeSource(organization_id=org.id, kind="website", title=page["title"] or page["url"], url=page["url"], content=page["text"])
                    db.add(src)
                    db.flush()
                    kn.index_source(db, src)
                    imported += 1
            if profile and result["description"]:
                profile.description = result["description"]
                sync_profile_knowledge(db, org.id, profile)
        except AppError:
            pass  # demo still works with default knowledge; the UI reports that the import failed
    agent = AIAgent(
        organization_id=org.id,
        name="Sarah",
        role="receptionist",
        status="active",
        languages=list(i18n.LANGUAGE_ORDER),
        activated_at=utcnow(),
        greeting=f"Hi! I'm Sarah, the AI employee for {org.name} (demo). How can I help you today?",
        capabilities=ROLE_DEFAULT_CAPS["receptionist"],
        industry_template_key=org.industry,
        widget_token="wt_demo_" + new_token(20),
    )
    db.add(agent)
    audit(db, "demo.created", org_id=org.id, actor_type="system", ip=client_ip(request), data={"industry": body.industry, "imported_pages": imported})
    db.commit()
    return {
        "widget_token": agent.widget_token,
        "business_name": org.name,
        "expires_at": org.demo_expires_at.isoformat() if org.demo_expires_at else None,
        "imported_pages": imported,
        "website_import_failed": bool(body.website) and imported == 0,
    }


def widget_js() -> Response:
    return Response(WIDGET_JS.read_text(), media_type="application/javascript", headers={"Cache-Control": "public, max-age=300"})
