"""Telephony webhooks: inbound SMS (STOP/START/HELP), delivery status, and the voice call loop (spec §10, §11, §95, §96).
All provider webhooks are signature-verified and de-duplicated before any processing."""

from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Any

from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.ai import i18n
from app.ai.nlu import HELP_WORDS, START_WORDS, STOP_WORDS, normalize_phone
from app.ai.orchestrator import process_customer_message, start_conversation
from app.config import get_settings
from app.db import get_db
from app.errors import AppError
from app.models import AIAgent, Call, Conversation, Customer, InboundWebhookEvent, Message, Organization, PhoneNumber
from app.observability import metrics
from app.providers.asr import get_asr_provider
from app.providers.messaging import get_sms_provider, get_voice_provider
from app.security import sign
from app.services import billing, crm
from app.services.common import emit_event, enqueue_job, utcnow

router = APIRouter(prefix="/webhooks", tags=["provider-webhooks"], include_in_schema=False)
EMPTY_TWIML = '<?xml version="1.0" encoding="UTF-8"?><Response></Response>'


def _twiml(xml: str) -> Response:
    return Response(xml, media_type="application/xml")


async def _verified_form(request: Request, provider: Any) -> dict[str, str]:
    form = {k: str(v) for k, v in (await request.form()).items()}
    url = get_settings().public_api_url.rstrip("/") + request.url.path + (f"?{request.url.query}" if request.url.query else "")
    if not provider.verify_webhook(url, form, request.headers.get("x-twilio-signature")):
        metrics.inc("webhook_signature_failures_total", provider=provider.name)
        raise AppError(403, "invalid_signature", "Webhook signature verification failed")
    return form


def _dedupe(db: Session, provider: str, external_id: str, org_id: uuid.UUID | None, event_type: str) -> bool:
    """Returns True if this is the first time we see the event."""
    try:
        with db.begin_nested():
            db.add(InboundWebhookEvent(provider=provider, external_id=external_id, organization_id=org_id, event_type=event_type))
        return True
    except IntegrityError:
        return False


def _number(db: Session, to: str) -> PhoneNumber | None:
    return db.scalar(select(PhoneNumber).where(PhoneNumber.number == (normalize_phone(to) or to)))


# ------------------------------------------------------------------ SMS


@router.post("/sms/incoming")
async def sms_incoming(request: Request, db: Session = Depends(get_db)) -> Response:
    provider = get_sms_provider()
    form = await _verified_form(request, provider)
    sid, frm, to, body = form.get("MessageSid", ""), form.get("From", ""), form.get("To", ""), (form.get("Body") or "").strip()
    number = _number(db, to)
    if number is None or not sid:
        return _twiml(EMPTY_TWIML)
    org = db.get(Organization, number.organization_id)
    if org is None or org.deleted_at is not None:
        return _twiml(EMPTY_TWIML)
    if not _dedupe(db, "sms", sid, org.id, "sms.inbound"):
        db.commit()
        return _twiml(EMPTY_TWIML)  # duplicate delivery: already processed
    phone = normalize_phone(frm)
    if phone is None:
        db.commit()
        return _twiml(EMPTY_TWIML)
    customer = crm.find_or_create_customer(db, org.id, phone=phone)
    keyword = body.upper().strip(" .!")
    conv = db.scalar(
        select(Conversation)
        .where(
            Conversation.organization_id == org.id,
            Conversation.channel == "sms",
            Conversation.contact_address == phone,
            Conversation.last_message_at > utcnow() - timedelta(days=7),
        )
        .order_by(Conversation.last_message_at.desc())
        .limit(1)
    )
    agent = db.get(AIAgent, number.agent_id) if number.agent_id else None
    if keyword in STOP_WORDS:
        crm.opt_out(db, customer, f"sms_keyword:{keyword}")
        _store_inbound(db, org, conv, customer, phone, body, sid, agent)
        db.commit()
        return _twiml(EMPTY_TWIML)  # the carrier/provider sends the compliant STOP confirmation
    if keyword in START_WORDS and customer.sms_opted_out:
        crm.opt_in(db, customer, f"sms_keyword:{keyword}")
        _store_inbound(db, org, conv, customer, phone, body, sid, agent)
        db.commit()
        return _twiml(EMPTY_TWIML)
    if keyword in HELP_WORDS:
        _store_inbound(db, org, conv, customer, phone, body, sid, agent)
        profile_phone = number.number
        from app.models import BusinessProfile

        p = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == org.id))
        db.commit()
        from xml.sax.saxutils import escape

        text = f"{org.name}: text us here for help with your request, or call {p.phone if p and p.phone else profile_phone}. Msg & data rates may apply. Reply STOP to opt out."
        return _twiml(f'<?xml version="1.0" encoding="UTF-8"?><Response><Message>{escape(text)}</Message></Response>')
    if customer.sms_opted_out:
        # Customer opted out and wrote again without START: record it for staff, never auto-reply.
        _store_inbound(db, org, conv, customer, phone, body, sid, agent)
        db.commit()
        return _twiml(EMPTY_TWIML)
    if conv is None and agent is not None:
        conv = start_conversation(db, org, agent, "sms", contact=phone, customer=customer, greet=False)
    if conv is None or agent is None or not number.sms_enabled:
        _store_inbound(db, org, conv, customer, phone, body, sid, agent)
        db.commit()
        return _twiml(EMPTY_TWIML)
    if not crm.has_sms_consent(db, customer):
        crm.record_consent(db, customer, "sms", "transactional", "granted", "inbound_sms")
    crm.stop_workflow_runs(db, customer_id=customer.id, reason="customer_replied")
    enqueue_job(db, "sms.respond", {"conversation_id": str(conv.id), "text": body[:1600], "message_sid": sid}, org_id=org.id, dedupe_key=f"sms-respond-{sid}")
    db.commit()
    return _twiml(EMPTY_TWIML)


def _store_inbound(
    db: Session, org: Organization, conv: Conversation | None, customer: Customer, phone: str, body: str, sid: str, agent: AIAgent | None
) -> None:
    if conv is None:
        conv = Conversation(
            organization_id=org.id, customer_id=customer.id, channel="sms", contact_address=phone, agent_id=agent.id if agent else None, state={}
        )
        db.add(conv)
        db.flush()
    db.add(Message(organization_id=org.id, conversation_id=conv.id, role="customer", content=body[:1600], provider_message_id=sid, meta={"channel": "sms"}))
    conv.last_message_at = utcnow()


def respond_to_sms(db: Session, conversation_id: uuid.UUID, text: str, message_sid: str) -> str:
    """Worker job: run the AI for an inbound SMS and deliver its reply through the SMS provider."""
    conv = db.scalar(select(Conversation).where(Conversation.id == conversation_id).with_for_update())
    if conv is None:
        return "missing_conversation"
    org = db.get(Organization, conv.organization_id)
    agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
    if org is None or agent is None:
        return "missing_agent"
    if db.scalar(select(Message.id).where(Message.organization_id == org.id, Message.provider_message_id == message_sid)):
        return "duplicate"
    _, result, reply = process_customer_message(db, org, agent, conv, text, provider_message_id=message_sid)
    if reply is None:
        return "no_reply"
    customer = db.get(Customer, conv.customer_id) if conv.customer_id else None
    if customer is None or customer.sms_opted_out:
        reply.delivery_status = "blocked"
        return "blocked"
    number = crm.org_sending_number(db, org.id)
    if number is None or not billing.within_limit(db, org, "sms"):
        reply.delivery_status = "blocked"
        reply.meta = {**reply.meta, "error": "no_number_or_limit"}
        return "blocked"
    res = get_sms_provider().send(
        from_number=number.number,
        to=customer.phone or "",
        body=reply.content[:1600],
        status_callback=f"{get_settings().public_api_url}/api/v1/webhooks/sms/status",
    )
    reply.provider_message_id = res.provider_message_id
    reply.delivery_status = res.status if res.ok else "failed"
    reply.meta = {**reply.meta, "channel": "sms", "provider": res.provider, "error": res.error}
    if res.ok:
        billing.record_usage(db, org.id, "sms", 1, provider=res.provider, channel="sms", conversation_id=conv.id)
        emit_event(db, org.id, "sms.sent", channel="sms", conversation_id=conv.id, data={"purpose": "reply"})
        return "sent"
    emit_event(db, org.id, "sms.failed", channel="sms", conversation_id=conv.id, data={"error": res.error})
    if res.retryable:
        raise RuntimeError(f"retryable sms failure: {res.error}")
    return "failed"


@router.post("/sms/status")
async def sms_status(request: Request, db: Session = Depends(get_db)) -> Response:
    form = await _verified_form(request, get_sms_provider())
    sid, status = form.get("MessageSid", ""), form.get("MessageStatus", "")
    msg = db.scalar(select(Message).where(Message.provider_message_id == sid))
    if msg is not None and status:
        order = ["queued", "sending", "sent", "delivered", "undelivered", "failed"]
        cur = msg.delivery_status or ""
        if status in order and (cur not in order or order.index(status) >= order.index(cur)):
            msg.delivery_status = status
        if status in ("failed", "undelivered"):
            msg.meta = {**msg.meta, "error_code": form.get("ErrorCode")}
            emit_event(
                db,
                msg.organization_id,
                "sms.failed",
                channel="sms",
                conversation_id=msg.conversation_id,
                data={"status": status, "code": form.get("ErrorCode")},
            )
            if form.get("ErrorCode") == "21610":  # recipient has replied STOP at the carrier
                conv = db.get(Conversation, msg.conversation_id)
                if conv and conv.customer_id:
                    c = db.get(Customer, conv.customer_id)
                    if c and not c.sms_opted_out:
                        crm.opt_out(db, c, "carrier_blocked_21610")
    db.commit()
    return Response(status_code=204)


# ------------------------------------------------------------------ voice
#
# Two ways of hearing the caller, chosen per call language:
#   * Twilio speech recognition: every turn is a <Gather input="speech" language="…"> (default; no extra servers).
#   * VibeVoice-ASR-Streaming (VOICE_ASR_PROVIDER=vibevoice, languages in i18n.VIBEVOICE_LANGS): the call's audio is
#     forked to /api/v1/voice/stream (<Start><Stream>), recognized by the self-hosted model, and replies are pushed by
#     updating the live call. Callers can interrupt the agent (barge-in).


def _gather_url(conv_id: uuid.UUID) -> str:
    return f"{get_settings().public_api_url}/api/v1/webhooks/voice/gather?conversation_id={conv_id}"


def _keepalive_url(conv_id: uuid.UUID) -> str:
    return f"{get_settings().public_api_url}/api/v1/webhooks/voice/keepalive?conversation_id={conv_id}"


def _language_url(conv_id: uuid.UUID) -> str:
    return f"{get_settings().public_api_url}/api/v1/webhooks/voice/language?conversation_id={conv_id}"


def stream_ws_url() -> str:
    base = get_settings().public_api_url.rstrip("/")
    return base.replace("https://", "wss://", 1).replace("http://", "ws://", 1) + "/api/v1/voice/stream"


def stream_token(conv_id: uuid.UUID | str, call_sid: str) -> str:
    return sign(f"{conv_id}:{call_sid}", "voice-stream")


def streaming_asr_for(language: str) -> bool:
    provider = get_asr_provider()
    return provider is not None and provider.supports(language)


def call_language(conv: Conversation, agent: AIAgent) -> str:
    return conv.language or (conv.state or {}).get("lang") or agent.language or "en"


def listen_twiml(conv: Conversation, agent: AIAgent, text: str, *, record: bool = False, first: bool = False) -> str:
    """Speak ``text`` in the call language, then listen for the caller using the configured recognizer."""
    voice = get_voice_provider()
    lang = call_language(conv, agent)
    if streaming_asr_for(lang) and not (conv.state or {}).get("asr_fallback"):
        if first:
            params = {"conversation_id": str(conv.id), "token": stream_token(conv.id, conv.external_id or "")}
            return voice.say_and_stream(text, stream_ws_url(), params, _keepalive_url(conv.id), voice=agent.voice, language=lang, record=record)
        return voice.say_and_wait(text, _keepalive_url(conv.id), voice=agent.voice, language=lang)
    return voice.say_and_gather(text, _gather_url(conv.id), voice=agent.voice, language=lang, record=record)


def _greet(db: Session, org: Organization, agent: AIAgent, conv: Conversation, call: Call | None) -> str:
    lang = call_language(conv, agent)
    text = i18n.t("voice_disclosure", lang, org=org.name, agent=agent.name)
    if call and call.recording_enabled:
        text += i18n.t("voice_recorded", lang)
    text += i18n.t("voice_how_help", lang)
    if not db.scalar(select(Message.id).where(Message.conversation_id == conv.id, Message.role == "ai")):
        db.add(Message(organization_id=org.id, conversation_id=conv.id, role="ai", content=text, meta={"greeting": True, "language": lang}))
    if call is not None:
        call.language = lang
        call.asr_provider = "vibevoice" if streaming_asr_for(lang) and not (conv.state or {}).get("asr_fallback") else "twilio"
    return listen_twiml(conv, agent, text, record=bool(call and call.recording_enabled), first=True)


@router.post("/voice/incoming")
async def voice_incoming(request: Request, db: Session = Depends(get_db)) -> Response:
    voice = get_voice_provider()
    form = await _verified_form(request, voice)
    call_sid, frm, to = form.get("CallSid", ""), form.get("From", ""), form.get("To", "")
    number = _number(db, to)
    if number is None:
        return _twiml(voice.hangup("Sorry, this number is not in service.", voice=None, language="en"))
    org = db.get(Organization, number.organization_id)
    agent = db.get(AIAgent, number.agent_id) if number.agent_id else None
    from app.models import BusinessProfile

    profile = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == number.organization_id))
    fallback = (profile.escalation_phone or profile.phone) if profile else None
    usable = (
        org is not None
        and org.deleted_at is None
        and agent is not None
        and agent.status == "active"
        and number.voice_enabled
        and billing.has_feature(db, org, "voice")
        and billing.within_limit(db, org, "voice_minutes", 1)
        and "answer_calls" in (agent.capabilities or [])
    )
    if not usable:
        if fallback:
            return _twiml(voice.transfer(f"Thanks for calling {org.name if org else 'us'}. Connecting you now.", fallback, voice=None, language="en"))
        return _twiml(voice.hangup("Thanks for calling. We're unable to take your call right now. Please try again later.", voice=None, language="en"))
    assert org is not None and agent is not None
    existing = db.scalar(select(Call).where(Call.provider_call_id == call_sid))
    if existing is not None:
        conv = db.get(Conversation, existing.conversation_id)
        assert conv is not None
    else:
        phone = normalize_phone(frm)
        customer = crm.find_or_create_customer(db, org.id, phone=phone) if phone else None
        conv = start_conversation(db, org, agent, "voice", contact=phone, external_id=call_sid, customer=customer, greet=False)
        rec = bool(((org.settings or {}).get("recording") or {}).get("enabled")) and bool(
            ((org.settings or {}).get("recording") or {}).get("consent_configured")
        )
        db.add(
            Call(
                organization_id=org.id,
                conversation_id=conv.id,
                provider=voice.name,
                provider_call_id=call_sid,
                from_number=frm,
                to_number=to,
                status="in-progress",
                answered=True,
                recording_enabled=rec,
            )
        )
        emit_event(db, org.id, "call.answered", channel="voice", conversation_id=conv.id, agent_id=agent.id)
    call = db.scalar(select(Call).where(Call.provider_call_id == call_sid))
    languages = [x for x in (agent.languages or [agent.language or "en"]) if x in i18n.LANGS][:9]
    if len(languages) > 1 and not conv.language:
        # Press-a-digit language menu; each option is announced in its own language.
        primary = languages[0]
        intro = i18n.t("voice_disclosure", primary, org=org.name, agent=agent.name)
        options = [(code, i18n.t("voice_menu", code, n=i + 1)) for i, code in enumerate(languages)]
        db.commit()
        return _twiml(voice.language_menu(intro, options, _language_url(conv.id), voice=agent.voice, language=primary))
    twiml = _greet(db, org, agent, conv, call)
    db.commit()
    return _twiml(twiml)


@router.post("/voice/language")
async def voice_language(request: Request, conversation_id: uuid.UUID, db: Session = Depends(get_db)) -> Response:
    voice = get_voice_provider()
    form = await _verified_form(request, voice)
    conv = db.scalar(select(Conversation).where(Conversation.id == conversation_id, Conversation.channel == "voice").with_for_update())
    if conv is None or conv.external_id != form.get("CallSid"):
        return _twiml(voice.hangup("Sorry, something went wrong. Please call back.", voice=None, language="en"))
    org = db.get(Organization, conv.organization_id)
    agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
    assert org is not None and agent is not None
    languages = [x for x in (agent.languages or [agent.language or "en"]) if x in i18n.LANGS][:9]
    digits = (form.get("Digits") or "").strip()
    lang = languages[int(digits) - 1] if digits.isdigit() and 1 <= int(digits) <= len(languages) else languages[0]
    conv.language = lang
    conv.state = {**(conv.state or {}), "lang": lang}
    call = db.scalar(select(Call).where(Call.conversation_id == conv.id))
    emit_event(db, org.id, "call.language_selected", channel="voice", conversation_id=conv.id, data={"language": lang, "digits": digits or None})
    twiml = _greet(db, org, agent, conv, call)
    db.commit()
    return _twiml(twiml)


@router.post("/voice/keepalive")
async def voice_keepalive(request: Request, conversation_id: uuid.UUID, db: Session = Depends(get_db)) -> Response:
    """Streaming mode holds the line with <Pause>; each 20 s pause without a caller utterance lands here."""
    voice = get_voice_provider()
    form = await _verified_form(request, voice)
    conv = db.scalar(select(Conversation).where(Conversation.id == conversation_id, Conversation.channel == "voice").with_for_update())
    if conv is None or conv.external_id != form.get("CallSid"):
        return _twiml(voice.hangup("Sorry, something went wrong. Please call back.", voice=None, language="en"))
    org = db.get(Organization, conv.organization_id)
    agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
    assert org is not None and agent is not None
    lang = call_language(conv, agent)
    st = dict(conv.state or {})
    st["idle"] = int(st.get("idle", 0)) + 1
    conv.state = st
    if st["idle"] >= 3:
        _missed_call_followup(db, org, conv, "caller_silent")
        db.commit()
        return _twiml(voice.hangup(i18n.t("voice_silence_bye", lang), voice=agent.voice, language=lang))
    text = i18n.t("voice_silence", lang) if st["idle"] == 2 else ""
    db.commit()
    return _twiml(voice.say_and_wait(text, _keepalive_url(conv.id), voice=agent.voice, language=lang))


@router.post("/voice/gather")
async def voice_gather(request: Request, conversation_id: uuid.UUID, db: Session = Depends(get_db)) -> Response:
    voice = get_voice_provider()
    form = await _verified_form(request, voice)
    conv = db.scalar(select(Conversation).where(Conversation.id == conversation_id, Conversation.channel == "voice").with_for_update())
    if conv is None or conv.external_id != form.get("CallSid"):
        return _twiml(voice.hangup("Sorry, something went wrong. Please call back.", voice=None, language="en"))
    speech = (form.get("SpeechResult") or "").strip()
    confidence = float(form.get("Confidence") or 0) if form.get("Confidence") else (1.0 if speech else 0.0)
    twiml, _ = run_voice_turn(db, conv, speech, confidence)
    db.commit()
    return _twiml(twiml)


def _spoken(twiml: str) -> tuple[str, str]:
    """(TwiML, the text it speaks) — the media-stream loop uses the text length to know when the agent stops talking."""
    import re as _re
    from xml.sax.saxutils import unescape

    return twiml, unescape(" ".join(_re.findall(r"<Say[^>]*>(.*?)</Say>", twiml, flags=_re.S)))


def run_voice_turn(db: Session, conv: Conversation, speech: str, confidence: float, *, streamed: bool = False) -> tuple[str, str]:
    """One caller turn (from Twilio <Gather> or from the VibeVoice media stream) -> TwiML for what happens next."""
    voice = get_voice_provider()
    org = db.get(Organization, conv.organization_id)
    agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
    assert org is not None and agent is not None
    lang = call_language(conv, agent)
    st = dict(conv.state or {})
    st["idle"] = 0
    if not speech and not streamed:
        st["silence"] = int(st.get("silence", 0)) + 1
        conv.state = st
        if st["silence"] >= 2:
            _missed_call_followup(db, org, conv, "caller_silent")
            return _spoken(voice.hangup(i18n.t("voice_silence_bye", lang), voice=agent.voice, language=lang))
        return _spoken(listen_twiml(conv, agent, i18n.t("voice_silence", lang)))
    st["silence"] = 0
    if not speech or confidence < 0.35:
        st["unclear"] = int(st.get("unclear", 0)) + 1
        conv.state = st
        if st["unclear"] >= 3:
            _missed_call_followup(db, org, conv, "unclear_audio")
            fb = _fallback_number(db, org)
            if fb and "transfer_calls" in (agent.capabilities or []):
                return _spoken(voice.transfer(i18n.t("voice_unclear_transfer", lang), fb, voice=agent.voice, language=lang))
            return _spoken(voice.hangup(i18n.t("voice_unclear_bye", lang), voice=agent.voice, language=lang))
        return _spoken(listen_twiml(conv, agent, i18n.t("voice_unclear", lang)))
    conv.state = {**st, "unclear": 0}
    _, result, reply = process_customer_message(db, org, agent, conv, speech)
    if reply is not None:
        reply.meta = {**(reply.meta or {}), "asr": "vibevoice" if streamed else "twilio"}
    lang = call_language(conv, agent)  # the caller may have switched language mid-call
    call = db.scalar(select(Call).where(Call.conversation_id == conv.id))
    text = result.reply or i18n.t("anything_else", lang)
    if result.transfer_to:
        if call:
            call.transferred_to = result.transfer_to
        return _spoken(voice.transfer(text, result.transfer_to, voice=agent.voice, language=lang))
    if result.handoff or conv.handoff_active:
        return _spoken(voice.hangup(text + i18n.t("voice_thanks_bye", lang), voice=agent.voice, language=lang))
    if (conv.state or {}).get("stage") == "booked" and _is_goodbye(speech):
        return _spoken(voice.hangup(i18n.t("voice_goodbye", lang, org=org.name), voice=agent.voice, language=lang))
    return _spoken(listen_twiml(conv, agent, text))


_GOODBYES = (
    "no that's it",
    "that's all",
    "that is all",
    "nothing else",
    "goodbye",
    "bye",
    "no thanks",
    "no thank you",
    "that's everything",
    "eso es todo",
    "nada más",
    "adiós",
    "adios",
    "没有了",
    "就这样",
    "再见",
    "wala na",
    "yun lang",
    "paalam",
    "không còn gì",
    "vậy thôi",
    "tạm biệt",
    "لا شيء آخر",
    "هذا كل شيء",
    "مع السلامة",
    "c'est tout",
    "rien d'autre",
    "au revoir",
)


def _is_goodbye(s: str) -> bool:
    low = s.lower()
    return any(w in low for w in _GOODBYES)


def _fallback_number(db: Session, org: Organization) -> str | None:
    from app.models import BusinessProfile

    p = db.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == org.id))
    return (p.escalation_phone or p.phone) if p else None


def _missed_call_followup(db: Session, org: Organization, conv: Conversation, reason: str) -> None:
    """Calls that end before a lead is captured still produce a callback task + unqualified lead (missed-call recovery)."""
    if conv.lead_id or not conv.contact_address:
        return
    customer = crm.find_or_create_customer(db, org.id, phone=conv.contact_address)
    conv.customer_id = customer.id
    lead, _ = crm.create_or_update_lead(
        db,
        org,
        customer=customer,
        conversation=conv,
        agent=db.get(AIAgent, conv.agent_id) if conv.agent_id else None,
        source="ai_phone",
        channel="voice",
        service=None,
        qualification={"call_outcome": reason},
        qualified=False,
        urgency=None,
        summary=f"Call ended before details were collected ({reason.replace('_', ' ')}). Call back.",
    )
    from app.models import Task

    db.add(
        Task(
            organization_id=org.id,
            kind="follow_up",
            title=f"Call back {conv.contact_address}",
            description=f"Call ended early: {reason.replace('_', ' ')}",
            conversation_id=conv.id,
            lead_id=lead.id,
            customer_id=customer.id,
            priority="high",
            due_at=utcnow() + timedelta(minutes=30),
        )
    )


@router.post("/voice/status")
async def voice_status(request: Request, db: Session = Depends(get_db)) -> Response:
    form = await _verified_form(request, get_voice_provider())
    call = db.scalar(select(Call).where(Call.provider_call_id == form.get("CallSid", "")).with_for_update())
    if call is None:
        return Response(status_code=204)
    status = form.get("CallStatus", "")
    call.status = status or call.status
    if status in ("completed", "busy", "failed", "no-answer", "canceled"):
        first_time = call.ended_at is None
        call.ended_at = call.ended_at or utcnow()
        call.duration_seconds = int(form.get("CallDuration") or 0)
        conv = db.get(Conversation, call.conversation_id)
        org = db.get(Organization, call.organization_id)
        if first_time and org and conv:
            if call.duration_seconds:
                billing.record_usage(
                    db,
                    org.id,
                    "voice_minutes",
                    max(1, (call.duration_seconds + 59) // 60),
                    provider=call.provider,
                    channel="voice",
                    conversation_id=conv.id,
                    agent_id=conv.agent_id,
                )
            if status != "completed":
                call.answered = False
                emit_event(db, org.id, "call.abandoned", channel="voice", conversation_id=conv.id)
            if not conv.lead_id and not conv.handoff_active:
                _missed_call_followup(db, org, conv, "caller_hung_up_early")
            if conv.status != "needs_human":
                conv.status = "resolved"
            emit_event(db, org.id, "call.completed", channel="voice", conversation_id=conv.id, data={"duration": call.duration_seconds})
    db.commit()
    return Response(status_code=204)
