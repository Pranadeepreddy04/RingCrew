"""Real-time voice sockets backed by a streaming ASR model (VibeVoice-ASR-Streaming).

* ``WS /api/v1/voice/stream`` — Twilio Media Streams (phone calls). Twilio forks the caller's 8 kHz μ-law audio here
  (``<Start><Stream>`` with a signed ``token`` parameter). Each caller utterance is recognized, the AI turn runs, and
  the reply is pushed by updating the live call's TwiML. Speaking while the agent talks interrupts it (barge-in).
* ``WS /api/v1/public/conversations/{id}/voice`` — browser voice for the website widget. The page streams microphone
  PCM; the server sends partial transcripts, the final transcript and the AI reply (which the browser speaks).
"""

from __future__ import annotations

import asyncio
import base64
import contextlib
import hmac
import json
import logging
import time
import uuid
from typing import Any

import numpy as np
from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from sqlalchemy import select

from app.ai import i18n
from app.ai.orchestrator import process_customer_message
from app.db import SessionLocal
from app.models import AIAgent, Conversation, Organization, Service
from app.observability import metrics
from app.providers.asr import get_asr_provider
from app.providers.messaging import get_voice_provider
from app.ratelimit import hit
from app.routers import voice_sms
from app.security import verify_signature
from app.services.serializers import public_message_out
from app.voice.engine import StreamingRecognizer, mulaw_decode, pcm16_to_float

log = logging.getLogger(__name__)
router = APIRouter(include_in_schema=False)

MAX_SESSION_SECONDS = 15 * 60
SPEECH_CHARS_PER_SECOND = 14.0  # rough TTS pace, used to know when the agent has stopped talking (barge-in window)


def _hotwords(db: Any, org: Organization, agent: AIAgent) -> str:
    names = [org.name, agent.name] + [s.name for s in db.scalars(select(Service).where(Service.organization_id == org.id, Service.active.is_(True))).all()]
    return ", ".join(dict.fromkeys(n for n in names if n))[:400]


# ------------------------------------------------------------------ phone (Twilio Media Streams)


class PhoneCallSession:
    def __init__(self, conv_id: uuid.UUID, call_sid: str) -> None:
        self.conv_id = conv_id
        self.call_sid = call_sid
        self.speaking_until = 0.0
        self.voice = get_voice_provider()
        self.fell_back = False

    async def on_speech_start(self) -> None:
        if time.monotonic() < self.speaking_until:
            # Barge-in: the caller started talking over the agent — cut the agent's speech and listen.
            self.speaking_until = 0.0
            metrics.inc("voice_barge_in_total")
            await asyncio.to_thread(self._update, None)

    async def on_final(self, text: str) -> None:
        twiml, reply = await asyncio.to_thread(self._turn, text)
        if twiml:
            await asyncio.to_thread(self.voice.update_call, self.call_sid, twiml)
            self.speaking_until = time.monotonic() + len(reply or "") / SPEECH_CHARS_PER_SECOND

    async def on_error(self, code: str) -> None:
        # The ASR server is unreachable: switch the rest of this call to Twilio's own speech recognition.
        if self.fell_back:
            return
        self.fell_back = True
        metrics.inc("voice_asr_fallback_total")
        await asyncio.to_thread(self._fallback)

    def _update(self, text: str | None) -> None:
        with SessionLocal() as db:
            conv = db.get(Conversation, self.conv_id)
            agent = db.get(AIAgent, conv.agent_id) if conv and conv.agent_id else None
            if conv is None or agent is None:
                return
            twiml = self.voice.say_and_wait(text or "", voice_sms._keepalive_url(conv.id), voice=agent.voice, language=voice_sms.call_language(conv, agent))
        self.voice.update_call(self.call_sid, twiml)

    def _turn(self, text: str) -> tuple[str | None, str | None]:
        with SessionLocal() as db:
            conv = db.scalar(select(Conversation).where(Conversation.id == self.conv_id).with_for_update())
            if conv is None or conv.status == "resolved":
                return None, None
            twiml, spoken = voice_sms.run_voice_turn(db, conv, text.strip(), 1.0 if text.strip() else 0.0, streamed=True)
            db.commit()
            return twiml, spoken

    def _fallback(self) -> None:
        with SessionLocal() as db:
            conv = db.scalar(select(Conversation).where(Conversation.id == self.conv_id).with_for_update())
            agent = db.get(AIAgent, conv.agent_id) if conv and conv.agent_id else None
            if conv is None or agent is None:
                return
            conv.state = {**(conv.state or {}), "asr_fallback": True}
            lang = voice_sms.call_language(conv, agent)
            twiml = voice_sms.listen_twiml(conv, agent, i18n.t("voice_unclear", lang))
            db.commit()
        self.voice.update_call(self.call_sid, twiml)


@router.websocket("/voice/stream")
async def twilio_media_stream(ws: WebSocket) -> None:
    await ws.accept()
    rec: StreamingRecognizer | None = None
    started = time.monotonic()
    try:
        while time.monotonic() - started < MAX_SESSION_SECONDS:
            raw = await ws.receive_text()
            ev = json.loads(raw)
            kind = ev.get("event")
            if kind == "start":
                start = ev.get("start") or {}
                params = start.get("customParameters") or {}
                call_sid = str(start.get("callSid") or "")
                try:
                    conv_id = uuid.UUID(str(params.get("conversation_id")))
                except ValueError:
                    await ws.close(code=1008)
                    return
                if not verify_signature(f"{conv_id}:{call_sid}", str(params.get("token") or ""), "voice-stream"):
                    metrics.inc("webhook_signature_failures_total", provider="voice-stream")
                    await ws.close(code=1008)
                    return
                ctx = await asyncio.to_thread(_phone_context, conv_id, call_sid)
                if ctx is None:
                    await ws.close(code=1008)
                    return
                language, hotwords, silence_ms = ctx
                provider = get_asr_provider()
                if provider is None:
                    await ws.close(code=1011)
                    return
                session = PhoneCallSession(conv_id, call_sid)
                rec = StreamingRecognizer(
                    provider,
                    sample_rate=8000,
                    language=language,
                    hotwords=hotwords,
                    silence_ms=silence_ms,
                    on_speech_start=session.on_speech_start,
                    on_final=session.on_final,
                    on_error=session.on_error,
                )
            elif kind == "media" and rec is not None:
                media = ev.get("media") or {}
                if media.get("track", "inbound") == "inbound" and media.get("payload"):
                    await rec.feed(mulaw_decode(base64.b64decode(media["payload"])))
            elif kind == "stop":
                if rec is not None:
                    await rec.end_of_speech()
                break
    except WebSocketDisconnect:
        return
    except Exception:
        log.exception("media stream failed")
    with contextlib.suppress(Exception):
        await ws.close()


def _phone_context(conv_id: uuid.UUID, call_sid: str) -> tuple[str, str, int] | None:
    from app.config import get_settings

    with SessionLocal() as db:
        conv = db.get(Conversation, conv_id)
        if conv is None or conv.channel != "voice" or conv.external_id != call_sid:
            return None
        org = db.get(Organization, conv.organization_id)
        agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
        if org is None or agent is None:
            return None
        return voice_sms.call_language(conv, agent), _hotwords(db, org, agent), get_settings().voice_endpoint_silence_ms


# ------------------------------------------------------------------ browser voice (website widget)


@router.websocket("/public/conversations/{conversation_id}/voice")
async def browser_voice(ws: WebSocket, conversation_id: uuid.UUID) -> None:
    """Protocol (JSON text frames unless noted):
    client -> {"type": "start", "visitor_token": "…", "sample_rate": 16000, "format": "f32"|"s16", "language": "es"?}
    client -> binary audio frames (mono, little-endian) | {"type": "stop"} to end the utterance (push-to-talk release)
    server -> {"type": "ready", "language", "asr"} | {"type": "unavailable", "reason"} (use the browser's own recognizer)
    server -> {"type": "speech_start"} | {"type": "partial", "text"} | {"type": "final", "text"}
    server -> {"type": "reply", "messages": [...], "language", "handoff"} | {"type": "error", "code"}
    """
    await ws.accept()
    ip = ws.client.host if ws.client else "unknown"
    if not hit(f"widget-voice:{ip}", 20, 60):
        await ws.send_json({"type": "error", "code": "rate_limited"})
        await ws.close(code=1008)
        return
    try:
        first = await asyncio.wait_for(ws.receive_json(), timeout=10)
    except Exception:
        with contextlib.suppress(Exception):
            await ws.close(code=1008)
        return
    from app.routers.public import _visitor_token

    token = str(first.get("visitor_token") or "")
    if first.get("type") != "start" or not token or not hmac.compare_digest(token, _visitor_token(conversation_id)):
        await ws.send_json({"type": "error", "code": "unauthorized"})
        await ws.close(code=1008)
        return
    sr = int(first.get("sample_rate") or 16000)
    fmt = "s16" if first.get("format") == "s16" else "f32"
    if not 8000 <= sr <= 48000:
        await ws.send_json({"type": "error", "code": "bad_sample_rate"})
        await ws.close(code=1008)
        return
    info = await asyncio.to_thread(_browser_context, conversation_id)
    if info is None:
        await ws.send_json({"type": "error", "code": "not_found"})
        await ws.close(code=1008)
        return
    language, hotwords, allowed = info
    if first.get("language") in allowed:
        language = str(first["language"])
    provider = get_asr_provider()
    if provider is None or not provider.supports(language):
        await ws.send_json({"type": "unavailable", "reason": "no_streaming_asr" if provider is None else "language_not_supported", "language": language})
        await ws.close()
        return

    send_lock = asyncio.Lock()

    async def send(obj: dict[str, Any]) -> None:
        async with send_lock:
            with contextlib.suppress(Exception):
                await ws.send_json(obj)

    async def on_speech_start() -> None:
        await send({"type": "speech_start"})

    async def on_partial(text: str) -> None:
        await send({"type": "partial", "text": text})

    async def on_error(code: str) -> None:
        await send({"type": "error", "code": code})

    async def on_final(text: str) -> None:
        await send({"type": "final", "text": text})
        if not text.strip():
            return
        out = await asyncio.to_thread(_browser_turn, conversation_id, text)
        if out is not None:
            await send({"type": "reply", **out})
            if out.get("language") and provider.supports(out["language"]):
                rec.language = out["language"]

    rec = StreamingRecognizer(
        provider,
        sample_rate=sr,
        language=language,
        hotwords=hotwords,
        on_speech_start=on_speech_start,
        on_partial=on_partial,
        on_final=on_final,
        on_error=on_error,
    )
    await send({"type": "ready", "language": language, "asr": provider.name})
    started = time.monotonic()
    try:
        while time.monotonic() - started < MAX_SESSION_SECONDS:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break
            if msg.get("bytes") is not None:
                data: bytes = msg["bytes"]
                if len(data) > 256_000:
                    continue
                pcm = pcm16_to_float(data) if fmt == "s16" else np.frombuffer(data[: len(data) // 4 * 4], dtype="<f4")
                await rec.feed(pcm)
            elif msg.get("text"):
                cmd = json.loads(msg["text"])
                if cmd.get("type") == "stop":
                    await rec.end_of_speech()
                elif cmd.get("type") == "close":
                    break
    except WebSocketDisconnect:
        return
    except Exception:
        log.exception("browser voice failed")
    with contextlib.suppress(Exception):
        await ws.close()


def _browser_context(conversation_id: uuid.UUID) -> tuple[str, str, list[str]] | None:
    with SessionLocal() as db:
        conv = db.get(Conversation, conversation_id)
        if conv is None or conv.channel != "web":
            return None
        org = db.get(Organization, conv.organization_id)
        agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
        if org is None or agent is None or agent.deleted_at is not None:
            return None
        allowed = list(agent.languages or [agent.language or "en"])
        return conv.language or agent.language or "en", _hotwords(db, org, agent), allowed


def _browser_turn(conversation_id: uuid.UUID, text: str) -> dict[str, Any] | None:
    with SessionLocal() as db:
        conv = db.scalar(select(Conversation).where(Conversation.id == conversation_id).with_for_update())
        if conv is None:
            return None
        org = db.get(Organization, conv.organization_id)
        agent = db.get(AIAgent, conv.agent_id) if conv.agent_id else None
        if org is None or agent is None:
            return None
        cmsg, result, reply = process_customer_message(db, org, agent, conv, text[:2000])
        cmsg.meta = {**(cmsg.meta or {}), "input": "voice", "asr": "vibevoice"}
        db.commit()
        return {
            "messages": [public_message_out(reply)] if reply else [],
            "language": conv.language or agent.language or "en",
            "handoff": bool(result.handoff or conv.handoff_active),
            "customer_message_id": str(cmsg.id),
        }
