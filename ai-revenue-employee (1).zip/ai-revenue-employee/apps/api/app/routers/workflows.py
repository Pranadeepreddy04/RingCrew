"""Follow-up workflow configuration (spec §31)."""

from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.db import get_db
from app.deps import OrgContext, require
from app.errors import AppError, not_found
from app.models import Customer, Workflow, WorkflowRun
from app.services import billing
from app.services.automation import STOP_CONDITIONS, TEMPLATE_VARS, TRIGGERS, validate_workflow
from app.services.common import audit

router = APIRouter(prefix="/workflows", tags=["workflows"])


def _out(w: Workflow, stats: dict[str, int] | None = None) -> dict[str, Any]:
    return {
        "id": str(w.id),
        "name": w.name,
        "trigger": w.trigger,
        "steps": w.steps,
        "stop_conditions": w.stop_conditions,
        "quiet_hours": w.quiet_hours,
        "max_attempts": w.max_attempts,
        "active": w.active,
        "stats": stats or {},
    }


@router.get("")
def list_workflows(ctx: OrgContext = Depends(require("leads.read")), db: Session = Depends(get_db)) -> dict[str, Any]:
    rows = db.scalars(select(Workflow).where(Workflow.organization_id == ctx.org_id).order_by(Workflow.created_at)).all()
    stats: dict[uuid.UUID, dict[str, int]] = {}
    for wid, status, n in db.execute(
        select(WorkflowRun.workflow_id, WorkflowRun.status, func.count())
        .where(WorkflowRun.organization_id == ctx.org_id)
        .group_by(WorkflowRun.workflow_id, WorkflowRun.status)
    ).all():
        stats.setdefault(wid, {})[status] = int(n)
    return {
        "items": [_out(w, stats.get(w.id)) for w in rows],
        "triggers": sorted(TRIGGERS),
        "stop_conditions": sorted(STOP_CONDITIONS),
        "template_variables": sorted(TEMPLATE_VARS),
        "sms_enabled_on_plan": billing.has_feature(db, ctx.org, "sms"),
    }


class WorkflowIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    trigger: str
    steps: list[dict[str, Any]]
    stop_conditions: list[str] = Field(default_factory=list)
    quiet_hours: dict[str, Any] = Field(default_factory=dict)
    max_attempts: int = Field(default=3, ge=1, le=10)
    active: bool = True


def _validate(body: WorkflowIn) -> None:
    errs = validate_workflow(body.trigger, body.steps, body.stop_conditions, body.quiet_hours)
    if errs:
        raise AppError(422, "invalid_workflow", "Workflow is invalid", details=errs)


@router.post("", status_code=201)
def create(body: WorkflowIn, ctx: OrgContext = Depends(require("workflows.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    _validate(body)
    if body.active and len(body.steps) > 3 and not billing.has_feature(db, ctx.org, "advanced_workflows"):
        raise AppError(402, "plan_required", "Workflows with more than 3 steps require the Pro plan")
    w = Workflow(organization_id=ctx.org_id, **body.model_dump())
    db.add(w)
    db.flush()
    audit(db, "workflow.created", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="workflow", target_id=w.id)
    db.commit()
    return _out(w)


def _get(db: Session, ctx: OrgContext, wid: uuid.UUID) -> Workflow:
    w = db.scalar(select(Workflow).where(Workflow.id == wid, Workflow.organization_id == ctx.org_id))
    if w is None:
        raise not_found("Workflow")
    return w


@router.put("/{workflow_id}")
def update(workflow_id: uuid.UUID, body: WorkflowIn, ctx: OrgContext = Depends(require("workflows.manage")), db: Session = Depends(get_db)) -> dict[str, Any]:
    _validate(body)
    w = _get(db, ctx, workflow_id)
    if body.active and len(body.steps) > 3 and not billing.has_feature(db, ctx.org, "advanced_workflows"):
        raise AppError(402, "plan_required", "Workflows with more than 3 steps require the Pro plan")
    for k, v in body.model_dump().items():
        setattr(w, k, v)
    if not w.active:
        for r in db.scalars(select(WorkflowRun).where(WorkflowRun.workflow_id == w.id, WorkflowRun.status == "active")).all():
            r.status, r.stop_reason, r.next_run_at = "stopped", "workflow_disabled", None
    audit(db, "workflow.updated", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="workflow", target_id=w.id)
    db.commit()
    return _out(w)


@router.delete("/{workflow_id}")
def delete(workflow_id: uuid.UUID, ctx: OrgContext = Depends(require("workflows.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    w = _get(db, ctx, workflow_id)
    db.delete(w)
    audit(db, "workflow.deleted", org_id=ctx.org_id, actor_user_id=ctx.user.id, target_type="workflow", target_id=workflow_id)
    db.commit()
    return {"ok": True}


@router.get("/{workflow_id}/runs")
def runs(workflow_id: uuid.UUID, ctx: OrgContext = Depends(require("leads.read")), db: Session = Depends(get_db)) -> list[dict[str, Any]]:
    w = _get(db, ctx, workflow_id)
    rows = db.execute(
        select(WorkflowRun, Customer)
        .join(Customer, Customer.id == WorkflowRun.customer_id)
        .where(WorkflowRun.workflow_id == w.id, WorkflowRun.organization_id == ctx.org_id)
        .order_by(WorkflowRun.created_at.desc())
        .limit(100)
    ).all()
    return [
        {
            "id": str(r.id),
            "customer": c.name or c.phone,
            "status": r.status,
            "step_index": r.step_index,
            "attempts": r.attempts,
            "next_run_at": r.next_run_at.isoformat() if r.next_run_at else None,
            "stop_reason": r.stop_reason,
            "last_error": r.last_error,
            "lead_id": str(r.lead_id) if r.lead_id else None,
        }
        for r, c in rows
    ]


@router.post("/runs/{run_id}/stop")
def stop_run(run_id: uuid.UUID, ctx: OrgContext = Depends(require("workflows.manage")), db: Session = Depends(get_db)) -> dict[str, bool]:
    r = db.scalar(select(WorkflowRun).where(WorkflowRun.id == run_id, WorkflowRun.organization_id == ctx.org_id))
    if r is None:
        raise not_found("Workflow run")
    if r.status == "active":
        r.status, r.stop_reason, r.next_run_at = "stopped", "stopped_by_staff", None
    db.commit()
    return {"ok": True}
