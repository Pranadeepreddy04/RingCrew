"""Cryptographic helpers: password hashing, opaque tokens, encryption at rest, HMAC signing."""

from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
import time

import bcrypt
from cryptography.fernet import Fernet, InvalidToken

from app.config import get_settings


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode()[:72], bcrypt.gensalt(rounds=12)).decode()


def verify_password(password: str, password_hash: str | None) -> bool:
    if not password_hash:
        return False
    try:
        return bcrypt.checkpw(password.encode()[:72], password_hash.encode())
    except ValueError:
        return False


# Constant-time dummy check to reduce user-enumeration timing differences.
_DUMMY_HASH = bcrypt.hashpw(b"dummy-password", bcrypt.gensalt(rounds=12)).decode()


def dummy_verify() -> None:
    verify_password("not-the-password", _DUMMY_HASH)


def new_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _fernet() -> Fernet:
    s = get_settings()
    key = s.encryption_key
    if not key:
        # Development/test only: derive a stable key from SECRET_KEY. Production requires ENCRYPTION_KEY
        # (enforced in config validation).
        key = base64.urlsafe_b64encode(hashlib.sha256(("enc:" + s.secret_key).encode()).digest()).decode()
    return Fernet(key.encode())


def encrypt(plaintext: str) -> str:
    return _fernet().encrypt(plaintext.encode()).decode()


def decrypt(ciphertext: str) -> str:
    try:
        return _fernet().decrypt(ciphertext.encode()).decode()
    except InvalidToken as exc:  # key rotated or corrupted
        raise ValueError("Unable to decrypt stored credential") from exc


def sign(value: str, purpose: str) -> str:
    key = (get_settings().secret_key + ":" + purpose).encode()
    return hmac.new(key, value.encode(), hashlib.sha256).hexdigest()


def verify_signature(value: str, signature: str, purpose: str) -> bool:
    return hmac.compare_digest(sign(value, purpose), signature)


def signed_expiring(value: str, purpose: str, ttl_seconds: int) -> str:
    exp = int(time.time()) + ttl_seconds
    payload = f"{value}.{exp}"
    return f"{payload}.{sign(payload, purpose)}"


def verify_expiring(token: str, purpose: str) -> str | None:
    try:
        value, exp, sig = token.rsplit(".", 2)
    except ValueError:
        return None
    if not verify_signature(f"{value}.{exp}", sig, purpose):
        return None
    if int(exp) < int(time.time()):
        return None
    return value
