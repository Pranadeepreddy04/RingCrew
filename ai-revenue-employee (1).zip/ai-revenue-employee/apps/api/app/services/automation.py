"""Follow-up / reminder workflow engine (spec §31). Business-controlled triggers, delays, channel,
template, max attempts, quiet hours and stop conditions. Messages are rendered from approved
templates only — the AI never free-writes outbound follow-ups, so there are no AI messaging loops."""

from __future__ import annotations

import re
from datetime import datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import AIAgent, Appointment, Conversation, Customer, Lead, Message, Organization, Workflow, WorkflowRun
from app.services.common import emit_event, notify, utcnow

TRIGGERS = {"lead.created", "appointment.created", "appointment.completed"}
STOP_CONDITIONS = {"appointment_booked", "customer_replied", "opted_out", "lead_closed", "human_takeover", "appointment_cancelled"}
TEMPLATE_VARS = {"first_name", "name", "business_name", "agent_name", "service", "appointment_time"}
_VAR = re.compile(r"\{([a-z_]+)\}")


def validate_template(tpl: str) -> list[str]:
    return [v for v in _VAR.findall(tpl) if v not in TEMPLATE_VARS]


def render(tpl: str, ctx: dict[str, str]) -> str:
    return _VAR.sub(lambda m: ctx.get(m.group(1), ""), tpl).strip()


def in_quiet_hours(now_local: datetime, quiet: dict[str, Any]) -> bool:
    if not quiet or not quiet.get("start") or not quiet.get("end"):
        return False
    start, end, cur = time.fromisoformat(quiet["start"]), time.fromisoformat(quiet["end"]), now_local.time()
    return (start <= cur or cur < end) if start > end else (start <= cur < end)


def next_allowed(now_utc: datetime, tz: ZoneInfo, quiet: dict[str, Any]) -> datetime:
    local = now_utc.astimezone(tz)
    if not in_quiet_hours(local, quiet):
        return now_utc
    end = time.fromisoformat(quiet["end"])
    candidate = datetime.combine(local.date(), end, tzinfo=tz)
    if candidate <= local:
        candidate += timedelta(days=1)
    return candidate.astimezone(ZoneInfo("UTC"))


def _first_run_at(wf: Workflow, appointment: Appointment | None) -> datetime | None:
    if not wf.steps:
        return None
    step = wf.steps[0]
    if "before_appointment_minutes" in step:
        if appointment is None:
            return None
        at = appointment.start_at - timedelta(minutes=int(step["before_appointment_minutes"]))
        if at <= utcnow():
            # too late for the reminder window: only send if the appointment is still > 2h away
            return utcnow() if appointment.start_at - utcnow() > timedelta(hours=2) else None
        return at
    return utcnow() + timedelta(minutes=int(step.get("delay_minutes", 0)))


def start_workflows(
    db: Session, org: Organization, trigger: str, *, customer: Customer, lead: Lead | None = None, appointment: Appointment | None = None
) -> int:
    if org.is_demo:
        return 0
    n = 0
    for wf in db.scalars(select(Workflow).where(Workflow.organization_id == org.id, Workflow.trigger == trigger, Workflow.active.is_(True))).all():
        at = _first_run_at(wf, appointment)
        if at is None:
            continue
        exists = db.scalar(
            select(WorkflowRun.id).where(
                WorkflowRun.workflow_id == wf.id,
                WorkflowRun.lead_id == (lead.id if lead else None),
                WorkflowRun.appointment_id == (appointment.id if appointment else None),
            )
        )
        if exists:
            continue
        db.add(
            WorkflowRun(
                organization_id=org.id,
                workflow_id=wf.id,
                lead_id=lead.id if lead else None,
                appointment_id=appointment.id if appointment else None,
                customer_id=customer.id,
                next_run_at=at,
            )
        )
        n += 1
    return n


def _context(db: Session, org: Organization, run: WorkflowRun, customer: Customer) -> dict[str, str]:
    from app.services.scheduling import format_when

    lead = db.get(Lead, run.lead_id) if run.lead_id else None
    appt = db.get(Appointment, run.appointment_id) if run.appointment_id else None
    agent = (
        db.get(AIAgent, lead.agent_id)
        if lead and lead.agent_id
        else db.scalar(select(AIAgent).where(AIAgent.organization_id == org.id, AIAgent.status == "active").limit(1))
    )
    return {
        "first_name": (customer.name or "there").split(" ")[0],
        "name": customer.name or "there",
        "business_name": org.name,
        "agent_name": agent.name if agent else "the team",
        "service": (appt.service if appt else (lead.service if lead else None)) or "your request",
        "appointment_time": format_when(appt.start_at, ZoneInfo(org.timezone)) if appt else "",
    }


def _should_stop(db: Session, run: WorkflowRun, wf: Workflow, customer: Customer) -> str | None:
    conds = set(wf.stop_conditions or [])
    if customer.sms_opted_out:
        return "opted_out"
    lead = db.get(Lead, run.lead_id) if run.lead_id else None
    if lead is not None:
        if "lead_closed" in conds and lead.status in ("won", "lost"):
            return "lead_closed"
        if "appointment_booked" in conds and db.scalar(
            select(Appointment.id).where(Appointment.lead_id == lead.id, Appointment.status.in_(("scheduled", "confirmed", "completed")))
        ):
            return "appointment_booked"
        if "customer_replied" in conds:
            replied = db.scalar(
                select(Message.id)
                .join(Conversation, Conversation.id == Message.conversation_id)
                .where(
                    Conversation.organization_id == run.organization_id,
                    Conversation.customer_id == customer.id,
                    Message.role == "customer",
                    Message.created_at > run.created_at,
                )
                .limit(1)
            )
            if replied:
                return "customer_replied"
    if run.appointment_id:
        appt = db.get(Appointment, run.appointment_id)
        if appt is None or appt.status == "cancelled":
            return "appointment_cancelled"
    return None


def process_run(db: Session, run: WorkflowRun) -> str:
    """Execute the current step of one due run. Called by the worker with the row locked."""
    from app.services.crm import send_sms

    wf = db.get(Workflow, run.workflow_id)
    org = db.get(Organization, run.organization_id)
    customer = db.get(Customer, run.customer_id)
    if wf is None or org is None or customer is None or not wf.active or org.deleted_at is not None:
        run.status, run.stop_reason, run.next_run_at = "stopped", "workflow_inactive", None
        return "stopped"
    reason = _should_stop(db, run, wf, customer)
    if reason:
        run.status, run.stop_reason, run.next_run_at = "stopped", reason, None
        return "stopped"
    tz = ZoneInfo(org.timezone)
    allowed = next_allowed(utcnow(), tz, wf.quiet_hours or {})
    if allowed > utcnow():
        run.next_run_at = allowed
        return "deferred_quiet_hours"
    if run.attempts >= wf.max_attempts or run.step_index >= len(wf.steps):
        run.status, run.next_run_at = "completed", None
        return "completed"
    step = wf.steps[run.step_index]
    body = render(step.get("template", ""), _context(db, org, run, customer))
    purpose = "reminder" if "before_appointment_minutes" in step else "followup"
    result = send_sms(db, org, customer, body, purpose=purpose, idempotency_key=f"wfr:{run.id}:{run.step_index}")
    if not result.ok:
        if result.error in ("opted_out", "no_consent", "no_marketing_consent"):
            run.status, run.stop_reason, run.next_run_at = "stopped", result.error, None
            return "stopped"
        if result.retryable and run.retries < 5:
            # transient provider errors do not consume business attempts; bounded exponential backoff
            run.retries += 1
            run.last_error = result.error
            run.next_run_at = utcnow() + timedelta(minutes=5 * 2**run.retries)
            return "retry"
        run.status, run.last_error, run.next_run_at = "failed", result.error, None
        notify(db, org.id, "workflow.failed", f"Follow-up could not be sent to {customer.name or customer.phone}", result.error, "/app/workflows")
        return "failed"
    run.attempts += 1
    run.step_index += 1
    if run.lead_id:
        lead = db.get(Lead, run.lead_id)
        if lead:
            lead.last_activity_at = utcnow()
            if lead.status == "new":
                lead.status = "contacted"
    emit_event(db, org.id, "followup.sent", channel="sms", lead_id=run.lead_id, data={"workflow_id": str(wf.id), "step": run.step_index})
    if run.step_index >= len(wf.steps) or run.attempts >= wf.max_attempts:
        run.status, run.next_run_at = "completed", None
        return "sent_completed"
    nxt = wf.steps[run.step_index]
    if "before_appointment_minutes" in nxt and run.appointment_id:
        appt = db.get(Appointment, run.appointment_id)
        run.next_run_at = appt.start_at - timedelta(minutes=int(nxt["before_appointment_minutes"])) if appt else None
    else:
        run.next_run_at = utcnow() + timedelta(minutes=int(nxt.get("delay_minutes", 60)))
    if run.lead_id:
        lead = db.get(Lead, run.lead_id)
        if lead:
            lead.next_follow_up_at = run.next_run_at
    return "sent"


def validate_workflow(trigger: str, steps: list[dict[str, Any]], stop_conditions: list[str], quiet_hours: dict[str, Any]) -> list[str]:
    errs: list[str] = []
    if trigger not in TRIGGERS:
        errs.append(f"Unknown trigger {trigger}")
    if not steps or len(steps) > 10:
        errs.append("Workflows need between 1 and 10 steps")
    for i, s in enumerate(steps):
        if s.get("channel") != "sms":
            errs.append(f"Step {i + 1}: only the sms channel is supported")
        if not s.get("template") or len(s["template"]) > 640:
            errs.append(f"Step {i + 1}: template required (max 640 chars)")
        else:
            bad = validate_template(s["template"])
            if bad:
                errs.append(f"Step {i + 1}: unknown variables {bad}")
        if "before_appointment_minutes" in s:
            if trigger != "appointment.created":
                errs.append(f"Step {i + 1}: before_appointment_minutes only valid for appointment.created")
        elif not isinstance(s.get("delay_minutes"), int) or not (0 <= s["delay_minutes"] <= 60 * 24 * 30):
            errs.append(f"Step {i + 1}: delay_minutes must be 0–43200")
    for c in stop_conditions:
        if c not in STOP_CONDITIONS:
            errs.append(f"Unknown stop condition {c}")
    for k in ("start", "end"):
        v = (quiet_hours or {}).get(k)
        if v and not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", v):
            errs.append(f"quiet_hours.{k} must be HH:MM")
    return errs
