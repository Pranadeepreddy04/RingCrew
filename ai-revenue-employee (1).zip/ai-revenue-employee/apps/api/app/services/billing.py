"""Subscription billing: plans, trials, entitlements (backend-enforced), Stripe + sandbox providers (spec §47, §97)."""

from __future__ import annotations

import hashlib
import hmac
import json
import time
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Protocol

import httpx
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.errors import AppError
from app.models import AIAgent, Invoice, Membership, Organization, Plan, Subscription, UsageRecord
from app.services.common import audit, notify, utcnow

DEFAULT_PLANS: list[dict[str, Any]] = [
    {
        "key": "starter",
        "name": "Starter",
        "price_cents": 19900,
        "sort_order": 1,
        "features": ["web_chat", "lead_capture", "basic_scheduling", "knowledge_base"],
        "limits": {"agents": 1, "conversations_per_month": 500, "sms_per_month": 0, "voice_minutes_per_month": 0, "team_members": 2, "locations": 1},
    },
    {
        "key": "growth",
        "name": "Growth",
        "price_cents": 49900,
        "sort_order": 2,
        "features": [
            "web_chat",
            "lead_capture",
            "basic_scheduling",
            "knowledge_base",
            "voice",
            "sms",
            "followups",
            "calendar_sync",
            "advanced_qualification",
            "crm",
        ],
        "limits": {"agents": 2, "conversations_per_month": 2000, "sms_per_month": 2000, "voice_minutes_per_month": 1000, "team_members": 5, "locations": 1},
    },
    {
        "key": "pro",
        "name": "Pro",
        "price_cents": 99900,
        "sort_order": 3,
        "features": [
            "web_chat",
            "lead_capture",
            "basic_scheduling",
            "knowledge_base",
            "voice",
            "sms",
            "followups",
            "calendar_sync",
            "advanced_qualification",
            "crm",
            "multiple_agents",
            "advanced_workflows",
            "integrations",
            "webhooks",
            "advanced_analytics",
            "team_access",
        ],
        "limits": {
            "agents": 10,
            "conversations_per_month": 10000,
            "sms_per_month": 10000,
            "voice_minutes_per_month": 5000,
            "team_members": 25,
            "locations": 10,
        },
    },
]
TRIAL_DAYS = 14
TRIAL_PLAN = "growth"
PAST_DUE_GRACE_DAYS = 7
USAGE_LIMIT_KEYS = {"conversation": "conversations_per_month", "sms": "sms_per_month", "voice_minutes": "voice_minutes_per_month"}


def seed_plans(db: Session) -> None:
    existing = {p.key for p in db.scalars(select(Plan)).all()}
    for p in DEFAULT_PLANS:
        if p["key"] not in existing:
            db.add(Plan(**p))
    db.flush()


def start_trial(db: Session, org: Organization) -> Subscription:
    plan = db.scalar(select(Plan).where(Plan.key == TRIAL_PLAN)) or db.scalar(select(Plan).order_by(Plan.sort_order))
    if plan is None:
        seed_plans(db)
        plan = db.scalar(select(Plan).where(Plan.key == TRIAL_PLAN))
    assert plan is not None
    sub = Subscription(
        organization_id=org.id,
        plan_id=plan.id,
        status="trialing",
        trial_ends_at=utcnow() + timedelta(days=TRIAL_DAYS),
        current_period_end=utcnow() + timedelta(days=TRIAL_DAYS),
        provider=get_settings().billing_provider,
    )
    db.add(sub)
    db.flush()
    return sub


def get_subscription(db: Session, org_id: uuid.UUID) -> Subscription | None:
    return db.scalar(select(Subscription).where(Subscription.organization_id == org_id))


def subscription_is_usable(sub: Subscription | None) -> bool:
    if sub is None:
        return False
    now = utcnow()
    if sub.status == "trialing":
        return sub.trial_ends_at is not None and sub.trial_ends_at > now
    if sub.status == "active":
        return True
    if sub.status == "past_due":
        return sub.current_period_end is not None and sub.current_period_end + timedelta(days=PAST_DUE_GRACE_DAYS) > now
    return False


def entitlements(db: Session, org: Organization) -> dict[str, Any]:
    if org.is_demo:
        return {"usable": True, "features": DEFAULT_PLANS[-1]["features"], "limits": DEFAULT_PLANS[-1]["limits"], "plan": "demo", "status": "demo"}
    sub = get_subscription(db, org.id)
    usable = subscription_is_usable(sub)
    return {
        "usable": usable,
        "features": list(sub.plan.features) if sub and usable else [],
        "limits": dict(sub.plan.limits) if sub else {},
        "plan": sub.plan.key if sub else None,
        "status": sub.status if sub else "none",
    }


def has_feature(db: Session, org: Organization, feature: str) -> bool:
    ent = entitlements(db, org)
    return bool(ent["usable"]) and feature in ent["features"]


def require_feature(db: Session, org: Organization, feature: str) -> None:
    if not has_feature(db, org, feature):
        raise AppError(402, "plan_required", f"Your current plan does not include '{feature}'. Upgrade in Billing to enable it.")


def month_start(now: datetime | None = None) -> datetime:
    now = now or utcnow()
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def usage_this_month(db: Session, org_id: uuid.UUID, kind: str) -> int:
    return int(
        db.scalar(
            select(func.coalesce(func.sum(UsageRecord.quantity), 0)).where(
                UsageRecord.organization_id == org_id, UsageRecord.kind == kind, UsageRecord.created_at >= month_start()
            )
        )
        or 0
    )


def within_limit(db: Session, org: Organization, kind: str, adding: int = 1) -> bool:
    if org.is_demo:
        return True
    ent = entitlements(db, org)
    limit_key = USAGE_LIMIT_KEYS.get(kind)
    if not ent["usable"]:
        return False
    if not limit_key or limit_key not in ent["limits"]:
        return True
    override = ((org.settings or {}).get("usage_limits") or {}).get(limit_key)
    limit = int(override if override is not None else ent["limits"][limit_key])
    return usage_this_month(db, org.id, kind) + adding <= limit


def count_limit_ok(db: Session, org: Organization, resource: str) -> bool:
    ent = entitlements(db, org)
    limit = ent["limits"].get(resource)
    if limit is None:
        return True
    if resource == "agents":
        n = db.scalar(select(func.count()).select_from(AIAgent).where(AIAgent.organization_id == org.id, AIAgent.deleted_at.is_(None)))
    elif resource == "team_members":
        n = db.scalar(select(func.count()).select_from(Membership).where(Membership.organization_id == org.id))
    else:
        return True
    return int(n or 0) < int(limit)


def record_usage(db: Session, org_id: uuid.UUID, kind: str, quantity: int, *, cost_micros: int = 0, **kw: Any) -> None:
    db.add(UsageRecord(organization_id=org_id, kind=kind, quantity=quantity, cost_micros=cost_micros, **kw))


# ------------------------------------------------------------------ providers


class BillingProvider(Protocol):
    name: str

    def checkout(self, db: Session, org: Organization, plan: Plan, email: str) -> dict[str, Any]: ...

    def change_plan(self, db: Session, sub: Subscription, plan: Plan) -> None: ...

    def cancel(self, db: Session, sub: Subscription) -> None: ...

    def resume(self, db: Session, sub: Subscription) -> None: ...

    def portal(self, db: Session, sub: Subscription) -> str | None: ...


class SandboxBillingProvider:
    """No real charges. Applies the same state transitions a successful Stripe flow would,
    and is rejected in production by config validation."""

    name = "sandbox"

    def checkout(self, db: Session, org: Organization, plan: Plan, email: str) -> dict[str, Any]:
        sub = get_subscription(db, org.id)
        now = utcnow()
        if sub is None:
            sub = Subscription(organization_id=org.id, plan_id=plan.id, status="active")
            db.add(sub)
        sub.plan, sub.status, sub.provider = plan, "active", "sandbox"
        sub.provider_subscription_id = sub.provider_subscription_id or f"sandbox_sub_{uuid.uuid4().hex[:12]}"
        sub.trial_ends_at = None
        sub.cancel_at_period_end = False
        sub.current_period_end = now + timedelta(days=30)
        db.add(
            Invoice(
                organization_id=org.id,
                provider_invoice_id=f"sandbox_in_{uuid.uuid4().hex[:12]}",
                amount_cents=plan.price_cents,
                status="paid",
                period_start=now,
                period_end=sub.current_period_end,
            )
        )
        return {"mode": "sandbox", "completed": True, "url": None}

    def change_plan(self, db: Session, sub: Subscription, plan: Plan) -> None:
        sub.plan = plan

    def cancel(self, db: Session, sub: Subscription) -> None:
        sub.cancel_at_period_end = True

    def resume(self, db: Session, sub: Subscription) -> None:
        sub.cancel_at_period_end = False

    def portal(self, db: Session, sub: Subscription) -> str | None:
        return None


class StripeBillingProvider:
    name = "stripe"
    API = "https://api.stripe.com/v1"

    def _client(self) -> httpx.Client:
        key = get_settings().stripe_secret_key
        if not key:
            raise AppError(503, "billing_not_configured", "Stripe is not configured")
        return httpx.Client(base_url=self.API, auth=(key, ""), timeout=20)

    def _post(self, path: str, data: dict[str, Any], idem: str | None = None) -> dict[str, Any]:
        headers = {"Idempotency-Key": idem} if idem else {}
        with self._client() as c:
            r = c.post(path, data=data, headers=headers)
        if r.status_code >= 400:
            msg = (
                r.json().get("error", {}).get("message", "Stripe error") if r.headers.get("content-type", "").startswith("application/json") else "Stripe error"
            )
            raise AppError(502, "billing_provider_error", msg)
        return r.json()

    def _get(self, path: str) -> dict[str, Any]:
        with self._client() as c:
            r = c.get(path)
        if r.status_code >= 400:
            raise AppError(502, "billing_provider_error", "Stripe error")
        return r.json()

    def checkout(self, db: Session, org: Organization, plan: Plan, email: str) -> dict[str, Any]:
        if not plan.provider_price_id:
            raise AppError(503, "plan_not_configured", f"Plan '{plan.key}' has no Stripe price id configured (set it in Admin → Plans)")
        s = get_settings()
        sub = get_subscription(db, org.id)
        customer_id = sub.provider_customer_id if sub else None
        if not customer_id:
            cust = self._post("/customers", {"email": email, "name": org.name, "metadata[organization_id]": str(org.id)}, idem=f"cust-{org.id}")
            customer_id = cust["id"]
            if sub:
                sub.provider_customer_id = customer_id
        session = self._post(
            "/checkout/sessions",
            {
                "mode": "subscription",
                "customer": customer_id,
                "client_reference_id": str(org.id),
                "line_items[0][price]": plan.provider_price_id,
                "line_items[0][quantity]": "1",
                "subscription_data[metadata][organization_id]": str(org.id),
                "subscription_data[metadata][plan_key]": plan.key,
                "success_url": f"{s.public_web_url}/app/billing?checkout=success",
                "cancel_url": f"{s.public_web_url}/app/billing?checkout=cancelled",
            },
        )
        return {"mode": "stripe", "completed": False, "url": session["url"]}

    def change_plan(self, db: Session, sub: Subscription, plan: Plan) -> None:
        if not (sub.provider_subscription_id and plan.provider_price_id):
            raise AppError(400, "no_active_subscription", "Start a subscription with checkout first")
        current = self._get(f"/subscriptions/{sub.provider_subscription_id}")
        item_id = current["items"]["data"][0]["id"]
        self._post(
            f"/subscriptions/{sub.provider_subscription_id}",
            {"items[0][id]": item_id, "items[0][price]": plan.provider_price_id, "proration_behavior": "create_prorations"},
        )
        # authoritative state arrives via customer.subscription.updated webhook

    def cancel(self, db: Session, sub: Subscription) -> None:
        if not sub.provider_subscription_id:
            raise AppError(400, "no_active_subscription", "No active subscription")
        self._post(f"/subscriptions/{sub.provider_subscription_id}", {"cancel_at_period_end": "true"})

    def resume(self, db: Session, sub: Subscription) -> None:
        if not sub.provider_subscription_id:
            raise AppError(400, "no_active_subscription", "No active subscription")
        self._post(f"/subscriptions/{sub.provider_subscription_id}", {"cancel_at_period_end": "false"})

    def portal(self, db: Session, sub: Subscription) -> str | None:
        if not sub.provider_customer_id:
            return None
        r = self._post("/billing_portal/sessions", {"customer": sub.provider_customer_id, "return_url": f"{get_settings().public_web_url}/app/billing"})
        return str(r["url"])


def get_billing_provider() -> BillingProvider:
    return StripeBillingProvider() if get_settings().billing_provider == "stripe" else SandboxBillingProvider()


# ------------------------------------------------------------------ Stripe webhooks


def verify_stripe_signature(payload: bytes, header: str, secret: str, tolerance: int = 300) -> dict[str, Any]:
    parts: dict[str, list[str]] = {}
    for item in header.split(","):
        k, _, v = item.partition("=")
        parts.setdefault(k.strip(), []).append(v.strip())
    try:
        ts = int(parts["t"][0])
    except (KeyError, ValueError):
        raise AppError(400, "invalid_signature", "Missing timestamp") from None
    if abs(time.time() - ts) > tolerance:
        raise AppError(400, "invalid_signature", "Timestamp outside tolerance")
    expected = hmac.new(secret.encode(), f"{ts}.".encode() + payload, hashlib.sha256).hexdigest()
    if not any(hmac.compare_digest(expected, sig) for sig in parts.get("v1", [])):
        raise AppError(400, "invalid_signature", "Signature mismatch")
    return json.loads(payload)


def _ts(v: Any) -> datetime | None:
    return datetime.fromtimestamp(int(v), tz=timezone.utc) if v else None


STRIPE_STATUS = {
    "trialing": "trialing",
    "active": "active",
    "past_due": "past_due",
    "unpaid": "past_due",
    "canceled": "canceled",
    "incomplete": "incomplete",
    "incomplete_expired": "canceled",
    "paused": "past_due",
}


def apply_stripe_event(db: Session, event: dict[str, Any]) -> str:
    etype = event.get("type", "")
    obj = event.get("data", {}).get("object", {})
    if etype.startswith("customer.subscription."):
        org_id = (obj.get("metadata") or {}).get("organization_id")
        sub = db.scalar(select(Subscription).where(Subscription.provider_subscription_id == obj["id"]))
        if sub is None and org_id:
            sub = get_subscription(db, uuid.UUID(org_id))
        if sub is None:
            return "ignored:no_subscription"
        price_id = (obj.get("items", {}).get("data") or [{}])[0].get("price", {}).get("id")
        plan = db.scalar(select(Plan).where(Plan.provider_price_id == price_id)) if price_id else None
        if plan:
            sub.plan = plan
        sub.provider = "stripe"
        sub.provider_subscription_id = obj["id"]
        sub.provider_customer_id = obj.get("customer") or sub.provider_customer_id
        sub.status = "canceled" if etype.endswith("deleted") else STRIPE_STATUS.get(obj.get("status", ""), "incomplete")
        sub.current_period_end = (
            _ts(obj.get("current_period_end") or (obj.get("items", {}).get("data") or [{}])[0].get("current_period_end")) or sub.current_period_end
        )
        sub.cancel_at_period_end = bool(obj.get("cancel_at_period_end"))
        sub.trial_ends_at = _ts(obj.get("trial_end"))
        audit(db, "billing.subscription_updated", org_id=sub.organization_id, actor_type="system", data={"status": sub.status, "event": etype})
        return "applied"
    if etype == "checkout.session.completed":
        org_id = obj.get("client_reference_id")
        if org_id:
            sub = get_subscription(db, uuid.UUID(org_id))
            if sub:
                sub.provider_customer_id = obj.get("customer") or sub.provider_customer_id
                sub.provider_subscription_id = obj.get("subscription") or sub.provider_subscription_id
        return "applied"
    if etype in ("invoice.paid", "invoice.payment_failed", "invoice.finalized"):
        sub = db.scalar(select(Subscription).where(Subscription.provider_customer_id == obj.get("customer")))
        if sub is None:
            return "ignored:no_subscription"
        inv = db.scalar(select(Invoice).where(Invoice.provider_invoice_id == obj["id"]))
        status = "paid" if etype == "invoice.paid" else ("open" if etype == "invoice.payment_failed" else obj.get("status", "open"))
        if inv is None:
            inv = Invoice(organization_id=sub.organization_id, provider_invoice_id=obj["id"], amount_cents=int(obj.get("amount_due") or 0), status=status)
            db.add(inv)
        inv.status = status
        inv.hosted_url = obj.get("hosted_invoice_url")
        inv.period_start, inv.period_end = _ts(obj.get("period_start")), _ts(obj.get("period_end"))
        if etype == "invoice.payment_failed":
            sub.status = "past_due"
            notify(
                db,
                sub.organization_id,
                "billing.payment_failed",
                "Payment failed",
                "Update your payment method to keep your AI employees online.",
                "/app/billing",
                roles=("owner",),
            )
        elif etype == "invoice.paid" and sub.status == "past_due":
            sub.status = "active"  # payment recovery
        return "applied"
    return "ignored:unhandled_type"
