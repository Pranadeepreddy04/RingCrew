"""Cross-cutting services: audit log, analytics events, outgoing webhooks, notifications, jobs."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.models import (
    AuditLog,
    Event,
    Job,
    Membership,
    Notification,
    Organization,
    User,
    WebhookDelivery,
    WebhookEndpoint,
)
from app.observability import current_request_id

OUTGOING_WEBHOOK_EVENTS = {
    "lead.created",
    "lead.qualified",
    "lead.status_changed",
    "appointment.created",
    "appointment.cancelled",
    "appointment.rescheduled",
    "conversation.escalated",
    "customer.opted_out",
}


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def audit(
    db: Session,
    action: str,
    *,
    org_id: uuid.UUID | None,
    actor_user_id: uuid.UUID | None = None,
    actor_type: str = "user",
    target_type: str | None = None,
    target_id: Any = None,
    data: dict[str, Any] | None = None,
    ip: str | None = None,
) -> None:
    db.add(
        AuditLog(
            organization_id=org_id,
            actor_user_id=actor_user_id,
            actor_type=actor_type,
            action=action,
            target_type=target_type,
            target_id=str(target_id) if target_id is not None else None,
            data=data or {},
            ip=ip,
            request_id=current_request_id(),
        )
    )


def enqueue_job(
    db: Session,
    kind: str,
    payload: dict[str, Any],
    *,
    org_id: uuid.UUID | None = None,
    run_at: datetime | None = None,
    dedupe_key: str | None = None,
    max_attempts: int = 5,
) -> None:
    values = dict(
        id=uuid.uuid4(),
        organization_id=org_id,
        kind=kind,
        payload=payload,
        status="queued",
        run_at=run_at or utcnow(),
        attempts=0,
        max_attempts=max_attempts,
        dedupe_key=dedupe_key,
    )
    stmt = pg_insert(Job).values(**values)
    if dedupe_key:
        stmt = stmt.on_conflict_do_nothing(index_elements=["dedupe_key"])
    db.execute(stmt)


def emit_event(
    db: Session,
    org_id: uuid.UUID,
    type_: str,
    *,
    channel: str | None = None,
    conversation_id: uuid.UUID | None = None,
    lead_id: uuid.UUID | None = None,
    agent_id: uuid.UUID | None = None,
    data: dict[str, Any] | None = None,
    webhook_payload: dict[str, Any] | None = None,
    is_test: bool = False,
) -> None:
    """Record an analytics event and fan out to subscribed outgoing webhook endpoints."""
    if is_test:
        return  # owner test-mode conversations never pollute analytics or trigger webhooks
    db.add(
        Event(
            organization_id=org_id,
            type=type_,
            channel=channel,
            conversation_id=conversation_id,
            lead_id=lead_id,
            agent_id=agent_id,
            data=data or {},
        )
    )
    if type_ in OUTGOING_WEBHOOK_EVENTS:
        endpoints = db.scalars(select(WebhookEndpoint).where(WebhookEndpoint.organization_id == org_id, WebhookEndpoint.active.is_(True))).all()
        for ep in endpoints:
            if ep.events and type_ not in ep.events:
                continue
            delivery = WebhookDelivery(
                organization_id=org_id,
                endpoint_id=ep.id,
                event_type=type_,
                payload={
                    "id": str(uuid.uuid4()),
                    "type": type_,
                    "created_at": utcnow().isoformat(),
                    "organization_id": str(org_id),
                    "data": webhook_payload or data or {},
                },
            )
            db.add(delivery)
            db.flush()
            enqueue_job(db, "webhook.deliver", {"delivery_id": str(delivery.id)}, org_id=org_id)


NOTIFY_EMAIL_TYPES = {
    "lead.qualified",
    "handoff.required",
    "appointment.created",
    "workflow.failed",
    "integration.disconnected",
    "appointment.cancelled",
    "lead.created",
}


def notify(
    db: Session,
    org_id: uuid.UUID,
    type_: str,
    title: str,
    body: str | None = None,
    link: str | None = None,
    *,
    roles: tuple[str, ...] = ("owner", "manager"),
) -> None:
    """In-app notification for the org plus queued email per user preference (spec §50)."""
    db.add(Notification(organization_id=org_id, type=type_, title=title, body=body, link=link))
    members = db.execute(
        select(Membership, User)
        .join(User, User.id == Membership.user_id)
        .where(Membership.organization_id == org_id, Membership.role.in_(roles), User.is_active.is_(True))
    ).all()
    org = db.get(Organization, org_id)
    email_prefs: dict[str, bool] = ((org.settings or {}).get("notification_prefs") or {}).get("email", {}) if org else {}
    if not email_prefs.get(type_, type_ in NOTIFY_EMAIL_TYPES):
        return
    for _m, user in members:
        enqueue_job(
            db,
            "notification.email",
            {"user_id": str(user.id), "type": type_, "title": title, "body": body or "", "link": link},
            org_id=org_id,
        )
