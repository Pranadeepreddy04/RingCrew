"""Customers, consent, leads, handoff, outbound customer messaging (spec §11, §28, §29, §32)."""

from __future__ import annotations

import uuid
from datetime import timedelta
from typing import Any

from sqlalchemy import or_, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import (
    AIAgent,
    Appointment,
    Conversation,
    Customer,
    CustomerConsent,
    Lead,
    Message,
    Organization,
    PhoneNumber,
    Task,
    WorkflowRun,
)
from app.providers.messaging import SendResult, get_sms_provider
from app.services import billing
from app.services.common import audit, emit_event, notify, utcnow


def find_or_create_customer(
    db: Session, org_id: uuid.UUID, *, phone: str | None = None, email: str | None = None, name: str | None = None, zip_code: str | None = None
) -> Customer:
    conds = []
    if phone:
        conds.append(Customer.phone == phone)
    if email:
        conds.append(Customer.email == email.lower())
    cust = None
    if conds:
        cust = db.scalar(
            select(Customer)
            .where(Customer.organization_id == org_id, Customer.deleted_at.is_(None), Customer.merged_into_id.is_(None), or_(*conds))
            .order_by(Customer.created_at)
            .limit(1)
        )
    if cust is None:
        cust = Customer(organization_id=org_id, phone=phone, email=email.lower() if email else None, name=name, zip=zip_code)
        db.add(cust)
        db.flush()
    else:
        cust.name = cust.name or name
        cust.phone = cust.phone or phone
        cust.email = cust.email or (email.lower() if email else None)
        cust.zip = zip_code or cust.zip
    return cust


def record_consent(db: Session, customer: Customer, channel: str, purpose: str, status: str, source: str) -> None:
    db.add(CustomerConsent(organization_id=customer.organization_id, customer_id=customer.id, channel=channel, purpose=purpose, status=status, source=source))


def has_sms_consent(db: Session, customer: Customer, purpose: str = "transactional") -> bool:
    if customer.sms_opted_out:
        return False
    latest = db.scalar(
        select(CustomerConsent)
        .where(CustomerConsent.customer_id == customer.id, CustomerConsent.channel == "sms", CustomerConsent.purpose == purpose)
        .order_by(CustomerConsent.recorded_at.desc(), CustomerConsent.created_at.desc())
        .limit(1)
    )
    return latest is not None and latest.status == "granted"


def opt_out(db: Session, customer: Customer, source: str) -> None:
    customer.sms_opted_out = True
    for purpose in ("transactional", "marketing"):
        record_consent(db, customer, "sms", purpose, "revoked", source)
    stop_workflow_runs(db, customer_id=customer.id, reason="opted_out")
    emit_event(
        db,
        customer.organization_id,
        "customer.opted_out",
        channel="sms",
        data={"customer_id": str(customer.id)},
        webhook_payload={"customer_id": str(customer.id), "channel": "sms"},
    )
    audit(
        db, "customer.opted_out", org_id=customer.organization_id, actor_type="system", target_type="customer", target_id=customer.id, data={"source": source}
    )


def opt_in(db: Session, customer: Customer, source: str) -> None:
    customer.sms_opted_out = False
    record_consent(db, customer, "sms", "transactional", "granted", source)
    audit(db, "customer.opted_in", org_id=customer.organization_id, actor_type="system", target_type="customer", target_id=customer.id, data={"source": source})


def stop_workflow_runs(
    db: Session,
    *,
    customer_id: uuid.UUID | None = None,
    lead_id: uuid.UUID | None = None,
    appointment_id: uuid.UUID | None = None,
    reason: str,
    only_conditions: bool = True,
) -> int:
    q = select(WorkflowRun).where(WorkflowRun.status == "active")
    if customer_id:
        q = q.where(WorkflowRun.customer_id == customer_id)
    if lead_id:
        q = q.where(WorkflowRun.lead_id == lead_id)
    if appointment_id:
        q = q.where(WorkflowRun.appointment_id == appointment_id)
    n = 0
    from app.models import Workflow

    for run in db.scalars(q.with_for_update(skip_locked=False)).all():
        wf = db.get(Workflow, run.workflow_id)
        if reason == "opted_out" or not only_conditions or (wf and reason in (wf.stop_conditions or [])):
            run.status, run.stop_reason, run.next_run_at = "stopped", reason, None
            n += 1
    return n


def create_or_update_lead(
    db: Session,
    org: Organization,
    *,
    customer: Customer,
    conversation: Conversation | None,
    agent: AIAgent | None,
    source: str,
    channel: str,
    service: str | None,
    qualification: dict[str, Any],
    qualified: bool,
    urgency: str | None,
    summary: str | None,
) -> tuple[Lead, bool]:
    """Idempotent per conversation. Returns (lead, created)."""
    key = f"conv:{conversation.id}" if conversation else None
    lead = db.scalar(select(Lead).where(Lead.organization_id == org.id, Lead.idempotency_key == key)) if key else None
    created = False
    if lead is None:
        stmt = (
            pg_insert(Lead)
            .values(
                id=uuid.uuid4(),
                organization_id=org.id,
                customer_id=customer.id,
                conversation_id=conversation.id if conversation else None,
                agent_id=agent.id if agent else None,
                source=source,
                channel=channel,
                service=service,
                status="qualified" if qualified else "new",
                is_qualified=qualified,
                qualification=qualification,
                urgency=urgency,
                summary=summary,
                attribution_source=source,
                attribution_confidence="direct" if agent else "unknown",
                idempotency_key=key,
                last_activity_at=utcnow(),
            )
            .on_conflict_do_nothing(constraint="uq_leads_org_idem")
            .returning(Lead.id)
        )
        new_id = db.execute(stmt).scalar()
        lead = db.scalar(select(Lead).where(Lead.organization_id == org.id, Lead.idempotency_key == key)) if key else db.get(Lead, new_id)
        created = new_id is not None
        assert lead is not None
    else:
        was_qualified = lead.is_qualified
        lead.qualification = {**(lead.qualification or {}), **qualification}
        lead.service = service or lead.service
        lead.urgency = urgency or lead.urgency
        lead.summary = summary or lead.summary
        lead.last_activity_at = utcnow()
        if qualified and not was_qualified:
            lead.is_qualified = True
            if lead.status in ("new", "contacted"):
                lead.status = "qualified"
    is_test = bool(conversation and conversation.is_test)
    if created:
        emit_event(
            db,
            org.id,
            "lead.created",
            channel=channel,
            conversation_id=conversation.id if conversation else None,
            lead_id=lead.id,
            agent_id=agent.id if agent else None,
            data={"source": source, "qualified": qualified},
            webhook_payload=_lead_webhook(lead, customer),
            is_test=is_test,
        )
        if qualified:
            emit_event(
                db,
                org.id,
                "lead.qualified",
                channel=channel,
                lead_id=lead.id,
                agent_id=agent.id if agent else None,
                webhook_payload=_lead_webhook(lead, customer),
                is_test=is_test,
            )
        if not is_test:
            notify(
                db,
                org.id,
                "lead.qualified" if qualified else "lead.created",
                f"New {'qualified ' if qualified else ''}lead: {customer.name or customer.phone or 'Unknown'}",
                f"{service or 'Service request'} via {channel}",
                f"/app/leads?id={lead.id}",
            )
            from app.services.automation import start_workflows

            start_workflows(db, org, "lead.created", customer=customer, lead=lead)
    if conversation:
        conversation.lead_id = lead.id
    return lead, created


def _lead_webhook(lead: Lead, customer: Customer) -> dict[str, Any]:
    return {
        "lead_id": str(lead.id),
        "status": lead.status,
        "service": lead.service,
        "qualified": lead.is_qualified,
        "source": lead.source,
        "customer": {"id": str(customer.id), "name": customer.name, "phone": customer.phone, "email": customer.email},
    }


def set_lead_status(db: Session, org: Organization, lead: Lead, status: str, actor_user_id: uuid.UUID | None = None) -> None:
    stages = (org.settings or {}).get("pipeline_stages") or []
    if status not in stages:
        from app.errors import bad_request

        raise bad_request(f"Unknown pipeline stage '{status}'", "invalid_status")
    old = lead.status
    if old == status:
        return
    lead.status = status
    lead.last_activity_at = utcnow()
    if status in ("won", "lost"):
        lead.closed_at = utcnow()
        stop_workflow_runs(db, lead_id=lead.id, reason="lead_closed")
    if status == "qualified":
        lead.is_qualified = True
    emit_event(
        db,
        org.id,
        "lead.status_changed",
        lead_id=lead.id,
        data={"from": old, "to": status},
        webhook_payload={"lead_id": str(lead.id), "from": old, "to": status},
    )
    if status == "won":
        emit_event(db, org.id, "lead.won", lead_id=lead.id, data={"actual_revenue_cents": lead.actual_revenue_cents})
    audit(db, "lead.status_changed", org_id=org.id, actor_user_id=actor_user_id, target_type="lead", target_id=lead.id, data={"from": old, "to": status})


def start_handoff(
    db: Session,
    org: Organization,
    conv: Conversation,
    reason: str,
    *,
    summary: str | None = None,
    details: dict[str, Any] | None = None,
    priority: str = "high",
) -> Task:
    """Stop the AI and route the conversation to a human (spec §32)."""
    conv.handoff_active = True
    conv.status = "needs_human"
    conv.handoff_reason = reason
    customer = db.get(Customer, conv.customer_id) if conv.customer_id else None
    title = f"{reason.replace('_', ' ').capitalize()}: {customer.name if customer and customer.name else (conv.contact_address or 'website visitor')}"
    lines = [f"Reason: {reason.replace('_', ' ')}"]
    if summary:
        lines.append(f"Summary: {summary}")
    for k, v in (details or {}).items():
        lines.append(f"{k.replace('_', ' ').capitalize()}: {v}")
    lines.append("Next step: review the conversation and contact the customer.")
    task = Task(
        organization_id=org.id,
        kind="handoff",
        title=title[:300],
        description="\n".join(lines),
        conversation_id=conv.id,
        lead_id=conv.lead_id,
        customer_id=conv.customer_id,
        priority=priority,
        due_at=utcnow() + timedelta(minutes=30),
    )
    db.add(task)
    stop_workflow_runs(db, customer_id=conv.customer_id, reason="human_takeover") if conv.customer_id else None
    emit_event(
        db,
        org.id,
        "conversation.escalated",
        channel=conv.channel,
        conversation_id=conv.id,
        lead_id=conv.lead_id,
        agent_id=conv.agent_id,
        data={"reason": reason},
        webhook_payload={"conversation_id": str(conv.id), "reason": reason},
        is_test=conv.is_test,
    )
    if not conv.is_test:
        notify(
            db,
            org.id,
            "handoff.required",
            f"Human help needed — {reason.replace('_', ' ')}",
            summary,
            f"/app/inbox?id={conv.id}",
            roles=("owner", "manager", "staff"),
        )
    return task


def org_sending_number(db: Session, org_id: uuid.UUID) -> PhoneNumber | None:
    return db.scalar(select(PhoneNumber).where(PhoneNumber.organization_id == org_id, PhoneNumber.sms_enabled.is_(True)).order_by(PhoneNumber.created_at))


def send_sms(
    db: Session,
    org: Organization,
    customer: Customer,
    body: str,
    *,
    purpose: str,
    conversation: Conversation | None = None,
    idempotency_key: str | None = None,
    author: str = "ai",
) -> SendResult:
    """The only path for outbound SMS. Enforces opt-out, consent, plan, usage limits; records the message.
    Returns the provider's real result — callers must never report success when ok is False."""
    if org.is_demo or (conversation is not None and conversation.is_test):
        return SendResult(False, "none", None, "blocked", "demo_or_test_mode")
    if not customer.phone:
        return SendResult(False, "none", None, "blocked", "no_phone")
    if customer.sms_opted_out:
        return SendResult(False, "none", None, "blocked", "opted_out")
    if purpose in ("followup", "reminder", "confirmation") and not has_sms_consent(db, customer):
        return SendResult(False, "none", None, "blocked", "no_consent")
    if purpose == "marketing" and not has_sms_consent(db, customer, "marketing"):
        return SendResult(False, "none", None, "blocked", "no_marketing_consent")
    if not billing.has_feature(db, org, "sms"):
        return SendResult(False, "none", None, "blocked", "plan_excludes_sms")
    if not billing.within_limit(db, org, "sms"):
        return SendResult(False, "none", None, "blocked", "usage_limit_reached")
    number = org_sending_number(db, org.id)
    if number is None:
        return SendResult(False, "none", None, "blocked", "no_business_number")
    if idempotency_key:
        dup = db.scalar(select(Message).where(Message.organization_id == org.id, Message.meta["idempotency_key"].astext == idempotency_key))
        if dup is not None:
            return SendResult(True, dup.meta.get("provider", "unknown"), dup.provider_message_id, dup.delivery_status or "queued")
    if conversation is None:
        conversation = db.scalar(
            select(Conversation)
            .where(Conversation.organization_id == org.id, Conversation.channel == "sms", Conversation.contact_address == customer.phone)
            .order_by(Conversation.last_message_at.desc())
            .limit(1)
        )
        if conversation is None:
            conversation = Conversation(
                organization_id=org.id, customer_id=customer.id, channel="sms", contact_address=customer.phone, agent_id=number.agent_id, state={}
            )
            db.add(conversation)
            db.flush()
    provider = get_sms_provider()
    status_cb = f"{get_settings().public_api_url}/api/v1/webhooks/sms/status"
    result = provider.send(from_number=number.number, to=customer.phone, body=body, status_callback=status_cb)
    db.add(
        Message(
            organization_id=org.id,
            conversation_id=conversation.id,
            role=author,
            content=body,
            provider_message_id=result.provider_message_id,
            delivery_status=result.status if result.ok else "failed",
            meta={"channel": "sms", "purpose": purpose, "provider": result.provider, "error": result.error, "idempotency_key": idempotency_key},
        )
    )
    conversation.last_message_at = utcnow()
    if result.ok:
        billing.record_usage(db, org.id, "sms", 1, provider=result.provider, channel="sms", conversation_id=conversation.id)
        emit_event(db, org.id, "sms.sent", channel="sms", conversation_id=conversation.id, data={"purpose": purpose})
    else:
        emit_event(db, org.id, "sms.failed", channel="sms", conversation_id=conversation.id, data={"purpose": purpose, "error": result.error})
    return result


def upcoming_appointment(db: Session, org_id: uuid.UUID, customer_id: uuid.UUID) -> Appointment | None:
    return db.scalar(
        select(Appointment)
        .where(
            Appointment.organization_id == org_id,
            Appointment.customer_id == customer_id,
            Appointment.status.in_(("scheduled", "confirmed")),
            Appointment.start_at > utcnow(),
        )
        .order_by(Appointment.start_at)
        .limit(1)
    )


def merge_customers(db: Session, org_id: uuid.UUID, keep: Customer, dup: Customer) -> None:
    from app.models import StoredFile

    for model in (Lead, Appointment, Conversation, Task, CustomerConsent, WorkflowRun, StoredFile):
        db.execute(update(model).where(model.organization_id == org_id, model.customer_id == dup.id).values(customer_id=keep.id))  # type: ignore[attr-defined]
    keep.name = keep.name or dup.name
    keep.phone = keep.phone or dup.phone
    keep.email = keep.email or dup.email
    keep.zip = keep.zip or dup.zip
    keep.tags = sorted(set((keep.tags or []) + (dup.tags or [])))
    keep.notes = "\n".join(x for x in (keep.notes, dup.notes) if x) or None
    keep.sms_opted_out = keep.sms_opted_out or dup.sms_opted_out
    dup.merged_into_id = keep.id
    dup.deleted_at = utcnow()
