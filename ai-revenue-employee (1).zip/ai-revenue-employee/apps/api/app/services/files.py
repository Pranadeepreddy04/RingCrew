"""Secure file uploads (spec §51): signed upload tokens, type/size/magic-byte validation, tenant ownership,
unguessable storage keys, short-lived signed download URLs, malware-scan integration point."""

from __future__ import annotations

import hashlib
import os
import uuid
from pathlib import Path
from typing import Protocol

from app.config import get_settings
from app.errors import AppError
from app.security import signed_expiring, verify_expiring

ALLOWED_TYPES = {
    "image/jpeg": [b"\xff\xd8\xff"],
    "image/png": [b"\x89PNG\r\n\x1a\n"],
    "image/webp": [b"RIFF"],
    "image/heic": [b"\x00\x00\x00"],
    "application/pdf": [b"%PDF-"],
}


def upload_token(org_id: uuid.UUID, conversation_id: uuid.UUID, ttl: int = 86400) -> str:
    return signed_expiring(f"{org_id}:{conversation_id}", "upload", ttl)


def parse_upload_token(token: str) -> tuple[uuid.UUID, uuid.UUID]:
    value = verify_expiring(token, "upload")
    if not value:
        raise AppError(403, "invalid_upload_token", "This upload link is invalid or has expired")
    org, conv = value.split(":")
    return uuid.UUID(org), uuid.UUID(conv)


def validate_upload(content_type: str, data: bytes) -> None:
    if len(data) == 0:
        raise AppError(400, "empty_file", "The file is empty")
    if len(data) > get_settings().max_upload_bytes:
        raise AppError(413, "file_too_large", "Files must be 10 MB or smaller")
    sigs = ALLOWED_TYPES.get(content_type)
    if sigs is None:
        raise AppError(415, "unsupported_type", "Only JPEG, PNG, WEBP, HEIC images and PDF documents are accepted")
    if not any(data.startswith(s) for s in sigs):
        raise AppError(415, "type_mismatch", "The file contents do not match its type")


class Storage(Protocol):
    def put(self, key: str, data: bytes, content_type: str) -> None: ...

    def get(self, key: str) -> bytes: ...


class LocalStorage:
    def __init__(self) -> None:
        self.root = Path(get_settings().storage_dir).resolve()

    def _path(self, key: str) -> Path:
        p = (self.root / key).resolve()
        if not str(p).startswith(str(self.root)):
            raise AppError(400, "invalid_key", "Invalid storage key")
        return p

    def put(self, key: str, data: bytes, content_type: str) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_bytes(data)
        os.replace(tmp, p)

    def get(self, key: str) -> bytes:
        return self._path(key).read_bytes()


class S3Storage:
    """S3-compatible object storage (requires S3_BUCKET + credentials; boto3 installed on demand)."""

    def __init__(self) -> None:
        import boto3  # type: ignore[import-not-found]

        self.bucket = os.environ["S3_BUCKET"]
        self.client = boto3.client("s3", endpoint_url=os.environ.get("S3_ENDPOINT_URL") or None)

    def put(self, key: str, data: bytes, content_type: str) -> None:
        self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type, ServerSideEncryption="AES256")

    def get(self, key: str) -> bytes:
        return bytes(self.client.get_object(Bucket=self.bucket, Key=key)["Body"].read())


def get_storage() -> Storage:
    return S3Storage() if os.environ.get("S3_BUCKET") else LocalStorage()


def new_storage_key(org_id: uuid.UUID, filename: str) -> str:
    ext = Path(filename).suffix.lower()[:8]
    return f"{org_id}/{uuid.uuid4().hex}{uuid.uuid4().hex}{ext}"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def scan_for_malware(data: bytes) -> str:
    """Integration point for a malware scanner (e.g. ClamAV / cloud AV). Returns a scan status.
    Not configured by default: files are marked 'not_scanned' and served only to authenticated staff."""
    return "not_scanned"


def download_token(file_id: uuid.UUID, ttl: int = 300) -> str:
    return signed_expiring(str(file_id), "download", ttl)


def parse_download_token(token: str) -> uuid.UUID:
    v = verify_expiring(token, "download")
    if not v:
        raise AppError(403, "invalid_download_token", "This download link has expired")
    return uuid.UUID(v)
