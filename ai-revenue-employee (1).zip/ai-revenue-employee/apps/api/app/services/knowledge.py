"""Knowledge pipeline: source → parse → sanitize → chunk → (embed) → store → retrieve (spec §13).

Retrieval uses PostgreSQL full-text search (GIN index), always filtered by organization_id.
An embedding column exists for providers that support embeddings; lexical retrieval is the
default because it is deterministic, fast and requires no external credentials."""

from __future__ import annotations

import ipaddress
import re
import socket
import uuid
from dataclasses import dataclass
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin, urlparse

import httpx
from sqlalchemy import delete, text
from sqlalchemy.orm import Session

from app.errors import bad_request
from app.models import KnowledgeChunk, KnowledgeSource

CHUNK_CHARS = 900
MAX_SOURCE_CHARS = 200_000
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def sanitize(text_in: str) -> str:
    t = _CONTROL.sub(" ", text_in or "")
    t = re.sub(r"[ \t ]+", " ", t)
    t = re.sub(r"\n\s*\n\s*\n+", "\n\n", t)
    return t.strip()[:MAX_SOURCE_CHARS]


def chunk_text(content: str, size: int = CHUNK_CHARS) -> list[str]:
    paras = [p.strip() for p in re.split(r"\n\s*\n", content) if p.strip()]
    chunks: list[str] = []
    buf = ""
    for p in paras:
        while len(p) > size:  # hard-split very long paragraphs on sentence boundaries
            cut = p.rfind(". ", 0, size)
            cut = cut + 1 if cut > size // 3 else size
            if buf:
                chunks.append(buf)
                buf = ""
            chunks.append(p[:cut].strip())
            p = p[cut:].strip()
        if len(buf) + len(p) + 2 <= size:
            buf = f"{buf}\n\n{p}" if buf else p
        else:
            if buf:
                chunks.append(buf)
            buf = p
    if buf:
        chunks.append(buf)
    return chunks


def faq_to_chunks(faqs: list[dict[str, str]]) -> list[tuple[str, str]]:
    return [(f["question"].strip(), f"Q: {f['question'].strip()}\nA: {f['answer'].strip()}") for f in faqs if f.get("question") and f.get("answer")]


def index_source(db: Session, source: KnowledgeSource, faqs: list[dict[str, str]] | None = None) -> None:
    """(Re)build chunks for a source. Runs inside the caller's transaction."""
    db.execute(delete(KnowledgeChunk).where(KnowledgeChunk.source_id == source.id))
    if faqs is not None:
        pairs = faq_to_chunks(faqs)
        source.content = "\n\n".join(c for _, c in pairs)
        for i, (title, content) in enumerate(pairs):
            db.add(KnowledgeChunk(organization_id=source.organization_id, source_id=source.id, position=i, title=title, content=content))
    else:
        source.content = sanitize(source.content)
        for i, c in enumerate(chunk_text(source.content)):
            db.add(KnowledgeChunk(organization_id=source.organization_id, source_id=source.id, position=i, title=source.title, content=c))
    source.status = "ready"
    source.error = None


@dataclass
class Hit:
    chunk_id: uuid.UUID
    source_id: uuid.UUID
    source_kind: str
    title: str | None
    content: str
    score: float
    coverage: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "source_id": str(self.source_id),
            "kind": self.source_kind,
            "title": self.title,
            "content": self.content,
            "score": round(self.score, 4),
            "coverage": round(self.coverage, 3),
        }


_SEARCH_SQL = text(
    """
    WITH q AS (
      SELECT NULLIF(replace(plainto_tsquery('english', :query)::text, '&', '|'), '') AS qs
    )
    SELECT c.id, c.source_id, s.kind, c.title, c.content,
           ts_rank_cd(c.tsv, to_tsquery('english', q.qs), 32) AS score,
           (SELECT count(*) FROM unnest(tsvector_to_array(to_tsvector('english', coalesce(c.title,'') || ' ' || c.content))) AS lex
              WHERE lex = ANY (tsvector_to_array(to_tsvector('english', :query)))) AS matched,
           array_length(tsvector_to_array(to_tsvector('english', :query)), 1) AS qterms
    FROM knowledge_chunks c
    JOIN knowledge_sources s ON s.id = c.source_id
    CROSS JOIN q
    WHERE c.organization_id = :org_id
      AND s.organization_id = :org_id
      AND s.approved = true AND s.status = 'ready'
      AND q.qs IS NOT NULL
      AND c.tsv @@ to_tsquery('english', q.qs)
    ORDER BY score DESC
    LIMIT :limit
    """
)


def search(db: Session, org_id: uuid.UUID, query: str, limit: int = 4) -> list[Hit]:
    query = sanitize(query)[:500]
    if not query:
        return []
    rows = db.execute(_SEARCH_SQL, {"query": query, "org_id": org_id, "limit": limit}).all()
    hits: list[Hit] = []
    for r in rows:
        coverage = (r.matched or 0) / max(r.qterms or 1, 1)
        hits.append(Hit(r.id, r.source_id, r.kind, r.title, r.content, float(r.score) * 0.5 + coverage, coverage))
    hits.sort(key=lambda h: h.score, reverse=True)
    return hits


# ------------------------------------------------------------------ website import (SSRF-safe)


class _TextExtractor(HTMLParser):
    SKIP = {"script", "style", "noscript", "svg", "nav", "footer", "form", "iframe", "head"}
    BLOCK = {"p", "div", "section", "article", "li", "h1", "h2", "h3", "h4", "br", "tr", "header", "main"}

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.links: list[str] = []
        self.title = ""
        self.description = ""
        self._skip = 0
        self._in_title = False

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        a = dict(attrs)
        if tag == "title":
            self._in_title = True
        if tag == "meta" and (a.get("name") or "").lower() == "description":
            self.description = a.get("content") or ""
        if tag == "a" and a.get("href"):
            self.links.append(a["href"] or "")
        if tag in self.SKIP:
            self._skip += 1
        if tag in self.BLOCK:
            self.parts.append("\n\n")

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self._in_title = False
        if tag in self.SKIP and self._skip:
            self._skip -= 1

    def handle_data(self, data: str) -> None:
        if self._in_title:
            self.title += data
        elif not self._skip:
            self.parts.append(data)


def _assert_public_host(url: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise bad_request("Only http(s) website URLs are supported", "invalid_url")
    try:
        infos = socket.getaddrinfo(parsed.hostname, parsed.port or (443 if parsed.scheme == "https" else 80))
    except socket.gaierror:
        raise bad_request("Could not resolve that website address", "unresolvable_url") from None
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            raise bad_request("That address is not allowed", "blocked_url")


def fetch_page(url: str, client: httpx.Client) -> tuple[str, _TextExtractor]:
    for _ in range(4):
        _assert_public_host(url)
        resp = client.get(url, follow_redirects=False)
        if resp.is_redirect and resp.headers.get("location"):
            url = urljoin(url, resp.headers["location"])
            continue
        resp.raise_for_status()
        ctype = resp.headers.get("content-type", "")
        if "html" not in ctype and "text" not in ctype:
            raise bad_request("The website did not return an HTML page", "not_html")
        parser = _TextExtractor()
        parser.feed(resp.text[:2_000_000])
        return url, parser
    raise bad_request("Too many redirects", "too_many_redirects")


def import_website(url: str, max_pages: int = 5) -> dict[str, Any]:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    pages: list[dict[str, str]] = []
    with httpx.Client(timeout=10, headers={"User-Agent": "AIRevenueEmployeeBot/1.0 (+business onboarding import)"}) as client:
        try:
            final_url, root = fetch_page(url, client)
        except httpx.HTTPError as exc:
            raise bad_request(f"Could not fetch the website: {exc.__class__.__name__}", "fetch_failed") from None
        pages.append({"url": final_url, "title": root.title.strip(), "text": sanitize("".join(root.parts))})
        host = urlparse(final_url).hostname
        wanted = ("about", "service", "faq", "question", "pricing", "area", "contact", "warrant", "financ")
        seen = {final_url.rstrip("/")}
        for href in root.links:
            if len(pages) >= max_pages:
                break
            full = urljoin(final_url, href).split("#")[0].rstrip("/")
            if urlparse(full).hostname != host or full in seen or not any(w in full.lower() for w in wanted):
                continue
            seen.add(full)
            try:
                u, p = fetch_page(full, client)
                pages.append({"url": u, "title": p.title.strip(), "text": sanitize("".join(p.parts))})
            except Exception:
                continue
    return {"description": root.description.strip(), "title": root.title.strip(), "pages": pages}
