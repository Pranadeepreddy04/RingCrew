"""Availability and booking (spec §30, §90). Guarantees:
- only real availability is offered (business hours − existing appointments − external busy time);
- availability is re-checked inside the booking transaction;
- a Postgres exclusion constraint makes double-booking impossible even under concurrency;
- idempotency keys make retries safe;
- success is only reported after the transaction commits."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.ai.nlu import DatePreference
from app.models import Appointment, BusinessProfile, Customer, Organization
from app.providers.calendar import BusyInterval, CalendarError, external_calendar
from app.services.common import utcnow

STEP_MINUTES = 30
DAY_KEYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
ACTIVE_STATUSES = ("scheduled", "confirmed")


@dataclass
class Slot:
    start: datetime
    end: datetime

    def label(self, tz: ZoneInfo) -> str:
        return format_when(self.start, tz)

    def as_dict(self, tz: ZoneInfo) -> dict[str, Any]:
        return {"start": self.start.isoformat(), "end": self.end.isoformat(), "label": self.label(tz)}


def format_when(dt: datetime, tz: ZoneInfo) -> str:
    local = dt.astimezone(tz)
    hour = local.strftime("%I").lstrip("0")
    return f"{local.strftime('%A, %b')} {local.day} at {hour}:{local.strftime('%M %p')}"


def resources_for(org: Organization) -> list[str]:
    cap = int((org.settings or {}).get("booking_capacity", 1) or 1)
    return ["default"] if cap <= 1 else [f"crew-{i + 1}" for i in range(cap)]


def _overlaps(a_start: datetime, a_end: datetime, b_start: datetime, b_end: datetime) -> bool:
    return a_start < b_end and b_start < a_end


def _candidate_starts(profile: BusinessProfile, tz: ZoneInfo, window_start: datetime, window_end: datetime, duration: timedelta) -> list[datetime]:
    out: list[datetime] = []
    day: date = window_start.astimezone(tz).date()
    last_day = window_end.astimezone(tz).date()
    while day <= last_day:
        for rng in (profile.hours or {}).get(DAY_KEYS[day.weekday()], []) or []:
            open_t = time.fromisoformat(rng[0])
            close_t = time.fromisoformat(rng[1])
            cur = datetime.combine(day, open_t, tzinfo=tz)
            close = datetime.combine(day, close_t, tzinfo=tz)
            while cur + duration <= close:
                if cur >= window_start and cur + duration <= window_end:
                    out.append(cur.astimezone(ZoneInfo("UTC")))
                cur += timedelta(minutes=STEP_MINUTES)
        day += timedelta(days=1)
    return out


class AvailabilityError(Exception):
    pass


def available_slots(
    db: Session,
    org: Organization,
    profile: BusinessProfile,
    *,
    window_start: datetime | None = None,
    window_end: datetime | None = None,
    duration_minutes: int | None = None,
    exclude_appointment_id: uuid.UUID | None = None,
) -> list[Slot]:
    """All free slots in the window. Raises AvailabilityError if an external calendar is connected but unavailable."""
    tz = ZoneInfo(org.timezone)
    duration = timedelta(minutes=duration_minutes or profile.appointment_duration_minutes)
    earliest = utcnow() + timedelta(hours=profile.booking_lead_time_hours)
    ws = max(window_start or earliest, earliest)
    we = window_end or (utcnow() + timedelta(days=profile.booking_horizon_days))
    if we <= ws:
        return []
    starts = _candidate_starts(profile, tz, ws, we, duration)
    if not starts:
        return []
    q = select(Appointment).where(
        Appointment.organization_id == org.id, Appointment.status.in_(ACTIVE_STATUSES), Appointment.start_at < we + duration, Appointment.end_at > ws - duration
    )
    if exclude_appointment_id:
        q = q.where(Appointment.id != exclude_appointment_id)
    appts = db.scalars(q).all()
    ext = external_calendar(db, org.id)
    ext_busy: list[BusyInterval] = []
    if ext is not None:
        try:
            ext_busy = ext.busy(ws, we + duration)
        except CalendarError as exc:
            raise AvailabilityError(str(exc)) from exc
    resources = resources_for(org)
    slots: list[Slot] = []
    for s in starts:
        e = s + duration
        if any(_overlaps(s, e, b.start, b.end) for b in ext_busy):
            continue
        for res in resources:
            if not any(a.resource == res and _overlaps(s, e, a.start_at, a.end_at) for a in appts):
                slots.append(Slot(s, e))
                break
    return slots


def pick_offer(slots: list[Slot], tz: ZoneInfo, pref: DatePreference | None, limit: int = 3) -> tuple[list[Slot], bool]:
    """Choose up to `limit` slots to offer. Returns (slots, matched_preference)."""
    if not slots:
        return [], False
    if pref:
        today = utcnow().astimezone(tz).date()
        filtered = slots
        if pref.relative_days is not None:
            target = today + timedelta(days=pref.relative_days)
            filtered = [s for s in filtered if s.start.astimezone(tz).date() == target]
        if pref.weekday is not None:
            filtered = [s for s in filtered if s.start.astimezone(tz).weekday() == pref.weekday]
            if pref.next_week:
                filtered = [s for s in filtered if (s.start.astimezone(tz).date() - today).days >= 7] or filtered
        elif pref.next_week:
            filtered = [s for s in filtered if (s.start.astimezone(tz).date() - today).days >= 7 - today.weekday()]
        if pref.part_of_day:
            rng = {"morning": (0, 12), "afternoon": (12, 17), "evening": (17, 24)}[pref.part_of_day]
            filtered = [s for s in filtered if rng[0] <= s.start.astimezone(tz).hour < rng[1]]
        if filtered:
            # spread across the day(s) rather than three consecutive half hours
            picked: list[Slot] = []
            for s in filtered:
                if all(abs((s.start - p.start).total_seconds()) >= 5400 for p in picked):
                    picked.append(s)
                if len(picked) == limit:
                    break
            return picked, True
    picked = []
    seen_days: set[date] = set()
    for s in slots:
        d = s.start.astimezone(tz).date()
        if d not in seen_days:
            picked.append(s)
            seen_days.add(d)
        if len(picked) == limit:
            break
    return picked, pref is None


@dataclass
class BookingResult:
    ok: bool
    appointment: Appointment | None = None
    error_code: str | None = None
    message: str | None = None
    duplicate: bool = False


def book(
    db: Session,
    org: Organization,
    profile: BusinessProfile,
    *,
    customer: Customer,
    start: datetime,
    service: str,
    source: str,
    idempotency_key: str,
    lead_id: uuid.UUID | None = None,
    conversation_id: uuid.UUID | None = None,
    notes: str | None = None,
    location: str | None = None,
    duration_minutes: int | None = None,
) -> BookingResult:
    """Book within the caller's transaction; the caller must commit before reporting success."""
    existing = db.scalar(select(Appointment).where(Appointment.organization_id == org.id, Appointment.idempotency_key == idempotency_key))
    if existing is not None and existing.status in ACTIVE_STATUSES:
        return BookingResult(True, existing, duplicate=True)
    duration = timedelta(minutes=duration_minutes or profile.appointment_duration_minutes)
    end = start + duration
    try:
        free = available_slots(
            db,
            org,
            profile,
            window_start=start - timedelta(minutes=1),
            window_end=end + timedelta(minutes=1),
            duration_minutes=int(duration.total_seconds() // 60),
        )
    except AvailabilityError as exc:
        return BookingResult(False, error_code="calendar_unavailable", message=str(exc))
    if not any(s.start == start for s in free):
        return BookingResult(False, error_code="slot_unavailable", message="That time is no longer available")
    for resource in resources_for(org):
        appt = Appointment(
            organization_id=org.id,
            customer_id=customer.id,
            lead_id=lead_id,
            conversation_id=conversation_id,
            service=service,
            resource=resource,
            location=location,
            start_at=start,
            end_at=end,
            timezone=org.timezone,
            status="scheduled",
            source=source,
            notes=notes,
            idempotency_key=idempotency_key,
        )
        nested = db.begin_nested()
        try:
            db.add(appt)
            db.flush()
        except IntegrityError as exc:
            nested.rollback()
            if "uq_appt_org_idem" in str(exc.orig):
                dup = db.scalar(select(Appointment).where(Appointment.organization_id == org.id, Appointment.idempotency_key == idempotency_key))
                return BookingResult(True, dup, duplicate=True)
            continue  # exclusion constraint: this resource was taken concurrently; try the next one
        ext = external_calendar(db, org.id)
        if ext is not None:
            try:
                appt.external_event_id = ext.create_event(
                    summary=f"{service} — {customer.name or 'Customer'}",
                    description=f"Booked by AI employee. Phone: {customer.phone or '-'}\n{notes or ''}",
                    start=start,
                    end=end,
                    tz=org.timezone,
                    idempotency_key=str(appt.id).replace("-", ""),
                )
                appt.external_calendar_provider = ext.name
            except CalendarError as exc:
                nested.rollback()
                return BookingResult(False, error_code="calendar_unavailable", message=str(exc))
        nested.commit()
        return BookingResult(True, appt)
    return BookingResult(False, error_code="slot_unavailable", message="That time was just booked by someone else")


def cancel(db: Session, org: Organization, appt: Appointment) -> BookingResult:
    if appt.status not in ACTIVE_STATUSES:
        return BookingResult(False, appt, "not_active", "This appointment is not active")
    if appt.external_event_id and appt.external_calendar_provider:
        ext = external_calendar(db, org.id)
        if ext is not None:
            try:
                ext.delete_event(appt.external_event_id)
            except CalendarError as exc:
                return BookingResult(False, appt, "calendar_unavailable", str(exc))
    appt.status = "cancelled"
    return BookingResult(True, appt)


def reschedule(db: Session, org: Organization, profile: BusinessProfile, appt: Appointment, new_start: datetime) -> BookingResult:
    if appt.status not in ACTIVE_STATUSES:
        return BookingResult(False, appt, "not_active", "This appointment is not active")
    duration = appt.end_at - appt.start_at
    try:
        free = available_slots(
            db,
            org,
            profile,
            window_start=new_start - timedelta(minutes=1),
            window_end=new_start + duration + timedelta(minutes=1),
            duration_minutes=int(duration.total_seconds() // 60),
            exclude_appointment_id=appt.id,
        )
    except AvailabilityError as exc:
        return BookingResult(False, appt, "calendar_unavailable", str(exc))
    if not any(s.start == new_start for s in free):
        return BookingResult(False, appt, "slot_unavailable", "That time is no longer available")
    nested = db.begin_nested()
    old = (appt.start_at, appt.end_at)
    try:
        appt.start_at, appt.end_at = new_start, new_start + duration
        db.flush()
    except IntegrityError:
        nested.rollback()
        return BookingResult(False, appt, "slot_unavailable", "That time was just booked by someone else")
    if appt.external_event_id:
        ext = external_calendar(db, org.id)
        if ext is not None:
            try:
                ext.update_event(appt.external_event_id, start=appt.start_at, end=appt.end_at, tz=org.timezone)
            except CalendarError as exc:
                nested.rollback()
                appt.start_at, appt.end_at = old
                return BookingResult(False, appt, "calendar_unavailable", str(exc))
    nested.commit()
    appt.reminder_sent_at = None
    return BookingResult(True, appt)
