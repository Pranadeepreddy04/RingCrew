"""Explicit response serializers (no accidental leakage of secrets/internal columns)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from app.models import (
    AIAgent,
    Appointment,
    BusinessProfile,
    Conversation,
    Customer,
    Lead,
    Message,
    Organization,
    Service,
    Task,
)


def _iso(d: datetime | None) -> str | None:
    return d.isoformat() if d else None


def org_out(o: Organization) -> dict[str, Any]:
    s = o.settings or {}
    return {
        "id": str(o.id),
        "name": o.name,
        "slug": o.slug,
        "industry": o.industry,
        "timezone": o.timezone,
        "status": o.status,
        "is_demo": o.is_demo,
        "onboarding_step": o.onboarding_step,
        "onboarding_completed": o.onboarding_completed_at is not None,
        "pipeline_stages": s.get("pipeline_stages", []),
        "recording": s.get("recording", {}),
        "ai_settings": s.get("ai", {}),
        "notification_prefs": (s.get("notification_prefs") or {}).get("email", {}),
        "usage_limits": s.get("usage_limits", {}),
        "created_at": _iso(o.created_at),
    }


def profile_out(p: BusinessProfile) -> dict[str, Any]:
    return {
        "website": p.website,
        "phone": p.phone,
        "address": p.address,
        "description": p.description,
        "employees_count": p.employees_count,
        "service_area_zips": p.service_area_zips,
        "service_area_description": p.service_area_description,
        "hours": p.hours,
        "appointment_duration_minutes": p.appointment_duration_minutes,
        "booking_lead_time_hours": p.booking_lead_time_hours,
        "booking_horizon_days": p.booking_horizon_days,
        "emergency_instructions": p.emergency_instructions,
        "escalation_rules": p.escalation_rules,
        "escalation_phone": p.escalation_phone,
        "pricing_info": p.pricing_info,
        "policies": p.policies,
    }


def service_out(s: Service) -> dict[str, Any]:
    return {"id": str(s.id), "name": s.name, "description": s.description, "duration_minutes": s.duration_minutes, "active": s.active}


def agent_out(a: AIAgent, *, include_widget: bool = True) -> dict[str, Any]:
    out = {
        "id": str(a.id),
        "name": a.name,
        "role": a.role,
        "greeting": a.greeting,
        "tone": a.tone,
        "language": a.language,
        "languages": a.languages or [a.language],
        "greetings": a.greetings or {},
        "voice": a.voice,
        "capabilities": a.capabilities,
        "status": a.status,
        "industry": a.industry_template_key,
        "prompt_version": a.prompt_version,
        "pack_overrides": a.pack_overrides,
        "activated_at": _iso(a.activated_at),
        "created_at": _iso(a.created_at),
    }
    if include_widget:
        out["widget_token"] = a.widget_token
        out["widget_settings"] = a.widget_settings
    return out


def customer_out(c: Customer) -> dict[str, Any]:
    return {
        "id": str(c.id),
        "name": c.name,
        "phone": c.phone,
        "email": c.email,
        "address": c.address,
        "zip": c.zip,
        "tags": c.tags,
        "notes": c.notes,
        "sms_opted_out": c.sms_opted_out,
        "communication_preferences": c.communication_preferences,
        "merged_into_id": str(c.merged_into_id) if c.merged_into_id else None,
        "created_at": _iso(c.created_at),
    }


def lead_out(x: Lead) -> dict[str, Any]:
    return {
        "id": str(x.id),
        "customer": {"id": str(x.customer.id), "name": x.customer.name, "phone": x.customer.phone, "email": x.customer.email} if x.customer else None,
        "conversation_id": str(x.conversation_id) if x.conversation_id else None,
        "source": x.source,
        "channel": x.channel,
        "service": x.service,
        "summary": x.summary,
        "status": x.status,
        "is_qualified": x.is_qualified,
        "qualification": x.qualification,
        "urgency": x.urgency,
        "assigned_user_id": str(x.assigned_user_id) if x.assigned_user_id else None,
        "last_activity_at": _iso(x.last_activity_at),
        "next_follow_up_at": _iso(x.next_follow_up_at),
        "estimated_value_cents": x.estimated_value_cents,
        "actual_revenue_cents": x.actual_revenue_cents,
        "attribution_source": x.attribution_source,
        "attribution_confidence": x.attribution_confidence,
        "created_at": _iso(x.created_at),
    }


def appointment_out(a: Appointment) -> dict[str, Any]:
    return {
        "id": str(a.id),
        "customer": {"id": str(a.customer.id), "name": a.customer.name, "phone": a.customer.phone} if a.customer else None,
        "lead_id": str(a.lead_id) if a.lead_id else None,
        "conversation_id": str(a.conversation_id) if a.conversation_id else None,
        "service": a.service,
        "resource": a.resource,
        "location": a.location,
        "start_at": _iso(a.start_at),
        "end_at": _iso(a.end_at),
        "timezone": a.timezone,
        "status": a.status,
        "source": a.source,
        "notes": a.notes,
        "external_calendar_provider": a.external_calendar_provider,
        "created_at": _iso(a.created_at),
    }


def message_out(m: Message) -> dict[str, Any]:
    return {"id": str(m.id), "role": m.role, "content": m.content, "created_at": _iso(m.created_at), "delivery_status": m.delivery_status, "meta": m.meta}


def public_message_out(m: Message) -> dict[str, Any]:
    return {"id": str(m.id), "role": "assistant" if m.role in ("ai", "human") else m.role, "content": m.content, "created_at": _iso(m.created_at)}


def conversation_out(c: Conversation) -> dict[str, Any]:
    st = c.state or {}
    return {
        "id": str(c.id),
        "channel": c.channel,
        "language": c.language or "en",
        "status": c.status,
        "handoff_active": c.handoff_active,
        "handoff_reason": c.handoff_reason,
        "summary": c.summary,
        "customer": {"id": str(c.customer.id), "name": c.customer.name, "phone": c.customer.phone} if c.customer else None,
        "agent_id": str(c.agent_id) if c.agent_id else None,
        "lead_id": str(c.lead_id) if c.lead_id else None,
        "appointment_id": st.get("appointment_id"),
        "collected": st.get("fields", {}),
        "is_test": c.is_test,
        "last_message_at": _iso(c.last_message_at),
        "created_at": _iso(c.created_at),
    }


def task_out(t: Task) -> dict[str, Any]:
    return {
        "id": str(t.id),
        "kind": t.kind,
        "title": t.title,
        "description": t.description,
        "status": t.status,
        "priority": t.priority,
        "conversation_id": str(t.conversation_id) if t.conversation_id else None,
        "lead_id": str(t.lead_id) if t.lead_id else None,
        "customer_id": str(t.customer_id) if t.customer_id else None,
        "assigned_user_id": str(t.assigned_user_id) if t.assigned_user_id else None,
        "due_at": _iso(t.due_at),
        "created_at": _iso(t.created_at),
    }
