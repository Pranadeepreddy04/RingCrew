"""Local telephony simulator (sandbox providers only).

Sends correctly signed Twilio-style webhooks to your running API so you can exercise the SMS and
voice flows end-to-end without a carrier account.

  python -m app.simulate sms  --to +15551234567 --from +19405550123 "My roof is leaking"
  python -m app.simulate call --to +15551234567 --from +19405550123 "My roof is leaking" "house" "76201" "James Carter" "1"

--to must be a number connected to a business (Connections → Phone number).
"""

from __future__ import annotations

import argparse
import re
import sys
import uuid
from urllib.parse import urlencode

import httpx

from app.config import get_settings
from app.providers.messaging import sandbox_webhook_token, twilio_signature


def _post(base: str, public: str, path: str, params: dict[str, str]) -> httpx.Response:
    sig = twilio_signature(sandbox_webhook_token(), public.rstrip("/") + path, params)
    return httpx.post(
        base.rstrip("/") + path, content=urlencode(params), headers={"Content-Type": "application/x-www-form-urlencoded", "X-Twilio-Signature": sig}, timeout=30
    )


def _say(twiml: str) -> str:
    return " ".join(re.findall(r"<Say[^>]*>(.*?)</Say>", twiml)) or twiml


def main() -> None:
    s = get_settings()
    if s.sms_provider != "sandbox" or s.voice_provider != "sandbox":
        sys.exit("The simulator only works with SMS_PROVIDER=sandbox and VOICE_PROVIDER=sandbox")
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["sms", "call"])
    ap.add_argument("--to", required=True)
    ap.add_argument("--from", dest="frm", default="+19405550123")
    ap.add_argument("--base", default="http://localhost:8000/api/v1", help="where to send the webhook")
    ap.add_argument("messages", nargs="+")
    a = ap.parse_args()
    public = s.public_api_url.rstrip("/") + "/api/v1"
    if a.mode == "sms":
        for text in a.messages:
            r = _post(a.base, public, "/webhooks/sms/incoming", {"MessageSid": "SM" + uuid.uuid4().hex, "From": a.frm, "To": a.to, "Body": text})
            print(f"> {text}   [{r.status_code}]  (the worker sends the reply; see the Inbox)")
        return
    call_sid = "CA" + uuid.uuid4().hex
    r = _post(a.base, public, "/webhooks/voice/incoming", {"CallSid": call_sid, "From": a.frm, "To": a.to})
    print("AI:", _say(r.text))
    m = re.search(r"conversation_id=([0-9a-f-]{36})", r.text)
    if not m:
        return
    for text in a.messages:
        r = _post(a.base, public, f"/webhooks/voice/gather?conversation_id={m.group(1)}", {"CallSid": call_sid, "SpeechResult": text, "Confidence": "0.9"})
        print(">", text)
        print("AI:", _say(r.text))
        if "<Hangup/>" in r.text or "<Dial" in r.text:
            break
    _post(a.base, public, "/webhooks/voice/status", {"CallSid": call_sid, "CallStatus": "completed", "CallDuration": "95"})
    print("(call completed)")


if __name__ == "__main__":
    main()
