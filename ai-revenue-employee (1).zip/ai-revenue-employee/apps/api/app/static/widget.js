/* AI Revenue Employee — embeddable website chat widget.
 * Install: <script src="https://YOUR-API/widget.js" data-token="wt_..." async></script>
 * The public token only allows chatting with this AI employee; it grants no admin access. */
(function () {
  "use strict";
  var script = document.currentScript || document.querySelector("script[data-token][src*='widget.js']");
  if (!script) return;
  var TOKEN = script.getAttribute("data-token");
  var API = script.getAttribute("data-api") || new URL(script.src).origin;
  if (!TOKEN || window.__areWidgetLoaded) return;
  window.__areWidgetLoaded = true;
  var STORE = "are_chat_" + TOKEN;
  var state = { conv: null, visitor: null, last: null, open: false, sending: false, cfg: null, seen: {}, lang: null, customerSpoke: false };
  var voice = { on: false, mode: null, ws: null, audio: null, rec: null, muted: false };
  try { var saved = JSON.parse(localStorage.getItem(STORE) || "null"); if (saved) { state.conv = saved.conv; state.visitor = saved.visitor; state.lang = saved.lang || null; } } catch (e) {}

  function persist() { try { localStorage.setItem(STORE, JSON.stringify({ conv: state.conv, visitor: state.visitor, lang: state.lang })); } catch (e) {} }
  function api(path, opts) {
    opts = opts || {};
    var headers = opts.headers || {};
    if (state.visitor) headers["X-Visitor-Token"] = state.visitor;
    if (opts.json !== undefined) { headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(opts.json); }
    return fetch(API + "/api/v1" + path, { method: opts.method || "GET", headers: headers, body: opts.body }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) { if (!r.ok) { var e = new Error((d.error && d.error.message) || "Request failed"); e.status = r.status; throw e; } return d; });
    });
  }

  var host = document.createElement("div");
  host.id = "are-chat-widget";
  document.body.appendChild(host);
  var root = host.attachShadow ? host.attachShadow({ mode: "open" }) : host;

  function render(cfg) {
    var side = cfg.position === "bottom-left" ? "left" : "right";
    var color = cfg.primary_color || "#1f5eff";
    root.innerHTML =
      '<style>' +
      ':host{all:initial}*{box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}' +
      '.launch{position:fixed;bottom:20px;' + side + ':20px;width:60px;height:60px;border-radius:50%;border:0;background:' + color + ';color:#fff;cursor:pointer;box-shadow:0 8px 24px rgba(0,0,0,.2);z-index:2147483646;display:flex;align-items:center;justify-content:center}' +
      '.launch:focus-visible,button:focus-visible,textarea:focus-visible{outline:3px solid #111;outline-offset:2px}' +
      '.panel{position:fixed;bottom:92px;' + side + ':20px;width:370px;max-width:calc(100vw - 24px);height:560px;max-height:calc(100vh - 110px);background:#fff;color:#111;border-radius:16px;box-shadow:0 16px 48px rgba(0,0,0,.22);display:none;flex-direction:column;overflow:hidden;z-index:2147483647}' +
      '.panel.open{display:flex}@media(max-width:480px){.panel{bottom:0;' + side + ':0;width:100vw;max-width:100vw;height:100%;max-height:100%;border-radius:0}}' +
      '.hd{background:' + color + ';color:#fff;padding:14px 16px;display:flex;align-items:center;gap:10px}.hd img{width:32px;height:32px;border-radius:50%;background:#fff;object-fit:cover}' +
      '.hd .t{font-weight:600;font-size:15px;line-height:1.2}.hd .s{font-size:12px;opacity:.85}.hd .x{background:transparent;border:0;color:#fff;font-size:22px;cursor:pointer;padding:4px 8px}' +
      '.demo{background:#fff4d6;color:#6b4e00;font-size:12px;padding:6px 12px;text-align:center}' +
      '.msgs{flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:8px;background:#f7f8fa}' +
      '.m{max-width:82%;padding:9px 12px;border-radius:14px;font-size:14px;line-height:1.4;white-space:pre-wrap;word-wrap:break-word}' +
      '.m.a{background:#fff;border:1px solid #e6e8ec;align-self:flex-start;border-bottom-left-radius:4px}.m.c{background:' + color + ';color:#fff;align-self:flex-end;border-bottom-right-radius:4px}' +
      '.m.sys{align-self:center;background:transparent;color:#666;font-size:12px}' +
      '.typing{align-self:flex-start;color:#777;font-size:13px;padding:4px 8px}' +
      '.ft{border-top:1px solid #e6e8ec;padding:10px;display:flex;gap:8px;align-items:flex-end;background:#fff}' +
      'textarea{flex:1;resize:none;border:1px solid #d5d8de;border-radius:10px;padding:9px 10px;font-size:14px;max-height:120px;min-height:40px;color:#111}' +
      '.send,.att{border:0;border-radius:10px;height:40px;cursor:pointer}.send{background:' + color + ';color:#fff;padding:0 14px;font-weight:600}.send:disabled{opacity:.5;cursor:default}' +
      '.mic{background:#eef0f3;width:40px;height:40px;border:0;border-radius:10px;cursor:pointer;flex-shrink:0;display:flex;align-items:center;justify-content:center;color:#111}.mic.on{background:#c62828;color:#fff}' +
      '.lang{margin-left:auto;background:rgba(255,255,255,.18);color:#fff;border:1px solid rgba(255,255,255,.5);border-radius:8px;font-size:12px;padding:3px 4px;max-width:110px}.lang option{color:#111}' +
      '.vs{font-size:12px;color:#555;padding:4px 12px;background:#fff;display:none}.vs.show{display:block}' +
      '.att{background:#eef0f3;width:40px;font-size:18px}.disc{font-size:11px;color:#777;padding:0 12px 8px;background:#fff}.sr{position:absolute;left:-9999px}' +
      '</style>' +
      '<button class="launch" aria-label="Open chat with ' + esc(cfg.business_name) + '" aria-expanded="false"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4 5h16v11H8l-4 4V5z" stroke="#fff" stroke-width="2" stroke-linejoin="round"/></svg></button>' +
      '<div class="panel" role="dialog" aria-modal="false" aria-label="' + esc(cfg.title) + '">' +
      '<div class="hd">' + (cfg.logo_url ? '<img alt="" src="' + esc(cfg.logo_url) + '">' : "") + '<div><div class="t">' + esc(cfg.title) + '</div><div class="s">' + esc(cfg.agent_name) + (cfg.online ? " · AI assistant" : " · We'll reply soon") + '</div></div>' + langSelect(cfg) + '<button class="x" aria-label="Close chat"' + ((cfg.languages || []).length > 1 ? "" : ' style="margin-left:auto"') + '>×</button></div>' +
      (cfg.is_demo ? '<div class="demo">Demo — no real bookings or messages are made.</div>' : "") +
      '<div class="msgs" aria-live="polite" aria-relevant="additions"></div><div class="vs" aria-live="polite"></div>' +
      '<div class="ft">' + (cfg.uploads_enabled ? '<button class="att" aria-label="Attach a photo">📎</button><input class="file sr" type="file" accept="image/jpeg,image/png,image/webp,image/heic,application/pdf" aria-label="Choose a photo to upload">' : "") +
      (voiceSupported() ? '<button class="mic" aria-pressed="false" aria-label="Talk (voice)"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3" stroke="currentColor" stroke-width="2"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>' : "") +
      '<label class="sr" for="are-input">Type your message</label><textarea id="are-input" dir="auto" rows="1" placeholder="Type your message…" maxlength="2000"></textarea><button class="send" disabled>Send</button></div>' +
      '<div class="disc">' + esc(cfg.sms_disclosure) + '</div></div>';
    var launch = root.querySelector(".launch"), panel = root.querySelector(".panel"), input = root.querySelector("textarea"), send = root.querySelector(".send");
    launch.addEventListener("click", function () { toggle(!state.open); });
    root.querySelector(".x").addEventListener("click", function () { toggle(false); launch.focus(); });
    panel.addEventListener("keydown", function (e) { if (e.key === "Escape") { toggle(false); launch.focus(); } });
    input.addEventListener("input", function () { send.disabled = !input.value.trim() || state.sending; input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 120) + "px"; });
    input.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); } });
    send.addEventListener("click", submit);
    var mic = root.querySelector(".mic");
    if (mic) mic.addEventListener("click", function () { voice.on ? voiceStop() : voiceStart(); });
    var sel = root.querySelector(".lang");
    if (sel) sel.addEventListener("change", function () {
      state.lang = sel.value; persist();
      if (voice.on) { voiceStop(); voiceStart(); }
      // No customer message yet: restart the chat so the greeting is in the chosen language.
      (state.starting || Promise.resolve()).then(function () {
        if (state.conv && !state.customerSpoke) { state.conv = null; state.visitor = null; state.seen = {}; state.last = null; box().innerHTML = ""; persist(); ensureConversation(); }
      });
    });
    var att = root.querySelector(".att"), fileIn = root.querySelector(".file");
    if (att && fileIn) {
      att.addEventListener("click", function () { fileIn.click(); });
      fileIn.addEventListener("change", function () { if (fileIn.files && fileIn.files[0]) upload(fileIn.files[0]); fileIn.value = ""; });
    }
  }

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function box() { return root.querySelector(".msgs"); }
  function add(role, text, id) {
    if (id && state.seen[id]) return;
    if (id) state.seen[id] = true;
    var d = document.createElement("div");
    d.className = "m " + (role === "customer" ? "c" : role === "system" ? "sys" : "a");
    d.setAttribute("dir", "auto");
    d.textContent = text;
    if (role === "customer") state.customerSpoke = true;
    box().appendChild(d);
    box().scrollTop = box().scrollHeight;
  }
  function typing(on) {
    var t = root.querySelector(".typing");
    if (on && !t) { t = document.createElement("div"); t.className = "typing"; t.textContent = state.cfg.agent_name + " is typing…"; box().appendChild(t); box().scrollTop = box().scrollHeight; }
    if (!on && t) t.remove();
  }
  function toggle(open) {
    state.open = open;
    root.querySelector(".panel").classList.toggle("open", open);
    root.querySelector(".launch").setAttribute("aria-expanded", String(open));
    if (open) { ensureConversation().then(function () { root.querySelector("textarea").focus(); }); }
  }
  function ingest(msgs) {
    (msgs || []).forEach(function (m) { add(m.role, m.content, m.id); if (!state.last || m.created_at > state.last) state.last = m.created_at; });
  }
  function ensureConversation() {
    if (state.conv) return api("/public/conversations/" + state.conv + "/messages").then(function (d) { ingest(d.messages); }).catch(function (e) {
      if (e.status === 403 || e.status === 404 || e.status === 401) { state.conv = null; state.visitor = null; persist(); return ensureConversation(); }
    });
    state.starting = api("/public/widget/" + TOKEN + "/conversations", { method: "POST", json: state.lang ? { language: state.lang } : {} }).then(function (d) {
      state.conv = d.conversation_id; state.visitor = d.visitor_token; state.customerSpoke = false; setLang(d.language); persist(); ingest(d.messages);
    }).catch(function () { add("system", "Chat is unavailable right now. Please call us instead."); }).then(function () { state.starting = null; });
    return state.starting;
  }
  function submit(spoken) {
    var input = root.querySelector("textarea"), text = typeof spoken === "string" ? spoken : input.value.trim();
    if (!text || state.sending || !state.conv) return;
    state.sending = true; root.querySelector(".send").disabled = true;
    input.value = ""; input.style.height = "auto";
    add("customer", text); typing(true);
    api("/public/conversations/" + state.conv + "/messages", { method: "POST", json: { text: text } }).then(function (d) {
      if (d.customer_message_id) state.seen[d.customer_message_id] = true;
      typing(false); ingest(d.messages); setLang(d.language); speakReplies(d.messages);
    }).catch(function (e) { typing(false); add("system", e.status === 429 ? "You're sending messages too quickly — please wait a moment." : "Message not sent. Please try again."); })
      .then(function () { state.sending = false; root.querySelector(".send").disabled = !root.querySelector("textarea").value.trim(); });
  }
  function upload(file) {
    if (!state.conv) return;
    add("system", "Uploading " + file.name + "…");
    api("/public/conversations/" + state.conv + "/upload-token").then(function (t) {
      var fd = new FormData(); fd.append("file", file);
      return fetch(API + "/api/v1/public/uploads", { method: "POST", headers: { "X-Upload-Token": t.upload_token }, body: fd }).then(function (r) {
        return r.json().then(function (d) { if (!r.ok) throw new Error((d.error && d.error.message) || "Upload failed"); return d; });
      });
    }).then(function (d) { add("system", "Uploaded " + d.filename + ". Thank you!"); }).catch(function (e) { add("system", e.message); });
  }
  function poll() {
    if (state.open && state.conv && !state.sending) {
      api("/public/conversations/" + state.conv + "/messages" + (state.last ? "?after=" + encodeURIComponent(state.last) : "")).then(function (d) { ingest(d.messages); }).catch(function () {});
    }
    setTimeout(poll, 5000);
  }
  // ---------------------------------------------------------------- languages
  function langInfo(code) { var l = (state.cfg && state.cfg.languages) || []; for (var i = 0; i < l.length; i++) if (l[i].code === code) return l[i]; return l[0] || { code: "en", bcp47: "en-US", native: "English" }; }
  function langSelect(cfg) {
    var l = cfg.languages || [];
    if (l.length < 2) return "";
    var cur = state.lang || "";
    return '<select class="lang" aria-label="Language"><option value=""' + (cur ? "" : " selected") + '>🌐 Auto</option>' + l.map(function (x) {
      return '<option value="' + esc(x.code) + '"' + (cur === x.code ? " selected" : "") + ">" + esc(x.native) + "</option>";
    }).join("") + "</select>";
  }
  function setLang(code) { if (code) state.current = code; }

  // ---------------------------------------------------------------- voice
  // Streams the microphone to the server's VibeVoice-ASR-Streaming socket when available, otherwise uses the
  // browser's speech recognition. Replies are read aloud with the browser's speech synthesis; the microphone is
  // muted while the agent talks so it does not hear itself.
  function Recognition() { return window.SpeechRecognition || window.webkitSpeechRecognition || null; }
  function voiceSupported() { return !!(Recognition() || (navigator.mediaDevices && window.AudioContext && window.WebSocket)); }
  function vstatus(t) { var v = root.querySelector(".vs"); if (!v) return; v.textContent = t || ""; v.classList.toggle("show", !!t); }
  function micUi(on) { var m = root.querySelector(".mic"); if (m) { m.classList.toggle("on", on); m.setAttribute("aria-pressed", String(on)); m.setAttribute("aria-label", on ? "Stop voice" : "Talk (voice)"); } }
  function curLang() { return state.lang || state.current || (state.cfg && state.cfg.default_language) || "en"; }
  function speakReplies(msgs) {
    if (!voice.on || !msgs || !msgs.length) return;
    var text = msgs.map(function (m) { return m.content; }).join(" ");
    if (!("speechSynthesis" in window)) { resume(); return; }
    voice.muted = true;
    var u = new SpeechSynthesisUtterance(text), bcp = langInfo(curLang()).bcp47;
    u.lang = bcp;
    var vs = window.speechSynthesis.getVoices(), pick = null;
    for (var i = 0; i < vs.length; i++) { if (vs[i].lang === bcp) { pick = vs[i]; break; } if (!pick && vs[i].lang.indexOf(bcp.split("-")[0]) === 0) pick = vs[i]; }
    if (pick) u.voice = pick;
    u.onend = u.onerror = resume;
    window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
  }
  function resume() {
    voice.muted = false;
    if (voice.on && voice.mode === "browser" && voice.rec) { try { voice.rec.lang = langInfo(curLang()).bcp47; voice.rec.start(); } catch (e) {} }
  }
  function voiceStart() {
    if (!state.conv) return;
    voice.on = true; voice.muted = false; micUi(true);
    var vi = state.cfg.voice_input || {};
    if (vi.asr === "vibevoice" && (vi.vibevoice_languages || []).indexOf(curLang()) >= 0 && navigator.mediaDevices) streamStart();
    else browserStart();
  }
  function voiceStop() {
    voice.on = false; voice.mode = null; micUi(false); vstatus("");
    try { if (voice.ws) { voice.ws.send(JSON.stringify({ type: "close" })); voice.ws.close(); } } catch (e) {}
    voice.ws = null;
    if (voice.audio) { try { voice.audio.node.disconnect(); voice.audio.src.disconnect(); voice.audio.media.getTracks().forEach(function (t) { t.stop(); }); voice.audio.ctx.close(); } catch (e) {} voice.audio = null; }
    if (voice.rec) { try { voice.rec.abort(); } catch (e) {} voice.rec = null; }
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  }
  function browserStart() {
    var R = Recognition();
    if (!R) { vstatus("Voice isn't supported in this browser."); voiceStop(); return; }
    var r = new R();
    r.lang = langInfo(curLang()).bcp47; r.continuous = false; r.interimResults = true;
    r.onresult = function (e) {
      var interim = "";
      for (var i = e.resultIndex; i < e.results.length; i++) {
        var res = e.results[i];
        if (res.isFinal) { var t = res[0].transcript.trim(); vstatus("Listening…"); if (t) { voice.muted = true; submit(t); } }
        else interim += res[0].transcript;
      }
      if (interim) vstatus("🎙 " + interim);
    };
    r.onerror = function (e) { if (e.error === "not-allowed" || e.error === "service-not-allowed") { vstatus("Microphone permission was denied."); voiceStop(); } };
    r.onend = function () { if (voice.on && !voice.muted && voice.rec === r) { try { r.start(); } catch (e) {} } };
    voice.rec = r; voice.mode = "browser"; vstatus("Listening…");
    try { r.start(); } catch (e) {}
  }
  function streamStart() {
    var sock = new WebSocket(API.replace(/^http/, "ws") + "/api/v1/public/conversations/" + state.conv + "/voice");
    voice.ws = sock;
    navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 } }).then(function (media) {
      var ctx = new (window.AudioContext || window.webkitAudioContext)();
      var begin = function () { sock.send(JSON.stringify({ type: "start", visitor_token: state.visitor, sample_rate: ctx.sampleRate, format: "f32", language: curLang() })); };
      if (sock.readyState === 1) begin(); else sock.onopen = begin;
      var heard = "";
      sock.onmessage = function (ev) {
        var m = JSON.parse(ev.data);
        if (m.type === "ready") {
          voice.mode = "stream"; vstatus("Listening… (VibeVoice)");
          var src = ctx.createMediaStreamSource(media), node = ctx.createScriptProcessor(4096, 1, 1);
          node.onaudioprocess = function (e) { if (!voice.muted && sock.readyState === 1) sock.send(new Float32Array(e.inputBuffer.getChannelData(0)).buffer); };
          src.connect(node); node.connect(ctx.destination);
          voice.audio = { ctx: ctx, media: media, node: node, src: src };
        } else if (m.type === "unavailable") {
          media.getTracks().forEach(function (t) { t.stop(); }); ctx.close(); voice.ws = null; browserStart();
        } else if (m.type === "partial") vstatus("🎙 " + m.text);
        else if (m.type === "final") { heard = m.text; vstatus("Listening…"); if (heard) { state.sending = true; add("customer", heard); typing(true); } }
        else if (m.type === "reply") {
          if (m.customer_message_id) state.seen[m.customer_message_id] = true;
          state.sending = false; typing(false); voice.muted = true; ingest(m.messages); setLang(m.language); speakReplies(m.messages);
        }
        else if (m.type === "error") vstatus("Voice is unavailable right now.");
      };
    }).catch(function () { vstatus("Microphone permission was denied."); voiceStop(); });
  }

  api("/public/widget/" + TOKEN + "/config").then(function (cfg) { state.cfg = cfg; render(cfg); poll(); }).catch(function () { host.remove(); });
})();
