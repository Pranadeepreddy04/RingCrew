"""Real-time voice plumbing shared by the phone media stream and the browser voice socket.

* ``mulaw_decode``      — Twilio Media Streams deliver 8 kHz G.711 μ-law; convert to float32 PCM.
* ``Endpointer``        — energy-based voice activity detection with an adaptive noise floor. Decides where a caller's
                          utterance starts (with 300 ms of pre-roll so the first syllable is not clipped) and where it
                          ends (``silence_ms`` of quiet after speech, or a hard cap on utterance length).
* ``StreamingRecognizer`` — opens one ASR session per utterance, streams the audio to it while the caller speaks,
                          reports partial transcripts, and returns the flushed final transcript at end of speech.
"""

from __future__ import annotations

import logging
from collections import deque
from collections.abc import Awaitable, Callable
from dataclasses import dataclass

import numpy as np

from app.providers.asr import ASRError, ASRProvider, ASRSession

log = logging.getLogger(__name__)


def _mulaw_table() -> np.ndarray:
    u = np.arange(256, dtype=np.int32)
    u = ~u & 0xFF
    sign = u & 0x80
    exponent = (u >> 4) & 0x07
    mantissa = u & 0x0F
    sample = ((mantissa << 3) + 0x84) << exponent
    sample -= 0x84
    sample = np.where(sign != 0, -sample, sample)
    return (sample.astype(np.float32) / 32768.0).astype(np.float32)


_MULAW = _mulaw_table()


def mulaw_decode(data: bytes) -> np.ndarray:
    return _MULAW[np.frombuffer(data, dtype=np.uint8)]


def mulaw_encode(pcm: np.ndarray) -> bytes:
    """float32 [-1, 1] -> μ-law bytes (used by tests to synthesize telephone audio)."""
    x = np.clip(np.asarray(pcm, dtype=np.float64), -1.0, 1.0) * 32767.0
    sign = np.where(x < 0, 0x80, 0x00)
    mag = np.minimum(np.abs(x) + 0x84, 32635).astype(np.int32)
    exponent = np.floor(np.log2(np.maximum(mag, 1))).astype(np.int32) - 7
    exponent = np.clip(exponent, 0, 7)
    mantissa = (mag >> (exponent + 3)) & 0x0F
    return (~(sign | (exponent << 4) | mantissa) & 0xFF).astype(np.uint8).tobytes()


def pcm16_to_float(data: bytes) -> np.ndarray:
    return np.frombuffer(data, dtype="<i2").astype(np.float32) / 32768.0


@dataclass
class VadEvent:
    kind: str  # "start" | "audio" | "end"
    audio: np.ndarray | None = None


class Endpointer:
    FRAME_MS = 20

    def __init__(
        self,
        sample_rate: int,
        *,
        silence_ms: int = 700,
        min_speech_ms: int = 120,
        preroll_ms: int = 300,
        max_utterance_ms: int = 30_000,
        threshold_db: float = -42.0,
    ) -> None:
        self.sr = sample_rate
        self.frame = int(sample_rate * self.FRAME_MS / 1000)
        self.silence_frames = max(1, silence_ms // self.FRAME_MS)
        self.min_speech_frames = max(1, min_speech_ms // self.FRAME_MS)
        self.max_frames = max_utterance_ms // self.FRAME_MS
        self.threshold_db = threshold_db
        self.noise_db = -60.0
        self._buf = np.zeros(0, dtype=np.float32)
        self._preroll: deque[np.ndarray] = deque(maxlen=max(1, preroll_ms // self.FRAME_MS))
        self.in_speech = False
        self._voiced_run = 0
        self._silence_run = 0
        self._frames = 0

    def _is_voiced(self, frame: np.ndarray) -> bool:
        rms = float(np.sqrt(np.mean(frame.astype(np.float64) ** 2)) + 1e-9)
        db = 20 * np.log10(rms)
        voiced = db > max(self.threshold_db, self.noise_db + 12.0)
        if not voiced:  # track the background level slowly so a noisy line does not count as speech
            self.noise_db = 0.95 * self.noise_db + 0.05 * db
        return voiced

    def feed(self, pcm: np.ndarray) -> list[VadEvent]:
        self._buf = np.concatenate([self._buf, np.asarray(pcm, dtype=np.float32)])
        events: list[VadEvent] = []
        while len(self._buf) >= self.frame:
            frame, self._buf = self._buf[: self.frame], self._buf[self.frame :]
            voiced = self._is_voiced(frame)
            if not self.in_speech:
                self._preroll.append(frame)
                self._voiced_run = self._voiced_run + 1 if voiced else 0
                if self._voiced_run >= self.min_speech_frames:
                    self.in_speech = True
                    self._silence_run = 0
                    self._frames = len(self._preroll)
                    events.append(VadEvent("start", np.concatenate(list(self._preroll))))
                    self._preroll.clear()
                continue
            events.append(VadEvent("audio", frame))
            self._frames += 1
            self._silence_run = 0 if voiced else self._silence_run + 1
            if self._silence_run >= self.silence_frames or self._frames >= self.max_frames:
                events.append(VadEvent("end"))
                self.in_speech = False
                self._voiced_run = 0
        return events

    def force_end(self) -> list[VadEvent]:
        if not self.in_speech:
            return []
        self.in_speech = False
        self._voiced_run = 0
        return [VadEvent("end")]


OnText = Callable[[str], Awaitable[None]]
OnEvent = Callable[[], Awaitable[None]]


class StreamingRecognizer:
    """Feeds audio through the endpointer and an ASR provider; calls back with partials and per-utterance finals."""

    SEND_MS = 100

    def __init__(
        self,
        provider: ASRProvider,
        *,
        sample_rate: int,
        language: str,
        hotwords: str = "",
        silence_ms: int = 700,
        on_speech_start: OnEvent | None = None,
        on_partial: OnText | None = None,
        on_final: OnText | None = None,
        on_error: OnText | None = None,
    ) -> None:
        self.provider = provider
        self.sr = sample_rate
        self.language = language
        self.hotwords = hotwords
        self.vad = Endpointer(sample_rate, silence_ms=silence_ms)
        self.on_speech_start, self.on_partial, self.on_final, self.on_error = on_speech_start, on_partial, on_final, on_error
        self.session: ASRSession | None = None
        self._pending: list[np.ndarray] = []
        self._pending_len = 0
        self._last_partial = ""
        self.utterances = 0

    async def feed(self, pcm: np.ndarray) -> None:
        for ev in self.vad.feed(pcm):
            await self._handle(ev)

    async def end_of_speech(self) -> None:
        """Push-to-talk release / stream stop: finish the current utterance now."""
        for ev in self.vad.force_end():
            await self._handle(ev)

    async def _handle(self, ev: VadEvent) -> None:
        if ev.kind == "start":
            if self.on_speech_start:
                await self.on_speech_start()
            try:
                self.session = await self.provider.open(language=self.language, hotwords=self.hotwords)
            except Exception as e:
                self.session = None
                log.warning("asr open failed: %s", e)
                if self.on_error:
                    await self.on_error("asr_unavailable")
                return
            self._last_partial = ""
            self.session.on_partial = self._partial
            await self._queue(ev.audio, force=True)
        elif ev.kind == "audio":
            await self._queue(ev.audio)
        elif ev.kind == "end":
            await self._queue(None, force=True)
            session, self.session = self.session, None
            if session is None:
                return
            try:
                text = await session.finish()
            except (ASRError, Exception) as e:
                log.warning("asr finish failed: %s", e)
                if self.on_error:
                    await self.on_error("asr_failed")
                return
            self.utterances += 1
            if self.on_final:
                await self.on_final(text)

    async def _queue(self, audio: np.ndarray | None, force: bool = False) -> None:
        if audio is not None and len(audio):
            self._pending.append(audio)
            self._pending_len += len(audio)
        if self.session is None:
            self._pending, self._pending_len = [], 0
            return
        if self._pending and (force or self._pending_len >= self.sr * self.SEND_MS // 1000):
            chunk = np.concatenate(self._pending)
            self._pending, self._pending_len = [], 0
            try:
                await self.session.send_audio(chunk, self.sr)
            except Exception as e:
                log.warning("asr send failed: %s", e)

    async def _partial(self, text: str) -> None:
        if self.on_partial and text and text != self._last_partial:
            self._last_partial = text
            await self.on_partial(text)
