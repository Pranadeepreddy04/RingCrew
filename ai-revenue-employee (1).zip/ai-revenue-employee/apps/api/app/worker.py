"""Background worker: durable Postgres job queue + workflow scheduler + maintenance (spec §31, §38, §40).

Run: python -m app.worker            (loop)
     python -m app.worker --once     (single pass, used by tests/cron)"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import logging
import signal
import time
import uuid
from datetime import timedelta
from typing import Any, Callable

import httpx
from sqlalchemy import delete, select, text, update
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import SessionLocal
from app.models import Job, Lead, Message, Organization, User, WebhookDelivery, WebhookEndpoint, WorkflowRun
from app.observability import configure_logging, metrics
from app.security import decrypt
from app.services.common import utcnow

log = logging.getLogger("app.worker")
BACKOFF = [30, 120, 600, 1800, 7200, 21600]


def sign_webhook(secret: str, body: bytes, ts: int) -> str:
    return hmac.new(secret.encode(), f"{ts}.".encode() + body, hashlib.sha256).hexdigest()


def _deliver_webhook(db: Session, payload: dict[str, Any]) -> str:
    d = db.get(WebhookDelivery, uuid.UUID(payload["delivery_id"]))
    if d is None or d.status == "delivered":
        return "skip"
    ep = db.get(WebhookEndpoint, d.endpoint_id)
    if ep is None or not ep.active:
        d.status = "failed"
        d.last_error = "endpoint removed or inactive"
        return "skip"
    body = json.dumps(d.payload, separators=(",", ":"), default=str).encode()
    ts = int(time.time())
    sig = sign_webhook(decrypt(ep.secret_encrypted), body, ts)
    d.attempts += 1
    try:
        r = httpx.post(
            ep.url,
            content=body,
            timeout=10,
            follow_redirects=False,
            headers={
                "Content-Type": "application/json",
                "User-Agent": "AIRevenueEmployee-Webhooks/1.0",
                "X-ARE-Event": d.event_type,
                "X-ARE-Delivery": str(d.id),
                "X-ARE-Signature": f"t={ts},v1={sig}",
                "Idempotency-Key": str(d.payload.get("id")),
            },
        )
        d.response_code = r.status_code
        if 200 <= r.status_code < 300:
            d.status, d.delivered_at, d.last_error = "delivered", utcnow(), None
            return "delivered"
        d.last_error = f"HTTP {r.status_code}"
    except httpx.HTTPError as exc:
        d.last_error = exc.__class__.__name__
    db.commit()  # keep the attempt record even though the job will be retried
    raise RuntimeError(d.last_error or "delivery failed")


def _notification_email(db: Session, payload: dict[str, Any]) -> str:
    from app.providers.email import send_email

    user = db.get(User, uuid.UUID(payload["user_id"]))
    if user is None or not user.is_active:
        return "skip"
    link = f"{get_settings().public_web_url}{payload.get('link') or '/app'}"
    res = send_email(db, user.email, payload["title"], f"{payload['title']}\n\n{payload.get('body') or ''}\n\nOpen: {link}")
    if not res.ok:
        raise RuntimeError(res.error or "email failed")
    return res.status


def _sms_respond(db: Session, payload: dict[str, Any]) -> str:
    from app.routers.voice_sms import respond_to_sms

    return respond_to_sms(db, uuid.UUID(payload["conversation_id"]), payload["text"], payload["message_sid"])


def _crm_sync(db: Session, payload: dict[str, Any]) -> str:
    from app.models import Customer, Integration
    from app.providers.crm import CRMError, crm_adapter

    lead = db.get(Lead, uuid.UUID(payload["lead_id"]))
    if lead is None:
        return "skip"
    integ = db.scalar(
        select(Integration).where(Integration.organization_id == lead.organization_id, Integration.kind == "crm", Integration.status != "disconnected")
    )
    if integ is None:
        return "no_crm"
    adapter = crm_adapter(integ)
    customer = db.get(Customer, lead.customer_id)
    if adapter is None or customer is None:
        return "skip"
    try:
        ids = adapter.upsert_lead(lead, customer)
    except CRMError as exc:
        integ.last_error = str(exc)
        if not exc.retryable:
            integ.status = "error"
            from app.services.common import notify

            notify(db, lead.organization_id, "integration.disconnected", "CRM sync failed", str(exc), "/app/integrations", roles=("owner",))
            return "failed_permanent"
        raise
    lead.qualification = {**(lead.qualification or {}), "_external": {**(lead.qualification or {}).get("_external", {}), **ids}}
    integ.last_sync_at, integ.status, integ.last_error = utcnow(), "connected", None
    return "synced"


def _tenant_purge(db: Session, payload: dict[str, Any]) -> str:
    from app.routers.organizations import purge_tenant

    purge_tenant(db, uuid.UUID(payload["organization_id"]))
    return "purged"


HANDLERS: dict[str, Callable[[Session, dict[str, Any]], str]] = {
    "webhook.deliver": _deliver_webhook,
    "notification.email": _notification_email,
    "sms.respond": _sms_respond,
    "crm.sync_lead": _crm_sync,
    "tenant.purge": _tenant_purge,
}


def process_jobs(limit: int = 20) -> int:
    n = 0
    with SessionLocal() as db:
        jobs = db.scalars(
            select(Job).where(Job.status == "queued", Job.run_at <= utcnow()).order_by(Job.run_at).limit(limit).with_for_update(skip_locked=True)
        ).all()
        ids = [j.id for j in jobs]
        for j in jobs:
            j.status, j.locked_at = "running", utcnow()
        db.commit()
    for jid in ids:
        with SessionLocal() as db:
            job = db.get(Job, jid)
            if job is None:
                continue
            handler = HANDLERS.get(job.kind)
            try:
                if handler is None:
                    raise RuntimeError(f"no handler for {job.kind}")
                result = handler(db, job.payload)
                job.status, job.last_error = "done", None
                metrics.inc("jobs_total", kind=job.kind, status="done")
                log.info("job_done", extra={"job_id": str(job.id), "kind": job.kind, "result": result})
                db.commit()
            except Exception as exc:
                db.rollback()
                job = db.get(Job, jid)
                assert job is not None
                job.attempts += 1
                job.last_error = str(exc)[:1000]
                if job.attempts >= job.max_attempts:
                    job.status = "failed"
                    metrics.inc("jobs_total", kind=job.kind, status="failed")
                    log.error("job_failed", extra={"job_id": str(job.id), "kind": job.kind, "error": job.last_error})
                    if job.kind == "webhook.deliver":
                        d = db.get(WebhookDelivery, uuid.UUID(job.payload["delivery_id"]))
                        if d:
                            d.status = "failed"
                else:
                    job.status = "queued"
                    job.run_at = utcnow() + timedelta(seconds=BACKOFF[min(job.attempts - 1, len(BACKOFF) - 1)])
                    metrics.inc("jobs_total", kind=job.kind, status="retry")
                job.locked_at = None
                db.commit()
            n += 1
    return n


def process_workflows(limit: int = 50) -> int:
    from app.services.automation import process_run

    n = 0
    with SessionLocal() as db:
        runs = db.scalars(
            select(WorkflowRun)
            .where(WorkflowRun.status == "active", WorkflowRun.next_run_at <= utcnow())
            .order_by(WorkflowRun.next_run_at)
            .limit(limit)
            .with_for_update(skip_locked=True)
        ).all()
        for run in runs:
            try:
                with db.begin_nested():
                    outcome = process_run(db, run)
                metrics.inc("workflow_steps_total", outcome=outcome)
            except Exception as exc:
                log.exception("workflow_run_error", extra={"run_id": str(run.id)})
                run.status, run.last_error, run.next_run_at = "failed", str(exc)[:500], None
            n += 1
        db.commit()
    return n


def maintenance() -> None:
    with SessionLocal() as db:
        # recover jobs stuck in 'running' (worker crashed mid-job)
        db.execute(
            update(Job)
            .where(Job.status == "running", Job.locked_at < utcnow() - timedelta(minutes=10))  # type: ignore[attr-defined]
            .values(status="queued", locked_at=None)
        )
        # expire demo sandboxes
        for org in db.scalars(select(Organization).where(Organization.is_demo.is_(True), Organization.demo_expires_at < utcnow() - timedelta(hours=1))).all():
            db.execute(delete(Organization).where(Organization.id == org.id))
        # per-tenant retention: redact message bodies older than the configured number of days
        for org in db.scalars(select(Organization).where(Organization.deleted_at.is_(None))).all():
            days = int(((org.settings or {}).get("retention") or {}).get("message_days") or 0)
            if days > 0:
                db.execute(
                    update(Message)
                    .where(
                        Message.organization_id == org.id,
                        Message.created_at < utcnow() - timedelta(days=days),  # type: ignore[attr-defined]
                        Message.content != "[expired]",
                    )
                    .values(content="[expired]", meta={})
                )
        db.execute(text("DELETE FROM inbound_webhook_events WHERE created_at < now() - interval '30 days'"))
        db.commit()


def run_once() -> dict[str, int]:
    return {"jobs": process_jobs(), "workflows": process_workflows()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()
    configure_logging(get_settings().log_level)
    if args.once:
        print(run_once())
        maintenance()
        return
    stop = False

    def _stop(*_: Any) -> None:
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, _stop)
    signal.signal(signal.SIGINT, _stop)
    last_maint = 0.0
    log.info("worker_started")
    while not stop:
        try:
            did = run_once()
            if time.time() - last_maint > 300:
                maintenance()
                last_maint = time.time()
        except Exception:
            log.exception("worker_loop_error")
            did = {"jobs": 0, "workflows": 0}
        if not any(did.values()):
            time.sleep(2)
    log.info("worker_stopped")


if __name__ == "__main__":
    main()
