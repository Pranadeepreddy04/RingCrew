"""Use clock_timestamp() for created_at/updated_at so rows written in one transaction keep their real order
(e.g. a customer message and the AI reply stored in the same request).

Revision ID: 0002
Revises: 0001
"""
from __future__ import annotations

from alembic import op
from sqlalchemy import text

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

_Q = text(
    "SELECT table_name, column_name FROM information_schema.columns "
    "WHERE table_schema = current_schema() AND column_name IN ('created_at', 'updated_at', 'last_message_at', 'last_activity_at', 'run_at', 'recorded_at') "
    "AND column_default LIKE :d"
)


def _swap(old: str, new: str) -> None:
    conn = op.get_bind()
    for table, column in conn.execute(_Q, {"d": f"{old}%"}).all():
        op.execute(f'ALTER TABLE "{table}" ALTER COLUMN "{column}" SET DEFAULT {new}')


def upgrade() -> None:
    _swap("now()", "clock_timestamp()")


def downgrade() -> None:
    _swap("clock_timestamp()", "now()")
