"""Multilingual AI employees: enabled languages, per-language greetings, conversation language.

Revision ID: 0003
Revises: 0002
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("ai_agents", sa.Column("languages", postgresql.JSONB(), nullable=False, server_default=sa.text("'[\"en\"]'::jsonb")))
    op.add_column("ai_agents", sa.Column("greetings", postgresql.JSONB(), nullable=False, server_default=sa.text("'{}'::jsonb")))
    op.add_column("conversations", sa.Column("language", sa.String(length=10), nullable=True))
    # existing agents keep their configured language as the only enabled one
    op.execute("UPDATE ai_agents SET languages = jsonb_build_array(language)")


def downgrade() -> None:
    op.drop_column("conversations", "language")
    op.drop_column("ai_agents", "greetings")
    op.drop_column("ai_agents", "languages")
