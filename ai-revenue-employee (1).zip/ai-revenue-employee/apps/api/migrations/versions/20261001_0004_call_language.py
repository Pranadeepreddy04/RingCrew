"""Call language and speech-recognition provider.

Revision ID: 0004
Revises: 0003
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("calls", sa.Column("language", sa.String(10), nullable=True))
    op.add_column("calls", sa.Column("asr_provider", sa.String(20), nullable=True))


def downgrade() -> None:
    op.drop_column("calls", "asr_provider")
    op.drop_column("calls", "language")
