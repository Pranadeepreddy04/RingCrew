from __future__ import annotations

import os

os.environ.setdefault("APP_ENV", "test")
os.environ["DATABASE_URL"] = os.environ.get("TEST_DATABASE_URL", "postgresql+psycopg://postgres:postgres@localhost:5432/are_test")
os.environ.setdefault("SECRET_KEY", "test-secret-key-0123456789abcdef0123456789")
os.environ.setdefault("STORAGE_DIR", "/tmp/are-test-storage")
os.environ["PRIMARY_LLM_PROVIDER"] = "sandbox"
os.environ["SMS_PROVIDER"] = "sandbox"
os.environ["VOICE_PROVIDER"] = "sandbox"
os.environ["BILLING_PROVIDER"] = "sandbox"
os.environ["EMAIL_PROVIDER"] = "sandbox"
os.environ["PUBLIC_API_URL"] = "http://testserver"

import uuid  # noqa: E402
from collections.abc import Iterator  # noqa: E402
from typing import Any  # noqa: E402

import pytest  # noqa: E402
from alembic import command  # noqa: E402
from alembic.config import Config  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from sqlalchemy import text  # noqa: E402

from app.db import SessionLocal, engine  # noqa: E402

API_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


@pytest.fixture(scope="session", autouse=True)
def _migrate() -> Iterator[None]:
    with engine.begin() as c:
        c.execute(text("DROP SCHEMA public CASCADE; CREATE SCHEMA public;"))
    cfg = Config(os.path.join(API_DIR, "alembic.ini"))
    cfg.set_main_option("script_location", os.path.join(API_DIR, "migrations"))
    command.upgrade(cfg, "head")  # migrations from an empty database (spec §82)
    from app.cli import bootstrap

    bootstrap()
    yield


KEEP = {"alembic_version", "industry_templates", "plans"}


@pytest.fixture(autouse=True)
def _clean() -> Iterator[None]:
    yield
    with engine.begin() as c:
        tables = [r[0] for r in c.execute(text("SELECT tablename FROM pg_tables WHERE schemaname='public'"))]
        c.execute(text("TRUNCATE " + ", ".join(t for t in tables if t not in KEEP) + " CASCADE"))
    from app.ai.llm import clear_provider_override
    from app.providers.calendar import SandboxCalendar
    from app.providers.messaging import SandboxSms

    clear_provider_override()
    SandboxCalendar.busy_blocks = []
    SandboxCalendar.fail = False
    SandboxCalendar.events = {}
    SandboxSms.outbox = []
    SandboxSms.fail_next = 0
    from app.providers.asr import SandboxASR, VibeVoiceASR
    from app.providers.messaging import SandboxVoice

    SandboxVoice.updates = []
    SandboxASR.script.clear()
    VibeVoiceASR._config_cache.clear()


@pytest.fixture()
def app():  # type: ignore[no-untyped-def]
    from app.main import app as fastapi_app

    return fastapi_app


class Api:
    """Test client that behaves like the web app: cookie session + CSRF header + organization header."""

    def __init__(self, app: Any) -> None:
        self.c = TestClient(app)
        self.csrf: str | None = None
        self.org_id: str | None = None

    def _h(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        h = {}
        if self.csrf:
            h["X-CSRF-Token"] = self.csrf
        if self.org_id:
            h["X-Organization-Id"] = self.org_id
        h.update(extra or {})
        return h

    def get(self, path: str, **kw: Any) -> Any:
        return self.c.get("/api/v1" + path, headers=self._h(kw.pop("headers", None)), **kw)

    def post(self, path: str, json: Any = None, **kw: Any) -> Any:
        return self.c.post("/api/v1" + path, json=json, headers=self._h(kw.pop("headers", None)), **kw)

    def put(self, path: str, json: Any = None, **kw: Any) -> Any:
        return self.c.put("/api/v1" + path, json=json, headers=self._h(kw.pop("headers", None)), **kw)

    def patch(self, path: str, json: Any = None, **kw: Any) -> Any:
        return self.c.patch("/api/v1" + path, json=json, headers=self._h(kw.pop("headers", None)), **kw)

    def delete(self, path: str, json: Any = None, **kw: Any) -> Any:
        return self.c.request("DELETE", "/api/v1" + path, json=json, headers=self._h(kw.pop("headers", None)), **kw)

    def signup(self, email: str | None = None, password: str = "Sup3r-secret-pw", name: str = "Test Owner") -> dict[str, Any]:
        email = email or f"owner-{uuid.uuid4().hex[:8]}@example.com"
        r = self.post("/auth/signup", {"name": name, "email": email, "password": password})
        assert r.status_code == 201, r.text
        self.csrf = r.json()["csrf_token"]
        self.email, self.password = email, password
        return r.json()

    def login(self, email: str, password: str) -> Any:
        r = self.post("/auth/login", {"email": email, "password": password})
        if r.status_code == 200:
            self.csrf = r.json()["csrf_token"]
        return r

    def create_org(self, name: str = "Mike's Roofing", industry: str = "roofing", zips: list[str] | None = None) -> dict[str, Any]:
        r = self.post(
            "/organizations",
            {
                "name": name,
                "industry": industry,
                "timezone": "America/Chicago",
                "service_area_zips": zips if zips is not None else ["76201", "76205"],
                "phone": "+19405550100",
            },
        )
        assert r.status_code == 201, r.text
        self.org_id = r.json()["id"]
        return r.json()


@pytest.fixture()
def api(app: Any) -> Api:
    return Api(app)


def make_business(api: Api, *, industry: str = "roofing", name: str = "Mike's Roofing", activate: bool = True, all_week: bool = True) -> dict[str, Any]:
    """Owner signup → org → profile → FAQ knowledge → AI employee → (activation). Returns ids."""
    api.signup()
    org = api.create_org(name=name, industry=industry)
    hours = {d: [["08:00", "17:00"]] for d in ("mon", "tue", "wed", "thu", "fri", "sat", "sun")} if all_week else None
    body: dict[str, Any] = {
        "description": f"{name} is a family-owned company.",
        "escalation_phone": "+19405550199",
        "emergency_instructions": "For emergencies call +1 940-555-0199.",
        "booking_lead_time_hours": 1,
    }
    if hours:
        body["hours"] = hours
    r = api.put("/organizations/current/profile", body)
    assert r.status_code == 200, r.text
    r = api.post(
        "/knowledge/faqs",
        {
            "faqs": [
                {"question": "Do you offer free inspections?", "answer": "Yes — roof inspections are free and take about 45 minutes."},
                {"question": "Do you offer financing?", "answer": "Yes, financing is available on approved credit for replacements."},
            ]
        },
    )
    assert r.status_code == 201, r.text
    r = api.post("/agents", {"name": "Sarah", "role": "receptionist"})
    assert r.status_code == 201, r.text
    agent = r.json()
    if activate:
        r = api.post(f"/agents/{agent['id']}/activate")
        assert r.status_code == 200, r.text
    return {"org": org, "agent": agent, "widget_token": agent["widget_token"]}


class Visitor:
    def __init__(self, api: Api, token: str) -> None:
        self.c = api.c
        r = self.c.post(f"/api/v1/public/widget/{token}/conversations")
        assert r.status_code == 201, r.text
        d = r.json()
        self.cid, self.vt = d["conversation_id"], d["visitor_token"]
        self.greeting = d["messages"][0]["content"]

    def say(self, text: str) -> str:
        r = self.c.post(f"/api/v1/public/conversations/{self.cid}/messages", json={"text": text}, headers={"X-Visitor-Token": self.vt})
        assert r.status_code == 200, r.text
        msgs = r.json()["messages"]
        return msgs[0]["content"] if msgs else ""


@pytest.fixture()
def db() -> Iterator[Any]:
    s = SessionLocal()
    try:
        yield s
    finally:
        s.close()
