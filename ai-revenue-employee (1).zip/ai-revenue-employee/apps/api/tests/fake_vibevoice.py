"""A stand-in for ``vibevoice_asr_streaming_fastapi_demo.py`` that speaks the same wire protocol without a GPU.

GET /config -> {"sample_rate": 24000, "chunk_seconds": 0.5}; GET /healthz -> {"status": "ok"}
WS  /ws/asr -> first text frame = options JSON; binary float32 LE frames; cumulative {"chunks", "text"} messages
               every 0.5 s of audio; "end" -> {"done": true, "text", "total_chunks"}.
Each websocket session transcribes to the next scripted utterance (revealed word by word as audio arrives).
"""

from __future__ import annotations

import asyncio
import json
import socket
import threading
from collections import deque
from http import HTTPStatus
from typing import Any

import numpy as np
from websockets.asyncio.server import ServerConnection, serve
from websockets.http11 import Request, Response

SAMPLE_RATE = 24000
CHUNK = SAMPLE_RATE // 2


class FakeVibeVoice:
    def __init__(self) -> None:
        self.script: deque[str] = deque()
        self.sessions: list[dict[str, Any]] = []
        self.port = _free_port()
        self.url = f"http://127.0.0.1:{self.port}"
        self._loop = asyncio.new_event_loop()
        self._ready = threading.Event()
        self._stop: asyncio.Future[None] | None = None
        self._thread = threading.Thread(target=self._run, daemon=True)

    def __enter__(self) -> FakeVibeVoice:
        self._thread.start()
        assert self._ready.wait(5)
        return self

    def __exit__(self, *exc: Any) -> None:
        if self._stop is not None:
            self._loop.call_soon_threadsafe(self._stop.set_result, None)
        self._thread.join(5)

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self._main())

    async def _main(self) -> None:
        self._stop = self._loop.create_future()
        async with serve(self._handler, "127.0.0.1", self.port, process_request=self._http):
            self._ready.set()
            await self._stop

    def _http(self, connection: ServerConnection, request: Request) -> Response | None:
        if request.path == "/config":
            return connection.respond(HTTPStatus.OK, json.dumps({"sample_rate": SAMPLE_RATE, "chunk_seconds": 0.5}))
        if request.path == "/healthz":
            return connection.respond(HTTPStatus.OK, json.dumps({"status": "ok"}))
        if request.path != "/ws/asr":
            return connection.respond(HTTPStatus.NOT_FOUND, "not found")
        return None

    async def _handler(self, ws: ServerConnection) -> None:
        opts = json.loads(await ws.recv())
        target = self.script.popleft() if self.script else ""
        sess: dict[str, Any] = {"options": opts, "samples": 0, "target": target}
        self.sessions.append(sess)
        words = target.split()
        buffered = 0
        chunks = 0

        def text_for(n: int) -> str:
            return " ".join(words[: min(len(words), n * 2)])

        async for msg in ws:
            if isinstance(msg, bytes):
                pcm = np.frombuffer(msg, dtype="<f4")
                assert np.all(np.isfinite(pcm))
                sess["samples"] += len(pcm)
                buffered += len(pcm)
                while buffered >= CHUNK:
                    buffered -= CHUNK
                    chunks += 1
                    await ws.send(json.dumps({"chunks": chunks, "text": text_for(chunks)}))
            elif msg == "end":
                if buffered:
                    chunks += 1
                await ws.send(json.dumps({"chunks": chunks, "text": target, "done": True, "total_chunks": chunks}))
                return


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def speech(seconds: float, sr: int, amp: float = 0.3) -> np.ndarray:
    """Voiced-sounding test signal (a modulated tone) — loud enough for the energy endpointer."""
    t = np.arange(int(seconds * sr)) / sr
    return (amp * np.sin(2 * np.pi * 220 * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 3 * t))).astype(np.float32)


def silence(seconds: float, sr: int) -> np.ndarray:
    rng = np.random.default_rng(0)
    return (rng.standard_normal(int(seconds * sr)) * 0.0005).astype(np.float32)
