"""Spec §84 — real authentication flow, §5 RBAC, §45 session/CSRF protections."""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from fastapi.testclient import TestClient
from sqlalchemy import select, update

from app.models import OutboundEmail, User, UserSession
from app.services.common import utcnow
from tests.conftest import Api, make_business


def _latest_link(db: Any, to: str, marker: str) -> str:
    db.expire_all()
    mail = db.scalars(select(OutboundEmail).where(OutboundEmail.to_address == to).order_by(OutboundEmail.created_at.desc())).first()
    assert mail is not None
    line = next(ln for ln in mail.body.splitlines() if marker in ln)
    return line.split("token=")[1].strip()


def test_signup_login_session_logout(api: Api, db: Any) -> None:
    me = api.signup(email="flow@example.com")
    assert me["user"]["email"] == "flow@example.com" and me["organizations"] == []
    assert api.get("/auth/me").status_code == 200
    # protected route without org → 403 until an organization exists
    assert api.get("/leads").status_code == 403
    api.create_org()
    assert api.get("/leads").status_code == 200
    assert api.post("/auth/logout").status_code == 200
    assert api.get("/auth/me").status_code == 401
    assert api.get("/leads").status_code == 401
    r = api.login("flow@example.com", "Sup3r-secret-pw")
    assert r.status_code == 200 and r.json()["organizations"][0]["name"] == "Mike's Roofing"


def test_invalid_credentials_and_weak_passwords(api: Api) -> None:
    api.signup(email="creds@example.com")
    fresh = Api(api.c.app)
    assert fresh.login("creds@example.com", "wrong-password-1").status_code == 401
    assert fresh.login("nobody@example.com", "wrong-password-1").status_code == 401
    r = fresh.post("/auth/signup", {"name": "x", "email": "weak@example.com", "password": "short"})
    assert r.status_code == 422
    r = fresh.post("/auth/signup", {"name": "x", "email": "creds@example.com", "password": "Another-good-pw1"})
    assert r.status_code == 409


def test_csrf_required_for_cookie_sessions(api: Api) -> None:
    api.signup()
    csrf = api.csrf
    api.csrf = None
    r = api.post("/organizations", {"name": "X", "industry": "roofing"})
    assert r.status_code == 403 and r.json()["error"]["code"] == "csrf_failed"
    api.csrf = "forged"
    assert api.post("/organizations", {"name": "X", "industry": "roofing"}).status_code == 403
    api.csrf = csrf
    assert api.post("/organizations", {"name": "X", "industry": "roofing"}).status_code == 201


def test_expired_session(api: Api, db: Any) -> None:
    api.signup(email="exp@example.com")
    db.execute(update(UserSession).values(expires_at=utcnow() - timedelta(seconds=1)))
    db.commit()
    r = api.get("/auth/me")
    assert r.status_code == 401 and r.json()["error"]["code"] == "session_expired"


def test_disabled_account(api: Api, db: Any) -> None:
    api.signup(email="disabled@example.com")
    db.execute(update(User).where(User.email == "disabled@example.com").values(is_active=False))
    db.commit()
    assert api.get("/auth/me").status_code == 401
    fresh = Api(api.c.app)
    r = fresh.login("disabled@example.com", "Sup3r-secret-pw")
    assert r.status_code == 403 and r.json()["error"]["code"] == "account_disabled"


def test_email_verification(api: Api, db: Any) -> None:
    api.signup(email="verify@example.com")
    assert api.get("/auth/me").json()["user"]["email_verified"] is False
    token = _latest_link(db, "verify@example.com", "verify-email")
    assert api.post("/auth/verify-email", {"token": token}).status_code == 200
    assert api.get("/auth/me").json()["user"]["email_verified"] is True
    assert api.post("/auth/verify-email", {"token": token}).status_code == 400  # single use


def test_password_reset_and_change(api: Api, db: Any, app: Any) -> None:
    api.signup(email="reset@example.com")
    other = Api(app)
    other.login("reset@example.com", "Sup3r-secret-pw")
    anon = Api(app)
    assert anon.post("/auth/password-reset/request", {"email": "reset@example.com"}).status_code == 200
    assert anon.post("/auth/password-reset/request", {"email": "unknown@example.com"}).status_code == 200  # no enumeration
    token = _latest_link(db, "reset@example.com", "reset-password")
    assert anon.post("/auth/password-reset/confirm", {"token": token, "password": "Brand-new-pass1"}).status_code == 200
    assert other.get("/auth/me").status_code == 401  # all sessions revoked after reset
    assert anon.login("reset@example.com", "Sup3r-secret-pw").status_code == 401
    assert anon.login("reset@example.com", "Brand-new-pass1").status_code == 200
    second = Api(app)
    second.login("reset@example.com", "Brand-new-pass1")
    assert anon.post("/auth/password/change", {"current_password": "bad", "new_password": "Another-pass-22"}).status_code == 400
    assert anon.post("/auth/password/change", {"current_password": "Brand-new-pass1", "new_password": "Another-pass-22"}).status_code == 200
    assert second.get("/auth/me").status_code == 401  # other sessions revoked
    assert anon.get("/auth/me").status_code == 200  # current session kept


def test_bearer_token_auth_without_csrf(app: Any) -> None:
    c = TestClient(app)
    r = c.post("/api/v1/auth/signup", json={"name": "B", "email": "bearer@example.com", "password": "Sup3r-secret-pw"})
    token = r.cookies.get("are_session")
    c2 = TestClient(app)
    r = c2.post("/api/v1/organizations", json={"name": "Bearer Co", "industry": "hvac"}, headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 201


def test_rbac_roles(api: Api, app: Any) -> None:
    make_business(api)
    invites = {}
    for role in ("manager", "staff", "readonly"):
        r = api.post("/team/invitations", {"email": f"{role}@example.com", "role": role})
        assert r.status_code == 201, r.text
        invites[role] = r.json()["dev_accept_link"].split("token=")[1]
    users: dict[str, Api] = {}
    for role, token in invites.items():
        u = Api(app)
        r = u.post("/auth/invitations/accept", {"token": token, "name": role.title(), "password": "Role-pass-123"})
        assert r.status_code == 200, r.text
        u.csrf = r.json()["csrf_token"]
        users[role] = u
    ro, staff, mgr = users["readonly"], users["staff"], users["manager"]
    # readonly: analytics only
    assert ro.get("/analytics").status_code == 200
    assert ro.get("/leads").status_code == 403
    assert ro.get("/conversations").status_code == 403
    # staff: operational access, no configuration
    assert staff.get("/leads").status_code == 200
    assert staff.post("/agents", {"name": "X"}).status_code == 403
    assert staff.post("/knowledge/faqs", {"faqs": [{"question": "Q?", "answer": "A"}]}).status_code == 403
    assert staff.post("/billing/checkout", {"plan": "pro"}).status_code == 403
    assert staff.get("/integrations").status_code == 403
    # manager: AI configuration but not billing/team/integrations
    assert mgr.post("/knowledge/faqs", {"faqs": [{"question": "Do you do gutters?", "answer": "Yes."}]}).status_code == 201
    assert mgr.post("/team/invitations", {"email": "x@example.com", "role": "staff"}).status_code == 403
    assert mgr.post("/billing/checkout", {"plan": "pro"}).status_code == 403
    # owner cannot demote the last owner
    team = api.get("/team").json()["members"]
    owner = next(m for m in team if m["role"] == "owner")
    assert api.patch(f"/team/members/{owner['id']}", {"role": "staff"}).status_code == 400
    # invitation tokens are single-use
    assert Api(app).post("/auth/invitations/accept", {"token": invites["staff"], "name": "Again", "password": "Role-pass-123"}).status_code == 400


def test_security_headers_and_request_id(api: Api) -> None:
    r = api.c.get("/healthz")
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert len(r.headers["x-request-id"]) == 32
    assert api.c.get("/readyz").status_code == 200
    assert "http_requests_total" in api.c.get("/metrics").text
