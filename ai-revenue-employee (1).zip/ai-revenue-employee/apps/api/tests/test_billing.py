"""Billing acceptance (§97) in sandbox mode + Stripe webhook contract tests with real signature verification."""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any

import pytest
from sqlalchemy import select

from app.config import get_settings
from app.models import Plan, Subscription
from app.services import billing
from tests.conftest import Api, Visitor, make_business


def test_trial_entitlements_and_backend_enforcement(api: Api) -> None:
    make_business(api)
    ov = api.get("/billing").json()
    assert ov["subscription"]["status"] == "trialing" and ov["subscription"]["plan"]["key"] == "growth"
    assert "voice" in ov["entitlements"]["features"] and "webhooks" not in ov["entitlements"]["features"]
    # a Pro-only feature is refused by the backend regardless of what the UI shows
    r = api.post("/integrations/webhooks", {"url": "https://example.com/hook", "events": []})
    assert r.status_code == 402 and r.json()["error"]["code"] == "plan_required"


def test_subscription_lifecycle(api: Api) -> None:
    make_business(api)
    r = api.post("/billing/checkout", {"plan": "starter"})
    assert r.status_code == 200 and r.json()["completed"] is True
    ov = api.get("/billing").json()
    assert ov["subscription"]["status"] == "active" and ov["subscription"]["plan"]["key"] == "starter"
    assert ov["invoices"][0]["status"] == "paid" and ov["invoices"][0]["amount_cents"] == 19900
    assert api.post("/billing/checkout", {"plan": "pro"}).status_code == 409  # already subscribed → change plan
    # upgrade
    assert api.post("/billing/change-plan", {"plan": "pro"}).json()["subscription"]["plan"]["key"] == "pro"
    assert api.post("/integrations/webhooks", {"url": "https://example.com/hook", "events": ["lead.created"]}).status_code == 201
    # downgrade blocked when over the new plan's limits
    api.post("/agents", {"name": "Alex", "role": "lead_qualifier"})
    r = api.post("/billing/change-plan", {"plan": "starter"})
    assert r.status_code == 409 and r.json()["error"]["code"] == "downgrade_blocked"
    # renewal
    before = api.get("/billing").json()["subscription"]["current_period_end"]
    after = api.post("/billing/sandbox/simulate", {"event": "renewal"}).json()["subscription"]["current_period_end"]
    assert after > before
    # failed payment → past_due, still usable during grace; recovery → active
    ov = api.post("/billing/sandbox/simulate", {"event": "payment_failed"}).json()
    assert ov["subscription"]["status"] == "past_due" and ov["subscription"]["usable"] is True
    ov = api.post("/billing/sandbox/simulate", {"event": "payment_recovered"}).json()
    assert ov["subscription"]["status"] == "active" and all(i["status"] == "paid" for i in ov["invoices"])
    # cancellation at period end, resume, then end of period
    assert api.post("/billing/cancel").json()["subscription"]["cancel_at_period_end"] is True
    assert api.post("/billing/resume").json()["subscription"]["cancel_at_period_end"] is False
    api.post("/billing/cancel")
    ov = api.post("/billing/sandbox/simulate", {"event": "period_ended"}).json()
    assert ov["subscription"]["status"] == "canceled" and ov["entitlements"]["usable"] is False


def test_expired_trial_takes_ai_offline(api: Api) -> None:
    biz = make_business(api)
    api.post("/billing/sandbox/simulate", {"event": "trial_expired"})
    v = Visitor(api, biz["widget_token"])
    reply = v.say("Do you offer financing?")
    assert "team will get back to you" in reply
    assert api.get("/tasks").json()[0]["title"].lower().startswith("ai employee offline")
    agent_id = api.post("/agents", {"name": "Z"}).json()["id"]  # configuration is allowed…
    r = api.post(f"/agents/{agent_id}/activate")  # …but nothing can go live without an active subscription
    assert r.status_code == 400 and any(d["key"] == "subscription" for d in r.json()["error"]["details"])


def test_usage_limits_enforced(api: Api, db: Any) -> None:
    biz = make_business(api)
    assert api.patch("/organizations/current", {"usage_limits": {"conversations_per_month": 1}}).status_code == 200
    v1 = Visitor(api, biz["widget_token"])
    assert "financing" in v1.say("Do you offer financing?").lower()
    v2 = Visitor(api, biz["widget_token"])
    assert "follow up with you shortly" in v2.say("Do you offer financing?")


def _stripe_sig(payload: bytes, secret: str, ts: int | None = None) -> str:
    ts = ts or int(time.time())
    return f"t={ts},v1=" + hmac.new(secret.encode(), f"{ts}.".encode() + payload, hashlib.sha256).hexdigest()


@pytest.fixture()
def stripe_secret(monkeypatch: pytest.MonkeyPatch) -> str:
    monkeypatch.setattr(get_settings(), "stripe_webhook_secret", "whsec_test_123")
    return "whsec_test_123"


def test_stripe_webhook_signature_and_idempotency(api: Api, db: Any, stripe_secret: str) -> None:
    biz = make_business(api)
    org_id = biz["org"]["id"]
    pro = db.scalar(select(Plan).where(Plan.key == "pro"))
    pro.provider_price_id = "price_pro_123"
    db.commit()
    event = {
        "id": "evt_1",
        "type": "customer.subscription.updated",
        "data": {
            "object": {
                "id": "sub_123",
                "customer": "cus_9",
                "status": "active",
                "cancel_at_period_end": False,
                "current_period_end": int(time.time()) + 86400 * 30,
                "metadata": {"organization_id": org_id},
                "items": {"data": [{"price": {"id": "price_pro_123"}}]},
            }
        },
    }
    payload = json.dumps(event).encode()
    r = api.c.post("/api/v1/webhooks/stripe", content=payload, headers={"Stripe-Signature": "t=1,v1=bad"})
    assert r.status_code == 400
    r = api.c.post("/api/v1/webhooks/stripe", content=payload, headers={"Stripe-Signature": _stripe_sig(payload, stripe_secret, int(time.time()) - 3600)})
    assert r.status_code == 400  # replay outside tolerance
    r = api.c.post("/api/v1/webhooks/stripe", content=payload, headers={"Stripe-Signature": _stripe_sig(payload, stripe_secret)})
    assert r.status_code == 200 and r.json()["status"] == "applied"
    r = api.c.post("/api/v1/webhooks/stripe", content=payload, headers={"Stripe-Signature": _stripe_sig(payload, stripe_secret)})
    assert r.json()["status"] == "duplicate_ignored"
    db.expire_all()
    sub = db.scalar(select(Subscription))
    assert sub.status == "active" and sub.plan.key == "pro" and sub.provider_subscription_id == "sub_123"
    # payment failure then recovery via invoice events
    for i, (etype, status) in enumerate([("invoice.payment_failed", "past_due"), ("invoice.paid", "active")]):
        ev = {"id": f"evt_inv_{i}", "type": etype, "data": {"object": {"id": "in_1", "customer": "cus_9", "amount_due": 99900, "status": "open"}}}
        p = json.dumps(ev).encode()
        assert api.c.post("/api/v1/webhooks/stripe", content=p, headers={"Stripe-Signature": _stripe_sig(p, stripe_secret)}).status_code == 200
        db.expire_all()
        assert db.scalar(select(Subscription.status)) == status
    # cancellation
    ev = {"id": "evt_del", "type": "customer.subscription.deleted", "data": {"object": {**event["data"]["object"], "status": "canceled"}}}
    p = json.dumps(ev).encode()
    api.c.post("/api/v1/webhooks/stripe", content=p, headers={"Stripe-Signature": _stripe_sig(p, stripe_secret)})
    db.expire_all()
    sub = db.scalar(select(Subscription))
    assert sub.status == "canceled" and not billing.subscription_is_usable(sub)
