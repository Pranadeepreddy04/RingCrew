"""SMS (§11, §96) and voice (§10, §95) channel tests against the sandbox provider, exercising the same
signed-webhook code paths Twilio uses. Real-carrier acceptance requires credentials (see TESTING.md)."""

from __future__ import annotations

import uuid
from typing import Any
from urllib.parse import urlencode

from sqlalchemy import func, select

from app.models import Appointment, Call, Conversation, Customer, InboundWebhookEvent, Lead, Message, Task, UsageRecord
from app.providers.messaging import SandboxSms, sandbox_webhook_token, twilio_signature
from app.worker import run_once
from tests.conftest import Api, make_business

BIZ_NUMBER = "+19405551000"
CALLER = "+19405550123"


def _post(api: Api, path: str, params: dict[str, str], *, sign: bool = True) -> Any:
    url = "http://testserver/api/v1" + path
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    if sign:
        headers["X-Twilio-Signature"] = twilio_signature(sandbox_webhook_token(), url, params)
    return api.c.post("/api/v1" + path, content=urlencode(params), headers=headers)


def _setup(api: Api) -> dict[str, Any]:
    biz = make_business(api)
    r = api.post("/integrations/phone-numbers", {"mode": "existing", "number": BIZ_NUMBER})
    assert r.status_code == 201, r.text
    return biz


_sid = 0


def sms(api: Api, body: str, frm: str = CALLER, sid: str | None = None) -> Any:
    global _sid
    _sid += 1
    return _post(api, "/webhooks/sms/incoming", {"MessageSid": sid or f"SM{_sid:030d}", "From": frm, "To": BIZ_NUMBER, "Body": body})


def last_sms() -> str:
    return SandboxSms.outbox[-1]["body"] if SandboxSms.outbox else ""


def test_sms_signature_required(api: Api) -> None:
    _setup(api)
    r = _post(api, "/webhooks/sms/incoming", {"MessageSid": "SMx", "From": CALLER, "To": BIZ_NUMBER, "Body": "hi"}, sign=False)
    assert r.status_code == 403
    r = api.c.post(
        "/api/v1/webhooks/sms/incoming",
        content=urlencode({"MessageSid": "SMx", "From": CALLER, "To": BIZ_NUMBER, "Body": "hi"}),
        headers={"Content-Type": "application/x-www-form-urlencoded", "X-Twilio-Signature": "forged"},
    )
    assert r.status_code == 403


def test_sms_full_conversation_books_appointment(api: Api, db: Any) -> None:
    _setup(api)
    for text in ["Hi, my roof is leaking", "house", "76201", "James Carter"]:
        assert sms(api, text).status_code == 200
        run_once()
    assert "openings" in last_sms()  # phone taken from caller ID, no need to ask
    sms(api, "1")
    run_once()
    assert any(m["body"].startswith("You're all set, James!") for m in SandboxSms.outbox)
    cust = db.scalar(select(Customer).where(Customer.phone == CALLER))
    assert cust is not None and cust.name == "James Carter"
    assert db.scalar(select(func.count()).select_from(Appointment)) == 1
    lead = db.scalar(select(Lead))
    assert lead.source == "ai_sms" and lead.status == "appointment"
    assert db.scalar(select(func.count()).select_from(UsageRecord).where(UsageRecord.kind == "sms")) >= 5
    conv = api.get("/conversations", params={"filter": "sms"}).json()["items"][0]
    assert conv["lead_id"] == str(lead.id)


def test_duplicate_sms_webhook_processed_once(api: Api, db: Any) -> None:
    _setup(api)
    sms(api, "Do you offer financing?", sid="SMdup1")
    sms(api, "Do you offer financing?", sid="SMdup1")
    run_once()
    assert db.scalar(select(func.count()).select_from(Message).where(Message.role == "customer")) == 1
    assert len(SandboxSms.outbox) == 1
    assert db.scalar(select(func.count()).select_from(InboundWebhookEvent)) == 1


def test_stop_start_help_and_opted_out(api: Api, db: Any) -> None:
    _setup(api)
    sms(api, "Do you offer financing?")
    run_once()
    sent = len(SandboxSms.outbox)
    assert sms(api, "STOP").status_code == 200
    cust = db.scalar(select(Customer).where(Customer.phone == CALLER))
    assert cust.sms_opted_out
    # opted-out customer writing again gets no automated reply
    sms(api, "hello?")
    run_once()
    assert len(SandboxSms.outbox) == sent
    # automated follow-ups are blocked
    from app.models import Organization
    from app.services.crm import send_sms

    org = db.scalar(select(Organization))
    db.refresh(cust)
    assert send_sms(db, org, cust, "follow up", purpose="followup").error == "opted_out"
    r = sms(api, "HELP")
    assert "<Message>" in r.text and "Reply STOP" in r.text
    sms(api, "START")
    db.refresh(cust)
    assert not cust.sms_opted_out
    sms(api, "Do you offer financing?")
    run_once()
    assert len(SandboxSms.outbox) == sent + 1


def test_invalid_number_and_unknown_destination(api: Api, db: Any) -> None:
    _setup(api)
    assert sms(api, "hi", frm="not-a-number").status_code == 200
    r = _post(api, "/webhooks/sms/incoming", {"MessageSid": "SMz", "From": CALLER, "To": "+19995550000", "Body": "hi"})
    assert r.status_code == 200
    run_once()
    assert db.scalar(select(func.count()).select_from(Conversation)) == 0


def test_delivery_failure_retries_then_status_callback(api: Api, db: Any) -> None:
    _setup(api)
    SandboxSms.fail_next = 1
    sms(api, "Do you offer financing?")
    run_once()  # provider failure → job retried later, turn rolled back (no fabricated reply)
    assert not SandboxSms.outbox
    from app.models import Job
    from app.services.common import utcnow

    job = db.scalar(select(Job).where(Job.kind == "sms.respond"))
    assert job.status == "queued" and job.attempts == 1
    job.run_at = utcnow()
    db.commit()
    run_once()
    assert len(SandboxSms.outbox) == 1
    mid = SandboxSms.outbox[-1]["id"]
    r = _post(api, "/webhooks/sms/status", {"MessageSid": mid, "MessageStatus": "undelivered", "ErrorCode": "30003"})
    assert r.status_code == 204
    db.expire_all()
    assert db.scalar(select(Message.delivery_status).where(Message.provider_message_id == mid)) == "undelivered"


# ------------------------------------------------------------------ voice


def call(api: Api, sid: str = "CA0001") -> Any:
    return _post(api, "/webhooks/voice/incoming", {"CallSid": sid, "From": CALLER, "To": BIZ_NUMBER})


def speak(api: Api, conv_id: str, text: str, sid: str = "CA0001", confidence: str = "0.92") -> str:
    params = {"CallSid": sid, "SpeechResult": text, "Confidence": confidence} if text else {"CallSid": sid}
    r = _post(api, f"/webhooks/voice/gather?conversation_id={conv_id}", params)
    assert r.status_code == 200, r.text
    return r.text


def test_voice_call_books_appointment(api: Api, db: Any) -> None:
    _setup(api)
    r = call(api)
    assert r.status_code == 200 and "<Gather" in r.text and "AI assistant" in r.text and "recorded" not in r.text
    conv = db.scalar(select(Conversation).where(Conversation.channel == "voice"))
    cid = str(conv.id)
    assert "<Gather" in speak(api, cid, "My roof started leaking after last night's storm")
    speak(api, cid, "It's a house")
    speak(api, cid, "7 6 2 0 1")
    twiml = speak(api, cid, "James Carter")
    assert "openings" in twiml
    twiml = speak(api, cid, "the first one")
    assert "all set, James" in twiml
    assert "<Hangup/>" in speak(api, cid, "no that's all, goodbye")
    _post(api, "/webhooks/voice/status", {"CallSid": "CA0001", "CallStatus": "completed", "CallDuration": "185"})
    db.expire_all()
    c = db.scalar(select(Call))
    assert c.duration_seconds == 185 and c.ended_at is not None
    assert db.scalar(select(func.sum(UsageRecord.quantity)).where(UsageRecord.kind == "voice_minutes")) == 4
    lead = db.scalar(select(Lead))
    assert lead.source == "ai_phone" and lead.status == "appointment"
    detail = api.get(f"/conversations/{cid}").json()
    assert detail["call"]["duration_seconds"] == 185 and detail["summary"]


def test_voice_silence_unclear_and_human_transfer(api: Api, db: Any) -> None:
    _setup(api)
    call(api, "CA0002")
    cid = str(db.scalar(select(Conversation.id)))
    assert "didn't hear" in speak(api, cid, "", sid="CA0002")
    twiml = speak(api, cid, "", sid="CA0002")
    assert "<Hangup/>" in twiml
    assert db.scalar(select(Task).where(Task.kind == "follow_up")) is not None  # missed-call recovery task
    call(api, "CA0003")
    cid3 = str(db.scalar(select(Conversation.id).where(Conversation.external_id == "CA0003")))
    assert "catch that" in speak(api, cid3, "mumble", sid="CA0003", confidence="0.1")
    twiml = speak(api, cid3, "Can I talk to a real person please", sid="CA0003")
    assert "<Dial" in twiml and "+19405550199" in twiml


def test_voice_duplicate_call_webhook_and_hangup_early(api: Api, db: Any) -> None:
    _setup(api)
    call(api, "CA0004")
    call(api, "CA0004")
    assert db.scalar(select(func.count()).select_from(Call)) == 1
    _post(api, "/webhooks/voice/status", {"CallSid": "CA0004", "CallStatus": "completed", "CallDuration": "12"})
    db.expire_all()
    lead = db.scalar(select(Lead))
    assert lead is not None and not lead.is_qualified and "Call back" in (lead.summary or "")


def test_voice_blocked_when_not_entitled(api: Api, db: Any) -> None:
    biz = _setup(api)
    api.post(f"/agents/{biz['agent']['id']}/pause")
    r = call(api, "CA0005")
    assert "<Dial" in r.text  # forwarded to the business instead of an offline AI
    assert db.scalar(select(func.count()).select_from(Conversation)) == 0
    _ = uuid
