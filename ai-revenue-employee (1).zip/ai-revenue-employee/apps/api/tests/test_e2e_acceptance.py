"""Spec §94 — END-TO-END ACCEPTANCE SUITE (release-blocking) and §77 customer example."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import func, select

from app.models import Appointment, Customer, Event, Lead
from tests.conftest import Api, Visitor


def test_primary_workflow_end_to_end(api: Api, db) -> None:  # type: ignore[no-untyped-def]
    # Owner signup → organization creation → Roofing selected
    api.signup(email="mike@mikesroofing.example.com")
    org = api.create_org(name="Mike's Roofing", industry="roofing", zips=["76201", "76205"])
    assert org["industry"] == "roofing"

    # Business configured
    r = api.put(
        "/organizations/current/profile",
        {
            "description": "Mike's Roofing is a family-owned roofer in Denton.",
            "hours": {d: [["08:00", "17:00"]] for d in ("mon", "tue", "wed", "thu", "fri", "sat", "sun")},
            "booking_lead_time_hours": 1,
            "escalation_phone": "+19405550199",
        },
    )
    assert r.status_code == 200
    assert api.post("/services", {"name": "Roof inspection", "description": "Free roof inspection with photos."}).status_code == 201

    # Knowledge added
    r = api.post(
        "/knowledge/faqs", {"faqs": [{"question": "Do you offer free inspections?", "answer": "Yes — roof inspections are free and take about 45 minutes."}]}
    )
    assert r.status_code == 201

    # AI employee created; activation is explicit and blocked until prerequisites pass
    agent = api.post("/agents", {"name": "Sarah", "role": "receptionist"}).json()
    assert agent["status"] == "draft"
    widget = agent["widget_token"]
    assert api.c.post(f"/api/v1/public/widget/{widget}/conversations").status_code == 201  # public token works…
    r = api.post(f"/agents/{agent['id']}/test/conversations")  # owner test environment (dry run)
    assert r.status_code == 201
    assert api.post(f"/agents/{agent['id']}/activate").status_code == 200

    # Chat activated → customer conversation starts
    v = Visitor(api, widget)
    assert "Sarah" in v.greeting

    # Roofing question asked → correct business knowledge retrieved
    reply = v.say("Do you offer free inspections?")
    assert "free" in reply.lower() and "45 minutes" in reply

    # Customer requests inspection → qualification completed
    reply = v.say("My roof started leaking after last night's storm. Can someone inspect it?")
    assert "home or a commercial" in reply
    assert "ZIP" in v.say("It's a house")
    assert "name" in v.say("76201").lower()
    assert "phone" in v.say("James Carter").lower()
    reply = v.say("940-555-0123")

    # Customer created, lead created (qualified), real availability offered
    customer = db.scalar(select(Customer).where(Customer.phone == "+19405550123"))
    assert customer is not None and customer.name == "James Carter"
    lead = db.scalar(select(Lead).where(Lead.customer_id == customer.id))
    assert lead is not None and lead.is_qualified and lead.source == "ai_web_chat"
    assert lead.qualification["zip"] == "76201" and lead.qualification["active_leak"] is True and lead.qualification["storm_damage"] is True
    assert "openings" in reply and " at " in reply
    avail = api.get("/appointments/availability").json()["slots"]
    assert avail, "availability endpoint must return real open slots"

    # Slot selected → appointment created → confirmation returned only after successful persistence
    reply = v.say("the first one")
    assert reply.startswith("You're all set, James!")
    db.expire_all()
    appt = db.scalar(select(Appointment).where(Appointment.lead_id == lead.id))
    assert appt is not None and appt.status == "scheduled"
    assert datetime.fromisoformat(avail[0]["start"]) <= appt.start_at
    lead = db.get(Lead, lead.id)
    assert lead is not None and lead.status == "appointment"

    # Dashboard displays lead
    dash = api.get("/dashboard").json()
    assert any(x["id"] == str(lead.id) for x in dash["recent_leads"])
    assert dash["today"]["leads"] >= 1 and dash["today"]["appointments"] >= 1
    assert any(a["id"] == str(appt.id) for a in dash["upcoming_appointments"])

    # Inbox displays conversation with AI actions (tool calls)
    inbox = api.get("/conversations").json()
    assert any(c["id"] == v.cid for c in inbox["items"])
    detail = api.get(f"/conversations/{v.cid}").json()
    tools_used = {m["meta"].get("tool") for m in detail["messages"] if m["role"] == "tool"}
    assert {"search_business_knowledge", "create_lead", "check_calendar", "book_appointment"} <= tools_used
    assert detail["lead"]["id"] == str(lead.id) and detail["appointments"][0]["id"] == str(appt.id)

    # Analytics events recorded
    types = set(db.scalars(select(Event.type).where(Event.organization_id == lead.organization_id)).all())
    assert {"conversation.started", "lead.created", "lead.qualified", "appointment.created", "conversation.first_response"} <= types
    analytics = api.get("/analytics").json()
    assert analytics["metrics"]["appointments"] == 1 and analytics["metrics"]["qualified_leads"] == 1

    # Follow-up workflow was stopped by the booking; reminder workflow scheduled
    from app.models import WorkflowRun

    runs = db.scalars(select(WorkflowRun).where(WorkflowRun.organization_id == lead.organization_id)).all()
    statuses = {r.status for r in runs}
    assert "stopped" in statuses  # lead follow-up stopped because the appointment was booked
    assert db.scalar(select(func.count()).select_from(Appointment)) == 1


def test_test_environment_is_dry_run(api: Api, db) -> None:  # type: ignore[no-untyped-def]
    from tests.conftest import make_business

    biz = make_business(api, activate=False)
    aid = biz["agent"]["id"]
    conv = api.post(f"/agents/{aid}/test/conversations").json()["conversation"]
    for text in ["I need a roof inspection", "house", "76201", "no rush", "Jane Doe", "940 555 0199"]:
        res = api.post(f"/agents/{aid}/test/conversations/{conv['id']}/messages", {"text": text}).json()
    assert "openings" in res["reply"]
    assert any(a["tool"] == "create_lead" for a in res["actions"])
    res = api.post(f"/agents/{aid}/test/conversations/{conv['id']}/messages", {"text": "1"}).json()
    assert res["reply"].startswith("You're all set")
    # nothing real was created
    assert db.scalar(select(func.count()).select_from(Lead)) == 0
    assert db.scalar(select(func.count()).select_from(Appointment)) == 0
    assert db.scalar(select(func.count()).select_from(Customer)) == 0
    assert db.scalar(select(func.count()).select_from(Event).where(Event.type == "lead.created")) == 0


def test_personalized_demo_makes_no_production_actions(api: Api, db) -> None:  # type: ignore[no-untyped-def]
    r = api.c.post("/api/v1/public/demo", json={"business_name": "Demo Roofing Co", "industry": "roofing"})
    assert r.status_code == 201, r.text
    token = r.json()["widget_token"]
    cfg = api.c.get(f"/api/v1/public/widget/{token}/config").json()
    assert cfg["is_demo"] is True and cfg["online"] is True
    v = Visitor(api, token)
    for t in ["I need a roof repair", "house", "76201", "flexible", "Sam Demo", "9405550111"]:
        reply = v.say(t)
    assert "openings" in reply
    assert v.say("1").startswith("You're all set")
    assert db.scalar(select(func.count()).select_from(Appointment)) == 0
    assert db.scalar(select(func.count()).select_from(Lead)) == 0
