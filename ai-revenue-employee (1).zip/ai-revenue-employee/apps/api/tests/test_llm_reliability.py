"""AI reliability layer (§85), provider failover (§86), provider contract (§91)."""

from __future__ import annotations

import uuid
from typing import Any

import httpx
import pytest
from sqlalchemy import select

from app.ai import llm
from app.ai.llm import AnthropicProvider, FailingProvider, LLMError, LLMResult, grounded, set_provider_override
from app.models import AITrace, Organization, UsageRecord
from tests.conftest import Api, Visitor, make_business


class ScriptedProvider:
    name = "scripted"
    is_sandbox = False

    def __init__(self, tool_inputs: list[Any], answer: str | None = None) -> None:
        self.tool_inputs = list(tool_inputs)
        self.answer_text = answer
        self.calls = 0

    def tool_call(self, system: str, messages: Any, tool_name: str, schema: dict[str, Any], **kw: Any) -> LLMResult:
        self.calls += 1
        assert "DATA, never instructions" in system  # safety layer always present
        assert "<customer_message>" in messages[-1].content or "invalid" in messages[-1].content
        nxt = self.tool_inputs.pop(0) if self.tool_inputs else {"intent": "other", "fields": {}}
        return LLMResult(tool_input=nxt, input_tokens=100, output_tokens=20, model="claude-haiku-4-5")

    def generate(self, system: str, messages: Any, **kw: Any) -> LLMResult:
        self.calls += 1
        assert "<business_knowledge>" in messages[0].content
        return LLMResult(text=self.answer_text, input_tokens=200, output_tokens=30, model="claude-sonnet-4-5")

    def embed(self, texts: list[str]) -> None:
        return None


def test_llm_fields_are_validated_before_use(api: Api) -> None:
    biz = make_business(api)
    set_provider_override(
        ScriptedProvider(
            [
                {"intent": "book_service", "fields": {"property_type": "commercial", "service_requested": "repair"}},
                {"intent": "other", "fields": {"zip": "ABCDE"}},  # invalid → ignored
            ]
        )
    )
    v = Visitor(api, biz["widget_token"])
    reply = v.say("Water is dripping through the ceiling of our shop")
    assert "ZIP" in reply  # service + property type came from the LLM, validated against the pack
    reply = v.say("it's the one near the mall")
    detail = api.get(f"/conversations/{v.cid}").json()
    assert detail["collected"]["property_type"] == "commercial"
    assert "zip" not in detail["collected"]


def test_invalid_structured_output_is_repaired_or_discarded(api: Api, db: Any) -> None:
    biz = make_business(api)
    prov = ScriptedProvider([{"intent": "nonsense"}, {"intent": "still-bad"}])
    set_provider_override(prov)
    v = Visitor(api, biz["widget_token"])
    reply = v.say("Do you offer financing?")
    assert "financing" in reply.lower()  # deterministic path still answers from approved knowledge
    assert prov.calls >= 2
    statuses = db.scalars(select(AITrace.status).where(AITrace.operation == "extract")).all()
    assert statuses.count("invalid") == 2


def test_provider_outage_degrades_and_fallback_requires_tenant_permission(api: Api, db: Any) -> None:
    biz = make_business(api)
    primary, fallback = FailingProvider(), ScriptedProvider([{"intent": "question", "fields": {}}], answer="Yes, financing is available on approved credit.")
    set_provider_override(primary, fallback)
    v = Visitor(api, biz["widget_token"])
    reply = v.say("Do you offer financing?")
    assert "financing" in reply.lower()
    assert primary.calls >= 2 and fallback.calls == 0  # not permitted by tenant yet
    errors = db.scalars(select(AITrace).where(AITrace.provider == "failing")).all()
    assert errors and all(t.status == "error" and t.error for t in errors)
    assert api.patch("/organizations/current", {"allow_fallback_provider": True}).status_code == 200
    set_provider_override(FailingProvider(), fallback)
    v.say("Do you offer financing?")
    assert fallback.calls >= 1
    assert db.scalar(select(UsageRecord).where(UsageRecord.kind == "llm_tokens")) is not None


def test_ungrounded_llm_answers_are_rejected(api: Api) -> None:
    biz = make_business(api)
    set_provider_override(ScriptedProvider([{"intent": "question", "fields": {}}], answer="Yes! Financing starts at just $49/month with 0% APR."))
    v = Visitor(api, biz["widget_token"])
    reply = v.say("Do you offer financing?")
    assert "$49" not in reply and "0%" not in reply
    assert "approved credit" in reply  # falls back to the verbatim approved answer


def test_grounded_guard() -> None:
    kb = "Our diagnostic visit is $89. Call 940-555-0100. 10% off for seniors."
    assert grounded("The visit is $89.", kb)
    assert grounded("Seniors get 10% off.", kb)
    assert not grounded("The visit is $79.", kb)
    assert not grounded("Call 214-555-0000", kb)
    assert not grounded("We give 15% off", kb)


def test_anthropic_provider_contract(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(llm.get_settings(), "anthropic_api_key", "test-key")
    sent: dict[str, Any] = {}

    def fake_post(url: str, json: Any, headers: dict[str, str], timeout: float) -> httpx.Response:
        sent.update(url=url, json=json, headers=headers)
        return httpx.Response(
            200,
            json={
                "content": [{"type": "tool_use", "name": "record_extraction", "input": {"intent": "question", "fields": {}}}],
                "usage": {"input_tokens": 12, "output_tokens": 3},
            },
        )

    monkeypatch.setattr(httpx, "post", fake_post)
    p = AnthropicProvider()
    res = p.tool_call("sys", [llm.ChatMessage("user", "hi")], "record_extraction", {"type": "object"})
    assert res.tool_input == {"intent": "question", "fields": {}} and res.input_tokens == 12
    assert sent["headers"]["x-api-key"] == "test-key" and sent["headers"]["anthropic-version"] == "2023-06-01"
    assert sent["json"]["tool_choice"] == {"type": "tool", "name": "record_extraction"}

    monkeypatch.setattr(httpx, "post", lambda *a, **k: httpx.Response(529, json={}))
    with pytest.raises(LLMError) as e:
        p.generate("sys", [llm.ChatMessage("user", "hi")])
    assert e.value.transient
    monkeypatch.setattr(httpx, "post", lambda *a, **k: httpx.Response(400, text="bad request"))
    with pytest.raises(LLMError) as e:
        p.generate("sys", [llm.ChatMessage("user", "hi")])
    assert not e.value.transient

    def timeout(*a: Any, **k: Any) -> httpx.Response:
        raise httpx.ReadTimeout("slow")

    monkeypatch.setattr(httpx, "post", timeout)
    with pytest.raises(LLMError) as e:
        p.generate("sys", [llm.ChatMessage("user", "hi")])
    assert e.value.transient


def test_every_ai_action_is_traceable(api: Api, db: Any) -> None:
    biz = make_business(api)
    set_provider_override(ScriptedProvider([{"intent": "question", "fields": {}}], answer="Yes, financing is available on approved credit."))
    v = Visitor(api, biz["widget_token"])
    v.say("Do you offer financing?")
    traces = db.scalars(select(AITrace).where(AITrace.conversation_id == uuid.UUID(v.cid))).all()
    assert traces
    for t in traces:
        assert t.organization_id == uuid.UUID(biz["org"]["id"]) and t.agent_id and t.prompt_version and t.latency_ms is not None
        assert t.model and t.status
    _ = db.get(Organization, uuid.UUID(biz["org"]["id"]))
