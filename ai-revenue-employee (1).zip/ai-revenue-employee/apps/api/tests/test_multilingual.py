"""Multilingual AI employee: English, Spanish, Chinese, Tagalog, Vietnamese, Arabic, French.

Runs with the deterministic (sandbox) model, i.e. the keyword/catalog path that works without any LLM key.
"""

from __future__ import annotations

from typing import Any

import pytest
from sqlalchemy import select

from app.ai import i18n, nlu
from app.models import Appointment, Conversation, Lead
from tests.conftest import Api, make_business

ALL = ["en", "es", "zh", "tl", "vi", "ar", "fr"]

# (customer line, substring expected in the AI reply)
SCRIPTS: dict[str, list[tuple[str, str]]] = {
    "es": [
        ("Hola, mi techo tiene una gotera después de la tormenta. ¿Pueden inspeccionarlo?", "vivienda"),
        ("Es una casa", "código postal"),
        ("76201", "nombre"),
        ("Me llamo José García", "teléfono"),
        ("940-555-0123", "¿Cuál le conviene más?"),
        ("la primera", "quedó programada"),
    ],
    "zh": [
        ("你好，暴风雨后我家屋顶漏水了，可以来检查吗？", "邮政编码"),
        ("76201", "全名"),
        ("我叫王伟", "电话"),
        ("940-555-0123", "哪个时间"),
        ("第一个", "预约成功"),
    ],
    "tl": [
        ("Magandang araw, may tagas ang bubong ko pagkatapos ng bagyo. Pwede po bang ipa-inspeksyon?", "bahay"),
        ("Bahay po", "ZIP"),
        ("76201", "pangalan"),
        ("Ako si Maria Santos", "numero"),
        ("940-555-0123", "Alin po"),
        ("ang una", "Naka-book"),
    ],
    "vi": [
        ("Xin chào, mái nhà của tôi bị dột sau cơn bão. Bạn có thể kiểm tra không?", "ZIP"),
        ("76201", "Họ tên"),
        ("Tôi tên là Nguyễn Văn An", "số điện thoại"),
        ("940-555-0123", "Giờ nào"),
        ("lựa chọn một", "đã được đặt"),
    ],
    "ar": [
        ("مرحبا، سقف بيتي يسرب الماء بعد العاصفة. هل يمكنكم فحصه؟", "الرمز البريدي"),
        ("76201", "اسمك"),
        ("اسمي محمد علي", "رقم هاتف"),
        ("940-555-0123", "أيها يناسبك"),
        ("الأول", "تم حجز"),
    ],
    "fr": [
        ("Bonjour, mon toit fuit depuis l'orage. Pouvez-vous l'inspecter ?", "maison"),
        ("C'est une maison", "code postal"),
        ("76201", "nom complet"),
        ("Je m'appelle Marie Dubois", "numéro"),
        ("940-555-0123", "convient"),
        ("le premier", "confirmé"),
    ],
}
NAMES = {"es": "José García", "zh": "王伟", "tl": "Maria Santos", "vi": "Nguyễn Văn An", "ar": "محمد علي", "fr": "Marie Dubois"}


def _multilingual_business(api: Api) -> dict[str, Any]:
    b = make_business(api)
    r = api.patch(f"/agents/{b['agent']['id']}", {"languages": ALL})
    assert r.status_code == 200, r.text
    assert r.json()["languages"] == ALL
    return b


class LangVisitor:
    def __init__(self, api: Api, token: str, language: str | None = None) -> None:
        self.c = api.c
        r = self.c.post(f"/api/v1/public/widget/{token}/conversations", json={"language": language} if language else None)
        assert r.status_code == 201, r.text
        d = r.json()
        self.cid, self.vt, self.language = d["conversation_id"], d["visitor_token"], d["language"]
        self.greeting = d["messages"][0]["content"]

    def say(self, text: str) -> tuple[str, str]:
        r = self.c.post(f"/api/v1/public/conversations/{self.cid}/messages", json={"text": text}, headers={"X-Visitor-Token": self.vt})
        assert r.status_code == 200, r.text
        d = r.json()
        return (d["messages"][0]["content"] if d["messages"] else ""), d["language"]


@pytest.mark.parametrize("lang", list(SCRIPTS))
def test_customer_books_inspection_in_their_language(api: Api, db: Any, lang: str) -> None:
    b = _multilingual_business(api)
    v = LangVisitor(api, b["widget_token"])
    assert "Sarah" in v.greeting  # English greeting until the customer writes
    for line, expected in SCRIPTS[lang]:
        reply, detected = v.say(line)
        assert detected == lang, (line, detected)
        assert expected in reply, f"{lang}: {line!r} -> {reply!r}"
        assert "I don't have" not in reply and "Thanks" not in reply  # no English leaking into the reply
    conv = db.scalar(select(Conversation).where(Conversation.id == v.cid))
    assert conv.language == lang
    appt = db.scalar(select(Appointment).where(Appointment.conversation_id == conv.id))
    assert appt is not None and appt.status == "scheduled"
    lead = db.get(Lead, conv.lead_id)
    assert lead is not None and lead.customer.name == NAMES[lang]
    assert conv.state["fields"]["zip"] == "76201"
    assert conv.state["fields"]["phone"] == "+19405550123"


def test_english_is_unchanged_and_names_do_not_switch_language(api: Api) -> None:
    b = _multilingual_business(api)
    v = LangVisitor(api, b["widget_token"])
    reply, lang = v.say("My roof started leaking after last night's storm. Can someone inspect it?")
    assert lang == "en" and "home or a commercial" in reply
    v.say("It's a house")
    v.say("76201")
    reply, lang = v.say("José García")  # accented name must not flip the conversation to Spanish
    assert lang == "en" and "phone" in reply.lower()


def test_language_not_enabled_stays_in_default(api: Api) -> None:
    b = make_business(api)  # agent languages default to ["en"]
    v = LangVisitor(api, b["widget_token"])
    reply, lang = v.say("Hola, necesito una cita para revisar mi techo")
    assert lang == "en"
    assert reply  # answered in English rather than in an unconfigured language


def test_widget_config_and_explicit_start_language(api: Api) -> None:
    b = _multilingual_business(api)
    api.patch(f"/agents/{b['agent']['id']}", {"greetings": {"es": "¡Hola! Soy Sarah de Mike's Roofing. ¿En qué le puedo ayudar?"}})
    cfg = api.c.get(f"/api/v1/public/widget/{b['widget_token']}/config").json()
    assert [x["code"] for x in cfg["languages"]] == ALL
    assert next(x for x in cfg["languages"] if x["code"] == "ar")["rtl"] is True
    assert cfg["default_language"] == "en"
    es = LangVisitor(api, b["widget_token"], "es")
    assert es.language == "es" and es.greeting.startswith("¡Hola! Soy Sarah")
    zh = LangVisitor(api, b["widget_token"], "zh")
    assert zh.language == "zh" and "Mike's Roofing" in zh.greeting and "Sarah" in zh.greeting
    bogus = LangVisitor(api, b["widget_token"], "xx")
    assert bogus.language == "en"


def test_agent_language_validation(api: Api) -> None:
    b = make_business(api)
    aid = b["agent"]["id"]
    assert api.patch(f"/agents/{aid}", {"languages": ["en", "klingon"]}).status_code == 422
    assert api.patch(f"/agents/{aid}", {"languages": []}).status_code == 422
    assert api.patch(f"/agents/{aid}", {"greetings": {"xx": "hi"}}).status_code == 422
    r = api.patch(f"/agents/{aid}", {"languages": ["es", "en", "es"]})
    assert r.status_code == 200 and r.json()["languages"] == ["es", "en"] and r.json()["language"] == "es"


@pytest.mark.parametrize(
    ("lang", "text"),
    [
        ("es", "¡Huele a gas en la cocina!"),
        ("zh", "家里有煤气味"),
        ("vi", "Nhà tôi có mùi gas"),
        ("ar", "أشم رائحة غاز في البيت"),
        ("fr", "Ça sent le gaz chez moi"),
    ],
)
def test_gas_emergency_is_handed_off_in_any_language(api: Api, lang: str, text: str) -> None:
    b = _multilingual_business(api)
    v = LangVisitor(api, b["widget_token"])
    r = api.c.post(f"/api/v1/public/conversations/{v.cid}/messages", json={"text": text}, headers={"X-Visitor-Token": v.vt}).json()
    assert r["handoff"] is True, (lang, r)
    assert r["language"] == lang


def test_business_hours_question_answered_in_chinese_and_spanish(api: Api) -> None:
    b = _multilingual_business(api)
    reply, _ = LangVisitor(api, b["widget_token"]).say("你们的营业时间是几点？")
    assert "8:00" in reply and "星期" in reply
    reply, _ = LangVisitor(api, b["widget_token"]).say("¿Cuál es su horario?")
    assert "8:00" in reply and ("lunes" in reply or "domingo" in reply)


def test_knowledge_is_not_quoted_in_the_wrong_language_without_llm(api: Api) -> None:
    b = _multilingual_business(api)
    reply, lang = LangVisitor(api, b["widget_token"]).say("¿Ofrecen financiamiento?")
    assert lang == "es"
    assert "financing is available" not in reply  # the English FAQ is not pasted into a Spanish conversation
    assert "equipo" in reply  # tells the customer a team member can help


@pytest.mark.parametrize(
    ("text", "lang"),
    [
        ("Hola, mi techo tiene una gotera", "es"),
        ("你好，我需要修屋顶", "zh"),
        ("Magandang araw po, may tagas ang bubong", "tl"),
        ("Xin chào, mái nhà bị dột", "vi"),
        ("مرحبا، أحتاج إصلاح السقف", "ar"),
        ("Bonjour, j'ai une fuite dans le toit", "fr"),
        ("Hi, my roof is leaking", "en"),
    ],
)
def test_language_detection(text: str, lang: str) -> None:
    got, conf = i18n.detect(text)
    assert got == lang and conf >= 0.6


@pytest.mark.parametrize("text", ["76201", "940-555-0123", "José García", "Nguyen", "ok"])
def test_detection_ignores_numbers_and_names(text: str) -> None:
    got, _ = i18n.detect(text)
    assert got is None or got == "en"


def test_spoken_digits_and_unicode_names() -> None:
    assert nlu._spoken_digits("siete seis dos cero uno") == "76201"
    assert nlu._spoken_digits("七六二零一") == "76201"
    assert nlu._spoken_digits("bảy sáu hai không một") == "76201"
    assert nlu.clean_name("Nguyễn Văn An") == "Nguyễn Văn An"
    assert nlu.clean_name("王伟") == "王伟"
    assert nlu.clean_name("محمد علي") == "محمد علي"


def test_every_catalog_message_exists_in_every_language() -> None:
    missing = [(k, lang) for k, msgs in i18n.M.items() for lang in i18n.SUPPORTED if lang not in msgs]
    assert not missing, missing
