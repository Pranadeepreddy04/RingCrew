"""Outgoing webhooks (§38), knowledge (§13), files (§51), privacy (§46), admin (§49), config validation (§93)."""

from __future__ import annotations

import hashlib
import hmac
import json
import threading
import uuid
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

import pytest
from sqlalchemy import func, select

from app.config import ConfigError, Settings
from app.models import AuditLog, Customer, Message, Organization, StoredFile, WebhookDelivery
from app.services.common import utcnow
from app.worker import run_once
from tests.conftest import Api, Visitor, make_business

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 64


class _Hook(BaseHTTPRequestHandler):
    received: list[tuple[dict[str, str], bytes]] = []
    status = 200

    def do_POST(self) -> None:  # noqa: N802
        body = self.rfile.read(int(self.headers.get("content-length", 0)))
        _Hook.received.append((dict(self.headers), body))
        self.send_response(_Hook.status)
        self.end_headers()

    def log_message(self, *a: Any) -> None:
        pass


@pytest.fixture()
def hook_server() -> Any:
    _Hook.received, _Hook.status = [], 200
    srv = HTTPServer(("127.0.0.1", 0), _Hook)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{srv.server_address[1]}/hook"
    srv.shutdown()


def test_outgoing_webhooks_signed_and_retried(api: Api, db: Any, hook_server: str) -> None:
    biz = make_business(api)
    api.post("/billing/checkout", {"plan": "pro"})
    r = api.post("/integrations/webhooks", {"url": hook_server, "events": ["lead.created", "appointment.created"]})
    assert r.status_code == 201
    secret = r.json()["secret"]
    assert "secret" not in json.dumps(api.get("/integrations/webhooks").json()["endpoints"])  # never shown again
    v = Visitor(api, biz["widget_token"])
    for t in ["I need a roof repair", "house", "76201", "no rush", "Jane Doe", "940-555-0123", "1"]:
        v.say(t)
    run_once()
    types = [json.loads(b)["type"] for _, b in _Hook.received]
    assert "lead.created" in types and "appointment.created" in types and "lead.qualified" not in types
    headers, body = _Hook.received[0]
    ts, sig = headers["X-ARE-Signature"].split(",")
    expected = hmac.new(secret.encode(), f"{ts[2:]}.".encode() + body, hashlib.sha256).hexdigest()
    assert sig == f"v1={expected}"
    # failure → retried with backoff, not marked delivered
    _Hook.status = 500
    ep = api.get("/integrations/webhooks").json()["endpoints"][0]
    api.post(f"/integrations/webhooks/{ep['id']}/test")
    run_once()
    d = db.scalar(select(WebhookDelivery).where(WebhookDelivery.event_type == "webhook.test"))
    assert d.status == "pending" and d.response_code == 500


def test_knowledge_crud_search_and_documents(api: Api) -> None:
    make_business(api)
    src = api.post(
        "/knowledge/sources", {"kind": "policy", "title": "Cancellation policy", "content": "Cancel up to 24 hours before your visit at no charge."}
    ).json()
    hits = api.get("/knowledge/search", params={"q": "cancel visit"}).json()
    assert hits and "24 hours" in hits[0]["content"]
    api.patch(f"/knowledge/sources/{src['id']}", {"approved": False})
    assert all("24 hours" not in h["content"] for h in api.get("/knowledge/search", params={"q": "cancel visit"}).json())
    r = api.post(
        "/knowledge/documents",
        files={"file": ("services.txt", b"We install seamless gutters and gutter guards across Denton County.")},
        data={"title": "Gutters"},
        headers={},
    )
    assert r.status_code == 201, r.text
    assert api.get("/knowledge/search", params={"q": "gutter guards"}).json()
    bad = api.post("/knowledge/documents", files={"file": ("x.pdf", b"not a pdf at all, just text")})
    assert bad.status_code == 415
    assert api.delete(f"/knowledge/sources/{src['id']}").status_code == 200


def test_website_import_blocks_private_addresses(api: Api) -> None:
    make_business(api)
    for url in ("http://127.0.0.1:8000", "http://localhost", "http://169.254.169.254/latest/meta-data", "file:///etc/passwd"):
        r = api.post("/organizations/current/import-website", {"url": url, "confirm": True})
        assert r.status_code == 400, url
    assert api.post("/organizations/current/import-website", {"url": "https://example.com", "confirm": False}).status_code == 400


def test_secure_uploads(api: Api, db: Any) -> None:
    biz = make_business(api)
    v = Visitor(api, biz["widget_token"])
    tok = api.c.get(f"/api/v1/public/conversations/{v.cid}/upload-token", headers={"X-Visitor-Token": v.vt}).json()["upload_token"]
    up = lambda name, data, ctype, t=tok: api.c.post("/api/v1/public/uploads", files={"file": (name, data, ctype)}, headers={"X-Upload-Token": t})  # noqa: E731
    assert up("roof.png", PNG, "image/png").status_code == 201
    assert up("evil.png", b"MZ\x90\x00 fake exe", "image/png").status_code == 415  # magic-byte mismatch
    assert up("x.exe", b"MZ", "application/x-msdownload").status_code == 415
    assert up("big.png", PNG + b"\x00" * (11 * 1024 * 1024), "image/png").status_code == 413
    assert up("roof.png", PNG, "image/png", t="forged.123.abc").status_code == 403
    f = db.scalar(select(StoredFile))
    assert str(f.organization_id) == biz["org"]["id"] and len(f.storage_key.split("/")[1]) >= 64  # unguessable key
    detail = api.get(f"/conversations/{v.cid}").json()
    url = detail["files"][0]["download_url"]
    assert api.c.get(url, headers={"X-Organization-Id": api.org_id}).content == PNG
    other = Api(api.c.app)
    make_business(other, name="Other")
    assert other.c.get(url, headers={"X-Organization-Id": other.org_id}).status_code == 404


def test_privacy_export_and_customer_deletion(api: Api, db: Any) -> None:
    biz = make_business(api)
    v = Visitor(api, biz["widget_token"])
    for t in ["I need a roof repair", "house", "76201", "no rush", "Del Eted", "940-555-0166"]:
        v.say(t)
    export = api.get("/organizations/current/export").json()
    assert export["customers"][0]["phone"] == "+19405550166" and export["conversations"][0]["messages"]
    cid = export["customers"][0]["id"]
    assert api.delete(f"/customers/{cid}").status_code == 200
    db.expire_all()
    c = db.get(Customer, uuid.UUID(cid))
    assert c.phone is None and c.name == "Deleted customer"
    contents = db.scalars(select(Message.content).where(Message.conversation_id == uuid.UUID(v.cid))).all()
    assert all("940-555-0166" not in m and "Del Eted" not in m for m in contents)
    assert db.scalar(select(func.count()).select_from(AuditLog).where(AuditLog.action == "privacy.customer_deleted")) == 1


def test_org_deletion_requires_confirmation(api: Api, db: Any) -> None:
    make_business(api, name="Gone Roofing")
    assert api.delete("/organizations/current", {"confirm_name": "wrong"}).status_code == 400
    assert api.delete("/organizations/current", {"confirm_name": "Gone Roofing"}).status_code == 200
    assert api.get("/leads").status_code == 403
    from app.routers.organizations import purge_tenant

    org = db.scalar(select(Organization).where(Organization.name == "Gone Roofing"))
    purge_tenant(db, org.id)
    db.commit()
    assert db.scalar(select(func.count()).select_from(Organization).where(Organization.name == "Gone Roofing")) == 0


def test_admin_access_suspension_impersonation_investigation(api: Api, app: Any, db: Any) -> None:
    biz = make_business(api)
    v = Visitor(api, biz["widget_token"])
    v.say("Do you offer financing?")
    from app.cli import create_superadmin

    create_superadmin("root@example.com", "Root-password-123")
    assert api.get("/admin/overview").status_code == 403
    admin = Api(app)
    admin.login("root@example.com", "Root-password-123")
    ov = admin.get("/admin/overview").json()
    assert ov["organizations"] == 1
    inv = admin.get(f"/admin/conversations/{v.cid}/investigate").json()
    assert any(e["kind"] == "tool" for e in inv["timeline"]) and inv["collected_fields"] == []
    assert admin.post(f"/admin/organizations/{biz['org']['id']}/status", {"status": "suspended", "reason": "fraud review"}).status_code == 200
    assert api.get("/leads").json()["error"]["code"] == "organization_suspended"
    admin.post(f"/admin/organizations/{biz['org']['id']}/status", {"status": "active", "reason": "cleared"})
    owner_id = api.get("/auth/me").json()["user"]["id"]
    imp = Api(app)
    imp.login("root@example.com", "Root-password-123")
    r = imp.post("/admin/impersonate", {"user_id": owner_id, "reason": "customer asked for help with setup"})
    assert r.status_code == 200 and r.json()["impersonating"] is True
    assert db.scalar(select(func.count()).select_from(AuditLog).where(AuditLog.action == "admin.impersonation_started")) == 1
    r = admin.put("/admin/industry-templates/dental", {"status": "active"})
    assert r.status_code == 400 and r.json()["error"]["code"] == "compliance_required"
    assert admin.post("/organizations", {"name": "Dental", "industry": "dental"}).status_code == 400


def test_production_config_rejects_unsafe_settings() -> None:
    with pytest.raises(ConfigError) as e:
        Settings(app_env="production", secret_key="x" * 40, encryption_key=None, cookie_secure=True)
    msg = str(e.value)
    assert "ENCRYPTION_KEY" in msg and "Sandbox providers are not allowed" in msg
    with pytest.raises(ConfigError):
        Settings(app_env="production", secret_key="dev-insecure-secret-change-me-0000000000000000")
    ok = Settings(app_env="production", secret_key="k" * 40, encryption_key="a" * 44, cookie_secure=True, allow_sandbox_providers_in_production=True)
    assert ok.is_production
    assert Settings(app_env="development").app_env == "development"
    _ = utcnow
