"""Scheduling (§30), concurrency/race conditions (§90), idempotency (§89)."""

from __future__ import annotations

import threading
import uuid
from datetime import datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from sqlalchemy import func, select

from app.db import SessionLocal
from app.models import Appointment, BusinessProfile, Customer, Organization
from app.providers.calendar import BusyInterval, SandboxCalendar
from app.services import scheduling
from app.services.common import utcnow
from tests.conftest import Api, make_business


def _setup(api: Api) -> tuple[str, str]:
    make_business(api)
    cust = api.post("/customers", {"name": "Ann Slot", "phone": "9405550101"}).json()
    return api.org_id or "", cust["id"]


def test_slots_respect_hours_timezone_and_lead_time(api: Api) -> None:
    make_business(api, all_week=False)  # default Mon–Fri 08:00–17:00
    api.put(
        "/organizations/current/profile",
        {"hours": {"mon": [["09:00", "12:00"]], "wed": [["13:00", "15:00"]]}, "appointment_duration_minutes": 60, "booking_lead_time_hours": 2},
    )
    data = api.get("/appointments/availability").json()
    tz = ZoneInfo(data["timezone"])
    assert data["slots"]
    earliest = utcnow() + timedelta(hours=2)
    for s in data["slots"]:
        start = datetime.fromisoformat(s["start"]).astimezone(tz)
        end = datetime.fromisoformat(s["end"]).astimezone(tz)
        assert start >= earliest
        assert start.weekday() in (0, 2)
        if start.weekday() == 0:
            assert start.hour >= 9 and (end.hour, end.minute) <= (12, 0)
        else:
            assert start.hour >= 13 and (end.hour, end.minute) <= (15, 0)
        assert (end - start) == timedelta(minutes=60)


def test_booked_slot_disappears_and_double_booking_rejected(api: Api) -> None:
    _, cid = _setup(api)
    slot = api.get("/appointments/availability").json()["slots"][0]
    r = api.post("/appointments", {"customer_id": cid, "start": slot["start"], "service": "Inspection"}, headers={"Idempotency-Key": "k1"})
    assert r.status_code == 201, r.text
    assert slot["start"] not in [s["start"] for s in api.get("/appointments/availability").json()["slots"]]
    r2 = api.post("/appointments", {"customer_id": cid, "start": slot["start"], "service": "Inspection"}, headers={"Idempotency-Key": "k2"})
    assert r2.status_code == 409 and r2.json()["error"]["code"] == "slot_unavailable"


def test_idempotent_booking(api: Api, db: Any) -> None:
    _, cid = _setup(api)
    slot = api.get("/appointments/availability").json()["slots"][0]
    body = {"customer_id": cid, "start": slot["start"], "service": "Inspection"}
    a = api.post("/appointments", body, headers={"Idempotency-Key": "same"}).json()
    b = api.post("/appointments", body, headers={"Idempotency-Key": "same"}).json()
    assert a["id"] == b["id"]
    assert db.scalar(select(func.count()).select_from(Appointment)) == 1


def test_concurrent_booking_of_same_slot_only_one_wins(api: Api) -> None:
    org_id, cid = _setup(api)
    slot = api.get("/appointments/availability").json()["slots"][0]
    start = datetime.fromisoformat(slot["start"])
    results: list[bool] = []
    barrier = threading.Barrier(6)

    def worker(i: int) -> None:
        with SessionLocal() as s:
            org = s.get(Organization, uuid.UUID(org_id))
            prof = s.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == org.id))
            cust = s.get(Customer, uuid.UUID(cid))
            barrier.wait()
            res = scheduling.book(s, org, prof, customer=cust, start=start, service="Race", source="test", idempotency_key=f"race-{i}")
            try:
                s.commit()
                results.append(res.ok)
            except Exception:
                s.rollback()
                results.append(False)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    with SessionLocal() as s:
        n = s.scalar(select(func.count()).select_from(Appointment).where(Appointment.start_at == start, Appointment.status == "scheduled"))
    assert n == 1, results
    assert results.count(True) == 1


def test_capacity_allows_parallel_crews(api: Api, db: Any) -> None:
    org_id, cid = _setup(api)
    org = db.get(Organization, uuid.UUID(org_id))
    org.settings = {**org.settings, "booking_capacity": 2}
    db.commit()
    slot = api.get("/appointments/availability").json()["slots"][0]
    for k in ("a", "b"):
        assert api.post("/appointments", {"customer_id": cid, "start": slot["start"], "service": "x"}, headers={"Idempotency-Key": k}).status_code == 201
    assert api.post("/appointments", {"customer_id": cid, "start": slot["start"], "service": "x"}, headers={"Idempotency-Key": "c"}).status_code == 409


def test_external_calendar_busy_time_is_respected(api: Api) -> None:
    _setup(api)
    api.post("/integrations/sandbox-calendar/connect")
    first = api.get("/appointments/availability").json()["slots"][0]
    s = datetime.fromisoformat(first["start"])
    SandboxCalendar.busy_blocks = [BusyInterval(s, s + timedelta(hours=3))]
    starts = [datetime.fromisoformat(x["start"]) for x in api.get("/appointments/availability").json()["slots"]]
    assert all(not (s - timedelta(minutes=59) < x < s + timedelta(hours=3)) for x in starts)
    SandboxCalendar.fail = True
    assert api.get("/appointments/availability").status_code == 503


def test_reschedule_cancel_and_status(api: Api) -> None:
    _, cid = _setup(api)
    slots = api.get("/appointments/availability").json()["slots"]
    a = api.post("/appointments", {"customer_id": cid, "start": slots[0]["start"], "service": "x"}).json()
    r = api.post(f"/appointments/{a['id']}/reschedule", {"start": slots[5]["start"]})
    assert r.status_code == 200 and r.json()["start_at"] == datetime.fromisoformat(slots[5]["start"]).isoformat()
    assert slots[0]["start"] in [s["start"] for s in api.get("/appointments/availability").json()["slots"]]
    assert api.post(f"/appointments/{a['id']}/status", {"status": "confirmed"}).json()["status"] == "confirmed"
    assert api.post(f"/appointments/{a['id']}/status", {"status": "cancelled"}).json()["status"] == "cancelled"
    assert api.post(f"/appointments/{a['id']}/status", {"status": "completed"}).status_code == 409


def test_ai_cannot_book_unoffered_slot(api: Api) -> None:
    """High-impact tool validation: the AI may only book a slot the backend offered."""
    from app.ai import tools
    from app.models import AIAgent, Conversation

    biz = make_business(api)
    with SessionLocal() as s:
        org = s.get(Organization, uuid.UUID(biz["org"]["id"]))
        agent = s.get(AIAgent, uuid.UUID(biz["agent"]["id"]))
        conv = Conversation(organization_id=org.id, agent_id=agent.id, channel="web", state={"offered_slots": []})
        s.add(conv)
        s.flush()
        prof = s.scalar(select(BusinessProfile).where(BusinessProfile.organization_id == org.id))
        from app.industry import resolve_pack

        ctx = tools.ToolContext(s, org, agent, conv, prof, resolve_pack("roofing"))
        res = tools.execute(ctx, "book_appointment", {"slot_start": (utcnow() + timedelta(days=2)).isoformat()})
        assert not res.ok and res.error == "slot_not_offered"
        res = tools.execute(ctx, "book_appointment", {"slot_start": "not-a-date"})
        assert not res.ok and res.error == "invalid_arguments"
        res = tools.execute(ctx, "drop_database", {})
        assert not res.ok and res.error == "unknown_tool"
        agent.capabilities = [c for c in agent.capabilities if c != "schedule_appointments"]
        res = tools.execute(ctx, "check_calendar", {})
        assert not res.ok and res.error == "capability_disabled"
        s.rollback()
