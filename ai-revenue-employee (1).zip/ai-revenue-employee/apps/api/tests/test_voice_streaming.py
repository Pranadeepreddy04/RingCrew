"""Voice agent: multilingual phone calls (language menu, per-language voices and speech recognition) and the
VibeVoice-ASR-Streaming path (phone media streams and browser voice), tested against a protocol-faithful fake server."""

from __future__ import annotations

import asyncio
import base64
import json
import time
from collections.abc import Iterator
from typing import Any

import numpy as np
import pytest
from sqlalchemy import select

from app.config import get_settings
from app.models import Appointment, Call, Conversation, Message
from app.providers.asr import ASRError, VibeVoiceASR, resample
from app.providers.messaging import SandboxVoice
from app.routers import voice_stream
from app.routers.voice_sms import stream_token
from app.voice.engine import Endpointer, StreamingRecognizer, mulaw_decode, mulaw_encode
from tests.conftest import Api
from tests.fake_vibevoice import FakeVibeVoice, silence, speech
from tests.test_channels import BIZ_NUMBER, CALLER, _post, _setup, call, speak


@pytest.fixture()
def vibevoice(monkeypatch: pytest.MonkeyPatch) -> Iterator[FakeVibeVoice]:
    with FakeVibeVoice() as fake:
        s = get_settings()
        monkeypatch.setattr(s, "voice_asr_provider", "vibevoice")
        monkeypatch.setattr(s, "vibevoice_asr_url", fake.url)
        monkeypatch.setattr(s, "vibevoice_timeout_seconds", 5.0)
        yield fake


def _languages(api: Api, biz: dict[str, Any], langs: list[str]) -> None:
    r = api.patch(f"/agents/{biz['agent']['id']}", {"languages": langs})
    assert r.status_code == 200, r.text


# ------------------------------------------------------------------ multilingual phone calls (Twilio speech recognition)


def test_language_menu_and_spanish_call_with_twilio_asr(api: Api, db: Any) -> None:
    biz = _setup(api)
    _languages(api, biz, ["en", "es", "zh", "vi"])
    r = call(api, "CA1001")
    assert 'input="dtmf"' in r.text and "For English, press 1." in r.text
    assert "Para español, oprima 2." in r.text and 'language="es-US"' in r.text and "Google.es-US" in r.text
    assert "按3" in r.text or "3" in r.text
    cid = str(db.scalar(select(Conversation.id).where(Conversation.external_id == "CA1001")))
    r = _post(api, f"/webhooks/voice/language?conversation_id={cid}", {"CallSid": "CA1001", "Digits": "2"})
    assert r.status_code == 200 and "asistente de inteligencia artificial" in r.text
    assert '<Gather input="speech"' in r.text and 'language="es-US"' in r.text
    twiml = speak(api, cid, "Mi techo tiene una gotera desde la tormenta", sid="CA1001")
    assert "vivienda" in twiml and 'language="es-US"' in twiml
    speak(api, cid, "Es una casa", sid="CA1001")
    speak(api, cid, "siete seis dos cero uno", sid="CA1001")
    assert "teléfono" not in speak(api, cid, "José García", sid="CA1001")  # phone is known from caller ID → straight to times
    twiml = speak(api, cid, "la primera", sid="CA1001")
    assert "quedó programada" in twiml
    assert "<Hangup/>" in speak(api, cid, "No, eso es todo. Adiós", sid="CA1001")
    db.expire_all()
    c = db.scalar(select(Call).where(Call.provider_call_id == "CA1001"))
    assert c.language == "es" and c.asr_provider == "twilio"
    assert db.scalar(select(Appointment)) is not None


def test_language_menu_timeout_uses_primary_and_vietnamese_choice(api: Api, db: Any) -> None:
    biz = _setup(api)
    _languages(api, biz, ["en", "vi"])
    call(api, "CA1002")
    cid = str(db.scalar(select(Conversation.id).where(Conversation.external_id == "CA1002")))
    r = _post(api, f"/webhooks/voice/language?conversation_id={cid}", {"CallSid": "CA1002"})
    assert "AI assistant" in r.text and 'language="en-US"' in r.text
    call(api, "CA1003")
    cid = str(db.scalar(select(Conversation.id).where(Conversation.external_id == "CA1003")))
    r = _post(api, f"/webhooks/voice/language?conversation_id={cid}", {"CallSid": "CA1003", "Digits": "2"})
    assert 'language="vi-VN"' in r.text
    assert "Xin lỗi" in speak(api, cid, "", sid="CA1003")  # silence prompt in Vietnamese


def test_single_language_agent_has_no_menu(api: Api) -> None:
    _setup(api)
    r = call(api, "CA1004")
    assert 'input="dtmf"' not in r.text and '<Gather input="speech"' in r.text


def test_language_webhook_requires_signature(api: Api, db: Any) -> None:
    biz = _setup(api)
    _languages(api, biz, ["en", "es"])
    call(api, "CA1005")
    cid = str(db.scalar(select(Conversation.id)))
    assert _post(api, f"/webhooks/voice/language?conversation_id={cid}", {"CallSid": "CA1005", "Digits": "2"}, sign=False).status_code == 403


# ------------------------------------------------------------------ audio plumbing


def test_mulaw_roundtrip_and_resampling() -> None:
    x = speech(0.5, 8000)
    y = mulaw_decode(mulaw_encode(x))
    assert np.max(np.abs(x - y)) < 0.02
    up = resample(x, 8000, 24000)
    assert len(up) == 12000 and abs(float(np.max(np.abs(up))) - float(np.max(np.abs(x)))) < 0.01


def test_endpointer_finds_utterances_and_ignores_noise() -> None:
    e = Endpointer(8000, silence_ms=700)
    audio = np.concatenate([silence(1.0, 8000), speech(1.0, 8000), silence(1.0, 8000), speech(0.6, 8000), silence(1.0, 8000)])
    kinds = [ev.kind for i in range(0, len(audio), 160) for ev in e.feed(audio[i : i + 160])]
    assert kinds.count("start") == 2 and kinds.count("end") == 2
    assert [k for k in kinds if k != "audio"] == ["start", "end", "start", "end"]
    quiet = Endpointer(8000)
    assert not [ev for ev in quiet.feed(silence(3.0, 8000)) if ev.kind == "start"]


# ------------------------------------------------------------------ VibeVoice client (real websocket protocol)


def test_vibevoice_client_streams_float32_and_returns_final(vibevoice: FakeVibeVoice) -> None:
    vibevoice.script.extend(["hola mi techo tiene una gotera"])

    async def run() -> tuple[str, list[str]]:
        asr = VibeVoiceASR(hotwords="Mike's Roofing")
        assert (await asr.health())["ok"]
        partials: list[str] = []
        rec = StreamingRecognizer(asr, sample_rate=16000, language="es", hotwords="Sarah", on_partial=lambda t: _append(partials, t))
        finals: list[str] = []
        rec.on_final = lambda t: _append(finals, t)
        audio = np.concatenate([silence(0.5, 16000), speech(2.0, 16000), silence(1.0, 16000)])
        for i in range(0, len(audio), 320):
            await rec.feed(audio[i : i + 320])
        return finals[0], partials

    final, partials = asyncio.run(run())
    assert final == "hola mi techo tiene una gotera"
    assert partials and partials[0].startswith("hola")
    sess = vibevoice.sessions[0]
    assert sess["options"] == {"context_info": "Mike's Roofing, Sarah", "temperature": 0, "max_tokens": 256}
    assert 2.0 * 24000 <= sess["samples"] <= 3.5 * 24000  # resampled 16 kHz -> 24 kHz, pre-roll + speech + trailing silence


async def _append(xs: list[str], t: str) -> None:
    xs.append(t)


def test_vibevoice_unreachable_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    async def run() -> None:
        await VibeVoiceASR(base_url="http://127.0.0.1:9", timeout=1).open(language="en")

    with pytest.raises(Exception) as ei:
        asyncio.run(run())
    assert isinstance(ei.value, ASRError | OSError) or "connect" in str(ei.value).lower()


def test_vibevoice_only_handles_its_languages() -> None:
    asr = VibeVoiceASR(base_url="http://x")
    assert all(asr.supports(x) for x in ("en", "es", "zh", "fr"))
    assert not any(asr.supports(x) for x in ("vi", "tl", "ar"))


# ------------------------------------------------------------------ phone call over Twilio Media Streams + VibeVoice


def _frames(audio: np.ndarray) -> Iterator[str]:
    data = mulaw_encode(audio)
    for i in range(0, len(data), 160):  # 20 ms frames, like Twilio
        yield json.dumps({"event": "media", "media": {"track": "inbound", "payload": base64.b64encode(data[i : i + 160]).decode()}})


def _say_on_phone(ws: Any, seconds: float = 1.2) -> None:
    for f in _frames(np.concatenate([speech(seconds, 8000), silence(1.0, 8000)])):
        ws.send_text(f)


def _wait_updates(n: int, timeout: float = 10) -> list[tuple[str, str]]:
    end = time.time() + timeout
    while time.time() < end and len(SandboxVoice.updates) < n:
        time.sleep(0.05)
    return SandboxVoice.updates


def test_phone_call_with_vibevoice_streaming_books_in_spanish(api: Api, db: Any, vibevoice: FakeVibeVoice, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(voice_stream, "SPEECH_CHARS_PER_SECOND", 1e9)  # caller waits for the agent to finish each reply
    biz = _setup(api)
    _languages(api, biz, ["en", "es", "vi"])
    call(api, "CA2001")
    conv = db.scalar(select(Conversation).where(Conversation.external_id == "CA2001"))
    r = _post(api, f"/webhooks/voice/language?conversation_id={conv.id}", {"CallSid": "CA2001", "Digits": "2"})
    assert "<Start><Stream" in r.text and "ws://testserver/api/v1/voice/stream" in r.text and 'track="inbound_track"' in r.text
    assert stream_token(conv.id, "CA2001") in r.text and "<Gather" not in r.text and "/voice/keepalive" in r.text
    vibevoice.script.extend(["Mi techo tiene una gotera desde la tormenta", "Es una casa", "siete seis dos cero uno", "José García", "la primera"])
    with api.c.websocket_connect("/api/v1/voice/stream") as ws:
        ws.send_text(json.dumps({"event": "connected", "protocol": "Call", "version": "1.0.0"}))
        ws.send_text(
            json.dumps(
                {
                    "event": "start",
                    "start": {
                        "callSid": "CA2001",
                        "streamSid": "MZ1",
                        "customParameters": {"conversation_id": str(conv.id), "token": stream_token(conv.id, "CA2001")},
                    },
                }
            )
        )
        expected = ["vivienda", "código postal", "nombre", "Cuál le conviene", "quedó programada"]
        for i, needle in enumerate(expected):
            _say_on_phone(ws)
            updates = _wait_updates(i + 1)
            assert len(updates) >= i + 1, f"no reply for utterance {i}"
            sid, twiml = updates[i]
            assert sid == "CA2001" and needle in twiml, (needle, twiml)
            assert 'language="es-US"' in twiml and "/voice/keepalive" in twiml
        ws.send_text(json.dumps({"event": "stop"}))
    db.expire_all()
    assert db.scalar(select(Appointment)) is not None
    msgs = db.scalars(select(Message).where(Message.conversation_id == conv.id, Message.role == "ai")).all()
    assert any(m.meta.get("asr") == "vibevoice" for m in msgs)
    c = db.scalar(select(Call).where(Call.provider_call_id == "CA2001"))
    assert c.asr_provider == "vibevoice" and c.language == "es"
    assert len(vibevoice.sessions) == 5 and "Mike's Roofing" in (vibevoice.sessions[0]["options"]["context_info"] or "")


def test_caller_can_interrupt_the_agent(api: Api, db: Any, vibevoice: FakeVibeVoice) -> None:
    _setup(api)
    call(api, "CA2006")
    conv = db.scalar(select(Conversation))
    vibevoice.script.extend(["My roof is leaking", "sorry, it's a house"])
    with api.c.websocket_connect("/api/v1/voice/stream") as ws:
        ws.send_text(
            json.dumps(
                {
                    "event": "start",
                    "start": {"callSid": "CA2006", "customParameters": {"conversation_id": str(conv.id), "token": stream_token(conv.id, "CA2006")}},
                }
            )
        )
        _say_on_phone(ws)
        assert "home or a commercial" in _wait_updates(1)[0][1]
        _say_on_phone(ws)  # talks over the reply
        updates = _wait_updates(3)
        ws.send_text(json.dumps({"event": "stop"}))
    barge = updates[1][1]
    assert "<Say" not in barge and "<Pause" in barge  # agent speech cut immediately
    assert "ZIP" in updates[2][1]  # and the interruption was understood


def test_vietnamese_call_uses_twilio_asr_even_when_vibevoice_is_on(api: Api, db: Any, vibevoice: FakeVibeVoice) -> None:
    biz = _setup(api)
    _languages(api, biz, ["en", "vi"])
    call(api, "CA2002")
    cid = str(db.scalar(select(Conversation.id).where(Conversation.external_id == "CA2002")))
    r = _post(api, f"/webhooks/voice/language?conversation_id={cid}", {"CallSid": "CA2002", "Digits": "2"})
    assert "<Stream" not in r.text and '<Gather input="speech"' in r.text and 'language="vi-VN"' in r.text


def test_media_stream_rejects_forged_token(api: Api, db: Any, vibevoice: FakeVibeVoice) -> None:
    _setup(api)
    call(api, "CA2003")
    conv = db.scalar(select(Conversation))
    from starlette.websockets import WebSocketDisconnect

    with api.c.websocket_connect("/api/v1/voice/stream") as ws:
        ws.send_text(json.dumps({"event": "start", "start": {"callSid": "CA2003", "customParameters": {"conversation_id": str(conv.id), "token": "forged"}}}))
        with pytest.raises(WebSocketDisconnect) as ei:
            ws.receive_text()
        assert ei.value.code == 1008
    # a valid token for a different call is rejected too
    with api.c.websocket_connect("/api/v1/voice/stream") as ws:
        ws.send_text(
            json.dumps(
                {
                    "event": "start",
                    "start": {"callSid": "CA9999", "customParameters": {"conversation_id": str(conv.id), "token": stream_token(conv.id, "CA9999")}},
                }
            )
        )
        with pytest.raises(WebSocketDisconnect):
            ws.receive_text()


def test_streaming_falls_back_to_twilio_asr_when_vibevoice_is_down(api: Api, db: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    s = get_settings()
    monkeypatch.setattr(s, "voice_asr_provider", "vibevoice")
    monkeypatch.setattr(s, "vibevoice_asr_url", "http://127.0.0.1:9")
    monkeypatch.setattr(s, "vibevoice_timeout_seconds", 1.0)
    _setup(api)
    r = call(api, "CA2004")
    assert "<Start><Stream" in r.text
    conv = db.scalar(select(Conversation))
    with api.c.websocket_connect("/api/v1/voice/stream") as ws:
        ws.send_text(
            json.dumps(
                {
                    "event": "start",
                    "start": {"callSid": "CA2004", "customParameters": {"conversation_id": str(conv.id), "token": stream_token(conv.id, "CA2004")}},
                }
            )
        )
        _say_on_phone(ws)
        updates = _wait_updates(1)
        ws.send_text(json.dumps({"event": "stop"}))
    assert updates and '<Gather input="speech"' in updates[0][1] and "catch that" in updates[0][1]
    db.expire_all()
    assert db.get(Conversation, conv.id).state.get("asr_fallback") is True


def test_keepalive_prompts_then_hangs_up_on_silence(api: Api, db: Any, vibevoice: FakeVibeVoice) -> None:
    _setup(api)
    call(api, "CA2005")
    cid = str(db.scalar(select(Conversation.id)))
    url = f"/webhooks/voice/keepalive?conversation_id={cid}"
    assert "<Say" not in _post(api, url, {"CallSid": "CA2005"}).text
    assert "didn't hear" in _post(api, url, {"CallSid": "CA2005"}).text
    assert "<Hangup/>" in _post(api, url, {"CallSid": "CA2005"}).text


# ------------------------------------------------------------------ browser voice (website widget)


def _widget_conv(api: Api, biz: dict[str, Any], language: str | None = None) -> tuple[str, str]:
    r = api.c.post(f"/api/v1/public/widget/{biz['widget_token']}/conversations", json={"language": language} if language else None)
    d = r.json()
    return d["conversation_id"], d["visitor_token"]


def test_browser_voice_with_vibevoice(api: Api, db: Any, vibevoice: FakeVibeVoice) -> None:
    biz = _setup(api)
    _languages(api, biz, ["en", "es", "zh", "fr"])
    cid, vt = _widget_conv(api, biz)
    vibevoice.script.extend(["你好，暴风雨后我家屋顶漏水了，可以来检查吗？"])
    with api.c.websocket_connect(f"/api/v1/public/conversations/{cid}/voice") as ws:
        ws.send_json({"type": "start", "visitor_token": vt, "sample_rate": 16000, "format": "s16", "language": "zh"})
        ready = ws.receive_json()
        assert ready == {"type": "ready", "language": "zh", "asr": "vibevoice"}
        audio = np.concatenate([speech(1.5, 16000), silence(1.0, 16000)])
        pcm16 = (audio * 32767).astype("<i2").tobytes()
        for i in range(0, len(pcm16), 3200):
            ws.send_bytes(pcm16[i : i + 3200])
        seen: dict[str, Any] = {}
        while "reply" not in seen:
            m = ws.receive_json()
            seen.setdefault(m["type"], m)
        assert "speech_start" in seen and "partial" in seen
        assert seen["final"]["text"].startswith("你好")
        assert seen["reply"]["customer_message_id"] and seen["reply"]["language"] == "zh" and "邮政编码" in seen["reply"]["messages"][0]["content"]
        ws.send_json({"type": "close"})
    db.expire_all()
    cust = db.scalar(select(Message).where(Message.conversation_id == cid, Message.role == "customer"))
    assert cust.meta.get("input") == "voice" and cust.meta.get("asr") == "vibevoice"


def test_browser_voice_requires_visitor_token_and_reports_unsupported(api: Api, vibevoice: FakeVibeVoice) -> None:
    biz = _setup(api)
    _languages(api, biz, ["en", "vi"])
    cid, vt = _widget_conv(api, biz)
    with api.c.websocket_connect(f"/api/v1/public/conversations/{cid}/voice") as ws:
        ws.send_json({"type": "start", "visitor_token": "nope", "sample_rate": 16000})
        assert ws.receive_json()["code"] == "unauthorized"
    other, _ = _widget_conv(api, biz)
    with api.c.websocket_connect(f"/api/v1/public/conversations/{other}/voice") as ws:
        ws.send_json({"type": "start", "visitor_token": vt, "sample_rate": 16000})  # token of another conversation
        assert ws.receive_json()["code"] == "unauthorized"
    with api.c.websocket_connect(f"/api/v1/public/conversations/{cid}/voice") as ws:
        ws.send_json({"type": "start", "visitor_token": vt, "sample_rate": 16000, "language": "vi"})
        m = ws.receive_json()
        assert m["type"] == "unavailable" and m["reason"] == "language_not_supported"  # browser falls back to its own recognizer


def test_browser_voice_unavailable_without_streaming_asr(api: Api) -> None:
    biz = _setup(api)
    cid, vt = _widget_conv(api, biz)
    with api.c.websocket_connect(f"/api/v1/public/conversations/{cid}/voice") as ws:
        ws.send_json({"type": "start", "visitor_token": vt, "sample_rate": 16000})
        assert ws.receive_json() == {"type": "unavailable", "reason": "no_streaming_asr", "language": "en"}


def test_widget_config_reports_voice_mode(api: Api, vibevoice: FakeVibeVoice) -> None:
    biz = _setup(api)
    cfg = api.c.get(f"/api/v1/public/widget/{biz['widget_token']}/config").json()
    assert cfg["voice_input"]["asr"] == "vibevoice" and cfg["voice_input"]["vibevoice_languages"] == ["en", "es", "fr", "zh"]


_ = (CALLER, BIZ_NUMBER)


def test_vibevoice_language_routing_is_configurable(api: Api, db: Any, vibevoice: FakeVibeVoice, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(get_settings(), "vibevoice_languages", "en,es,zh,fr,vi")
    biz = _setup(api)
    _languages(api, biz, ["en", "vi"])
    call(api, "CA2010")
    cid = str(db.scalar(select(Conversation.id).where(Conversation.external_id == "CA2010")))
    r = _post(api, f"/webhooks/voice/language?conversation_id={cid}", {"CallSid": "CA2010", "Digits": "2"})
    assert "<Start><Stream" in r.text and 'language="vi-VN"' in r.text
    cfg = api.c.get(f"/api/v1/public/widget/{biz['widget_token']}/config").json()
    assert "vi" in cfg["voice_input"]["vibevoice_languages"]
