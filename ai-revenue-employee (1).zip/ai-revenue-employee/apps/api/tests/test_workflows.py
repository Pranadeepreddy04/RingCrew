"""Follow-up automation (§31): triggers, delays, quiet hours, stop conditions, consent, no loops."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select

from app.models import Customer, Lead, Workflow, WorkflowRun
from app.providers.messaging import SandboxSms
from app.services.common import utcnow
from app.worker import run_once
from tests.conftest import Api, Visitor, make_business
from tests.test_channels import BIZ_NUMBER, sms


def _lead_without_booking(api: Api) -> Visitor:
    biz = make_business(api)
    assert api.post("/integrations/phone-numbers", {"mode": "existing", "number": BIZ_NUMBER}).status_code == 201
    for w in api.get("/workflows").json()["items"]:
        api.put(f"/workflows/{w['id']}", {**{k: w[k] for k in ("name", "trigger", "steps", "stop_conditions", "max_attempts", "active")}, "quiet_hours": {}})
    v = Visitor(api, biz["widget_token"])
    for t in ["I need a roof repair", "house", "76201", "no rush", "Jane Doe", "940-555-0123"]:
        v.say(t)
    return v


def _due_now(db: Any) -> None:
    for r in db.scalars(select(WorkflowRun).where(WorkflowRun.status == "active")).all():
        r.next_run_at = utcnow()
    db.commit()


def test_followup_sent_then_second_step_then_completes(api: Api, db: Any) -> None:
    _lead_without_booking(api)
    run = db.scalar(select(WorkflowRun))
    assert run is not None and run.status == "active"
    assert 55 <= (run.next_run_at - utcnow()).total_seconds() / 60 <= 61  # configured delay
    run_once()
    assert not SandboxSms.outbox  # not due yet
    _due_now(db)
    run_once()
    assert len(SandboxSms.outbox) == 1 and SandboxSms.outbox[0]["body"].startswith("Hi Jane, this is Sarah with Mike's Roofing")
    db.expire_all()
    run = db.scalar(select(WorkflowRun))
    assert run.step_index == 1 and run.status == "active"
    assert db.scalar(select(Lead.status)) == "qualified"  # never moved backwards by automation
    _due_now(db)
    run_once()
    db.expire_all()
    assert len(SandboxSms.outbox) == 2 and db.scalar(select(WorkflowRun.status)) == "completed"
    _due_now(db)
    run_once()
    assert len(SandboxSms.outbox) == 2  # max attempts respected: no loops


def test_followup_stops_when_customer_replies(api: Api, db: Any) -> None:
    _lead_without_booking(api)
    sms(api, "Do you offer financing?", frm="+19405550123")
    db.expire_all()
    assert db.scalar(select(WorkflowRun.stop_reason)) == "customer_replied"


def test_followup_stops_on_booking_and_opt_out(api: Api, db: Any) -> None:
    v = _lead_without_booking(api)
    v.say("1")
    db.expire_all()
    runs = {r.workflow_id: r for r in db.scalars(select(WorkflowRun)).all()}
    lead_wf = db.scalar(select(Workflow).where(Workflow.trigger == "lead.created"))
    assert runs[lead_wf.id].stop_reason == "appointment_booked"
    sms(api, "STOP", frm="+19405550123")
    db.expire_all()
    assert all(r.status != "active" for r in db.scalars(select(WorkflowRun)).all())


def test_quiet_hours_defer(api: Api, db: Any) -> None:
    _lead_without_booking(api)
    wf = db.scalar(select(Workflow).where(Workflow.trigger == "lead.created"))
    wf.quiet_hours = {"start": "00:00", "end": "23:59"}
    db.commit()
    _due_now(db)
    run_once()
    db.expire_all()
    assert not SandboxSms.outbox
    assert db.scalar(select(WorkflowRun.next_run_at).where(WorkflowRun.workflow_id == wf.id)) > utcnow()


def test_no_consent_no_followup(api: Api, db: Any) -> None:
    _lead_without_booking(api)
    from app.models import CustomerConsent

    for c in db.scalars(select(CustomerConsent)).all():
        db.delete(c)
    db.commit()
    _due_now(db)
    run_once()
    db.expire_all()
    assert not SandboxSms.outbox
    assert db.scalar(select(WorkflowRun.stop_reason).where(WorkflowRun.status == "stopped")) == "no_consent"


def test_workflow_validation(api: Api) -> None:
    make_business(api)
    bad = api.post(
        "/workflows",
        {
            "name": "x",
            "trigger": "lead.created",
            "steps": [{"delay_minutes": 5, "channel": "fax", "template": "Hi {secret}"}],
            "stop_conditions": ["whenever"],
            "quiet_hours": {"start": "25:00"},
        },
    )
    assert bad.status_code == 422
    details = " ".join(bad.json()["error"]["details"])
    assert "sms" in details and "secret" in details and "whenever" in details and "quiet_hours" in details
    ok = api.post(
        "/workflows",
        {
            "name": "Review request",
            "trigger": "appointment.completed",
            "steps": [{"delay_minutes": 120, "channel": "sms", "template": "Thanks {first_name}! Reply STOP to opt out."}],
            "stop_conditions": ["opted_out"],
        },
    )
    assert ok.status_code == 201
    _ = Customer
