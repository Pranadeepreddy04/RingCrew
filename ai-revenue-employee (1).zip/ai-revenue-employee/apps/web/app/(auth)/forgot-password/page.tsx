"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";

import { Alert, Button, Input } from "@/components/ui";
import { errorText, post } from "@/lib/api";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await post("/auth/password-reset/request", { email });
      setSent(true);
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <h1 className="text-3xl font-semibold">Reset your password</h1>
      {sent ? (
        <div className="mt-4"><Alert tone="go">If an account exists for {email}, we&apos;ve emailed a reset link. It expires in 1 hour.</Alert></div>
      ) : (
        <form onSubmit={submit} className="mt-5 space-y-4">
          <Input label="Email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          {err && <Alert>{err}</Alert>}
          <Button type="submit" loading={busy} className="w-full">Email me a reset link</Button>
        </form>
      )}
      <p className="mt-4 text-sm"><Link className="text-link underline" href="/login">Back to sign in</Link></p>
    </>
  );
}
