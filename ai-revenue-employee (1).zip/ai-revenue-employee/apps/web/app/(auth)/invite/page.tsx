"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState, type FormEvent } from "react";

import { Alert, Button, Input, Loading } from "@/components/ui";
import { errorText, get, post, setOrgId } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export default function InvitePage() {
  return <Suspense><Invite /></Suspense>;
}

function Invite() {
  const token = useSearchParams().get("token") ?? "";
  const router = useRouter();
  const { refresh } = useAuth();
  const [info, setInfo] = useState<{ email: string; role: string; organization_name: string; has_account: boolean } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [f, setF] = useState({ name: "", password: "" });
  const [busy, setBusy] = useState(false);
  useEffect(() => { get<typeof info>(`/auth/invitations/${encodeURIComponent(token)}`).then(setInfo).catch((e) => setErr(errorText(e))); }, [token]);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const me = await post<{ organizations: { id: string; name: string }[] }>("/auth/invitations/accept", { token, ...f });
      const org = me.organizations.find((o) => o.name === info?.organization_name);
      setOrgId(org?.id ?? null);
      await refresh();
      router.replace("/app/dashboard");
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };
  if (!info && !err) return <Loading />;
  return (
    <>
      <h1 className="text-3xl font-semibold">Join {info?.organization_name ?? "your team"}</h1>
      {info && <p className="mt-1 text-muted">You were invited as {info.role} ({info.email}).</p>}
      {info && (
        <form onSubmit={submit} className="mt-5 space-y-4">
          {!info.has_account && <Input label="Your name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />}
          <Input label={info.has_account ? "Your existing password" : "Choose a password"} type="password" required value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
          {err && <Alert>{err}</Alert>}
          <Button type="submit" loading={busy} className="w-full">Accept invitation</Button>
        </form>
      )}
      {!info && err && <div className="mt-4"><Alert>{err}</Alert></div>}
    </>
  );
}
