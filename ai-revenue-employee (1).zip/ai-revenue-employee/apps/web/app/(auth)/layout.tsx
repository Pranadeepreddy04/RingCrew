import type { ReactNode } from "react";

import { Logo } from "@/components/site-chrome";

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <main id="main" className="flex min-h-screen flex-col items-center px-4 py-10">
      <Logo />
      <div className="mt-8 w-full max-w-md rounded-lg border border-line bg-surface p-6">{children}</div>
    </main>
  );
}
