"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState, type FormEvent } from "react";

import { Alert, Button, Input } from "@/components/ui";
import { errorText, get, post } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export default function LoginPage() {
  return <Suspense><Login /></Suspense>;
}

function Login() {
  const router = useRouter();
  const params = useSearchParams();
  const { refresh } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [google, setGoogle] = useState(false);
  useEffect(() => { get<{ enabled: boolean }>("/auth/google/status").then((r) => setGoogle(r.enabled)).catch(() => setGoogle(false)); }, []);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      await post("/auth/login", { email, password });
      const me = await refresh();
      const next = params.get("next");
      router.replace(next && next.startsWith("/") && !next.startsWith("//") ? next : me?.organizations.length ? "/app/dashboard" : "/onboarding");
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <h1 className="text-3xl font-semibold">Sign in</h1>
      <form onSubmit={submit} className="mt-5 space-y-4">
        <Input label="Email" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        <Input label="Password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        {err && <Alert>{err}</Alert>}
        <Button type="submit" loading={busy} className="w-full">Sign in</Button>
      </form>
      {google && <a href="/api/v1/auth/google/start" className="mt-3 flex h-10 items-center justify-center rounded-md border border-line font-semibold hover:border-ink-2">Continue with Google</a>}
      <div className="mt-5 flex justify-between text-sm">
        <Link className="text-link underline" href="/forgot-password">Forgot password?</Link>
        <Link className="text-link underline" href="/signup">Create an account</Link>
      </div>
    </>
  );
}
