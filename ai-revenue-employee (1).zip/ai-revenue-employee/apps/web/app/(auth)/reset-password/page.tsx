"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";

import { Alert, Button, Input } from "@/components/ui";
import { errorText, post } from "@/lib/api";

export default function ResetPage() {
  return <Suspense><Reset /></Suspense>;
}

function Reset() {
  const token = useSearchParams().get("token") ?? "";
  const [password, setPassword] = useState("");
  const [done, setDone] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      await post("/auth/password-reset/confirm", { token, password });
      setDone(true);
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <h1 className="text-3xl font-semibold">Choose a new password</h1>
      {done ? (
        <div className="mt-4 space-y-3"><Alert tone="go">Password updated. You&apos;ve been signed out everywhere.</Alert><Link className="text-link underline" href="/login">Sign in</Link></div>
      ) : (
        <form onSubmit={submit} className="mt-5 space-y-4">
          <Input label="New password" type="password" autoComplete="new-password" required minLength={10} value={password} onChange={(e) => setPassword(e.target.value)} />
          {err && <Alert>{err}</Alert>}
          <Button type="submit" loading={busy} disabled={!token} className="w-full">Save password</Button>
        </form>
      )}
    </>
  );
}
