"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";

import { Alert, Button, Input } from "@/components/ui";
import { errorText, post } from "@/lib/api";
import { useAuth } from "@/lib/auth";

export default function SignupPage() {
  return <Suspense><Signup /></Suspense>;
}

function Signup() {
  const router = useRouter();
  const params = useSearchParams();
  const { refresh } = useAuth();
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      await post("/auth/signup", f);
      await refresh();
      const industry = params.get("industry");
      router.replace(industry ? `/onboarding?industry=${encodeURIComponent(industry)}` : "/onboarding");
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };
  return (
    <>
      <h1 className="text-3xl font-semibold">Build your AI employee</h1>
      <p className="mt-1 text-muted">Step 1 of 9 — create your account.</p>
      <form onSubmit={submit} className="mt-5 space-y-4">
        <Input label="Your name" autoComplete="name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Input label="Work email" type="email" autoComplete="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
        <Input label="Password" type="password" autoComplete="new-password" required minLength={10} hint="At least 10 characters, with a number or symbol." value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} />
        {err && <Alert>{err}</Alert>}
        <Button type="submit" loading={busy} className="w-full">Create account</Button>
      </form>
      <p className="mt-4 text-sm text-muted">By creating an account you agree to the <Link className="text-link underline" href="/terms">terms</Link> and <Link className="text-link underline" href="/privacy">privacy policy</Link>.</p>
      <p className="mt-2 text-sm">Already have an account? <Link className="text-link underline" href="/login">Sign in</Link></p>
    </>
  );
}
