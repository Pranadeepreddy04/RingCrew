"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";

import { Alert, Loading } from "@/components/ui";
import { errorText, post } from "@/lib/api";

export default function VerifyPage() {
  return <Suspense><Verify /></Suspense>;
}

function Verify() {
  const token = useSearchParams().get("token") ?? "";
  const [state, setState] = useState<{ ok?: boolean; err?: string }>({});
  useEffect(() => {
    post("/auth/verify-email", { token }).then(() => setState({ ok: true })).catch((e) => setState({ err: errorText(e) }));
  }, [token]);
  return (
    <>
      <h1 className="text-3xl font-semibold">Verify email</h1>
      <div className="mt-4">
        {state.ok ? <Alert tone="go">Your email is verified.</Alert> : state.err ? <Alert>{state.err}</Alert> : <Loading label="Verifying" />}
      </div>
      <p className="mt-4 text-sm"><Link className="text-link underline" href="/app/dashboard">Go to your dashboard</Link></p>
    </>
  );
}
