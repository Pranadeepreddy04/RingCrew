"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";

import { ChatPanel, type ChatLine } from "@/components/chat-panel";
import { Alert, Badge, Button, Input, Select } from "@/components/ui";
import { VoiceButton, type VoiceReply } from "@/components/voice-button";
import { byCode, LANGUAGES, SAMPLE_OPENERS } from "@/lib/languages";
import { errorText, get, post } from "@/lib/api";
import { useLoad } from "@/lib/hooks";

interface Industry { key: string; name: string; status: string }

export default function DemoPage() {
  return (
    <Suspense>
      <Demo />
    </Suspense>
  );
}

function Demo() {
  const params = useSearchParams();
  const industries = useLoad(() => get<Industry[]>("/industries"));
  const [form, setForm] = useState({ business_name: "", website: "", industry: params.get("industry") ?? "roofing" });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [session, setSession] = useState<{ cid: string; vt: string; name: string; importFailed: boolean } | null>(null);
  const [lines, setLines] = useState<ChatLine[]>([]);
  const [startLang, setStartLang] = useState("");
  const [lang, setLang] = useState("en");
  const [reply, setReply] = useState<{ id: number; text: string; language: string } | null>(null);
  const [voiceStatus, setVoiceStatus] = useState<string | null>(null);

  const showReplies = (messages: { content: string }[], language: string) => {
    setLang(language);
    setLines((l) => [...l, ...messages.map((m) => ({ role: "assistant" as const, text: m.content }))]);
    const text = messages.map((m) => m.content).join(" ");
    if (text) setReply({ id: Date.now(), text, language });
  };

  const start = async (e: FormEvent) => {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const d = await post<{ widget_token: string; business_name: string; website_import_failed: boolean }>("/public/demo", {
        business_name: form.business_name, industry: form.industry, website: form.website || null,
      });
      const c = await post<{ conversation_id: string; visitor_token: string; language: string; messages: { content: string }[] }>(
        `/public/widget/${d.widget_token}/conversations`,
        startLang ? { language: startLang } : undefined,
      );
      setSession({ cid: c.conversation_id, vt: c.visitor_token, name: d.business_name, importFailed: d.website_import_failed });
      setLang(c.language);
      setReply(null);
      setLines(c.messages.map((m) => ({ role: "assistant", text: m.content })));
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };

  const send = async (text: string) => {
    if (!session) return;
    setLines((l) => [...l, { role: "customer", text }]);
    try {
      const r = await fetch(`/api/v1/public/conversations/${session.cid}/messages`, {
        method: "POST", headers: { "Content-Type": "application/json", "X-Visitor-Token": session.vt }, body: JSON.stringify({ text }),
      });
      const d = (await r.json()) as { messages?: { content: string }[]; language?: string; error?: { message: string } };
      if (!r.ok) throw new Error(d.error?.message ?? "Message failed");
      showReplies(d.messages ?? [], d.language ?? lang);
    } catch (e) {
      setLines((l) => [...l, { role: "system", text: e instanceof Error ? e.message : "Message failed" }]);
    }
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-14">
      <h1 className="text-5xl font-semibold">Try a live demo</h1>
      <p className="mt-3 max-w-2xl text-lg text-muted">We&apos;ll set up a temporary AI employee for your business. Chat with it the way your customers would. Demos make no real bookings or messages and expire after 24 hours.</p>
      <div className="mt-8 grid gap-8 lg:grid-cols-[360px_1fr]">
        <form onSubmit={start} className="space-y-4 rounded-lg border border-line bg-surface p-5">
          <Input label="Business name" required value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} />
          <Input label="Website (optional)" hint="We read public pages to learn about your business." value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="yourbusiness.com" />
          <Select label="Industry" value={form.industry} onChange={(e) => setForm({ ...form, industry: e.target.value })}>
            {(industries.data ?? []).filter((i) => i.status !== "disabled").map((i) => (
              <option key={i.key} value={i.key}>{i.name}{i.status === "beta" ? " (beta)" : ""}</option>
            ))}
          </Select>
          <Select label="Customer language" hint="The AI also detects the language from what the customer writes or says." value={startLang} onChange={(e) => setStartLang(e.target.value)}>
            <option value="">Detect automatically</option>
            {LANGUAGES.map((l) => <option key={l.code} value={l.code}>{l.native} — {l.name}</option>)}
          </Select>
          {err && <Alert>{err}</Alert>}
          <Button type="submit" loading={busy} className="w-full">{session ? "Start a new demo" : "Create my demo"}</Button>
        </form>
        <div>
          {session ? (
            <>
              {session.importFailed && <div className="mb-3"><Alert tone="wait">We couldn&apos;t read that website, so the demo only knows the basics. A real setup lets you add your own FAQs and services.</Alert></div>}
              <ChatPanel lines={lines} onSend={send} agentName={`Sarah · ${session.name}`}
                header={<>
                  <Badge tone="plain">Speaking: {byCode(lang).native}</Badge>
                  {voiceStatus && <span className="text-[13px] text-muted">{voiceStatus}</span>}
                </>}
                toolbar={<VoiceButton language={lang} stream={{ conversationId: session.cid, visitorToken: session.vt }} replyToSpeak={reply}
                  onBrowserText={(t) => void send(t)} onStatus={setVoiceStatus}
                  onStreamTurn={(t: string, r: VoiceReply) => { setLines((l) => [...l, { role: "customer", text: t }]); showReplies(r.messages, r.language); }} />}
                suggestions={lines.length > 1 ? ["What are your hours?", "Do you service 76201?", "I want to talk to a person"]
                  : ["en", "es", "zh", "vi", "ar", "fr", "tl"].map((c) => SAMPLE_OPENERS[c] ?? "").filter(Boolean)} />
            </>
          ) : (
            <div className="flex h-full min-h-72 items-center justify-center rounded-lg border border-dashed border-line bg-surface p-6 text-center text-muted">
              Fill in your business details to start chatting with your demo AI employee.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
