import type { Metadata } from "next";

import { ButtonLink } from "@/components/ui";

export const metadata: Metadata = { title: "How it works" };

const GROUPS: { title: string; items: [string, string][] }[] = [
  { title: "Talks to customers", items: [
    ["Phone calls", "Answers your business number, discloses that it's an AI assistant, and transfers to your team when needed."],
    ["Text messages", "Replies to texts, handles STOP and HELP automatically, and keeps consent records."],
    ["Website chat", "Paste one line of code into your site. Works on phones."] ] },
  { title: "Does the work", items: [
    ["Qualifies leads", "Asks the questions for your trade — service, property type, ZIP code, urgency — and checks your service area."],
    ["Books appointments", "Offers open times from your calendar and books the one the customer picks. Double-booking is prevented."],
    ["Follows up", "Sends the follow-up and reminder texts you approve, at the times you choose, and stops when the customer books, replies or opts out."] ] },
  { title: "Keeps you in control", items: [
    ["Answers from your information", "Uses your FAQs, services, policies and website — nothing it made up."],
    ["Test before going live", "Chat with your AI employee and see every action it would take before you switch it on."],
    ["Take over anytime", "Jump into any conversation from the inbox. The AI stops until you hand it back."] ] },
  { title: "Shows the results", items: [
    ["Dashboard", "Calls answered, leads captured, appointments booked and hand-offs, today and over time."],
    ["Lead pipeline", "Board and table views, from new lead to won job, with the conversation attached."],
    ["Honest numbers", "Estimated opportunity value is always shown separately from revenue you actually recorded."] ] },
];

export default function Features() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-14">
      <h1 className="text-5xl font-semibold">How your AI employee works</h1>
      <p className="mt-3 max-w-2xl text-lg text-muted">It works like a trained office assistant: it answers, asks the right questions, uses your calendar, and tells your team what happened.</p>
      <div className="mt-10 space-y-10">
        {GROUPS.map((g) => (
          <section key={g.title}>
            <h2 className="text-3xl font-semibold">{g.title}</h2>
            <dl className="mt-4 grid gap-4 sm:grid-cols-3">
              {g.items.map(([t, d]) => (
                <div key={t} className="rounded-lg border border-line bg-surface p-4">
                  <dt className="text-lg font-semibold">{t}</dt>
                  <dd className="mt-1 text-muted">{d}</dd>
                </div>
              ))}
            </dl>
          </section>
        ))}
      </div>
      <div className="mt-12"><ButtonLink href="/signup" size="lg">Build my AI employee</ButtonLink></div>
    </div>
  );
}
