import type { Metadata } from "next";
import { notFound } from "next/navigation";

import { Alert, ButtonLink } from "@/components/ui";
import { INDUSTRY_PAGES, findIndustry } from "@/lib/industries";

export function generateStaticParams() {
  return INDUSTRY_PAGES.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = findIndustry((await params).slug);
  return { title: p ? `AI employee for ${p.name}` : "Industry" };
}

export default async function IndustryPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = findIndustry((await params).slug);
  if (!p) notFound();
  return (
    <div className="mx-auto max-w-4xl px-4 py-14">
      <p className="font-semibold text-ink-2">{p.name}</p>
      <h1 className="mt-1 text-5xl font-semibold">{p.headline}</h1>
      <p className="mt-4 max-w-2xl text-lg text-muted">{p.intro}</p>
      {p.available !== "now" && <div className="mt-6"><Alert tone="wait">{p.name} isn&apos;t available yet. We&apos;re launching with roofing, HVAC, plumbing and remodeling first.</Alert></div>}
      <div className="mt-10 grid gap-6 sm:grid-cols-2">
        <section className="rounded-lg border border-line bg-surface p-5">
          <h2 className="text-2xl font-semibold">What it asks callers</h2>
          <ul className="mt-3 list-disc space-y-1 pl-5">{p.asks.map((a) => <li key={a}>{a}</li>)}</ul>
        </section>
        <section className="rounded-lg border border-line bg-surface p-5">
          <h2 className="text-2xl font-semibold">What it books</h2>
          <p className="mt-3">{p.books}.</p>
          <p className="mt-3 text-muted">It never quotes prices or promises you haven&apos;t approved. Pricing questions go to your team.</p>
        </section>
      </div>
      {p.available === "now" && (
        <div className="mt-10 flex flex-wrap gap-3">
          <ButtonLink href={`/signup?industry=${p.key}`} size="lg">Build my AI employee</ButtonLink>
          <ButtonLink href={`/demo?industry=${p.key}`} variant="secondary" size="lg">Try a live demo</ButtonLink>
        </div>
      )}
    </div>
  );
}
