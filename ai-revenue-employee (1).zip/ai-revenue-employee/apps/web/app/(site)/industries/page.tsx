import type { Metadata } from "next";
import Link from "next/link";

import { Badge } from "@/components/ui";
import { INDUSTRY_PAGES } from "@/lib/industries";

export const metadata: Metadata = { title: "Industries" };

export default function Industries() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-14">
      <h1 className="text-5xl font-semibold">Industries</h1>
      <p className="mt-3 max-w-2xl text-lg text-muted">Each industry comes with the questions, booking type and escalation rules that trade needs. You can adjust them for your business.</p>
      <ul className="mt-8 grid gap-4 sm:grid-cols-2">
        {INDUSTRY_PAGES.map((p) => (
          <li key={p.slug}>
            <Link href={`/industries/${p.slug}`} className="block h-full rounded-lg border border-line bg-surface p-5 hover:border-ink-2">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-2xl font-semibold">{p.name}</h2>
                {p.available === "now" ? <Badge tone="go">Available</Badge> : <Badge>Planned</Badge>}
              </div>
              <p className="mt-2 text-muted">{p.headline}</p>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
