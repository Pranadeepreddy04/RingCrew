import Link from "next/link";

import { ButtonLink } from "@/components/ui";
import { INDUSTRY_PAGES } from "@/lib/industries";

const CALL: { who: "caller" | "ai" | "action"; text: string }[] = [
  { who: "ai", text: "Thanks for calling Mike's Roofing, this is Sarah, an AI assistant. How can I help?" },
  { who: "caller", text: "My roof started leaking after last night's storm." },
  { who: "ai", text: "I'm sorry to hear that. Is this for a home or a commercial property?" },
  { who: "caller", text: "It's our house, ZIP 76201." },
  { who: "action", text: "Checked service area · 76201 is covered" },
  { who: "action", text: "Checked Mike's calendar · 3 openings found" },
  { who: "ai", text: "We have inspection openings Thursday at 10:00 AM and Friday at 2:30 PM. Which works better?" },
  { who: "caller", text: "Thursday." },
  { who: "action", text: "Booked Thursday 10:00 AM · confirmed by calendar" },
  { who: "ai", text: "You're all set, James. Your inspection is booked for Thursday at 10:00 AM." },
];

export default function Home() {
  return (
    <>
      <section className="bg-ink text-white">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 lg:grid-cols-[1.05fr_1fr] lg:py-20">
          <div>
            <h1 className="text-5xl font-bold text-white sm:text-6xl">Never lose a customer because you missed their call</h1>
            <p className="mt-5 max-w-xl text-lg text-white/80">
              Your AI employee answers calls and messages, captures leads, books appointments and follows up 24/7.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <ButtonLink href="/signup" variant="hivis" size="lg">Build my AI employee</ButtonLink>
              <Link href="/demo" className="inline-flex h-12 items-center rounded-md border border-white/30 px-6 font-semibold text-white hover:bg-white/10">
                Try live demo
              </Link>
            </div>
            <p className="mt-4 text-sm text-white/60">14-day trial. You approve everything it says before it goes live.</p>
          </div>
          <CallCard />
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-4xl font-semibold">What happens on every call</h2>
        <p className="mt-2 max-w-2xl text-muted">A chatbot answers with text. Your AI employee does the work, in your real systems, and only tells the customer what actually happened.</p>
        <ol className="mt-8 grid gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Understands the request", "Repair or replacement, home or business, how urgent — the questions your office manager would ask."],
            ["Checks your rules", "Service area, business hours and the answers you approved. If it doesn't know, it says so."],
            ["Books real time", "Offers only open slots on your calendar and confirms after the booking is saved."],
            ["Hands you the lead", "Customer, notes and appointment land in your dashboard, with follow-up handled by the rules you set."],
          ].map(([t, d], i) => (
            <li key={t} className="bg-surface p-5">
              <span className="font-display text-3xl font-bold text-ink-2 tabular">{i + 1}</span>
              <h3 className="mt-2 text-xl font-semibold">{t}</h3>
              <p className="mt-1 text-[15px] text-muted">{d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-y border-line bg-surface">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 lg:grid-cols-2">
          <div>
            <h2 className="text-4xl font-semibold">It knows when to stop</h2>
            <p className="mt-3 max-w-lg text-muted">
              Customers asking for a person, complaints, emergencies and anything it can&apos;t answer go to your team — with the conversation, the reason and the details already written up.
            </p>
          </div>
          <ul className="grid gap-3 text-[15px]">
            {[
              "Never invents prices, discounts, warranties or availability",
              "Never says an appointment is booked unless your calendar confirmed it",
              "Stops texting anyone who replies STOP",
              "Goes quiet the moment your staff takes over a conversation",
              "Keeps each business's customers and data completely separate",
            ].map((x) => (
              <li key={x} className="flex gap-3 rounded-md border border-line p-3">
                <svg aria-hidden="true" viewBox="0 0 20 20" className="mt-0.5 size-5 shrink-0 text-go"><path d="M4 10.5l4 4 8-9" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" /></svg>
                {x}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-4xl font-semibold">Built for service businesses</h2>
        <div className="mt-6 flex flex-wrap gap-2">
          {INDUSTRY_PAGES.map((p) => (
            <Link key={p.slug} href={`/industries/${p.slug}`} className="rounded-full border border-line bg-surface px-4 py-2 font-medium hover:border-ink-2">
              {p.name}
              {p.available !== "now" && <span className="ml-2 text-[13px] text-muted">coming later</span>}
            </Link>
          ))}
        </div>
        <div className="mt-12 flex flex-wrap items-center justify-between gap-4 rounded-lg bg-hivis px-6 py-6">
          <p className="font-display text-2xl font-semibold">Answer every lead. Book more jobs. Follow up automatically.</p>
          <ButtonLink href="/signup" size="lg">Build my AI employee</ButtonLink>
        </div>
      </section>
    </>
  );
}

function CallCard() {
  return (
    <figure aria-label="Example phone call handled by an AI employee" className="rounded-xl bg-white p-4 text-ink shadow-2xl sm:p-5">
      <div className="mb-3 flex items-center justify-between border-b border-line pb-3">
        <div className="flex items-center gap-2">
          <span className="relative flex size-2.5"><span className="absolute inline-flex size-full animate-ping rounded-full bg-go opacity-60" /><span className="relative inline-flex size-2.5 rounded-full bg-go" /></span>
          <span className="font-semibold">Incoming call · (940) 555-0123</span>
        </div>
        <span className="text-sm text-muted tabular">02:41</span>
      </div>
      <ol className="space-y-2 text-[14px]">
        {CALL.map((l, i) => (
          <li key={i} className="call-line" style={{ animationDelay: `${0.25 + i * 0.45}s` }}>
            {l.who === "action" ? (
              <span className="inline-flex items-center gap-1.5 rounded bg-hivis-soft px-2 py-1 text-[13px] font-semibold">
                <svg aria-hidden="true" viewBox="0 0 20 20" className="size-3.5"><path d="M4 10.5l4 4 8-9" fill="none" stroke="currentColor" strokeWidth="2.6" /></svg>
                {l.text}
              </span>
            ) : (
              <p className={l.who === "ai" ? "text-ink" : "text-ink-2"}>
                <span className="font-semibold">{l.who === "ai" ? "Sarah (AI): " : "Caller: "}</span>
                {l.text}
              </p>
            )}
          </li>
        ))}
      </ol>
      <figcaption className="call-line mt-4 rounded-md border-l-4 border-hivis bg-canvas p-3 text-[14px]" style={{ animationDelay: `${0.25 + CALL.length * 0.45}s` }}>
        <span className="block font-semibold">New qualified lead — James Carter</span>
        Roof leak / storm damage · Inspection Thursday 10:00 AM · Source: AI phone employee
      </figcaption>
    </figure>
  );
}
