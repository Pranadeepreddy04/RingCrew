"use client";

import { Alert, ButtonLink, Loading } from "@/components/ui";
import { get, money } from "@/lib/api";
import { useLoad } from "@/lib/hooks";

interface PlanOut { key: string; name: string; price_cents: number; features: string[]; limits: Record<string, number> }

const FEATURE_NAMES: Record<string, string> = {
  web_chat: "Website chat", lead_capture: "Lead capture", basic_scheduling: "Appointment booking", knowledge_base: "Answers from your business info",
  voice: "Phone calls", sms: "Text messages", followups: "Automatic follow-ups", calendar_sync: "Google Calendar sync", advanced_qualification: "Custom qualification questions",
  crm: "Built-in CRM", multiple_agents: "Multiple AI employees", advanced_workflows: "Advanced follow-up workflows", integrations: "CRM integrations",
  webhooks: "Webhooks", advanced_analytics: "Advanced analytics", team_access: "Larger teams",
};

export default function Pricing() {
  const { data, error, loading } = useLoad(() => get<PlanOut[]>("/plans"));
  return (
    <div className="mx-auto max-w-6xl px-4 py-14">
      <h1 className="text-5xl font-semibold">Pricing</h1>
      <p className="mt-3 max-w-2xl text-lg text-muted">Every plan starts with a 14-day trial. Phone minutes and texts beyond your plan&apos;s allowance are billed separately.</p>
      {loading && <Loading />}
      {error && <Alert>{error}</Alert>}
      <div className="mt-8 grid gap-4 lg:grid-cols-3">
        {data?.map((p) => (
          <section key={p.key} className={`flex flex-col rounded-lg border bg-surface p-6 ${p.key === "growth" ? "border-ink ring-2 ring-ink" : "border-line"}`}>
            <h2 className="text-3xl font-semibold">{p.name}</h2>
            <p className="mt-2"><span className="font-display text-4xl font-bold tabular">{money(p.price_cents)}</span><span className="text-muted">/month</span></p>
            <ul className="mt-4 flex-1 space-y-1.5 text-[15px]">
              <li>{p.limits.agents === 1 ? "1 AI employee" : `Up to ${p.limits.agents} AI employees`}</li>
              <li>{p.limits.conversations_per_month?.toLocaleString()} conversations / month</li>
              {!!p.limits.voice_minutes_per_month && <li>{p.limits.voice_minutes_per_month.toLocaleString()} voice minutes / month</li>}
              {!!p.limits.sms_per_month && <li>{p.limits.sms_per_month.toLocaleString()} texts / month</li>}
              <li>{p.limits.team_members} team members</li>
              {p.features.map((f) => <li key={f} className="text-ink-2">{FEATURE_NAMES[f] ?? f}</li>)}
            </ul>
            <ButtonLink href="/signup" className="mt-6" variant={p.key === "growth" ? "primary" : "secondary"}>Start free trial</ButtonLink>
          </section>
        ))}
      </div>
    </div>
  );
}
