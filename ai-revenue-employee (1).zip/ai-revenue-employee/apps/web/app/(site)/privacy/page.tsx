import type { Metadata } from "next";

export const metadata: Metadata = { title: "Privacy" };

export default function Privacy() {
  return (
    <article className="mx-auto max-w-3xl space-y-4 px-4 py-14 leading-relaxed">
      <h1 className="text-5xl font-semibold">Privacy policy</h1>
      <p className="rounded-md bg-wait-soft p-3 text-wait">Draft structure for your legal team. This page must be reviewed and completed by counsel before launch.</p>
      <h2 className="text-2xl font-semibold">What we collect</h2>
      <p>Account details for business users; and, on behalf of each business, the messages, call transcripts, contact details and appointment information their customers provide.</p>
      <h2 className="text-2xl font-semibold">How it is used</h2>
      <p>To operate each business&apos;s AI employee, show results in their dashboard, and send messages the business has configured. Each business&apos;s data is kept separate from every other business.</p>
      <h2 className="text-2xl font-semibold">Text messages and calls</h2>
      <p>Customers can reply STOP to stop texts at any time. Call recording is off unless a business enables it and configures the required disclosures.</p>
      <h2 className="text-2xl font-semibold">Retention, export and deletion</h2>
      <p>Businesses can export their data, delete individual customer records, and delete their account. Retention periods are configurable per business.</p>
      <h2 className="text-2xl font-semibold">Service providers</h2>
      <p>We use providers for hosting, AI language processing, telephony, email and payments. [List providers and data-processing terms here.]</p>
      <h2 className="text-2xl font-semibold">Contact</h2>
      <p>[Company legal name, address and privacy contact.]</p>
    </article>
  );
}
