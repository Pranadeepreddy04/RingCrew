import type { Metadata } from "next";

export const metadata: Metadata = { title: "Terms" };

export default function Terms() {
  return (
    <article className="mx-auto max-w-3xl space-y-4 px-4 py-14 leading-relaxed">
      <h1 className="text-5xl font-semibold">Terms of service</h1>
      <p className="rounded-md bg-wait-soft p-3 text-wait">Draft structure for your legal team. This page must be reviewed and completed by counsel before launch.</p>
      <h2 className="text-2xl font-semibold">The service</h2>
      <p>AI Revenue Employee provides software that answers customer communications and performs actions a business configures.</p>
      <h2 className="text-2xl font-semibold">Business responsibilities</h2>
      <p>Businesses are responsible for the accuracy of the information they provide, for obtaining consent required to contact their customers, for call-recording disclosures in their jurisdictions, and for reviewing their AI employee before activating it.</p>
      <h2 className="text-2xl font-semibold">Acceptable use</h2>
      <p>No unsolicited marketing, no use for regulated professional advice, and no use in industries marked unavailable.</p>
      <h2 className="text-2xl font-semibold">Billing</h2>
      <p>Subscriptions renew monthly until cancelled. Usage beyond plan allowances is billed as described on the pricing page.</p>
      <h2 className="text-2xl font-semibold">Liability</h2>
      <p>[Limitation of liability, warranties, governing law — to be completed by counsel.]</p>
    </article>
  );
}
