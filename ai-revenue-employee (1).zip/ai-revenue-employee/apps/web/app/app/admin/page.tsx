"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

import { Alert, Badge, Button, Input, Loading, PageHeader, Panel, Select, cx, statusTone } from "@/components/ui";
import { ago, get, label, money, post, put, when } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";

const TABS = ["Overview", "Businesses", "Users", "Plans", "Industry templates", "Feature flags", "Jobs", "Integrations", "Audit log", "Investigate"] as const;

export default function AdminPage() {
  const { me } = useAuth();
  const [tab, setTab] = useState<(typeof TABS)[number]>("Overview");
  if (!me?.user.is_superadmin) return <Alert>Platform administrators only.</Alert>;
  return (
    <>
      <PageHeader title="Platform admin" description="Every change and impersonation here is recorded in the audit log." />
      <div role="tablist" aria-label="Admin sections" className="mb-4 flex flex-wrap gap-1">
        {TABS.map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={cx("rounded-md px-3 py-1.5 text-sm font-medium", tab === t ? "bg-ink text-white" : "bg-surface")}>{t}</button>)}
      </div>
      {tab === "Overview" && <Overview />}
      {tab === "Businesses" && <Orgs />}
      {tab === "Users" && <Users />}
      {tab === "Plans" && <Plans />}
      {tab === "Industry templates" && <Templates />}
      {tab === "Feature flags" && <Flags />}
      {tab === "Jobs" && <Jobs />}
      {tab === "Integrations" && <IntegrationHealth />}
      {tab === "Audit log" && <Audit />}
      {tab === "Investigate" && <Investigate />}
    </>
  );
}

function Overview() {
  const d = useLoad(() => get<Record<string, unknown>>("/admin/overview"), []);
  if (!d.data) return d.loading ? <Loading /> : <Alert>{d.error}</Alert>;
  const o = d.data as { organizations: number; demo_organizations: number; users: number; mrr_cents: number; subscriptions: Record<string, number>; failed_jobs: number; queued_jobs: number;
    failed_webhooks: number; failed_workflow_runs: number; integration_errors: number; ai_errors_24h: number; leads_30d: number; usage_30d: Record<string, { quantity: number; estimated_cost_usd: number }> };
  const tiles: [string, string | number][] = [["Businesses", o.organizations], ["Demo sandboxes", o.demo_organizations], ["Users", o.users], ["MRR", money(o.mrr_cents)], ["Leads (30d)", o.leads_30d],
    ["Failed jobs", o.failed_jobs], ["Queued jobs", o.queued_jobs], ["Failed webhooks", o.failed_webhooks], ["Failed follow-ups", o.failed_workflow_runs], ["Integration errors", o.integration_errors], ["AI errors (24h)", o.ai_errors_24h]];
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-4 lg:grid-cols-6">
        {tiles.map(([k, v]) => <div key={k} className="bg-surface p-4"><p className="font-display text-3xl font-bold tabular">{v}</p><p className="text-[13px] text-muted">{k}</p></div>)}
      </div>
      <Panel title="Subscriptions">{Object.entries(o.subscriptions).map(([s, n]) => <Badge key={s} tone={statusTone(s)}>{n} {label(s)}</Badge>)}</Panel>
      <Panel title="Usage, last 30 days">{Object.entries(o.usage_30d).map(([k, u]) => <p key={k}>{label(k)}: {u.quantity.toLocaleString()} (est. ${u.estimated_cost_usd})</p>)}</Panel>
    </div>
  );
}

function Orgs() {
  const [q, setQ] = useState("");
  const list = useLoad(() => get<{ id: string; name: string; industry: string; status: string; is_demo: boolean; deleted: boolean; plan: string | null; subscription_status: string | null; created_at: string }[]>(`/admin/organizations${q ? `?q=${encodeURIComponent(q)}` : ""}`), [q]);
  const { run } = useAction();
  const setStatus = async (id: string, status: string) => {
    const reason = window.prompt(`Reason for ${status === "suspended" ? "suspending" : "reactivating"}:`);
    if (!reason) return;
    await run("s", () => post(`/admin/organizations/${id}/status`, { status, reason }), "Updated");
    void list.reload();
  };
  return (
    <Panel padded={false}>
      <div className="p-3"><Input label="Search" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      <table className="w-full text-left text-[14px]"><thead className="text-[13px] text-muted"><tr><th className="px-3">Business</th><th>Industry</th><th>Plan</th><th>Status</th><th /></tr></thead>
        <tbody className="divide-y divide-line">{list.data?.map((o) => (
          <tr key={o.id}><td className="px-3 py-2">{o.name}{o.is_demo && " (demo)"}<span className="block text-[12px] text-muted">{o.id} · {ago(o.created_at)}</span></td><td>{label(o.industry)}</td>
            <td>{o.plan ?? "—"} {o.subscription_status && <Badge tone={statusTone(o.subscription_status)}>{label(o.subscription_status)}</Badge>}</td>
            <td><Badge tone={statusTone(o.deleted ? "cancelled" : o.status)}>{o.deleted ? "Deleted" : label(o.status)}</Badge></td>
            <td>{!o.deleted && (o.status === "active" ? <Button size="sm" variant="ghost" onClick={() => void setStatus(o.id, "suspended")}>Suspend</Button> : <Button size="sm" variant="secondary" onClick={() => void setStatus(o.id, "active")}>Reactivate</Button>)}</td></tr>
        ))}</tbody></table>
    </Panel>
  );
}

function Users() {
  const { refresh } = useAuth();
  const router = useRouter();
  const [q, setQ] = useState("");
  const list = useLoad(() => get<{ id: string; email: string; name: string; is_active: boolean; is_superadmin: boolean; last_login_at: string | null }[]>(`/admin/users${q ? `?q=${encodeURIComponent(q)}` : ""}`), [q]);
  const { run } = useAction();
  const impersonate = async (id: string) => {
    const reason = window.prompt("Why do you need to sign in as this user? (recorded in the audit log)");
    if (!reason || reason.length < 10) return;
    const r = await run("i", () => post("/admin/impersonate", { user_id: id, reason }));
    if (r) { await refresh(); router.push("/app/dashboard"); }
  };
  return (
    <Panel padded={false}>
      <div className="p-3"><Input label="Search email" value={q} onChange={(e) => setQ(e.target.value)} /></div>
      <ul className="divide-y divide-line">{list.data?.map((u) => (
        <li key={u.id} className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 text-[14px]">
          <span>{u.name} · {u.email} {u.is_superadmin && <Badge tone="live">Admin</Badge>} {!u.is_active && <Badge tone="stop">Disabled</Badge>}<span className="block text-[12px] text-muted">Last sign-in {u.last_login_at ? ago(u.last_login_at) : "never"}</span></span>
          {!u.is_superadmin && <span className="flex gap-2">
            <Button size="sm" variant="secondary" onClick={() => void run("a", () => post(`/admin/users/${u.id}/status`, { is_active: !u.is_active }), "Updated").then(() => list.reload())}>{u.is_active ? "Disable" : "Enable"}</Button>
            {u.is_active && <Button size="sm" variant="ghost" onClick={() => void impersonate(u.id)}>Sign in as</Button>}
          </span>}
        </li>
      ))}</ul>
    </Panel>
  );
}

interface PlanRow { key: string; name: string; price_cents: number; features: string[]; limits: Record<string, number>; provider_price_id: string | null; active: boolean }

function Plans() {
  const list = useLoad(() => get<PlanRow[]>("/admin/plans"), []);
  return <div className="grid gap-4 lg:grid-cols-3">{list.data?.map((p) => <PlanEditor key={p.key} plan={p} onSaved={() => void list.reload()} />)}</div>;
}

function PlanEditor({ plan, onSaved }: { plan: PlanRow; onSaved: () => void }) {
  const [f, setF] = useState({ name: plan.name, price: String(plan.price_cents / 100), price_id: plan.provider_price_id ?? "", limits: JSON.stringify(plan.limits, null, 1), active: plan.active });
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    let limits: Record<string, number>;
    try { limits = JSON.parse(f.limits); } catch { window.alert("Limits must be valid JSON"); return; }
    await run("p", () => put(`/admin/plans/${plan.key}`, { name: f.name, price_cents: Math.round(parseFloat(f.price) * 100), features: plan.features, limits, provider_price_id: f.price_id || null, active: f.active }), "Plan saved");
    onSaved();
  };
  return (
    <Panel title={plan.key}>
      <form onSubmit={submit} className="space-y-2">
        <Input label="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Input label="Monthly price ($)" inputMode="decimal" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} />
        <Input label="Stripe price ID" value={f.price_id} onChange={(e) => setF({ ...f, price_id: e.target.value })} />
        <label className="block text-[13px] font-semibold text-ink-2" htmlFor={`lim-${plan.key}`}>Limits (JSON)</label>
        <textarea id={`lim-${plan.key}`} className="h-36 w-full rounded-md border border-line p-2 font-mono text-[12px]" value={f.limits} onChange={(e) => setF({ ...f, limits: e.target.value })} />
        <Button type="submit" size="sm" loading={pending === "p"}>Save plan</Button>
      </form>
    </Panel>
  );
}

function Templates() {
  const list = useLoad(() => get<{ key: string; name: string; category: string; status: string; version: number | null }[]>("/admin/industry-templates"), []);
  const { run } = useAction();
  return (
    <Panel padded={false}>
      <ul className="divide-y divide-line">{list.data?.map((t) => (
        <li key={t.key} className="flex items-center justify-between gap-3 px-3 py-2">
          <span>{t.name} <span className="text-[12px] text-muted">{t.key} · v{t.version} · {label(t.category)}</span></span>
          <Select label="Status" value={t.status} onChange={(e) => void run("t", () => put(`/admin/industry-templates/${t.key}`, { status: e.target.value }), "Template updated").then(() => list.reload())}>
            <option value="active">Active</option><option value="beta">Beta</option><option value="disabled">Disabled</option>
          </Select>
        </li>
      ))}</ul>
    </Panel>
  );
}

function Flags() {
  const list = useLoad(() => get<{ id: string; key: string; enabled: boolean; organization_id: string | null; description: string | null }[]>("/admin/feature-flags"), []);
  const [f, setF] = useState({ key: "", organization_id: "", description: "" });
  const { run } = useAction();
  const save = (key: string, enabled: boolean, organization_id: string | null, description?: string | null) =>
    void run("f", () => put("/admin/feature-flags", { key, enabled, organization_id: organization_id || null, description: description || null }), "Flag saved").then(() => list.reload());
  return (
    <Panel>
      <ul className="mb-4 divide-y divide-line">{list.data?.map((fl) => (
        <li key={fl.id} className="flex items-center justify-between py-2 text-[14px]"><span><code>{fl.key}</code> {fl.organization_id ? `(org ${fl.organization_id.slice(0, 8)})` : "(global)"} <span className="text-muted">{fl.description}</span></span>
          <Button size="sm" variant={fl.enabled ? "primary" : "secondary"} onClick={() => save(fl.key, !fl.enabled, fl.organization_id, fl.description)}>{fl.enabled ? "On" : "Off"}</Button></li>
      ))}</ul>
      <form onSubmit={(e) => { e.preventDefault(); save(f.key, false, f.organization_id, f.description); }} className="grid gap-2 sm:grid-cols-4 sm:items-end">
        <Input label="Key" required pattern="[a-z0-9_.-]+" value={f.key} onChange={(e) => setF({ ...f, key: e.target.value })} />
        <Input label="Organization ID (optional)" value={f.organization_id} onChange={(e) => setF({ ...f, organization_id: e.target.value })} />
        <Input label="Description" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        <Button type="submit">Add flag</Button>
      </form>
    </Panel>
  );
}

function Jobs() {
  const [status, setStatus] = useState("failed");
  const list = useLoad(() => get<{ id: string; kind: string; status: string; attempts: number; last_error: string | null; created_at: string }[]>(`/admin/jobs?status=${status}`), [status]);
  const { run } = useAction();
  return (
    <Panel>
      <Select label="Status" value={status} onChange={(e) => setStatus(e.target.value)}><option value="failed">Failed</option><option value="queued">Queued</option><option value="running">Running</option><option value="done">Done</option></Select>
      <ul className="mt-3 divide-y divide-line text-[14px]">{list.data?.length === 0 && <li className="py-2 text-muted">None.</li>}{list.data?.map((j) => (
        <li key={j.id} className="flex items-center justify-between gap-2 py-2"><span><code>{j.kind}</code> · {j.attempts} attempts · {ago(j.created_at)}{j.last_error && <span className="block text-[12px] text-stop">{j.last_error}</span>}</span>
          {j.status === "failed" && <Button size="sm" variant="secondary" onClick={() => void run("r", () => post(`/admin/jobs/${j.id}/retry`), "Queued for retry").then(() => list.reload())}>Retry</Button>}</li>
      ))}</ul>
    </Panel>
  );
}

function IntegrationHealth() {
  const list = useLoad(() => get<{ organization: string; kind: string; provider: string; status: string; last_error: string | null; last_sync_at: string | null }[]>("/admin/integrations/health"), []);
  return <Panel padded={false}><ul className="divide-y divide-line text-[14px]">{list.data?.map((i, n) => <li key={n} className="px-3 py-2">{i.organization} · {i.kind}/{i.provider} <Badge tone={statusTone(i.status)}>{label(i.status)}</Badge> {i.last_error && <span className="text-stop">{i.last_error}</span>}</li>)}</ul></Panel>;
}

function Audit() {
  const list = useLoad(() => get<{ id: string; action: string; actor_type: string; organization_id: string | null; target: string | null; ip: string | null; created_at: string; data: unknown }[]>("/admin/audit-logs"), []);
  return <Panel padded={false}><ul className="divide-y divide-line text-[13px]">{list.data?.map((a) => <li key={a.id} className="px-3 py-1.5"><span className="text-muted tabular">{when(a.created_at)}</span> <code>{a.action}</code> by {a.actor_type} {a.target && `→ ${a.target}`} {a.ip && `from ${a.ip}`}</li>)}</ul></Panel>;
}

function Investigate() {
  const [id, setId] = useState("");
  const [res, setRes] = useState<{ outcome: string; stage: string; handoff_reason: string | null; collected_fields: string[]; timeline: Record<string, unknown>[] } | null>(null);
  const { run, pending } = useAction();
  return (
    <Panel title="Why didn't this customer get an appointment?">
      <form onSubmit={(e) => { e.preventDefault(); void run("i", () => get<typeof res>(`/admin/conversations/${id.trim()}/investigate`)).then((r) => r && setRes(r)); }} className="flex gap-2">
        <label htmlFor="cid" className="sr-only">Conversation ID</label>
        <input id="cid" value={id} onChange={(e) => setId(e.target.value)} placeholder="Conversation ID" className="h-10 flex-1 rounded-md border border-line px-3" />
        <Button type="submit" loading={pending === "i"}>Investigate</Button>
      </form>
      {res && (
        <div className="mt-4 space-y-2">
          <p>Outcome: <strong>{label(res.outcome)}</strong> · stage {label(res.stage)} {res.handoff_reason && `· handed off (${label(res.handoff_reason)})`} · collected: {res.collected_fields.join(", ") || "nothing"}</p>
          <ol className="space-y-1 text-[13px]">{res.timeline.map((t, i) => <li key={i} className="rounded bg-canvas px-2 py-1"><span className="text-muted tabular">{when(String(t.at))}</span> <strong>{String(t.kind)}</strong> {String(t.role ?? t.type ?? t.operation ?? "")} {t.content ? `— ${String(t.content)}` : ""} {t.status ? `[${String(t.status)}]` : ""} {t.error ? <span className="text-stop">{String(t.error)}</span> : null}</li>)}</ol>
        </div>
      )}
    </Panel>
  );
}
