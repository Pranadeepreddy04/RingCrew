"use client";

import { useState, type FormEvent } from "react";

import { CAPABILITY_LABELS } from "@/components/business-forms";
import { TestConsole } from "@/components/test-console";
import { byCode, LANGUAGES } from "@/lib/languages";
import { Alert, Badge, Button, Checkbox, Empty, Input, Loading, Modal, PageHeader, Select, Textarea, cx, statusTone } from "@/components/ui";
import { ApiError, del, errorText, get, label, patch, post, put } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";
import type { Agent } from "@/lib/types";

const ROLES = ["receptionist", "lead_qualifier", "appointment_setter", "follow_up", "sales_assistant", "customer_service"];

export default function AgentsPage() {
  const { can } = useAuth();
  const list = useLoad(() => get<Agent[]>("/agents"), []);
  const [sel, setSel] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const agent = list.data?.find((a) => a.id === (sel ?? list.data?.[0]?.id));
  return (
    <>
      <PageHeader title="AI employees" description="Each AI employee shares your business knowledge, customers and calendar." action={can("configure") && <Button onClick={() => setCreating(true)}>Add AI employee</Button>} />
      {list.loading && !list.data ? <Loading /> : list.error ? <Alert>{list.error}</Alert> : !agent ? <Empty title="No AI employees yet" action={<Button onClick={() => setCreating(true)}>Create one</Button>} /> : (
        <>
          <div role="tablist" aria-label="AI employees" className="mb-4 flex flex-wrap gap-2">
            {list.data?.map((a) => (
              <button key={a.id} role="tab" aria-selected={a.id === agent.id} onClick={() => setSel(a.id)}
                className={cx("flex items-center gap-2 rounded-md border px-3 py-2 text-left", a.id === agent.id ? "border-ink bg-surface" : "border-line bg-surface/60")}>
                <span className={cx("size-2 rounded-full", a.status === "active" ? "bg-go" : "bg-muted")} aria-hidden="true" />
                <span className="font-semibold">{a.name}</span><span className="text-sm text-muted">{label(a.role)}</span>
              </button>
            ))}
          </div>
          <AgentDetail key={agent.id} agent={agent} editable={can("configure")} onChanged={() => void list.reload()} />
        </>
      )}
      <Modal open={creating} onClose={() => setCreating(false)} title="Add an AI employee">
        <CreateAgent onDone={(id) => { setCreating(false); setSel(id); void list.reload(); }} />
      </Modal>
    </>
  );
}

function CreateAgent({ onDone }: { onDone: (id: string) => void }) {
  const [f, setF] = useState({ name: "", role: "receptionist" });
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const a = await run("c", () => post<Agent>("/agents", f), "AI employee created");
    if (a) onDone(a.id);
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Input label="Name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <Select label="Role" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>{ROLES.map((r) => <option key={r} value={r}>{label(r)}</option>)}</Select>
      <Button type="submit" loading={pending === "c"}>Create</Button>
    </form>
  );
}

const TABS = ["Settings", "Questions", "Website chat", "Test"] as const;

function AgentDetail({ agent, editable, onChanged }: { agent: Agent; editable: boolean; onChanged: () => void }) {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Settings");
  const { run, pending } = useAction();
  const [blocked, setBlocked] = useState<{ label: string }[] | null>(null);
  const activate = async () => {
    setBlocked(null);
    try {
      await post(`/agents/${agent.id}/activate`);
      onChanged();
    } catch (e) {
      if (e instanceof ApiError && Array.isArray(e.details)) setBlocked(e.details as { label: string }[]);
      else setBlocked([{ label: errorText(e) }]);
    }
  };
  return (
    <section className="rounded-lg border border-line bg-surface">
      <header className="flex flex-wrap items-center justify-between gap-3 border-b border-line p-4">
        <div className="flex items-center gap-3">
          <h2 className="text-2xl font-semibold">{agent.name}</h2>
          <Badge tone={statusTone(agent.status)}>{agent.status === "active" ? "Online" : label(agent.status)}</Badge>
        </div>
        {editable && (
          <div className="flex flex-wrap gap-2">
            {agent.status === "active" ? <Button variant="secondary" loading={pending === "pause"} onClick={() => void run("pause", () => post(`/agents/${agent.id}/pause`), "Paused").then(onChanged)}>Pause</Button>
              : <Button variant="hivis" onClick={() => void activate()}>Activate</Button>}
            <Button variant="ghost" loading={pending === "del"} onClick={() => { if (window.confirm(`Remove ${agent.name}? Its widget stops working immediately.`)) void run("del", () => del(`/agents/${agent.id}`), "Removed").then(onChanged); }}>Remove</Button>
          </div>
        )}
      </header>
      {blocked && <div className="p-4 pb-0"><Alert>Finish these first: {blocked.map((b) => b.label).join("; ")}</Alert></div>}
      <div role="tablist" aria-label="Sections" className="flex gap-1 border-b border-line px-4 pt-3">
        {TABS.map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={cx("-mb-px border-b-2 px-3 py-2 text-sm font-semibold", tab === t ? "border-ink" : "border-transparent text-muted")}>{t}</button>)}
      </div>
      <div className="p-4">
        {tab === "Settings" && <Settings agent={agent} editable={editable} onChanged={onChanged} />}
        {tab === "Questions" && <Questions agent={agent} editable={editable} />}
        {tab === "Website chat" && <Widget agent={agent} editable={editable} onChanged={onChanged} />}
        {tab === "Test" && (editable ? <TestConsole agentId={agent.id} agentName={agent.name} languages={agent.languages} /> : <p className="text-muted">Only owners and managers can use the test environment.</p>)}
      </div>
    </section>
  );
}

function Settings({ agent, editable, onChanged }: { agent: Agent; editable: boolean; onChanged: () => void }) {
  const [f, setF] = useState({ name: agent.name, greeting: agent.greeting, tone: agent.tone, voice: agent.voice ?? "", language: agent.language });
  const [caps, setCaps] = useState(agent.capabilities);
  const [langs, setLangs] = useState<string[]>(agent.languages?.length ? agent.languages : [agent.language]);
  const [greetings, setGreetings] = useState<Record<string, string>>(agent.greetings ?? {});
  const { run, pending } = useAction();
  const save = async (e: FormEvent) => {
    e.preventDefault();
    const { language: _primary, ...rest } = f;
    void _primary;
    await run("s", () => patch(`/agents/${agent.id}`, {
      ...rest, voice: rest.voice || null, capabilities: caps, languages: langs,
      greetings: Object.fromEntries(Object.entries(greetings).filter(([k, v]) => langs.includes(k) && k !== langs[0] && v.trim())),
    }), "Saved");
    onChanged();
  };
  const toggleLang = (code: string, on: boolean) => {
    if (on) setLangs((l) => (l.includes(code) ? l : [...l, code]));
    else setLangs((l) => (l.length > 1 ? l.filter((c) => c !== code) : l));
  };
  return (
    <form onSubmit={save} className="grid gap-4 lg:grid-cols-2">
      <fieldset disabled={!editable} className="space-y-3">
        <Input label="Name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Textarea label="Greeting" value={f.greeting} onChange={(e) => setF({ ...f, greeting: e.target.value })} />
        <Select label="Tone" value={f.tone} onChange={(e) => setF({ ...f, tone: e.target.value })}>{["friendly", "professional", "warm", "concise"].map((t) => <option key={t} value={t}>{label(t)}</option>)}</Select>
        <Select label="Phone voice" value={f.voice} onChange={(e) => setF({ ...f, voice: e.target.value })}>
          <option value="">Default (Joanna)</option><option value="Polly.Matthew">Matthew</option><option value="Polly.Salli">Salli</option><option value="Polly.Joey">Joey</option>
        </Select>
        <p className="text-[13px] text-muted">The English voice. Other languages use a matching native voice automatically.</p>
      </fieldset>
      <fieldset disabled={!editable} className="lg:col-span-2">
        <legend className="mb-1 text-[13px] font-semibold text-ink-2">Languages it speaks</legend>
        <p className="mb-2 text-[13px] text-muted">
          The AI answers in the customer&apos;s language when it is enabled here. Callers hear a &ldquo;press 1 for English, 2 for Spanish…&rdquo; menu when more than one is on.
          The first language is the default. Have a native speaker review replies before going live.
        </p>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {LANGUAGES.map((l) => (
            <Checkbox key={l.code} label={`${l.native}${l.native !== l.name ? ` · ${l.name}` : ""}${langs[0] === l.code ? " (default)" : ""}`}
              hint={l.vibevoice ? "Voice: VibeVoice or Twilio speech recognition" : "Voice: Twilio speech recognition"}
              checked={langs.includes(l.code)} disabled={!editable || (langs.length === 1 && langs[0] === l.code)} onChange={(v) => toggleLang(l.code, v)} />
          ))}
        </div>
        {langs.length > 1 && (
          <div className="mt-3 grid gap-3 lg:grid-cols-2">
            <Select label="Default language" value={langs[0]} onChange={(e) => setLangs((l) => [e.target.value, ...l.filter((c) => c !== e.target.value)])}>
              {langs.map((c) => <option key={c} value={c}>{byCode(c).native}</option>)}
            </Select>
            {langs.slice(1).map((c) => (
              <Input key={c} dir="auto" label={`Greeting in ${byCode(c).name} (optional)`} placeholder="Leave empty for the built-in translated greeting"
                value={greetings[c] ?? ""} onChange={(e) => setGreetings({ ...greetings, [c]: e.target.value })} maxLength={500} />
            ))}
          </div>
        )}
      </fieldset>
      <fieldset disabled={!editable}>
        <legend className="mb-2 text-[13px] font-semibold text-ink-2">What it does</legend>
        <div className="space-y-2">{Object.entries(CAPABILITY_LABELS).map(([k, l]) => <Checkbox key={k} label={l} checked={caps.includes(k)} disabled={!editable} onChange={(v) => setCaps(v ? [...caps, k] : caps.filter((c) => c !== k))} />)}</div>
      </fieldset>
      {editable && <Button type="submit" className="w-fit" loading={pending === "s"}>Save changes</Button>}
    </form>
  );
}

interface PackField { key: string; label: string; type: string; required: boolean; enabled: boolean; prompt: string | null; options: string[]; locked: boolean }

function Questions({ agent, editable }: { agent: Agent; editable: boolean }) {
  const pack = useLoad(() => get<{ name: string; appointment_label: string; fields: PackField[] }>(`/agents/${agent.id}/pack`), [agent.id]);
  const [fields, setFields] = useState<Record<string, { enabled: boolean; required: boolean; prompt: string }> | null>(null);
  const { run, pending } = useAction();
  if (pack.loading && !pack.data) return <Loading />;
  if (!pack.data) return <Alert>{pack.error}</Alert>;
  const cur = fields ?? Object.fromEntries(pack.data.fields.map((x) => [x.key, { enabled: x.enabled, required: x.required, prompt: x.prompt ?? "" }]));
  const save = async () => {
    const r = await run("q", () => put(`/agents/${agent.id}/pack`, { fields: cur }), "Questions saved");
    if (r) { setFields(null); void pack.reload(); }
  };
  return (
    <div className="space-y-3">
      <p className="text-muted">Industry template: <strong>{pack.data.name}</strong>. Books a <strong>{pack.data.appointment_label}</strong> once the required questions are answered.</p>
      <ul className="divide-y divide-line rounded-md border border-line">
        {pack.data.fields.map((x) => {
          const v = cur[x.key]!;
          return (
            <li key={x.key} className="grid gap-2 p-3 sm:grid-cols-[180px_1fr]">
              <div>
                <p className="font-semibold">{x.label}</p>
                {x.options.length > 0 && <p className="text-[12px] text-muted">{x.options.map(label).join(", ")}</p>}
                <div className="mt-1 flex gap-3">
                  <Checkbox label="Ask" checked={v.enabled} disabled={!editable || x.locked} onChange={(b) => setFields({ ...cur, [x.key]: { ...v, enabled: b, required: b && v.required } })} />
                  <Checkbox label="Required" checked={v.required} disabled={!editable || x.locked || !v.enabled} onChange={(b) => setFields({ ...cur, [x.key]: { ...v, required: b } })} />
                </div>
              </div>
              <Input label="How it asks" disabled={!editable} value={v.prompt} placeholder="Default wording" onChange={(e) => setFields({ ...cur, [x.key]: { ...v, prompt: e.target.value } })} />
            </li>
          );
        })}
      </ul>
      {editable && <Button loading={pending === "q"} disabled={!fields} onClick={() => void save()}>Save questions</Button>}
    </div>
  );
}

function Widget({ agent, editable, onChanged }: { agent: Agent; editable: boolean; onChanged: () => void }) {
  const ws = agent.widget_settings ?? {};
  const [f, setF] = useState({ title: ws.title ?? "", welcome_message: ws.welcome_message ?? "", primary_color: ws.primary_color ?? "#1f5eff", position: ws.position ?? "bottom-right", logo_url: ws.logo_url ?? "" });
  const { run, pending } = useAction();
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const code = `<script src="${origin}/widget.js" data-token="${agent.widget_token}" async></script>`;
  const save = async (e: FormEvent) => {
    e.preventDefault();
    await run("w", () => patch(`/agents/${agent.id}`, { widget_settings: Object.fromEntries(Object.entries(f).filter(([, v]) => v)) }), "Widget saved");
    onChanged();
  };
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div>
        <h3 className="text-lg font-semibold">Install on your website</h3>
        <p className="text-muted">Paste this just before the closing &lt;/body&gt; tag on every page.</p>
        <pre className="mt-2 overflow-x-auto rounded-md bg-ink p-3 text-[13px] text-white"><code>{code}</code></pre>
        <div className="mt-2 flex gap-2">
          <Button size="sm" variant="secondary" onClick={() => void navigator.clipboard.writeText(code).then(() => undefined)}>Copy code</Button>
          {editable && <Button size="sm" variant="ghost" loading={pending === "rot"} onClick={() => { if (window.confirm("Create a new code? The old code stops working immediately.")) void run("rot", () => post(`/agents/${agent.id}/rotate-widget-token`), "New code created").then(onChanged); }}>Replace code</Button>}
        </div>
        <p className="mt-3 text-[13px] text-muted">The code only lets visitors chat with {agent.name}. It gives no access to your account.</p>
      </div>
      <form onSubmit={save} className="space-y-3">
        <fieldset disabled={!editable} className="space-y-3">
          <Input label="Chat title" placeholder="Chat with us" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <Textarea label="Welcome message" placeholder={agent.greeting} value={f.welcome_message} onChange={(e) => setF({ ...f, welcome_message: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <Input label="Color" type="color" value={f.primary_color} onChange={(e) => setF({ ...f, primary_color: e.target.value })} />
            <Select label="Position" value={f.position} onChange={(e) => setF({ ...f, position: e.target.value })}><option value="bottom-right">Bottom right</option><option value="bottom-left">Bottom left</option></Select>
          </div>
          <Input label="Logo URL (https)" value={f.logo_url} onChange={(e) => setF({ ...f, logo_url: e.target.value })} />
        </fieldset>
        {editable && <Button type="submit" loading={pending === "w"}>Save widget</Button>}
      </form>
    </div>
  );
}
