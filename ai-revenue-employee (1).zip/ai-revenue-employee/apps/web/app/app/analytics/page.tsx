"use client";

import { useState } from "react";

import { BarSeries, Funnel } from "@/components/charts";
import { Alert, Input, Loading, PageHeader, Panel } from "@/components/ui";
import { get, label, money } from "@/lib/api";
import { useLoad } from "@/lib/hooks";

interface A {
  range: { start: string; end: string; timezone: string };
  metrics: Record<string, number | null | string | Record<string, { quantity: number; estimated_cost_usd: number }>>;
  series: { date: string; leads: number; appointments: number; conversations: number; handoffs: number }[];
  funnel: { stage: string; count: number }[];
  by_source: { source: string; leads: number; won: number }[];
  by_channel: { channel: string; conversations: number; handoffs: number }[];
  handoff_reasons: { reason: string; count: number }[];
  after_hours_calls_answered: number;
  after_hours_note: string;
}

const iso = (d: Date) => d.toISOString().slice(0, 10);

export default function AnalyticsPage() {
  const [start, setStart] = useState(() => iso(new Date(Date.now() - 29 * 864e5)));
  const [end, setEnd] = useState(() => iso(new Date()));
  const { data, error, loading } = useLoad(() => get<A>(`/analytics?start=${start}&end=${end}`), [start, end]);
  const m = (data?.metrics ?? {}) as Record<string, number | null>;
  const fmt = (d: string) => new Date(`${d}T12:00:00`).toLocaleDateString("en-US", { month: "short", day: "numeric" });
  const tiles: [string, string][] = data ? [
    ["Conversations", String(m.conversations)], ["Calls answered", `${m.answered_calls} of ${m.calls}`], ["Leads", String(m.leads)], ["Qualified", String(m.qualified_leads)],
    ["Appointments", String(m.appointments)], ["Cancellations", String(m.cancellations)], ["No-shows", String(m.no_shows)], ["Follow-ups sent", String(m.follow_ups)],
    ["Human hand-offs", `${m.human_handoffs}${m.handoff_rate != null ? ` (${Math.round((m.handoff_rate as number) * 100)}%)` : ""}`],
    ["Median first reply", m.median_first_response_ms ? `${((m.median_first_response_ms as number) / 1000).toFixed(1)}s` : "—"],
    ["After-hours calls answered", String(data.after_hours_calls_answered)], ["AI / tool errors", `${m.ai_failures} / ${m.tool_failures}`],
  ] : [];
  return (
    <>
      <PageHeader title="Analytics" description="What your AI employees handled, and what came of it."
        action={<div className="flex gap-2"><Input label="From" type="date" value={start} max={end} onChange={(e) => setStart(e.target.value)} /><Input label="To" type="date" value={end} min={start} onChange={(e) => setEnd(e.target.value)} /></div>} />
      {loading && !data ? <Loading /> : error ? <Alert>{error}</Alert> : data && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-4 xl:grid-cols-6">
            {tiles.map(([k, v]) => <div key={k} className="bg-surface p-4"><p className="font-display text-3xl font-bold tabular">{v}</p><p className="text-[13px] text-muted">{k}</p></div>)}
          </div>
          <Panel title="Opportunity value">
            <div className="grid gap-4 sm:grid-cols-3">
              <div><p className="font-display text-3xl font-bold tabular">{money(m.estimated_opportunity_value_cents)}</p><p className="text-[13px] text-muted">Estimated value of AI-handled leads (not revenue)</p></div>
              <div><p className="font-display text-3xl font-bold tabular">{m.won_ai_leads}</p><p className="text-[13px] text-muted">AI-handled leads marked won</p></div>
              <div><p className="font-display text-3xl font-bold tabular">{money(m.confirmed_revenue_cents)}</p><p className="text-[13px] text-muted">Revenue your team recorded on those leads</p></div>
            </div>
            <p className="mt-3 text-[13px] text-muted">{String(data.metrics.attribution_note)}</p>
          </Panel>
          <div className="grid gap-5 xl:grid-cols-2">
            <BarSeries title="Leads per day" data={data.series.map((d) => ({ label: fmt(d.date), value: d.leads }))} />
            <BarSeries title="Appointments booked per day" data={data.series.map((d) => ({ label: fmt(d.date), value: d.appointments }))} />
            <BarSeries title="Conversations per day" data={data.series.map((d) => ({ label: fmt(d.date), value: d.conversations }))} />
            <Funnel steps={data.funnel} />
          </div>
          <div className="grid gap-5 lg:grid-cols-3">
            <Panel title="Leads by source" padded={false}><SimpleTable head={["Source", "Leads", "Won"]} rows={data.by_source.map((r) => [label(r.source), r.leads, r.won])} /></Panel>
            <Panel title="AI vs human by channel" padded={false}><SimpleTable head={["Channel", "Conversations", "Hand-offs"]} rows={data.by_channel.map((r) => [label(r.channel), r.conversations, r.handoffs])} /></Panel>
            <Panel title="Why conversations were handed off" padded={false}><SimpleTable head={["Reason", "Count"]} rows={data.handoff_reasons.map((r) => [label(r.reason), r.count])} /></Panel>
          </div>
          <Panel title="Usage and estimated cost">
            <SimpleTable head={["Type", "Quantity", "Est. cost"]} rows={Object.entries((data.metrics.usage ?? {}) as Record<string, { quantity: number; estimated_cost_usd: number }>).map(([k, u]) => [label(k), u.quantity.toLocaleString(), `$${u.estimated_cost_usd.toFixed(2)}`])} />
          </Panel>
        </div>
      )}
    </>
  );
}

function SimpleTable({ head, rows }: { head: string[]; rows: (string | number)[][] }) {
  if (!rows.length) return <p className="p-4 text-muted">No data for this period.</p>;
  return (
    <table className="w-full text-left text-[14px]">
      <thead className="border-b border-line text-[13px] text-muted"><tr>{head.map((h, i) => <th key={h} scope="col" className={`px-4 py-2 ${i ? "text-right" : ""}`}>{h}</th>)}</tr></thead>
      <tbody className="divide-y divide-line">{rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j} className={`px-4 py-2 ${j ? "text-right tabular" : ""}`}>{c}</td>)}</tr>)}</tbody>
    </table>
  );
}
