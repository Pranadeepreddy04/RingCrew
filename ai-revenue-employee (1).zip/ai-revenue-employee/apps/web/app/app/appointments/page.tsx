"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";

import { Alert, Badge, Button, Empty, Input, Loading, Modal, PageHeader, Select, Textarea, statusTone } from "@/components/ui";
import { api, get, label, phone, post } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";
import type { Appointment, Paged } from "@/lib/types";

interface Slot { start: string; end: string; label: string }

export default function AppointmentsPage() {
  return <Suspense><Appointments /></Suspense>;
}

function Appointments() {
  const params = useSearchParams();
  const [range, setRange] = useState<"upcoming" | "past">("upcoming");
  const [booking, setBooking] = useState(!!params.get("customer"));
  const [rescheduling, setRescheduling] = useState<Appointment | null>(null);
  const org = useLoad(() => get<{ timezone: string }>("/organizations/current"), []);
  const tz = org.data?.timezone;
  const now = new Date();
  const qs = range === "upcoming" ? `start=${encodeURIComponent(now.toISOString())}` : `start=${encodeURIComponent(new Date(now.getTime() - 90 * 864e5).toISOString())}&end=${encodeURIComponent(now.toISOString())}`;
  const list = useLoad(() => get<Appointment[]>(`/appointments?${qs}`), [range]);
  const { run, pending } = useAction();
  const { can } = useAuth();

  const setStatus = async (a: Appointment, status: string) => {
    if (status === "cancelled" && !window.confirm(`Cancel ${a.customer?.name ?? "this"} appointment?`)) return;
    await run(`${a.id}-${status}`, () => post(`/appointments/${a.id}/status`, { status }), `Marked ${label(status).toLowerCase()}`);
    void list.reload();
  };

  const days = new Map<string, Appointment[]>();
  const items = [...(list.data ?? [])].sort((x, y) => (range === "past" ? y.start_at.localeCompare(x.start_at) : x.start_at.localeCompare(y.start_at)));
  for (const a of items) {
    const d = new Date(a.start_at).toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", timeZone: tz });
    days.set(d, [...(days.get(d) ?? []), a]);
  }
  return (
    <>
      <PageHeader title="Appointments" description={tz ? `Times shown in ${tz.replace("_", " ")}.` : undefined}
        action={<div className="flex gap-2">
          <Select label="Show" value={range} onChange={(e) => setRange(e.target.value as "upcoming" | "past")}><option value="upcoming">Upcoming</option><option value="past">Past 90 days</option></Select>
          {can("leads") && <Button className="self-end" onClick={() => setBooking(true)}>Book appointment</Button>}
        </div>} />
      {list.loading && !list.data ? <Loading /> : list.error ? <Alert>{list.error}</Alert> : days.size === 0 ? (
        <Empty title={range === "upcoming" ? "Nothing on the calendar yet" : "No past appointments"}>Appointments your AI employee books appear here automatically.</Empty>
      ) : (
        <div className="space-y-5">
          {[...days.entries()].map(([day, appts]) => (
            <section key={day}>
              <h2 className="mb-2 text-xl font-semibold">{day}</h2>
              <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
                {appts.map((a) => (
                  <li key={a.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                    <div className="flex items-center gap-4">
                      <span className="w-20 font-display text-xl font-semibold tabular">{new Date(a.start_at).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZone: tz })}</span>
                      <div>
                        <p className="font-semibold">{a.customer?.name ?? "Customer"} {a.customer?.phone && <a className="ml-1 text-sm font-normal text-link underline" href={`tel:${a.customer.phone}`}>{phone(a.customer.phone)}</a>}</p>
                        <p className="text-[13px] text-muted">{a.service}{a.location ? ` · ${a.location}` : ""} · booked by {label(a.source)}</p>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <Badge tone={statusTone(a.status)}>{label(a.status)}</Badge>
                      {can("leads") && ["scheduled", "confirmed"].includes(a.status) && (
                        <>
                          {a.status === "scheduled" && <Button size="sm" variant="secondary" loading={pending === `${a.id}-confirmed`} onClick={() => void setStatus(a, "confirmed")}>Confirm</Button>}
                          <Button size="sm" variant="secondary" loading={pending === `${a.id}-completed`} onClick={() => void setStatus(a, "completed")}>Completed</Button>
                          <Button size="sm" variant="secondary" loading={pending === `${a.id}-no_show`} onClick={() => void setStatus(a, "no_show")}>No-show</Button>
                          <Button size="sm" variant="secondary" onClick={() => setRescheduling(a)}>Reschedule</Button>
                          <Button size="sm" variant="ghost" loading={pending === `${a.id}-cancelled`} onClick={() => void setStatus(a, "cancelled")}>Cancel</Button>
                        </>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
      <Modal open={booking} onClose={() => setBooking(false)} title="Book an appointment">
        <BookForm customerId={params.get("customer")} leadId={params.get("lead")} onDone={() => { setBooking(false); void list.reload(); }} />
      </Modal>
      <Modal open={!!rescheduling} onClose={() => setRescheduling(null)} title="Reschedule">
        {rescheduling && <Reschedule appt={rescheduling} onDone={() => { setRescheduling(null); void list.reload(); }} />}
      </Modal>
    </>
  );
}

function SlotPicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const slots = useLoad(() => get<{ slots: Slot[] }>("/appointments/availability?days=21"), []);
  if (slots.loading) return <Loading label="Checking availability" />;
  if (slots.error) return <Alert>{slots.error}</Alert>;
  if (!slots.data?.slots.length) return <Alert tone="wait">No open times in the next 3 weeks. Check your business hours in Settings.</Alert>;
  return (
    <Select label="Time" required value={value} onChange={(e) => onChange(e.target.value)}>
      <option value="">Choose an open time</option>
      {slots.data.slots.map((s) => <option key={s.start} value={s.start}>{s.label}</option>)}
    </Select>
  );
}

function BookForm({ customerId, leadId, onDone }: { customerId: string | null; leadId: string | null; onDone: () => void }) {
  const [q, setQ] = useState("");
  const customers = useLoad(() => get<Paged<{ id: string; name: string | null; phone: string | null }>>(`/customers?page_size=20${q ? `&q=${encodeURIComponent(q)}` : ""}`), [q]);
  const [f, setF] = useState({ customer_id: customerId ?? "", start: "", service: "", notes: "" });
  const [key] = useState(() => crypto.randomUUID());
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    // The idempotency key makes a double-click or network retry safe: the same booking is returned, never duplicated.
    const r = await run("book", () => api("/appointments", { method: "POST", body: { ...f, lead_id: leadId, notes: f.notes || null }, headers: { "Idempotency-Key": key } }), "Appointment booked");
    if (r) onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Input label="Find customer" placeholder="Name or phone" value={q} onChange={(e) => setQ(e.target.value)} />
      <Select label="Customer" required value={f.customer_id} onChange={(e) => setF({ ...f, customer_id: e.target.value })}>
        <option value="">Choose a customer</option>
        {customers.data?.items.map((c) => <option key={c.id} value={c.id}>{c.name ?? phone(c.phone)}</option>)}
      </Select>
      <Input label="Service" required value={f.service} onChange={(e) => setF({ ...f, service: e.target.value })} />
      <SlotPicker value={f.start} onChange={(v) => setF({ ...f, start: v })} />
      <Textarea label="Notes" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
      <Button type="submit" loading={pending === "book"}>Book appointment</Button>
    </form>
  );
}

function Reschedule({ appt, onDone }: { appt: Appointment; onDone: () => void }) {
  const [start, setStart] = useState("");
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const r = await run("rs", () => post(`/appointments/${appt.id}/reschedule`, { start }), "Appointment moved");
    if (r) onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <p>{appt.customer?.name} — {appt.service}</p>
      <SlotPicker value={start} onChange={setStart} />
      <Button type="submit" disabled={!start} loading={pending === "rs"}>Move appointment</Button>
    </form>
  );
}
