"use client";

import { useSearchParams } from "next/navigation";
import { Suspense } from "react";

import { Alert, Badge, Button, Loading, PageHeader, Panel, statusTone } from "@/components/ui";
import { get, label, money, post, when } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";

interface Plan { key: string; name: string; price_cents: number; features: string[]; limits: Record<string, number>; purchasable: boolean }
interface Overview {
  provider: string; is_sandbox: boolean;
  subscription: { plan: Plan; status: string; trial_ends_at: string | null; current_period_end: string | null; cancel_at_period_end: boolean; usable: boolean } | null;
  usage_this_month: Record<string, number>; plans: Plan[];
  invoices: { id: string; amount_cents: number; status: string; hosted_url: string | null; created_at: string }[];
}

export default function BillingPage() {
  return <Suspense><Billing /></Suspense>;
}

function Billing() {
  const params = useSearchParams();
  const { can } = useAuth();
  const ov = useLoad(() => get<Overview>("/billing"), []);
  const { run, pending } = useAction();
  if (ov.loading && !ov.data) return <Loading />;
  if (!ov.data) return <Alert>{ov.error}</Alert>;
  const d = ov.data;
  const sub = d.subscription;
  const owner = can("billing");
  const subscribed = sub && ["active", "past_due"].includes(sub.status);
  const choose = async (plan: string) => {
    if (subscribed) {
      await run(plan, () => post("/billing/change-plan", { plan }), "Plan changed");
      void ov.reload();
      return;
    }
    const r = await run(plan, () => post<{ url: string | null; completed: boolean }>("/billing/checkout", { plan }));
    if (r?.url) window.location.assign(r.url);
    else void ov.reload();
  };
  const limit = (k: string) => sub?.plan.limits[k];
  return (
    <>
      <PageHeader title="Billing" />
      {params.get("checkout") === "success" && <div className="mb-4"><Alert tone="go">Payment received. Your plan updates in a few seconds.</Alert></div>}
      {d.is_sandbox && <div className="mb-4"><Alert tone="wait">Billing is in sandbox mode on this server — plan changes take effect without charging a card.</Alert></div>}
      {sub && (
        <Panel title="Current plan" className="mb-5">
          <div className="flex flex-wrap items-center gap-3">
            <span className="font-display text-3xl font-bold">{sub.plan.name}</span>
            <Badge tone={statusTone(sub.status)}>{label(sub.status)}</Badge>
            {sub.cancel_at_period_end && <Badge tone="wait">Cancels {when(sub.current_period_end)}</Badge>}
          </div>
          {sub.status === "trialing" && <p className="mt-1 text-muted">Trial ends {when(sub.trial_ends_at)}. Choose a plan to keep your AI employee working.</p>}
          {sub.status === "past_due" && <div className="mt-2"><Alert>Your last payment failed. Update your payment method to avoid interruption.</Alert></div>}
          {!sub.usable && <div className="mt-2"><Alert>Your AI employees are offline because there&apos;s no active subscription.</Alert></div>}
          <dl className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {[["Conversations", "conversation", "conversations_per_month"], ["Texts", "sms", "sms_per_month"], ["Voice minutes", "voice_minutes", "voice_minutes_per_month"]].map(([n, k, l]) => (
              <div key={k}><dt className="text-[13px] text-muted">{n} this month</dt><dd className="font-display text-2xl font-semibold tabular">{d.usage_this_month[k!] ?? 0}<span className="text-base text-muted"> / {limit(l!) ?? "—"}</span></dd></div>
            ))}
          </dl>
          {owner && (
            <div className="mt-4 flex flex-wrap gap-2">
              {subscribed && !sub.cancel_at_period_end && <Button variant="secondary" loading={pending === "cancel"} onClick={() => { if (window.confirm("Cancel at the end of the billing period?")) void run("cancel", () => post("/billing/cancel"), "Cancellation scheduled").then(() => ov.reload()); }}>Cancel plan</Button>}
              {sub.cancel_at_period_end && <Button variant="secondary" loading={pending === "resume"} onClick={() => void run("resume", () => post("/billing/resume"), "Subscription resumed").then(() => ov.reload())}>Keep my plan</Button>}
              {!d.is_sandbox && subscribed && <Button variant="secondary" loading={pending === "portal"} onClick={() => void run("portal", () => post<{ url: string }>("/billing/portal")).then((r) => { if (r) window.location.assign(r.url); })}>Payment method and invoices</Button>}
            </div>
          )}
        </Panel>
      )}
      <div className="grid gap-4 lg:grid-cols-3">
        {d.plans.map((p) => {
          const current = sub?.plan.key === p.key && subscribed;
          return (
            <section key={p.key} className={`flex flex-col rounded-lg border bg-surface p-5 ${current ? "border-ink ring-2 ring-ink" : "border-line"}`}>
              <h2 className="text-2xl font-semibold">{p.name}</h2>
              <p><span className="font-display text-3xl font-bold tabular">{money(p.price_cents)}</span><span className="text-muted">/month</span></p>
              <p className="mt-2 flex-1 text-[14px] text-muted">{p.limits.agents} AI employee(s) · {p.limits.conversations_per_month?.toLocaleString()} conversations · {p.limits.sms_per_month ? `${p.limits.sms_per_month.toLocaleString()} texts` : "no texts"} · {p.limits.voice_minutes_per_month ? `${p.limits.voice_minutes_per_month.toLocaleString()} voice min` : "no calls"}</p>
              {owner && (current ? <Badge tone="go">Your plan</Badge> : (
                <Button className="mt-3" disabled={!p.purchasable} loading={pending === p.key} onClick={() => void choose(p.key)}>{subscribed ? `Switch to ${p.name}` : `Subscribe to ${p.name}`}</Button>
              ))}
              {!p.purchasable && <p className="mt-1 text-[12px] text-muted">Not yet available for purchase.</p>}
            </section>
          );
        })}
      </div>
      {owner && d.invoices.length > 0 && (
        <Panel title="Invoices" className="mt-5" padded={false}>
          <ul className="divide-y divide-line">{d.invoices.map((i) => <li key={i.id} className="flex justify-between px-4 py-2 text-[14px]"><span>{when(i.created_at)}</span><span className="tabular">{money(i.amount_cents)}</span><Badge tone={statusTone(i.status)}>{label(i.status)}</Badge>{i.hosted_url ? <a className="text-link underline" href={i.hosted_url}>View</a> : <span />}</li>)}</ul>
        </Panel>
      )}
    </>
  );
}
