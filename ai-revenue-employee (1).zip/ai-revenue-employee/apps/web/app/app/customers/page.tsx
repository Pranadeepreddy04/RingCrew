"use client";

import Link from "next/link";
import { useState, type FormEvent } from "react";

import { Alert, Badge, Button, Empty, Input, Loading, Modal, PageHeader, Pager, Panel, Textarea, statusTone } from "@/components/ui";
import { ago, del, get, label, patch, phone, post, when } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";
import type { Paged } from "@/lib/types";

interface Customer { id: string; name: string | null; phone: string | null; email: string | null; address: string | null; zip: string | null; tags: string[]; notes: string | null; sms_opted_out: boolean; created_at: string }
interface CustomerFull extends Customer {
  timeline: { type: string; at: string; text: string; id: string }[];
  consents: { channel: string; purpose: string; status: string; source: string; recorded_at: string }[];
  conversations: { id: string; channel: string; status: string }[];
  leads: { id: string; service: string | null; status: string }[];
}

export default function CustomersPage() {
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [openId, setOpenId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const list = useLoad(() => get<Paged<Customer>>(`/customers?page=${page}${q ? `&q=${encodeURIComponent(q)}` : ""}`), [page, q]);
  const dups = useLoad(() => get<{ match: string; customers: Customer[] }[]>("/customers/duplicates"), []);
  const { run } = useAction();
  const merge = async (keep: string, dup: string) => {
    const ok = await run("merge", () => post(`/customers/${keep}/merge`, { duplicate_id: dup }), "Customers merged");
    if (ok) { void dups.reload(); void list.reload(); }
  };
  return (
    <>
      <PageHeader title="Customers" action={<Button onClick={() => setCreating(true)}>Add customer</Button>} />
      {!!dups.data?.length && (
        <Panel title="Possible duplicates" className="mb-5">
          <ul className="space-y-2">
            {dups.data.map((g) => (
              <li key={g.match} className="flex flex-wrap items-center gap-2 text-[14px]">
                <span className="text-muted">Same {g.match.includes("@") ? "email" : g.match.startsWith("+") ? "phone" : "name"} ({g.match.startsWith("+") ? phone(g.match) : g.match}):</span>
                {g.customers.map((c) => <span key={c.id} className="rounded bg-canvas px-2 py-0.5">{c.name ?? c.phone}</span>)}
                {g.customers.length >= 2 && <Button size="sm" variant="secondary" onClick={() => void merge(g.customers[0]!.id, g.customers[1]!.id)}>Merge into first</Button>}
              </li>
            ))}
          </ul>
        </Panel>
      )}
      <label htmlFor="cq" className="sr-only">Search customers</label>
      <input id="cq" type="search" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Search name, phone or email" className="mb-3 h-9 w-full max-w-md rounded-md border border-line bg-surface px-3 text-sm" />
      {list.loading && !list.data ? <Loading /> : list.error ? <Alert>{list.error}</Alert> : list.data?.items.length === 0 ? <Empty title="No customers yet">Customers are created automatically when someone contacts your AI employee.</Empty> : (
        <div className="overflow-x-auto rounded-lg border border-line bg-surface">
          <table className="w-full text-left text-[14px]">
            <thead className="border-b border-line text-[13px] text-muted"><tr>{["Name", "Phone", "Email", "ZIP", "Texts", "Added"].map((h) => <th key={h} scope="col" className="px-3 py-2">{h}</th>)}</tr></thead>
            <tbody className="divide-y divide-line">
              {list.data?.items.map((c) => (
                <tr key={c.id} className="hover:bg-canvas">
                  <td className="px-3 py-2"><button className="font-semibold text-link underline" onClick={() => setOpenId(c.id)}>{c.name ?? "Unnamed"}</button></td>
                  <td className="px-3 py-2 tabular">{phone(c.phone)}</td><td className="px-3 py-2">{c.email ?? "—"}</td><td className="px-3 py-2">{c.zip ?? "—"}</td>
                  <td className="px-3 py-2">{c.sms_opted_out ? <Badge tone="stop">Opted out</Badge> : <Badge tone="go">OK</Badge>}</td>
                  <td className="px-3 py-2 text-muted">{ago(c.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {list.data && <Pager page={page} total={list.data.total} pageSize={list.data.page_size} onPage={setPage} />}
      <Modal open={!!openId} onClose={() => setOpenId(null)} title="Customer" wide>
        {openId && <CustomerDetail id={openId} onChanged={() => void list.reload()} onDeleted={() => { setOpenId(null); void list.reload(); }} />}
      </Modal>
      <Modal open={creating} onClose={() => setCreating(false)} title="Add customer">
        <CustomerForm onSaved={() => { setCreating(false); void list.reload(); }} />
      </Modal>
    </>
  );
}

function CustomerForm({ initial, onSaved }: { initial?: Customer; onSaved: () => void }) {
  const [f, setF] = useState({ name: initial?.name ?? "", phone: initial?.phone ?? "", email: initial?.email ?? "", address: initial?.address ?? "", zip: initial?.zip ?? "", notes: initial?.notes ?? "", tags: (initial?.tags ?? []).join(", ") });
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const body = { name: f.name || null, phone: f.phone || null, email: f.email || null, address: f.address || null, zip: f.zip || null, notes: f.notes || null,
      tags: f.tags.split(",").map((t) => t.trim()).filter(Boolean) };
    const r = await run("save", () => (initial ? patch(`/customers/${initial.id}`, body) : post("/customers", body)), "Customer saved");
    if (r) onSaved();
  };
  return (
    <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2">
      <Input label="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <Input label="Phone" type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
      <Input label="Email" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
      <Input label="ZIP" value={f.zip} onChange={(e) => setF({ ...f, zip: e.target.value })} />
      <Input className="sm:col-span-2" label="Address" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
      <Input className="sm:col-span-2" label="Tags" hint="Comma separated" value={f.tags} onChange={(e) => setF({ ...f, tags: e.target.value })} />
      <Textarea className="sm:col-span-2" label="Notes" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
      <Button type="submit" loading={pending === "save"}>Save customer</Button>
    </form>
  );
}

function CustomerDetail({ id, onChanged, onDeleted }: { id: string; onChanged: () => void; onDeleted: () => void }) {
  const { data, error, loading, reload } = useLoad(() => get<CustomerFull>(`/customers/${id}`), [id]);
  const { org } = useAuth();
  const { run, pending } = useAction();
  const [editing, setEditing] = useState(false);
  if (loading && !data) return <Loading />;
  if (error || !data) return <Alert>{error}</Alert>;
  const optOut = async () => {
    await run("oo", () => post(`/customers/${id}/sms-consent`, { sms_opted_out: true }), "Texts stopped for this customer");
    void reload();
  };
  const optIn = async () => {
    const source = window.prompt("How did the customer ask to receive texts again? (e.g. 'Customer texted START on May 3')");
    if (!source) return;
    await run("oi", () => post(`/customers/${id}/sms-consent`, { sms_opted_out: false, source }), "Texts re-enabled");
    void reload();
  };
  const remove = async () => {
    if (!window.confirm("Delete this customer's personal data? Messages are redacted and files removed. This can't be undone.")) return;
    const r = await run("del", () => del(`/customers/${id}`), "Customer data deleted");
    if (r) onDeleted();
  };
  if (editing) return <CustomerForm initial={data} onSaved={() => { setEditing(false); void reload(); onChanged(); }} />;
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-2xl font-semibold">{data.name ?? "Unnamed"}</h3>
          <p className="text-muted">{phone(data.phone)} · {data.email ?? "no email"} · {data.address ?? data.zip ?? ""}</p>
          {data.tags.length > 0 && <p className="mt-1 flex gap-1">{data.tags.map((t) => <Badge key={t}>{t}</Badge>)}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" onClick={() => setEditing(true)}>Edit</Button>
          {data.sms_opted_out ? <Button size="sm" variant="secondary" loading={pending === "oi"} onClick={() => void optIn()}>Re-enable texts</Button>
            : <Button size="sm" variant="secondary" loading={pending === "oo"} onClick={() => void optOut()}>Stop texts</Button>}
          {org && ["owner", "manager"].includes(org.role) && <Button size="sm" variant="danger" loading={pending === "del"} onClick={() => void remove()}>Delete data</Button>}
        </div>
      </div>
      {data.notes && <p className="rounded-md bg-canvas p-3 text-[14px] whitespace-pre-wrap">{data.notes}</p>}
      <section>
        <h4 className="font-semibold">Activity</h4>
        <ol className="mt-2 space-y-1.5 text-[14px]">
          {data.timeline.map((e) => (
            <li key={`${e.type}-${e.id}`} className="flex gap-3">
              <span className="w-32 shrink-0 text-muted tabular">{when(e.at)}</span>
              {e.type === "conversation" ? <Link className="text-link underline" href={`/app/inbox?id=${e.id}`}>{e.text}</Link> : e.type === "lead" ? <Link className="text-link underline" href={`/app/leads?id=${e.id}`}>{e.text}</Link> : <span>{e.text}</span>}
            </li>
          ))}
        </ol>
      </section>
      <section>
        <h4 className="font-semibold">Consent record</h4>
        {data.consents.length === 0 ? <p className="text-[14px] text-muted">No texting consent recorded — automated texts will not be sent.</p> : (
          <ul className="text-[14px]">{data.consents.map((c, i) => <li key={i}><Badge tone={statusTone(c.status === "granted" ? "active" : "failed")}>{label(c.status)}</Badge> {c.channel} {c.purpose} — {c.source} ({when(c.recorded_at)})</li>)}</ul>
        )}
      </section>
    </div>
  );
}
