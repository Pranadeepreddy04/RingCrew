"use client";

import Link from "next/link";

import { Alert, Badge, Button, ButtonLink, Loading, Panel, PageHeader, statusTone } from "@/components/ui";
import { ago, get, label, money, patch, when } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useLoad } from "@/lib/hooks";
import type { Agent, Appointment, Conversation, Lead, Task } from "@/lib/types";

interface Metrics {
  calls: number; answered_calls: number; conversations: number; leads: number; qualified_leads: number; appointments: number; follow_ups: number;
  human_handoffs: number; estimated_opportunity_value_cents: number; confirmed_revenue_cents: number; avg_first_response_ms: number | null; attribution_note: string;
}
interface Dash {
  today: Metrics; agents: Agent[]; timezone: string; recent_conversations?: Conversation[]; pipeline?: { stage: string; count: number }[];
  recent_leads?: Lead[]; tasks?: Task[]; upcoming_appointments?: Appointment[];
}

export default function Dashboard() {
  const { org } = useAuth();
  const { data, error, loading, reload } = useLoad(() => get<Dash>("/dashboard"));
  if (loading && !data) return <Loading />;
  if (error || !data) return <Alert>{error ?? "Couldn't load the dashboard."}</Alert>;
  const t = data.today;
  const stats: [string, number | string][] = [
    ["Calls answered", t.answered_calls], ["Conversations", t.conversations], ["New leads", t.leads], ["Qualified", t.qualified_leads],
    ["Appointments", t.appointments], ["Follow-ups sent", t.follow_ups], ["Human transfers", t.human_handoffs],
  ];
  return (
    <>
      <PageHeader title="Dashboard" description={`Today in ${data.timezone.replace("_", " ")}`} />
      {org && !org.onboarding_completed && (
        <div className="mb-5"><Alert tone="live">Setup isn&apos;t finished yet. <Link href="/onboarding" className="font-semibold underline">Continue setup</Link> to put your AI employee to work.</Alert></div>
      )}
      <section aria-label="AI employees" className="mb-5 flex flex-wrap gap-3">
        {data.agents.length === 0 && <ButtonLink href="/onboarding">Create your first AI employee</ButtonLink>}
        {data.agents.map((a) => (
          <Link key={a.id} href="/app/ai-employees" className="flex items-center gap-3 rounded-lg border border-line bg-surface px-4 py-3 hover:border-ink-2">
            <span className={`size-2.5 rounded-full ${a.status === "active" ? "bg-go" : "bg-muted"}`} aria-hidden="true" />
            <span><span className="font-semibold">{a.name}</span> <span className="text-muted">— {label(a.role)}</span></span>
            <Badge tone={a.status === "active" ? "go" : "wait"}>{a.status === "active" ? "Online" : label(a.status)}</Badge>
          </Link>
        ))}
      </section>
      <section aria-label="Today" className="mb-6 grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-4 xl:grid-cols-8">
        {stats.map(([k, v]) => (
          <div key={k} className="bg-surface p-4">
            <p className="font-display text-4xl font-bold tabular">{v}</p>
            <p className="text-[13px] text-muted">{k}</p>
          </div>
        ))}
        <div className="bg-surface p-4" title={t.attribution_note}>
          <p className="font-display text-4xl font-bold tabular">{money(t.estimated_opportunity_value_cents)}</p>
          <p className="text-[13px] text-muted">Estimated opportunities (not revenue)</p>
        </div>
      </section>
      <div className="grid gap-5 xl:grid-cols-2">
        {data.recent_conversations && (
          <Panel title="Recent conversations" action={<Link className="text-sm text-link underline" href="/app/inbox">Open inbox</Link>} padded={false}>
            {data.recent_conversations.length === 0 ? <p className="p-4 text-muted">No conversations yet. Once your AI employee is live, customer chats, calls and texts appear here.</p> : (
              <ul className="divide-y divide-line">
                {data.recent_conversations.map((c) => (
                  <li key={c.id}>
                    <Link href={`/app/inbox?id=${c.id}`} className="flex items-center justify-between gap-3 px-4 py-2.5 hover:bg-canvas">
                      <span className="min-w-0"><span className="font-semibold">{c.customer?.name ?? c.customer?.phone ?? "Website visitor"}</span>
                        <span className="block truncate text-[13px] text-muted">{label(c.channel)} · {c.summary ?? "No summary yet"}</span></span>
                      <span className="shrink-0 text-right">{c.status === "needs_human" ? <Badge tone="stop">Needs you</Badge> : <Badge tone={statusTone(c.status)}>{label(c.status)}</Badge>}
                        <span className="block text-[12px] text-muted">{ago(c.last_message_at)}</span></span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        )}
        {data.recent_leads && (
          <Panel title="New leads" action={<Link className="text-sm text-link underline" href="/app/leads">All leads</Link>} padded={false}>
            {data.recent_leads.length === 0 ? <p className="p-4 text-muted">No leads yet.</p> : (
              <ul className="divide-y divide-line">
                {data.recent_leads.map((l) => (
                  <li key={l.id}>
                    <Link href={`/app/leads?id=${l.id}`} className="flex items-center justify-between gap-3 px-4 py-2.5 hover:bg-canvas">
                      <span className="min-w-0"><span className="font-semibold">{l.is_qualified && "✓ "}{l.customer?.name ?? "Unknown"}</span>
                        <span className="block truncate text-[13px] text-muted">{l.service ?? "Request"} · {label(l.source)}</span></span>
                      <Badge tone={statusTone(l.status)}>{label(l.status)}</Badge>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        )}
        {data.pipeline && (
          <Panel title="Lead pipeline">
            <div className="flex flex-wrap gap-2">
              {data.pipeline.map((p) => (
                <Link key={p.stage} href={`/app/leads?status=${p.stage}`} className="min-w-24 flex-1 rounded-md border border-line p-3 hover:border-ink-2">
                  <p className="font-display text-3xl font-bold tabular">{p.count}</p><p className="text-[13px] text-muted">{label(p.stage)}</p>
                </Link>
              ))}
            </div>
          </Panel>
        )}
        {data.upcoming_appointments && (
          <Panel title="Upcoming appointments" action={<Link className="text-sm text-link underline" href="/app/appointments">Calendar</Link>} padded={false}>
            {data.upcoming_appointments.length === 0 ? <p className="p-4 text-muted">Nothing scheduled.</p> : (
              <ul className="divide-y divide-line">
                {data.upcoming_appointments.map((a) => (
                  <li key={a.id} className="flex justify-between gap-3 px-4 py-2.5">
                    <span><span className="font-semibold">{a.customer?.name ?? "Customer"}</span><span className="block text-[13px] text-muted">{a.service}</span></span>
                    <span className="text-right text-sm tabular">{when(a.start_at, data.timezone)}</span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        )}
        {data.tasks && (
          <Panel title="Needs your attention" padded={false}>
            {data.tasks.length === 0 ? <p className="p-4 text-muted">Nothing waiting on you.</p> : (
              <ul className="divide-y divide-line">
                {data.tasks.map((t2) => (
                  <li key={t2.id} className="flex items-start justify-between gap-3 px-4 py-2.5">
                    <div>
                    <Link href={t2.conversation_id ? `/app/inbox?id=${t2.conversation_id}` : t2.lead_id ? `/app/leads?id=${t2.lead_id}` : "/app/leads"} className="block hover:underline">
                      {t2.priority === "high" && <Badge tone="stop">Urgent</Badge>} <span className="font-semibold">{t2.title}</span>
                    </Link>
                    <span className="text-[12px] text-muted">{ago(t2.created_at)}</span>
                    </div>
                    <Button size="sm" variant="secondary" onClick={() => void patch(`/tasks/${t2.id}`, { status: "done" }).then(reload)}>Done</Button>
                  </li>
                ))}
              </ul>
            )}
          </Panel>
        )}
      </div>
    </>
  );
}
