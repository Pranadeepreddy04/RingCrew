"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState, type FormEvent } from "react";

import { Alert, Badge, Button, Empty, Loading, PageHeader, Pager, cx, statusTone } from "@/components/ui";
import { ago, get, label, phone, post, when } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";
import { byCode } from "@/lib/languages";
import type { Appointment, Conversation, Lead, Message, Paged, Task } from "@/lib/types";

const FILTERS: [string, string][] = [["all", "All"], ["needs_human", "Needs a person"], ["unresolved", "Open"], ["completed", "Resolved"], ["phone", "Calls"], ["sms", "Texts"], ["web", "Website"], ["test", "Tests"]];

interface Detail extends Conversation {
  messages: Message[];
  lead: Lead | null;
  appointments: Appointment[];
  tasks: Task[];
  call: { status: string; duration_seconds: number | null; recording_enabled: boolean; transferred_to: string | null } | null;
  files: { id: string; filename: string; download_url: string }[];
}

export default function InboxPage() {
  return <Suspense><Inbox /></Suspense>;
}

function Inbox() {
  const params = useSearchParams();
  const router = useRouter();
  const [filter, setFilter] = useState("all");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const selected = params.get("id");
  const list = useLoad(() => get<Paged<Conversation>>(`/conversations?filter=${filter}&page=${page}${q ? `&q=${encodeURIComponent(q)}` : ""}`), [filter, page, q]);
  useEffect(() => {
    const t = setInterval(() => void list.reload(), 15000);
    return () => clearInterval(t);
  }, [list]);

  return (
    <>
      <PageHeader title="Inbox" description="Every call, text and chat your AI employee handled. Take over any conversation — the AI stops until you hand it back." />
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div role="tablist" aria-label="Filter conversations" className="flex flex-wrap gap-1">
          {FILTERS.map(([k, l]) => (
            <button key={k} role="tab" aria-selected={filter === k} onClick={() => { setFilter(k); setPage(1); }}
              className={cx("rounded-md px-3 py-1.5 text-sm font-medium", filter === k ? "bg-ink text-white" : "bg-surface text-ink-2 hover:bg-line")}>{l}</button>
          ))}
        </div>
        <label htmlFor="inbox-q" className="sr-only">Search</label>
        <input id="inbox-q" type="search" placeholder="Search name, phone, summary" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} className="h-9 min-w-56 flex-1 rounded-md border border-line bg-surface px-3 text-sm" />
      </div>
      <div className="grid gap-4 lg:grid-cols-[360px_1fr]">
        <div className={cx(selected && "hidden lg:block")}>
          {list.loading && !list.data ? <Loading /> : list.error ? <Alert>{list.error}</Alert> : list.data?.items.length === 0 ? (
            <Empty title="No conversations here">Conversations appear as soon as customers call, text or chat.</Empty>
          ) : (
            <ul className="divide-y divide-line overflow-hidden rounded-lg border border-line bg-surface">
              {list.data?.items.map((c) => (
                <li key={c.id}>
                  <button onClick={() => router.push(`/app/inbox?id=${c.id}`)} aria-current={selected === c.id || undefined}
                    className={cx("block w-full px-3 py-2.5 text-left hover:bg-canvas", selected === c.id && "bg-hivis-soft")}>
                    <span className="flex items-center justify-between gap-2">
                      <span className="truncate font-semibold">{c.customer?.name ?? (c.customer?.phone ? phone(c.customer.phone) : "Website visitor")}</span>
                      <span className="shrink-0 text-[12px] text-muted">{ago(c.last_message_at)}</span>
                    </span>
                    <span className="mt-0.5 block truncate text-[13px] text-muted">{c.preview}</span>
                    <span className="mt-1 flex gap-1.5"><Badge>{label(c.channel === "voice" ? "call" : c.channel)}</Badge>
                      {c.language && c.language !== "en" && <Badge tone="plain">{byCode(c.language).native}</Badge>}
                      {c.status === "needs_human" ? <Badge tone="stop">Needs a person</Badge> : <Badge tone={statusTone(c.status)}>{label(c.status)}</Badge>}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
          {list.data && <Pager page={page} total={list.data.total} pageSize={list.data.page_size} onPage={setPage} />}
        </div>
        <div>{selected ? <ConversationDetail id={selected} onChange={() => void list.reload()} onBack={() => router.push("/app/inbox")} /> : (
          <div className="hidden h-64 items-center justify-center rounded-lg border border-dashed border-line text-muted lg:flex">Select a conversation</div>
        )}</div>
      </div>
    </>
  );
}

function ConversationDetail({ id, onChange, onBack }: { id: string; onChange: () => void; onBack: () => void }) {
  const { can } = useAuth();
  const { data, error, loading, reload } = useLoad(() => get<Detail>(`/conversations/${id}`), [id]);
  const { run, pending } = useAction();
  const [text, setText] = useState("");
  useEffect(() => {
    const t = setInterval(() => void reload(), 8000);
    return () => clearInterval(t);
  }, [reload]);
  if (loading && !data) return <Loading />;
  if (error || !data) return <Alert>{error}</Alert>;
  const act = async (path: string, msg: string) => {
    await run(path, () => post(`/conversations/${id}/${path}`), msg);
    await reload();
    onChange();
  };
  const send = async (e: FormEvent) => {
    e.preventDefault();
    const ok = await run("send", () => post(`/conversations/${id}/messages`, { text }), "Message sent");
    if (ok) setText("");
    await reload();
  };
  const writable = can("conversations");
  return (
    <article className="rounded-lg border border-line bg-surface">
      <header className="flex flex-wrap items-start justify-between gap-3 border-b border-line p-4">
        <div>
          <button className="mb-1 text-sm text-link underline lg:hidden" onClick={onBack}>Back to list</button>
          <h2 className="text-2xl font-semibold">{data.customer?.name ?? "Website visitor"}</h2>
          <p className="text-sm text-muted">{label(data.channel === "voice" ? "phone call" : data.channel)} · {byCode(data.language).name} · started {when(data.created_at)}
            {data.customer?.phone && <> · <a className="text-link underline" href={`tel:${data.customer.phone}`}>{phone(data.customer.phone)}</a></>}</p>
          {data.handoff_reason && <p className="mt-1"><Badge tone="stop">Handed off: {label(data.handoff_reason)}</Badge></p>}
        </div>
        {writable && (
          <div className="flex flex-wrap gap-2">
            {data.handoff_active ? (
              <Button variant="secondary" size="sm" loading={pending === "return-to-ai"} onClick={() => void act("return-to-ai", "Returned to the AI")}>Return to AI</Button>
            ) : (
              <Button size="sm" loading={pending === "takeover"} onClick={() => void act("takeover", "You're handling this conversation")}>Take over</Button>
            )}
            {data.status !== "resolved" && <Button variant="secondary" size="sm" loading={pending === "resolve"} onClick={() => void act("resolve", "Marked resolved")}>Mark resolved</Button>}
          </div>
        )}
      </header>
      <div className="grid lg:grid-cols-[1fr_240px]">
        <div className="p-4">
          <ol className="space-y-2" aria-label="Transcript">
            {data.messages.map((m) => <MessageRow key={m.id} m={m} />)}
          </ol>
          {writable && data.handoff_active && data.channel !== "voice" && (
            <form onSubmit={send} className="mt-4 flex gap-2">
              <label htmlFor="reply" className="sr-only">Reply</label>
              <input id="reply" value={text} onChange={(e) => setText(e.target.value)} maxLength={1600} placeholder={data.channel === "sms" ? "Text the customer…" : "Reply in the chat…"} className="h-10 flex-1 rounded-md border border-line px-3" />
              <Button type="submit" disabled={!text.trim()} loading={pending === "send"}>Send</Button>
            </form>
          )}
          {writable && !data.handoff_active && data.channel !== "voice" && <p className="mt-4 text-[13px] text-muted">Take over to reply yourself. The AI stops responding while you&apos;re in the conversation.</p>}
        </div>
        <aside className="space-y-4 border-t border-line p-4 text-[14px] lg:border-t-0 lg:border-l">
          {data.summary && <section><h3 className="font-semibold">Summary</h3><p className="text-muted">{data.summary}</p></section>}
          {Object.keys(data.collected).length > 0 && (
            <section><h3 className="font-semibold">Details collected</h3>
              <dl className="mt-1 space-y-0.5">{Object.entries(data.collected).map(([k, v]) => <div key={k} className="flex justify-between gap-2"><dt className="text-muted">{label(k)}</dt><dd className="text-right">{k === "phone" ? phone(String(v)) : label(String(v))}</dd></div>)}</dl>
            </section>
          )}
          {data.lead && <section><h3 className="font-semibold">Lead</h3><Link className="text-link underline" href={`/app/leads?id=${data.lead.id}`}>{data.lead.service ?? "View lead"}</Link> <Badge tone={statusTone(data.lead.status)}>{label(data.lead.status)}</Badge></section>}
          {data.appointments.map((a) => <section key={a.id}><h3 className="font-semibold">Appointment</h3><p>{when(a.start_at)}</p><Badge tone={statusTone(a.status)}>{label(a.status)}</Badge></section>)}
          {data.call && <section><h3 className="font-semibold">Call</h3><p className="text-muted">{label(data.call.status)}{data.call.duration_seconds ? ` · ${Math.round(data.call.duration_seconds / 60)} min` : ""}{data.call.transferred_to ? ` · transferred to ${phone(data.call.transferred_to)}` : ""}</p></section>}
          {data.files.length > 0 && <section><h3 className="font-semibold">Files</h3><ul>{data.files.map((f) => <li key={f.id}><a className="text-link underline" href={f.download_url}>{f.filename}</a></li>)}</ul></section>}
          {data.tasks.length > 0 && <section><h3 className="font-semibold">Tasks</h3><ul className="space-y-1">{data.tasks.map((t) => <li key={t.id}>{t.title} <Badge tone={statusTone(t.status === "done" ? "completed" : "open")}>{label(t.status)}</Badge></li>)}</ul></section>}
        </aside>
      </div>
    </article>
  );
}

function MessageRow({ m }: { m: Message }) {
  if (m.role === "tool") {
    const ok = m.meta.ok !== false;
    return <li className={cx("w-fit rounded px-2 py-0.5 text-[12px] font-semibold", ok ? "bg-hivis-soft" : "bg-stop-soft text-stop")}>AI action · {m.content}</li>;
  }
  if (m.role === "system") return <li className="text-center text-[12px] text-muted">{m.content}</li>;
  const mine = m.role === "customer";
  return (
    <li className={cx("max-w-[85%] rounded-xl px-3 py-2 text-[14px] whitespace-pre-wrap", mine ? "bg-canvas" : m.role === "human" ? "ml-auto bg-ink-2 text-white" : "ml-auto border border-line bg-surface")}>
      <span className="mb-0.5 block text-[11px] font-semibold opacity-70">{mine ? "Customer" : m.role === "human" ? "Team" : "AI"} · {when(m.created_at)}{m.delivery_status ? ` · ${label(m.delivery_status)}` : ""}{m.meta.input === "voice" ? " · spoken" : ""}{m.meta.asr === "vibevoice" && !mine ? " · VibeVoice ASR" : ""}</span>
      <span dir="auto" className="block">{m.content}</span>
    </li>
  );
}
