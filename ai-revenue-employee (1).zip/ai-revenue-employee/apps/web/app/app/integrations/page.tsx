"use client";

import { useSearchParams } from "next/navigation";
import { Suspense, useState, type FormEvent } from "react";

import { Alert, Badge, Button, Checkbox, Input, Loading, Modal, PageHeader, Panel, Select, statusTone } from "@/components/ui";
import { ago, del, get, label, patch, phone, post } from "@/lib/api";
import { useAction, useLoad } from "@/lib/hooks";
import type { Agent } from "@/lib/types";

interface Conn { id: string; provider: string; status: string; last_sync_at: string | null; last_error: string | null; connected_at: string }
interface Card { provider: string; name: string; available: boolean; requires: string; permissions: string[]; connection: Conn | null }
interface Catalog {
  calendar: Card[]; crm: Card[];
  phone: { provider: string; is_sandbox: boolean; voice_provider: string; sms_on_plan: boolean; voice_on_plan: boolean; webhook_urls: Record<string, string>;
    numbers: { id: string; number: string; provider: string; agent_id: string | null; sms_enabled: boolean; voice_enabled: boolean }[] };
  email: { provider: string; is_sandbox: boolean }; payments: { provider: string; is_sandbox: boolean };
}

export default function IntegrationsPage() {
  return <Suspense><Integrations /></Suspense>;
}

function Integrations() {
  const params = useSearchParams();
  const cat = useLoad(() => get<Catalog>("/integrations"), []);
  const agents = useLoad(() => get<Agent[]>("/agents"), []);
  const { run, pending } = useAction();
  const [numberOpen, setNumberOpen] = useState(false);
  const [hubspot, setHubspot] = useState(false);
  if (cat.loading && !cat.data) return <Loading />;
  if (cat.error || !cat.data) return <Alert>{cat.error}</Alert>;
  const c = cat.data;
  const connectGoogle = async () => {
    const r = await run("g", () => get<{ url: string }>("/integrations/google-calendar/connect"));
    if (r) window.location.assign(r.url);
  };
  const card = (k: Card, onConnect: () => void) => (
    <li key={k.provider} className="rounded-lg border border-line bg-surface p-4">
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-lg font-semibold">{k.name}</h3>
        {k.connection ? <Badge tone={statusTone(k.connection.status)}>{label(k.connection.status)}</Badge> : !k.available && <Badge>Not available</Badge>}
      </div>
      {k.permissions.length > 0 && <ul className="mt-2 list-disc pl-5 text-[14px] text-muted">{k.permissions.map((p) => <li key={p}>{p}</li>)}</ul>}
      {k.connection ? (
        <>
          <p className="mt-2 text-[13px] text-muted">Connected {ago(k.connection.connected_at)} · last sync {k.connection.last_sync_at ? ago(k.connection.last_sync_at) : "never"}</p>
          {k.connection.last_error && <Alert>{k.connection.last_error}</Alert>}
          <div className="mt-3 flex gap-2">
            <Button size="sm" variant="secondary" loading={pending === `t${k.provider}`} onClick={() => void run(`t${k.provider}`, () => post<{ ok: boolean }>(`/integrations/${k.connection!.id}/test`)).then((r) => { void cat.reload(); if (r) window.alert(r.ok ? "Connection works." : "Connection failed — reconnect."); })}>Test connection</Button>
            {k.available && <Button size="sm" variant="secondary" onClick={onConnect}>Reconnect</Button>}
            <Button size="sm" variant="ghost" onClick={() => { if (window.confirm(`Disconnect ${k.name}?`)) void run("d", () => del(`/integrations/${k.connection!.id}`), "Disconnected").then(() => cat.reload()); }}>Disconnect</Button>
          </div>
        </>
      ) : k.available ? <Button size="sm" className="mt-3" loading={pending === "g" && k.provider === "google"} onClick={onConnect}>Connect</Button>
        : <p className="mt-2 text-[13px] text-muted">{k.requires}</p>}
    </li>
  );
  return (
    <>
      <PageHeader title="Connections" description="Connect the tools your AI employee works with. Passwords and tokens are encrypted and never shown again." />
      {params.get("connected") && <div className="mb-4"><Alert tone="go">Connected {params.get("connected")}.</Alert></div>}
      {params.get("error") && <div className="mb-4"><Alert>{params.get("error")}</Alert></div>}
      <div className="space-y-6">
        <section>
          <h2 className="mb-2 text-2xl font-semibold">Calendar</h2>
          <p className="mb-3 max-w-2xl text-muted">Without a connected calendar, bookings go into the built-in calendar (Appointments). A connected calendar adds its busy times and receives every booking.</p>
          <ul className="grid gap-3 md:grid-cols-3">
            {c.calendar.map((k) => card(k, k.provider === "google" ? () => void connectGoogle() : () => void run("s", () => post("/integrations/sandbox-calendar/connect"), "Sandbox calendar connected").then(() => cat.reload())))}
          </ul>
        </section>
        <Panel title="Phone number (calls and texts)" action={<Button size="sm" onClick={() => setNumberOpen(true)} disabled={!c.phone.sms_on_plan && !c.phone.voice_on_plan}>Add number</Button>}>
          {c.phone.is_sandbox && <div className="mb-3"><Alert tone="wait">Telephony is in sandbox mode on this server: numbers are simulated and no real calls or texts happen. The operator must configure Twilio credentials to go live.</Alert></div>}
          {!c.phone.sms_on_plan && <div className="mb-3"><Alert tone="wait">Calls and texts need the Growth plan or higher.</Alert></div>}
          {c.phone.numbers.length === 0 ? <p className="text-muted">No number connected yet.</p> : (
            <ul className="divide-y divide-line">
              {c.phone.numbers.map((n) => (
                <li key={n.id} className="flex flex-wrap items-center justify-between gap-3 py-2">
                  <span className="font-display text-xl font-semibold tabular">{phone(n.number)}</span>
                  <div className="flex flex-wrap items-center gap-3">
                    <Select label="Answered by" value={n.agent_id ?? ""} onChange={(e) => void run("a", () => patch(`/integrations/phone-numbers/${n.id}`, { agent_id: e.target.value }), "Updated").then(() => cat.reload())}>
                      {agents.data?.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                    </Select>
                    <Checkbox label="Calls" checked={n.voice_enabled} onChange={(v) => void run("v", () => patch(`/integrations/phone-numbers/${n.id}`, { voice_enabled: v }), "Updated").then(() => cat.reload())} />
                    <Checkbox label="Texts" checked={n.sms_enabled} onChange={(v) => void run("m", () => patch(`/integrations/phone-numbers/${n.id}`, { sms_enabled: v }), "Updated").then(() => cat.reload())} />
                    <Button size="sm" variant="ghost" onClick={() => { if (window.confirm("Disconnect this number?")) void run("r", () => del(`/integrations/phone-numbers/${n.id}`), "Number removed").then(() => cat.reload()); }}>Remove</Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <details className="mt-3 text-[14px]"><summary className="cursor-pointer font-semibold">Webhook addresses (for your telephony provider)</summary>
            <dl className="mt-2 space-y-1">{Object.entries(c.phone.webhook_urls).map(([k, v]) => <div key={k}><dt className="text-muted">{label(k)}</dt><dd><code className="break-all">{v}</code></dd></div>)}</dl>
          </details>
        </Panel>
        <section>
          <h2 className="mb-2 text-2xl font-semibold">CRM</h2>
          <ul className="grid gap-3 md:grid-cols-3">{c.crm.map((k) => card(k, () => setHubspot(true)))}</ul>
        </section>
        <Panel title="Email and payments">
          <p>Email: {c.email.is_sandbox ? <Badge tone="wait">Sandbox — emails are recorded, not sent</Badge> : <Badge tone="go">{c.email.provider}</Badge>}</p>
          <p className="mt-1">Payments: {c.payments.is_sandbox ? <Badge tone="wait">Sandbox — no real charges</Badge> : <Badge tone="go">{c.payments.provider}</Badge>}</p>
        </Panel>
        <Webhooks />
      </div>
      <Modal open={numberOpen} onClose={() => setNumberOpen(false)} title="Add a phone number"><NumberForm agents={agents.data ?? []} onDone={() => { setNumberOpen(false); void cat.reload(); }} /></Modal>
      <Modal open={hubspot} onClose={() => setHubspot(false)} title="Connect HubSpot"><HubSpotForm onDone={() => { setHubspot(false); void cat.reload(); }} /></Modal>
    </>
  );
}

function NumberForm({ agents, onDone }: { agents: Agent[]; onDone: () => void }) {
  const [f, setF] = useState({ mode: "provision", area_code: "", number: "", agent_id: agents[0]?.id ?? "" });
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const r = await run("n", () => post("/integrations/phone-numbers", { mode: f.mode, area_code: f.area_code || null, number: f.number || null, agent_id: f.agent_id || null }), "Number connected");
    if (r) onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Select label="How" value={f.mode} onChange={(e) => setF({ ...f, mode: e.target.value })}>
        <option value="provision">Get a new local number</option><option value="existing">Use a number already on the platform account</option>
      </Select>
      {f.mode === "provision" ? <Input label="Area code" required pattern="\d{3}" value={f.area_code} onChange={(e) => setF({ ...f, area_code: e.target.value })} />
        : <Input label="Number" type="tel" required value={f.number} onChange={(e) => setF({ ...f, number: e.target.value })} />}
      <Select label="Answered by" value={f.agent_id} onChange={(e) => setF({ ...f, agent_id: e.target.value })}>{agents.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</Select>
      <Button type="submit" loading={pending === "n"}>Connect number</Button>
    </form>
  );
}

function HubSpotForm({ onDone }: { onDone: () => void }) {
  const [token, setToken] = useState("");
  const { run, pending } = useAction();
  return (
    <form onSubmit={(e) => { e.preventDefault(); void run("h", () => post("/integrations/hubspot/connect", { access_token: token }), "HubSpot connected").then((r) => r && onDone()); }} className="space-y-3">
      <p className="text-muted">In HubSpot, create a private app with the scopes <em>crm.objects.contacts.write</em> and <em>crm.objects.deals.write</em>, then paste its access token here.</p>
      <Input label="Private app access token" type="password" autoComplete="off" required value={token} onChange={(e) => setToken(e.target.value)} />
      <Button type="submit" loading={pending === "h"}>Connect</Button>
    </form>
  );
}

function Webhooks() {
  const w = useLoad(() => get<{ endpoints: { id: string; url: string; events: string[] }[]; available_events: string[]; enabled_on_plan: boolean;
    deliveries: { id: string; event_type: string; status: string; attempts: number; response_code: number | null; created_at: string }[] }>("/integrations/webhooks"), []);
  const [url, setUrl] = useState("");
  const [events, setEvents] = useState<string[]>([]);
  const [secret, setSecret] = useState<string | null>(null);
  const { run, pending } = useAction();
  if (!w.data) return w.loading ? <Loading /> : <Alert>{w.error}</Alert>;
  return (
    <Panel title="Webhooks (for developers)">
      {!w.data.enabled_on_plan && <div className="mb-3"><Alert tone="wait">Webhooks are part of the Pro plan.</Alert></div>}
      {secret && <div className="mb-3"><Alert tone="live">Signing secret (shown once): <code className="break-all">{secret}</code></Alert></div>}
      <ul className="mb-3 divide-y divide-line">
        {w.data.endpoints.map((e) => (
          <li key={e.id} className="flex flex-wrap items-center justify-between gap-2 py-2 text-[14px]">
            <span><code className="break-all">{e.url}</code><span className="block text-muted">{e.events.length ? e.events.join(", ") : "All events"}</span></span>
            <span className="flex gap-2">
              <Button size="sm" variant="secondary" onClick={() => void run("t", () => post(`/integrations/webhooks/${e.id}/test`), "Test event queued").then(() => setTimeout(() => void w.reload(), 3000))}>Send test</Button>
              <Button size="sm" variant="ghost" onClick={() => void run("d", () => del(`/integrations/webhooks/${e.id}`), "Removed").then(() => w.reload())}>Remove</Button>
            </span>
          </li>
        ))}
      </ul>
      {w.data.enabled_on_plan && (
        <form onSubmit={(e) => { e.preventDefault(); void run("c", () => post<{ secret: string }>("/integrations/webhooks", { url, events }), "Webhook added").then((r) => { if (r) { setSecret(r.secret); setUrl(""); void w.reload(); } }); }} className="space-y-2">
          <Input label="Endpoint URL (https)" required value={url} onChange={(e) => setUrl(e.target.value)} />
          <div className="flex flex-wrap gap-3">{w.data.available_events.map((ev) => <Checkbox key={ev} label={ev} checked={events.includes(ev)} onChange={(v) => setEvents(v ? [...events, ev] : events.filter((x) => x !== ev))} />)}</div>
          <Button type="submit" size="sm" loading={pending === "c"}>Add endpoint</Button>
        </form>
      )}
      {w.data.deliveries.length > 0 && (
        <details className="mt-3"><summary className="cursor-pointer font-semibold">Recent deliveries</summary>
          <ul className="mt-2 text-[14px]">{w.data.deliveries.map((d) => <li key={d.id}>{d.event_type} <Badge tone={statusTone(d.status === "delivered" ? "delivered" : d.status)}>{label(d.status)}</Badge> {d.response_code ?? ""} · {d.attempts} attempt(s) · {ago(d.created_at)}</li>)}</ul>
        </details>
      )}
    </Panel>
  );
}
