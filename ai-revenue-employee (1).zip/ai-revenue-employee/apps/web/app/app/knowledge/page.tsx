"use client";

import { useState, type FormEvent } from "react";

import { FaqEditor, type Faq } from "@/components/business-forms";
import { Alert, Badge, Button, Checkbox, Empty, Input, Loading, Modal, PageHeader, Panel, Select, Textarea } from "@/components/ui";
import { ago, api, del, get, label, patch, post, put } from "@/lib/api";
import { useAction, useLoad } from "@/lib/hooks";

interface Source { id: string; kind: string; title: string; url: string | null; status: string; approved: boolean; content: string; characters: number; chunks: number | null; updated_at: string | null }

const KIND: Record<string, string> = { faq: "FAQ", manual: "Info", policy: "Policy", document: "Document", website: "Website", profile: "Business profile", service: "Services" };

export default function KnowledgePage() {
  const list = useLoad(() => get<Source[]>("/knowledge/sources"), []);
  const [adding, setAdding] = useState<null | "faq" | "text" | "doc" | "web">(null);
  const [open, setOpen] = useState<Source | null>(null);
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<{ title: string | null; content: string; kind: string; coverage: number }[] | null>(null);
  const { run, pending } = useAction();
  const done = () => { setAdding(null); void list.reload(); };
  return (
    <>
      <PageHeader title="Knowledge" description="Everything your AI employee may tell customers. It answers only from approved sources here; if something isn't covered, it says so and passes the question to your team."
        action={<div className="flex flex-wrap gap-2">
          <Button onClick={() => setAdding("faq")}>Add FAQs</Button>
          <Button variant="secondary" onClick={() => setAdding("text")}>Add info</Button>
          <Button variant="secondary" onClick={() => setAdding("doc")}>Upload document</Button>
          <Button variant="secondary" onClick={() => setAdding("web")}>Import website</Button>
        </div>} />
      <Panel title="Try a question" className="mb-5">
        <form onSubmit={(e) => { e.preventDefault(); void run("s", () => get<typeof hits>(`/knowledge/search?q=${encodeURIComponent(q)}`)).then((h) => setHits(h ?? [])); }} className="flex gap-2">
          <label htmlFor="kq" className="sr-only">Question</label>
          <input id="kq" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Do you offer financing?" className="h-10 flex-1 rounded-md border border-line px-3" />
          <Button type="submit" variant="secondary" loading={pending === "s"} disabled={!q.trim()}>Search</Button>
        </form>
        {hits && (hits.length === 0 ? <p className="mt-3 text-muted">No approved information matches. Your AI employee would say it doesn&apos;t have that information and hand it to your team.</p> : (
          <ul className="mt-3 space-y-2">{hits.map((h, i) => <li key={i} className="rounded-md bg-canvas p-2 text-[14px]"><Badge>{KIND[h.kind] ?? h.kind}</Badge> <strong>{h.title}</strong> <span className="text-muted">({Math.round(h.coverage * 100)}% match)</span><p className="mt-1 line-clamp-3 whitespace-pre-wrap">{h.content}</p></li>)}</ul>
        ))}
      </Panel>
      {list.loading && !list.data ? <Loading /> : list.error ? <Alert>{list.error}</Alert> : list.data?.length === 0 ? <Empty title="No knowledge yet">Add your FAQs first — they have the biggest impact.</Empty> : (
        <ul className="divide-y divide-line rounded-lg border border-line bg-surface">
          {list.data?.map((s) => (
            <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
              <button className="min-w-0 text-left" onClick={() => setOpen(s)}>
                <span className="font-semibold text-link underline">{s.title}</span>
                <span className="block text-[13px] text-muted">{KIND[s.kind] ?? s.kind} · {s.chunks ?? 0} section(s) · updated {ago(s.updated_at)}{s.url ? ` · ${s.url}` : ""}</span>
              </button>
              <div className="flex items-center gap-2">
                {s.status !== "ready" && <Badge tone="stop">{label(s.status)}</Badge>}
                <Checkbox label="Approved" checked={s.approved} onChange={(v) => void run("ap", () => patch(`/knowledge/sources/${s.id}`, { approved: v }), v ? "Approved" : "Hidden from the AI").then(() => list.reload())} />
                {!["profile", "service"].includes(s.kind) && <Button size="sm" variant="ghost" onClick={() => { if (window.confirm(`Delete "${s.title}"?`)) void run("d", () => del(`/knowledge/sources/${s.id}`), "Deleted").then(() => list.reload()); }}>Delete</Button>}
              </div>
            </li>
          ))}
        </ul>
      )}
      <Modal open={adding === "faq"} onClose={() => setAdding(null)} title="Add FAQs" wide><FaqForm onDone={done} /></Modal>
      <Modal open={adding === "text"} onClose={() => setAdding(null)} title="Add information" wide><TextForm onDone={done} /></Modal>
      <Modal open={adding === "doc"} onClose={() => setAdding(null)} title="Upload a document"><DocForm onDone={done} /></Modal>
      <Modal open={adding === "web"} onClose={() => setAdding(null)} title="Import from your website"><WebForm onDone={done} /></Modal>
      <Modal open={!!open} onClose={() => setOpen(null)} title={open?.title ?? ""} wide>{open && <SourceView source={open} onDone={() => { setOpen(null); void list.reload(); }} />}</Modal>
    </>
  );
}

function FaqForm({ onDone, sourceId, initial }: { onDone: () => void; sourceId?: string; initial?: Faq[] }) {
  const [faqs, setFaqs] = useState<Faq[]>(initial ?? [{ question: "", answer: "" }]);
  const { run, pending } = useAction();
  const save = async () => {
    const valid = faqs.filter((f) => f.question.trim() && f.answer.trim());
    const r = await run("f", () => (sourceId ? put(`/knowledge/faqs/${sourceId}`, { faqs: valid }) : post("/knowledge/faqs", { faqs: valid })), "FAQs saved");
    if (r) onDone();
  };
  return <div className="space-y-3"><FaqEditor value={faqs} onChange={setFaqs} /><Button loading={pending === "f"} onClick={() => void save()}>Save FAQs</Button></div>;
}

function TextForm({ onDone }: { onDone: () => void }) {
  const [f, setF] = useState({ kind: "manual", title: "", content: "" });
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (await run("t", () => post("/knowledge/sources", f), "Saved")) onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Select label="Type" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option value="manual">General information</option><option value="policy">Policy</option></Select>
      <Input label="Title" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
      <Textarea label="Content" required rows={10} value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} />
      <Button type="submit" loading={pending === "t"}>Save</Button>
    </form>
  );
}

function DocForm({ onDone }: { onDone: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!file) return;
    const fd = new FormData();
    fd.append("file", file);
    fd.append("title", title);
    if (await run("u", () => api("/knowledge/documents", { method: "POST", body: fd }), "Document added")) onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Input label="Title (optional)" value={title} onChange={(e) => setTitle(e.target.value)} />
      <div>
        <label htmlFor="doc" className="mb-1 block text-[13px] font-semibold text-ink-2">File</label>
        <input id="doc" type="file" accept=".txt,.md,.pdf,.docx" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        <p className="mt-1 text-[13px] text-muted">PDF, Word, text or Markdown, up to 5 MB. Only upload material you&apos;re happy for customers to be told.</p>
      </div>
      <Button type="submit" disabled={!file} loading={pending === "u"}>Upload</Button>
    </form>
  );
}

function WebForm({ onDone }: { onDone: () => void }) {
  const [url, setUrl] = useState("");
  const [ok, setOk] = useState(false);
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const r = await run("w", () => post<{ sources: unknown[] }>("/organizations/current/import-website", { url, confirm: ok }));
    if (r) { window.alert(`Imported ${r.sources.length} page(s).`); onDone(); }
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Input label="Website" required value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://yourbusiness.com" />
      <Checkbox label="Yes, read my public website" checked={ok} onChange={setOk} />
      <Button type="submit" disabled={!ok} loading={pending === "w"}>Import</Button>
    </form>
  );
}

function SourceView({ source, onDone }: { source: Source; onDone: () => void }) {
  const faq = useLoad(() => (source.kind === "faq" ? get<{ faqs: Faq[] }>(`/knowledge/faqs/${source.id}`) : Promise.resolve(null)), [source.id]);
  const [content, setContent] = useState(source.content);
  const { run, pending } = useAction();
  if (source.kind === "faq") return faq.loading ? <Loading /> : <FaqForm sourceId={source.id} initial={faq.data?.faqs} onDone={onDone} />;
  if (["profile", "service"].includes(source.kind)) return <div><p className="mb-2 text-muted">Edit this in Settings.</p><pre className="whitespace-pre-wrap text-[14px]">{source.content}</pre></div>;
  return (
    <div className="space-y-3">
      <Textarea label="Content" rows={14} value={content} onChange={(e) => setContent(e.target.value)} />
      <Button loading={pending === "e"} onClick={() => void run("e", () => patch(`/knowledge/sources/${source.id}`, { content }), "Saved").then((r) => r && onDone())}>Save</Button>
    </div>
  );
}
