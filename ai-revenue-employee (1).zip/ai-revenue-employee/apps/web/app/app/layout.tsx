"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";

import { Logo } from "@/components/site-chrome";
import { Loading, cx } from "@/components/ui";
import { ago, get, post } from "@/lib/api";
import { useRequireAuth, type Permission } from "@/lib/auth";

const NAV: { href: string; label: string; perm?: Permission }[] = [
  { href: "/app/dashboard", label: "Dashboard" },
  { href: "/app/inbox", label: "Inbox", perm: "conversations" },
  { href: "/app/leads", label: "Leads", perm: "leads" },
  { href: "/app/appointments", label: "Appointments", perm: "leads" },
  { href: "/app/customers", label: "Customers", perm: "leads" },
  { href: "/app/ai-employees", label: "AI employees" },
  { href: "/app/knowledge", label: "Knowledge", perm: "configure" },
  { href: "/app/workflows", label: "Follow-ups", perm: "leads" },
  { href: "/app/analytics", label: "Analytics", perm: "analytics" },
  { href: "/app/integrations", label: "Connections", perm: "integrations" },
  { href: "/app/team", label: "Team" },
  { href: "/app/billing", label: "Billing" },
  { href: "/app/settings", label: "Settings" },
];

interface Notif { id: string; title: string; body: string | null; link: string | null; read: boolean; created_at: string }

export default function AppLayout({ children }: { children: ReactNode }) {
  const auth = useRequireAuth();
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const [notifs, setNotifs] = useState<{ unread: number; items: Notif[] }>({ unread: 0, items: [] });
  const [showNotifs, setShowNotifs] = useState(false);

  useEffect(() => {
    if (!auth.org) return;
    const load = () => get<{ unread: number; items: Notif[] }>("/notifications").then(setNotifs).catch(() => undefined);
    void load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, [auth.org]);

  if (auth.loading || !auth.me || !auth.org) return <Loading />;
  const items = NAV.filter((n) => !n.perm || auth.can(n.perm));
  const nav = (
    <nav aria-label="App" className="flex flex-col gap-0.5">
      {items.map((n) => (
        <Link key={n.href} href={n.href} onClick={() => setOpen(false)} aria-current={path.startsWith(n.href) ? "page" : undefined}
          className={cx("rounded-md px-3 py-2 text-[15px] font-medium", path.startsWith(n.href) ? "bg-ink text-white" : "text-ink-2 hover:bg-canvas")}>
          {n.label}
        </Link>
      ))}
      {auth.me.user.is_superadmin && (
        <Link href="/app/admin" aria-current={path.startsWith("/app/admin") ? "page" : undefined}
          className={cx("mt-3 rounded-md px-3 py-2 text-[15px] font-medium", path.startsWith("/app/admin") ? "bg-ink text-white" : "text-ink-2 hover:bg-canvas")}>
          Platform admin
        </Link>
      )}
    </nav>
  );

  return (
    <div className="min-h-screen">
      {auth.me.impersonating && (
        <div role="alert" className="bg-stop px-4 py-2 text-center text-sm font-semibold text-white">
          You are viewing this account as {auth.me.user.email} (admin impersonation — every action is audited). <button className="underline" onClick={() => void auth.logout()}>End session</button>
        </div>
      )}
      {auth.org.is_demo && <div className="bg-hivis px-4 py-1.5 text-center text-sm">Demo organization — no real messages or bookings.</div>}
      <header className="sticky top-0 z-30 border-b border-line bg-surface">
        <div className="flex items-center justify-between gap-3 px-4 py-2.5">
          <div className="flex items-center gap-3">
            <button className="rounded-md border border-line px-2 py-1.5 lg:hidden" aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(!open)}>
              Menu
            </button>
            <Logo />
          </div>
          <div className="flex items-center gap-2">
            {auth.me.organizations.length > 1 ? (
              <>
                <label htmlFor="org-switch" className="sr-only">Business</label>
                <select id="org-switch" value={auth.org.id} onChange={(e) => auth.switchOrg(e.target.value)} className="h-9 max-w-44 rounded-md border border-line bg-surface px-2 text-sm">
                  {auth.me.organizations.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
                </select>
              </>
            ) : <span className="hidden text-sm font-semibold sm:inline">{auth.org.name}</span>}
            <div className="relative">
              <button onClick={() => setShowNotifs(!showNotifs)} aria-expanded={showNotifs} className="relative rounded-md border border-line px-2.5 py-1.5 text-sm" aria-label={`Notifications, ${notifs.unread} unread`}>
                Alerts
                {notifs.unread > 0 && <span className="ml-1.5 rounded bg-hivis px-1.5 text-xs font-bold tabular">{notifs.unread}</span>}
              </button>
              {showNotifs && (
                <div className="absolute right-0 z-40 mt-2 w-80 rounded-lg border border-line bg-surface shadow-xl">
                  <div className="flex items-center justify-between border-b border-line px-3 py-2">
                    <span className="font-semibold">Notifications</span>
                    <button className="text-sm text-link underline" onClick={() => void post("/notifications/read-all").then(() => setNotifs({ ...notifs, unread: 0, items: notifs.items.map((n) => ({ ...n, read: true })) }))}>Mark all read</button>
                  </div>
                  <ul className="max-h-96 overflow-y-auto">
                    {notifs.items.length === 0 && <li className="p-3 text-sm text-muted">No notifications yet.</li>}
                    {notifs.items.map((n) => (
                      <li key={n.id} className={cx("border-b border-line px-3 py-2 text-sm", !n.read && "bg-hivis-soft")}>
                        <Link href={n.link ?? "/app/dashboard"} onClick={() => setShowNotifs(false)} className="block">
                          <span className="font-semibold">{n.title}</span>
                          {n.body && <span className="block text-muted">{n.body}</span>}
                          <span className="text-xs text-muted">{ago(n.created_at)}</span>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            <button onClick={() => void auth.logout()} className="rounded-md px-2.5 py-1.5 text-sm text-ink-2 hover:bg-canvas">Sign out</button>
          </div>
        </div>
        {open && <div id="mobile-nav" className="border-t border-line p-3 lg:hidden">{nav}</div>}
      </header>
      <div className="flex">
        <aside className="sticky top-[53px] hidden h-[calc(100vh-53px)] w-56 shrink-0 overflow-y-auto border-r border-line bg-surface p-3 lg:block">{nav}</aside>
        <main id="main" className="min-w-0 flex-1 px-4 py-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
