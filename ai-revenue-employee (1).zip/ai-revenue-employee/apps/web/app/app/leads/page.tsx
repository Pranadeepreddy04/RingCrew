"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState, type DragEvent, type FormEvent } from "react";

import { Alert, Badge, Button, Empty, Input, Loading, Modal, PageHeader, Pager, Select, Textarea, cx, statusTone } from "@/components/ui";
import { ago, get, label, money, patch, phone, post, when } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";
import type { Appointment, Lead, Paged, Task } from "@/lib/types";

interface Board { stages: string[]; columns: Record<string, Lead[]> }

export default function LeadsPage() {
  return <Suspense><Leads /></Suspense>;
}

function Leads() {
  const params = useSearchParams();
  const router = useRouter();
  const [view, setView] = useState<"board" | "table">(params.get("status") ? "table" : "board");
  const [status, setStatus] = useState(params.get("status") ?? "");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [creating, setCreating] = useState(false);
  const board = useLoad(() => get<Board>("/leads/board"), []);
  const table = useLoad(() => get<Paged<Lead> & { stages: string[] }>(`/leads?page=${page}${status ? `&status=${status}` : ""}${q ? `&q=${encodeURIComponent(q)}` : ""}`), [page, status, q]);
  const { run } = useAction();
  const openId = params.get("id");
  const stages = board.data?.stages ?? table.data?.stages ?? [];

  const move = async (id: string, to: string) => {
    await run("move", () => patch(`/leads/${id}`, { status: to }), `Moved to ${label(to)}`);
    void board.reload();
    void table.reload();
  };
  const onDrop = (e: DragEvent, stage: string) => {
    e.preventDefault();
    const id = e.dataTransfer.getData("text/lead");
    if (id) void move(id, stage);
  };

  return (
    <>
      <PageHeader title="Leads" description="Every opportunity your AI employee and your team captured."
        action={<div className="flex gap-2">
          <div role="tablist" aria-label="View" className="flex rounded-md border border-line bg-surface p-0.5">
            {(["board", "table"] as const).map((v) => <button key={v} role="tab" aria-selected={view === v} onClick={() => setView(v)} className={cx("rounded px-3 py-1.5 text-sm font-medium", view === v && "bg-ink text-white")}>{v === "board" ? "Board" : "Table"}</button>)}
          </div>
          <Button onClick={() => setCreating(true)}>Add lead</Button>
        </div>} />
      {view === "board" ? (
        board.loading && !board.data ? <Loading /> : board.error ? <Alert>{board.error}</Alert> : (
          <div className="flex gap-3 overflow-x-auto pb-3">
            {stages.map((st) => (
              <section key={st} aria-label={label(st)} onDragOver={(e) => e.preventDefault()} onDrop={(e) => onDrop(e, st)} className="w-64 shrink-0 rounded-lg bg-line/50 p-2">
                <h2 className="mb-2 flex items-center justify-between px-1 text-lg font-semibold">{label(st)}<span className="text-sm text-muted tabular">{board.data?.columns[st]?.length ?? 0}</span></h2>
                <ul className="space-y-2">
                  {(board.data?.columns[st] ?? []).map((l) => (
                    <li key={l.id} draggable onDragStart={(e) => e.dataTransfer.setData("text/lead", l.id)} className="rounded-md border border-line bg-surface p-2.5">
                      <button onClick={() => router.push(`/app/leads?id=${l.id}`)} className="block w-full text-left">
                        <span className="font-semibold">{l.customer?.name ?? phone(l.customer?.phone)}</span>
                        <span className="block text-[13px] text-muted">{l.service ?? "Request"}</span>
                        {l.appointment && <span className="block text-[12px] text-ink-2">Appt {when(l.appointment.start_at)}</span>}
                        <span className="mt-1 flex flex-wrap gap-1">{l.is_qualified && <Badge tone="go">Qualified</Badge>}{l.urgency === "emergency" && <Badge tone="stop">Emergency</Badge>}<Badge>{label(l.source)}</Badge></span>
                      </button>
                      <label className="sr-only" htmlFor={`mv-${l.id}`}>Move {l.customer?.name}</label>
                      <select id={`mv-${l.id}`} value={l.status} onChange={(e) => void move(l.id, e.target.value)} className="mt-2 h-8 w-full rounded border border-line bg-surface px-1 text-[13px]">
                        {stages.map((s) => <option key={s} value={s}>{label(s)}</option>)}
                      </select>
                    </li>
                  ))}
                </ul>
              </section>
            ))}
          </div>
        )
      ) : (
        <>
          <div className="mb-3 flex flex-wrap gap-2">
            <label htmlFor="lq" className="sr-only">Search</label>
            <input id="lq" type="search" value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} placeholder="Search name, phone, service" className="h-9 min-w-56 flex-1 rounded-md border border-line bg-surface px-3 text-sm" />
            <label htmlFor="ls" className="sr-only">Status</label>
            <select id="ls" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }} className="h-9 rounded-md border border-line bg-surface px-2 text-sm">
              <option value="">All stages</option>{stages.map((s) => <option key={s} value={s}>{label(s)}</option>)}
            </select>
          </div>
          {table.loading && !table.data ? <Loading /> : table.error ? <Alert>{table.error}</Alert> : table.data?.items.length === 0 ? <Empty title="No leads match">Try a different search or stage.</Empty> : (
            <div className="overflow-x-auto rounded-lg border border-line bg-surface">
              <table className="w-full text-left text-[14px]">
                <thead className="border-b border-line text-[13px] text-muted"><tr>{["Customer", "Service", "Stage", "Source", "Appointment", "Est. value", "Created"].map((h) => <th key={h} scope="col" className="px-3 py-2 font-semibold">{h}</th>)}</tr></thead>
                <tbody className="divide-y divide-line">
                  {table.data?.items.map((l) => (
                    <tr key={l.id} className="hover:bg-canvas">
                      <td className="px-3 py-2"><Link className="font-semibold text-link underline" href={`/app/leads?id=${l.id}`}>{l.customer?.name ?? phone(l.customer?.phone)}</Link></td>
                      <td className="px-3 py-2">{l.service ?? "—"}</td>
                      <td className="px-3 py-2"><Badge tone={statusTone(l.status)}>{label(l.status)}</Badge></td>
                      <td className="px-3 py-2">{label(l.source)}</td>
                      <td className="px-3 py-2 tabular">{l.appointment ? when(l.appointment.start_at) : "—"}</td>
                      <td className="px-3 py-2 tabular">{money(l.estimated_value_cents)}</td>
                      <td className="px-3 py-2 text-muted">{ago(l.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {table.data && <Pager page={page} total={table.data.total} pageSize={table.data.page_size} onPage={setPage} />}
        </>
      )}
      <Modal open={!!openId} onClose={() => router.push("/app/leads")} title="Lead" wide>
        {openId && <LeadDetail id={openId} stages={stages} onChanged={() => { void board.reload(); void table.reload(); }} />}
      </Modal>
      <Modal open={creating} onClose={() => setCreating(false)} title="Add a lead">
        <CreateLead onDone={() => { setCreating(false); void board.reload(); void table.reload(); }} />
      </Modal>
    </>
  );
}

interface LeadFull extends Lead { appointments: Appointment[]; tasks: Task[]; stages: string[] }

function LeadDetail({ id, stages, onChanged }: { id: string; stages: string[]; onChanged: () => void }) {
  const { data, error, loading, reload } = useLoad(() => get<LeadFull>(`/leads/${id}`), [id]);
  const team = useLoad(() => get<{ members: { user_id: string; name: string }[] }>("/team"), []);
  const { run, pending } = useAction();
  const { can } = useAuth();
  const [vals, setVals] = useState<{ est: string; rev: string; summary: string } | null>(null);
  if (loading && !data) return <Loading />;
  if (error || !data) return <Alert>{error}</Alert>;
  const v = vals ?? { est: data.estimated_value_cents ? String(data.estimated_value_cents / 100) : "", rev: data.actual_revenue_cents ? String(data.actual_revenue_cents / 100) : "", summary: data.summary ?? "" };
  const save = async (body: Record<string, unknown>, msg: string) => {
    const r = await run("save", () => patch(`/leads/${id}`, body), msg);
    if (r) { await reload(); onChanged(); setVals(null); }
  };
  const qual = Object.entries(data.qualification).filter(([k]) => !k.startsWith("_"));
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-2xl font-semibold">{data.customer?.name ?? "Unknown"}</h3>
          <p className="text-muted">{data.service} · {label(data.source)} · {ago(data.created_at)}</p>
          {data.customer?.phone && <a className="font-semibold text-link underline" href={`tel:${data.customer.phone}`}>Call {phone(data.customer.phone)}</a>}
        </div>
        <Select label="Stage" value={data.status} disabled={!can("leads")} onChange={(e) => void save({ status: e.target.value }, `Moved to ${label(e.target.value)}`)}>
          {stages.map((s) => <option key={s} value={s}>{label(s)}</option>)}
        </Select>
      </div>
      {qual.length > 0 && (
        <dl className="grid grid-cols-2 gap-x-6 gap-y-1 rounded-md bg-canvas p-3 text-[14px] sm:grid-cols-3">
          {qual.map(([k, val]) => <div key={k}><dt className="text-muted">{label(k)}</dt><dd className="font-medium">{label(String(val))}</dd></div>)}
        </dl>
      )}
      <div className="grid gap-3 sm:grid-cols-3">
        <Select label="Assigned to" value={data.assigned_user_id ?? ""} onChange={(e) => void save(e.target.value ? { assigned_user_id: e.target.value } : { unassign: true }, "Assignment updated")}>
          <option value="">Unassigned</option>{team.data?.members.map((m) => <option key={m.user_id} value={m.user_id}>{m.name}</option>)}
        </Select>
        <Input label="Estimated value ($)" inputMode="decimal" value={v.est} onChange={(e) => setVals({ ...v, est: e.target.value })} />
        <Input label="Actual revenue ($)" hint="Only enter money you actually received." inputMode="decimal" value={v.rev} onChange={(e) => setVals({ ...v, rev: e.target.value })} />
      </div>
      <Textarea label="Notes" value={v.summary} onChange={(e) => setVals({ ...v, summary: e.target.value })} />
      <Button loading={pending === "save"} disabled={!vals} onClick={() => void save({
        estimated_value_cents: v.est ? Math.round(parseFloat(v.est) * 100) : undefined,
        actual_revenue_cents: v.rev ? Math.round(parseFloat(v.rev) * 100) : undefined, summary: v.summary }, "Lead saved")}>Save changes</Button>
      <section>
        <h4 className="font-semibold">Appointments</h4>
        {data.appointments.length === 0 ? <p className="text-muted">None yet. <Link className="text-link underline" href={`/app/appointments?customer=${data.customer?.id}&lead=${data.id}`}>Book one</Link></p> :
          <ul>{data.appointments.map((a) => <li key={a.id}>{when(a.start_at)} — {a.service} <Badge tone={statusTone(a.status)}>{label(a.status)}</Badge></li>)}</ul>}
      </section>
      {data.conversation_id && <Link className="text-link underline" href={`/app/inbox?id=${data.conversation_id}`}>Open conversation</Link>}
    </div>
  );
}

function CreateLead({ onDone }: { onDone: () => void }) {
  const [f, setF] = useState({ name: "", phone: "", email: "", service: "", notes: "" });
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const r = await run("c", () => post("/leads", { name: f.name, phone: f.phone || null, email: f.email || null, service: f.service || null, notes: f.notes || null }), "Lead added");
    if (r) onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <Input label="Name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <Input label="Phone" type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
      <Input label="Email" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
      <Input label="Service" value={f.service} onChange={(e) => setF({ ...f, service: e.target.value })} />
      <Textarea label="Notes" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} />
      <Button type="submit" loading={pending === "c"}>Add lead</Button>
    </form>
  );
}
