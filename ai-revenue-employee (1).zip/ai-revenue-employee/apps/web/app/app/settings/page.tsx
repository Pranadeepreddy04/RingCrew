"use client";

import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

import { HoursEditor, ZipInput, type Hours } from "@/components/business-forms";
import { Alert, Button, Checkbox, Input, Loading, PageHeader, Panel, Select, Textarea } from "@/components/ui";
import { del, get, label, patch, post, put } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";
import type { Org } from "@/lib/types";

const NOTIFY = [["lead.created", "New lead"], ["lead.qualified", "Qualified lead"], ["appointment.created", "Appointment booked"], ["appointment.cancelled", "Appointment cancelled"],
  ["handoff.required", "Human help needed"], ["workflow.failed", "Follow-up failed"], ["integration.disconnected", "Connection problem"]];

export default function SettingsPage() {
  const { can } = useAuth();
  const org = useLoad(() => get<Org>("/organizations/current"), []);
  if (org.loading && !org.data) return <Loading />;
  if (!org.data) return <Alert>{org.error}</Alert>;
  const owner = can("billing");
  return (
    <>
      <PageHeader title="Settings" />
      <div className="space-y-5">
        {owner && <Profile org={org.data} onSaved={() => void org.reload()} />}
        {owner && <Services org={org.data} onSaved={() => void org.reload()} />}
        {owner && <OrgSettings org={org.data} onSaved={() => void org.reload()} />}
        <Account />
        {owner && <Privacy org={org.data} />}
      </div>
    </>
  );
}

function Profile({ org, onSaved }: { org: Org; onSaved: () => void }) {
  const p = org.profile!;
  const [f, setF] = useState({ description: p.description ?? "", phone: p.phone ?? "", website: p.website ?? "", address: p.address ?? "", service_area_description: p.service_area_description ?? "",
    emergency_instructions: p.emergency_instructions ?? "", escalation_rules: p.escalation_rules ?? "", escalation_phone: p.escalation_phone ?? "", pricing_info: p.pricing_info ?? "",
    policies: p.policies ?? "", appointment_duration_minutes: p.appointment_duration_minutes, booking_lead_time_hours: p.booking_lead_time_hours, booking_horizon_days: p.booking_horizon_days });
  const [hours, setHours] = useState<Hours>(p.hours);
  const [zips, setZips] = useState<string[]>(p.service_area_zips);
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const body = { ...Object.fromEntries(Object.entries(f).map(([k, v]) => [k, v === "" ? null : v])), hours, service_area_zips: zips };
    if (await run("p", () => put("/organizations/current/profile", body), "Business profile saved")) onSaved();
  };
  return (
    <Panel title="Business profile">
      <form onSubmit={submit} className="space-y-4">
        <Textarea label="About the business" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        <div className="grid gap-3 sm:grid-cols-3">
          <Input label="Phone" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
          <Input label="Website" value={f.website} onChange={(e) => setF({ ...f, website: e.target.value })} />
          <Input label="Address" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
        </div>
        <ZipInput value={zips} onChange={setZips} />
        <Textarea label="Service area description" value={f.service_area_description} onChange={(e) => setF({ ...f, service_area_description: e.target.value })} />
        <HoursEditor value={hours} onChange={setHours} />
        <div className="grid gap-3 sm:grid-cols-3">
          <Input label="Appointment length (minutes)" type="number" min={15} max={480} value={f.appointment_duration_minutes} onChange={(e) => setF({ ...f, appointment_duration_minutes: Number(e.target.value) })} />
          <Input label="Minimum notice (hours)" type="number" min={0} max={168} value={f.booking_lead_time_hours} onChange={(e) => setF({ ...f, booking_lead_time_hours: Number(e.target.value) })} />
          <Input label="Book up to (days ahead)" type="number" min={1} max={90} value={f.booking_horizon_days} onChange={(e) => setF({ ...f, booking_horizon_days: Number(e.target.value) })} />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <Textarea label="Emergency instructions" value={f.emergency_instructions} onChange={(e) => setF({ ...f, emergency_instructions: e.target.value })} />
          <Textarea label="Hand-off rules" value={f.escalation_rules} onChange={(e) => setF({ ...f, escalation_rules: e.target.value })} />
          <Input label="Transfer calls to" value={f.escalation_phone} onChange={(e) => setF({ ...f, escalation_phone: e.target.value })} />
          <div />
          <Textarea label="Pricing the AI may share" hint="Leave empty and it never discusses prices." value={f.pricing_info} onChange={(e) => setF({ ...f, pricing_info: e.target.value })} />
          <Textarea label="Policies" value={f.policies} onChange={(e) => setF({ ...f, policies: e.target.value })} />
        </div>
        <Button type="submit" loading={pending === "p"}>Save business profile</Button>
      </form>
    </Panel>
  );
}

function Services({ org, onSaved }: { org: Org; onSaved: () => void }) {
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const { run, pending } = useAction();
  return (
    <Panel title="Services">
      <ul className="mb-3 divide-y divide-line">
        {org.services.map((s) => (
          <li key={s.id} className="flex items-center justify-between gap-2 py-2">
            <span><span className="font-semibold">{s.name}</span>{s.description && <span className="block text-[13px] text-muted">{s.description}</span>}</span>
            <Button size="sm" variant="ghost" onClick={() => void run("d", () => del(`/services/${s.id}`), "Service removed").then(onSaved)}>Remove</Button>
          </li>
        ))}
      </ul>
      <form onSubmit={(e) => { e.preventDefault(); void run("a", () => post("/services", { name, description: desc || null }), "Service added").then((r) => { if (r) { setName(""); setDesc(""); onSaved(); } }); }} className="grid gap-2 sm:grid-cols-[1fr_2fr_auto] sm:items-end">
        <Input label="Service" required value={name} onChange={(e) => setName(e.target.value)} />
        <Input label="Description" value={desc} onChange={(e) => setDesc(e.target.value)} />
        <Button type="submit" loading={pending === "a"}>Add</Button>
      </form>
    </Panel>
  );
}

function OrgSettings({ org, onSaved }: { org: Org; onSaved: () => void }) {
  const zones = useLoad(() => get<string[]>("/timezones"), []);
  const [f, setF] = useState({ name: org.name, timezone: org.timezone, stages: org.pipeline_stages.join(", "), rec_consent: !!org.recording.consent_configured,
    rec: !!org.recording.enabled, fallback: !!org.ai_settings.allow_fallback_provider });
  const [prefs, setPrefs] = useState<Record<string, boolean>>(Object.fromEntries(NOTIFY.map(([k]) => [k!, org.notification_prefs[k!] ?? true])));
  const { run, pending } = useAction();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const body = { name: f.name, timezone: f.timezone, pipeline_stages: f.stages.split(",").map((s) => s.trim()).filter(Boolean),
      recording_consent_configured: f.rec_consent, recording_enabled: f.rec, allow_fallback_provider: f.fallback, notification_prefs: prefs };
    if (await run("o", () => patch("/organizations/current", body), "Settings saved")) onSaved();
  };
  return (
    <Panel title="Business settings">
      <form onSubmit={submit} className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <Input label="Business name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
          <Select label="Time zone" value={f.timezone} onChange={(e) => setF({ ...f, timezone: e.target.value })}>{(zones.data ?? [f.timezone]).map((z) => <option key={z}>{z}</option>)}</Select>
        </div>
        <Input label="Lead pipeline stages" hint="Comma separated, in order. Must include won and lost." value={f.stages} onChange={(e) => setF({ ...f, stages: e.target.value })} />
        <fieldset className="space-y-2">
          <legend className="text-[13px] font-semibold text-ink-2">Call recording</legend>
          <Checkbox label="I have configured the recording disclosures required where my callers are located" hint="Some states require every party's consent. Check with your attorney." checked={f.rec_consent} onChange={(v) => setF({ ...f, rec_consent: v, rec: v && f.rec })} />
          <Checkbox label="Record calls (callers are told the call is recorded)" checked={f.rec} disabled={!f.rec_consent} onChange={(v) => setF({ ...f, rec: v })} />
        </fieldset>
        <Checkbox label="Allow a backup AI provider during outages" hint="Off by default. When on, customer messages may be processed by the configured secondary AI provider if the primary is unavailable." checked={f.fallback} onChange={(v) => setF({ ...f, fallback: v })} />
        <fieldset>
          <legend className="mb-1 text-[13px] font-semibold text-ink-2">Email me when</legend>
          <div className="grid gap-2 sm:grid-cols-2">{NOTIFY.map(([k, l]) => <Checkbox key={k} label={l!} checked={!!prefs[k!]} onChange={(v) => setPrefs({ ...prefs, [k!]: v })} />)}</div>
        </fieldset>
        <Button type="submit" loading={pending === "o"}>Save settings</Button>
      </form>
    </Panel>
  );
}

function Account() {
  const [f, setF] = useState({ current_password: "", new_password: "" });
  const { run, pending } = useAction();
  const { me } = useAuth();
  return (
    <Panel title="Your account">
      <p className="mb-3 text-muted">{me?.user.name} · {me?.user.email}{me && !me.user.email_verified && <> · <button className="text-link underline" onClick={() => void run("v", () => post("/auth/resend-verification"), "Verification email sent")}>Verify email</button></>}</p>
      <form onSubmit={(e) => { e.preventDefault(); void run("pw", () => post("/auth/password/change", f), "Password changed; other sessions were signed out").then((r) => r && setF({ current_password: "", new_password: "" })); }} className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
        <Input label="Current password" type="password" autoComplete="current-password" required value={f.current_password} onChange={(e) => setF({ ...f, current_password: e.target.value })} />
        <Input label="New password" type="password" autoComplete="new-password" required minLength={10} value={f.new_password} onChange={(e) => setF({ ...f, new_password: e.target.value })} />
        <Button type="submit" loading={pending === "pw"}>Change password</Button>
      </form>
    </Panel>
  );
}

function Privacy({ org }: { org: Org }) {
  const { refresh } = useAuth();
  const router = useRouter();
  const { run, pending } = useAction();
  const [confirm, setConfirm] = useState("");
  const exportData = async () => {
    const data = await run("x", () => get<unknown>("/organizations/current/export"));
    if (!data) return;
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${org.name.replace(/\W+/g, "-").toLowerCase()}-export.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  return (
    <Panel title="Data and privacy">
      <Button variant="secondary" loading={pending === "x"} onClick={() => void exportData()}>Download all data (JSON)</Button>
      <div className="mt-5 rounded-md border border-stop p-4">
        <h3 className="font-semibold text-stop">Delete this business</h3>
        <p className="text-[14px] text-muted">AI employees stop immediately. All data is permanently erased after 30 days.</p>
        <div className="mt-2 flex flex-wrap items-end gap-2">
          <Input label={`Type "${org.name}" to confirm`} value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          <Button variant="danger" disabled={confirm !== org.name} loading={pending === "del"} onClick={() => void run("del", () => del("/organizations/current", { confirm_name: confirm }), "Business deleted").then(async (r) => { if (r) { await refresh(); router.replace("/onboarding"); } })}>Delete business</Button>
        </div>
      </div>
      <p className="mt-3 text-[13px] text-muted">Customer deletion requests: open the customer and choose {label("delete_data")}.</p>
    </Panel>
  );
}
