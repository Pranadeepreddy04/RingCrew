"use client";

import { useState, type FormEvent } from "react";

import { Alert, Badge, Button, Input, Loading, PageHeader, Panel, Select } from "@/components/ui";
import { del, get, label, patch, post } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";

interface Team { members: { id: string; name: string; email: string; role: string; is_you: boolean; is_active: boolean }[]; invitations: { id: string; email: string; role: string; expires_at: string }[] }

const ROLE_HELP: Record<string, string> = {
  owner: "Everything, including billing, team and connections", manager: "AI setup, knowledge, leads, conversations and reports",
  staff: "Leads, customers, appointments and conversations", readonly: "Analytics only",
};

export default function TeamPage() {
  const { can } = useAuth();
  const team = useLoad(() => get<Team>("/team"), []);
  const [f, setF] = useState({ email: "", role: "staff" });
  const [link, setLink] = useState<string | null>(null);
  const { run, pending } = useAction();
  const manage = can("team");
  const invite = async (e: FormEvent) => {
    e.preventDefault();
    const r = await run("i", () => post<{ dev_accept_link?: string }>("/team/invitations", f), `Invitation sent to ${f.email}`);
    if (r) { setLink(r.dev_accept_link ?? null); setF({ email: "", role: "staff" }); void team.reload(); }
  };
  if (team.loading && !team.data) return <Loading />;
  if (!team.data) return <Alert>{team.error}</Alert>;
  return (
    <>
      <PageHeader title="Team" />
      <div className="grid gap-5 lg:grid-cols-[1fr_360px]">
        <Panel title="People" padded={false}>
          <ul className="divide-y divide-line">
            {team.data.members.map((m) => (
              <li key={m.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3">
                <span><span className="font-semibold">{m.name}{m.is_you && " (you)"}</span><span className="block text-[13px] text-muted">{m.email}</span></span>
                {manage && !m.is_you ? (
                  <span className="flex items-end gap-2">
                    <Select label="Role" value={m.role} onChange={(e) => void run("r", () => patch(`/team/members/${m.id}`, { role: e.target.value }), "Role updated").then(() => team.reload())}>
                      {Object.keys(ROLE_HELP).map((r) => <option key={r} value={r}>{label(r)}</option>)}
                    </Select>
                    <Button size="sm" variant="ghost" onClick={() => { if (window.confirm(`Remove ${m.name}?`)) void run("x", () => del(`/team/members/${m.id}`), "Removed").then(() => team.reload()); }}>Remove</Button>
                  </span>
                ) : <Badge>{label(m.role)}</Badge>}
              </li>
            ))}
            {team.data.invitations.map((i) => (
              <li key={i.id} className="flex items-center justify-between gap-3 px-4 py-3 text-muted">
                <span>{i.email} · invited as {label(i.role)}</span>
                <Button size="sm" variant="ghost" onClick={() => void run("v", () => del(`/team/invitations/${i.id}`), "Invitation cancelled").then(() => team.reload())}>Cancel invite</Button>
              </li>
            ))}
          </ul>
        </Panel>
        {manage && (
          <Panel title="Invite someone">
            <form onSubmit={invite} className="space-y-3">
              <Input label="Email" type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} />
              <Select label="Role" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })} hint={ROLE_HELP[f.role]}>
                {["manager", "staff", "readonly"].map((r) => <option key={r} value={r}>{label(r)}</option>)}
              </Select>
              <Button type="submit" loading={pending === "i"}>Send invitation</Button>
              {link && <Alert tone="live">Development mode: emails aren&apos;t sent. Share this link: <code className="break-all">{link}</code></Alert>}
            </form>
          </Panel>
        )}
      </div>
    </>
  );
}
