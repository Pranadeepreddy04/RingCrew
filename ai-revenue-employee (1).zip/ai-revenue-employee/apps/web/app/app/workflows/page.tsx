"use client";

import { useState, type FormEvent } from "react";

import { Alert, Badge, Button, Checkbox, Input, Loading, Modal, PageHeader, Select, Textarea, statusTone } from "@/components/ui";
import { del, get, label, post, put, when } from "@/lib/api";
import { useAuth } from "@/lib/auth";
import { useAction, useLoad } from "@/lib/hooks";

interface Step { delay_minutes?: number; before_appointment_minutes?: number; channel: string; template: string }
interface Workflow { id: string; name: string; trigger: string; steps: Step[]; stop_conditions: string[]; quiet_hours: { start?: string; end?: string }; max_attempts: number; active: boolean; stats: Record<string, number> }
interface WfList { items: Workflow[]; triggers: string[]; stop_conditions: string[]; template_variables: string[]; sms_enabled_on_plan: boolean }

const TRIGGER_TEXT: Record<string, string> = { "lead.created": "When a new lead comes in", "appointment.created": "When an appointment is booked", "appointment.completed": "When an appointment is completed" };
const STOP_TEXT: Record<string, string> = { appointment_booked: "Customer books an appointment", customer_replied: "Customer replies", opted_out: "Customer opts out", lead_closed: "Lead is won or lost", human_takeover: "Staff takes over", appointment_cancelled: "Appointment is cancelled" };

export default function WorkflowsPage() {
  const { can } = useAuth();
  const list = useLoad(() => get<WfList>("/workflows"), []);
  const [edit, setEdit] = useState<Workflow | "new" | null>(null);
  const [runsFor, setRunsFor] = useState<Workflow | null>(null);
  const { run } = useAction();
  const editable = can("configure");
  return (
    <>
      <PageHeader title="Follow-ups" description="Automatic texts your AI employee sends, using only the wording you approve. They respect quiet hours and stop the moment a customer books, replies or opts out."
        action={editable && <Button onClick={() => setEdit("new")}>New follow-up</Button>} />
      {list.data && !list.data.sms_enabled_on_plan && <div className="mb-4"><Alert tone="wait">Your plan doesn&apos;t include text messages, so follow-ups won&apos;t send. Upgrade in Billing.</Alert></div>}
      {list.loading && !list.data ? <Loading /> : list.error ? <Alert>{list.error}</Alert> : (
        <div className="space-y-3">
          {list.data?.items.map((w) => (
            <article key={w.id} className="rounded-lg border border-line bg-surface p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-xl font-semibold">{w.name}</h2>
                  <p className="text-muted">{TRIGGER_TEXT[w.trigger] ?? w.trigger} · {w.steps.length} message(s) · quiet hours {w.quiet_hours.start ? `${w.quiet_hours.start}–${w.quiet_hours.end}` : "off"}</p>
                  <p className="mt-1 flex flex-wrap gap-1.5 text-[13px]">{Object.entries(w.stats).map(([k, n]) => <Badge key={k} tone={statusTone(k)}>{n} {label(k)}</Badge>)}</p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  {editable && <Checkbox label="On" checked={w.active} onChange={(v) => void run("t", () => put(`/workflows/${w.id}`, { ...w, active: v }), v ? "Turned on" : "Turned off").then(() => list.reload())} />}
                  <Button size="sm" variant="secondary" onClick={() => setRunsFor(w)}>Activity</Button>
                  {editable && <Button size="sm" variant="secondary" onClick={() => setEdit(w)}>Edit</Button>}
                  {editable && <Button size="sm" variant="ghost" onClick={() => { if (window.confirm(`Delete "${w.name}"?`)) void run("d", () => del(`/workflows/${w.id}`), "Deleted").then(() => list.reload()); }}>Delete</Button>}
                </div>
              </div>
              <ol className="mt-3 space-y-1.5">
                {w.steps.map((s, i) => (
                  <li key={i} className="rounded-md bg-canvas p-2 text-[14px]">
                    <span className="font-semibold">{s.before_appointment_minutes != null ? `${Math.round(s.before_appointment_minutes / 60)}h before the appointment` : `After ${s.delay_minutes! >= 60 ? `${Math.round(s.delay_minutes! / 60)}h` : `${s.delay_minutes}m`}`}:</span> {s.template}
                  </li>
                ))}
              </ol>
            </article>
          ))}
        </div>
      )}
      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit === "new" ? "New follow-up" : "Edit follow-up"} wide>
        {edit && list.data && <WorkflowForm wf={edit === "new" ? null : edit} meta={list.data} onDone={() => { setEdit(null); void list.reload(); }} />}
      </Modal>
      <Modal open={!!runsFor} onClose={() => setRunsFor(null)} title={`Activity — ${runsFor?.name ?? ""}`} wide>
        {runsFor && <Runs id={runsFor.id} editable={editable} />}
      </Modal>
    </>
  );
}

function WorkflowForm({ wf, meta, onDone }: { wf: Workflow | null; meta: WfList; onDone: () => void }) {
  const [f, setF] = useState({ name: wf?.name ?? "", trigger: wf?.trigger ?? "lead.created", max_attempts: wf?.max_attempts ?? 2, active: wf?.active ?? true,
    stop_conditions: wf?.stop_conditions ?? ["appointment_booked", "customer_replied", "opted_out"], quiet: !!wf?.quiet_hours.start, qs: wf?.quiet_hours.start ?? "20:00", qe: wf?.quiet_hours.end ?? "08:00" });
  const [steps, setSteps] = useState<Step[]>(wf?.steps ?? [{ delay_minutes: 60, channel: "sms", template: "Hi {first_name}, this is {agent_name} with {business_name}. Reply STOP to opt out." }]);
  const { run, pending } = useAction();
  const beforeAppt = f.trigger === "appointment.created";
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const body = { name: f.name, trigger: f.trigger, steps, stop_conditions: f.stop_conditions, max_attempts: f.max_attempts, active: f.active, quiet_hours: f.quiet ? { start: f.qs, end: f.qe } : {} };
    const r = await run("s", () => (wf ? put(`/workflows/${wf.id}`, body) : post("/workflows", body)), "Follow-up saved");
    if (r) onDone();
  };
  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2">
        <Input label="Name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Select label="Start" value={f.trigger} onChange={(e) => setF({ ...f, trigger: e.target.value })}>{meta.triggers.map((t) => <option key={t} value={t}>{TRIGGER_TEXT[t] ?? t}</option>)}</Select>
      </div>
      <fieldset>
        <legend className="mb-1 text-[13px] font-semibold text-ink-2">Messages</legend>
        <p className="mb-2 text-[13px] text-muted">Variables: {meta.template_variables.map((v) => `{${v}}`).join(" ")}. Always include &ldquo;Reply STOP to opt out&rdquo;.</p>
        <div className="space-y-3">
          {steps.map((s, i) => (
            <div key={i} className="rounded-md border border-line p-3">
              {beforeAppt ? (
                <Input label="Hours before the appointment" type="number" min={1} value={Math.round((s.before_appointment_minutes ?? 1440) / 60)} onChange={(e) => setSteps(steps.map((x, j) => (j === i ? { channel: "sms", template: x.template, before_appointment_minutes: Number(e.target.value) * 60 } : x)))} />
              ) : (
                <Input label={i === 0 ? "Wait before sending (minutes)" : "Wait after previous message (minutes)"} type="number" min={0} value={s.delay_minutes ?? 60} onChange={(e) => setSteps(steps.map((x, j) => (j === i ? { channel: "sms", template: x.template, delay_minutes: Number(e.target.value) } : x)))} />
              )}
              <Textarea className="mt-2" label="Text message" maxLength={640} value={s.template} onChange={(e) => setSteps(steps.map((x, j) => (j === i ? { ...x, template: e.target.value } : x)))} />
              {steps.length > 1 && <Button type="button" size="sm" variant="ghost" onClick={() => setSteps(steps.filter((_, j) => j !== i))}>Remove message</Button>}
            </div>
          ))}
          <Button type="button" size="sm" variant="secondary" onClick={() => setSteps([...steps, beforeAppt ? { before_appointment_minutes: 120, channel: "sms", template: "" } : { delay_minutes: 1440, channel: "sms", template: "" }])}>Add message</Button>
        </div>
      </fieldset>
      <fieldset>
        <legend className="mb-1 text-[13px] font-semibold text-ink-2">Stop when</legend>
        <div className="grid gap-2 sm:grid-cols-2">
          {meta.stop_conditions.map((c) => <Checkbox key={c} label={STOP_TEXT[c] ?? c} checked={f.stop_conditions.includes(c)} disabled={c === "opted_out"}
            onChange={(v) => setF({ ...f, stop_conditions: v ? [...f.stop_conditions, c] : f.stop_conditions.filter((x) => x !== c) })} />)}
        </div>
      </fieldset>
      <div className="grid gap-3 sm:grid-cols-3">
        <Checkbox label="Quiet hours" hint="No texts between these times" checked={f.quiet} onChange={(v) => setF({ ...f, quiet: v })} />
        {f.quiet && <><Input label="From" type="time" value={f.qs} onChange={(e) => setF({ ...f, qs: e.target.value })} /><Input label="Until" type="time" value={f.qe} onChange={(e) => setF({ ...f, qe: e.target.value })} /></>}
      </div>
      <Input label="Maximum messages per customer" type="number" min={1} max={10} value={f.max_attempts} onChange={(e) => setF({ ...f, max_attempts: Number(e.target.value) })} />
      <Button type="submit" loading={pending === "s"}>Save follow-up</Button>
    </form>
  );
}

function Runs({ id, editable }: { id: string; editable: boolean }) {
  const runs = useLoad(() => get<{ id: string; customer: string; status: string; step_index: number; next_run_at: string | null; stop_reason: string | null; last_error: string | null }[]>(`/workflows/${id}/runs`), [id]);
  const { run } = useAction();
  if (runs.loading && !runs.data) return <Loading />;
  if (!runs.data?.length) return <p className="text-muted">No activity yet.</p>;
  return (
    <table className="w-full text-left text-[14px]">
      <thead className="text-[13px] text-muted"><tr><th className="py-1">Customer</th><th>Status</th><th>Sent</th><th>Next</th><th /></tr></thead>
      <tbody className="divide-y divide-line">
        {runs.data.map((r) => (
          <tr key={r.id}>
            <td className="py-2">{r.customer}</td>
            <td><Badge tone={statusTone(r.status)}>{label(r.status)}</Badge>{r.stop_reason && <span className="ml-1 text-muted">{label(r.stop_reason)}</span>}{r.last_error && <span className="block text-[12px] text-stop">{r.last_error}</span>}</td>
            <td className="tabular">{r.step_index}</td>
            <td className="tabular">{r.next_run_at ? when(r.next_run_at) : "—"}</td>
            <td>{editable && r.status === "active" && <Button size="sm" variant="ghost" onClick={() => void run("x", () => post(`/workflows/runs/${r.id}/stop`), "Stopped").then(() => runs.reload())}>Stop</Button>}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
