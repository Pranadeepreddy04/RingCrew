import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";

import { AuthProvider } from "@/lib/auth";
import { ToastProvider } from "@/lib/hooks";

import "./globals.css";

export const metadata: Metadata = {
  title: { default: "AI Revenue Employee", template: "%s · AI Revenue Employee" },
  description: "Your AI employee answers calls and messages, captures leads, books appointments and follows up 24/7.",
  manifest: "/manifest.webmanifest",
};

export const viewport: Viewport = { themeColor: "#102a43", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded focus:bg-hivis focus:px-3 focus:py-2">
          Skip to content
        </a>
        <AuthProvider>
          <ToastProvider>{children}</ToastProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
