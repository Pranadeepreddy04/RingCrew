"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState, type FormEvent } from "react";

import { CAPABILITY_LABELS, FaqEditor, HoursEditor, ZipInput, type Faq, type Hours } from "@/components/business-forms";
import { Logo } from "@/components/site-chrome";
import { TestConsole } from "@/components/test-console";
import { Alert, Badge, Button, Checkbox, Input, Loading, Select, Textarea } from "@/components/ui";
import { errorText, get, patch, post, put, setOrgId } from "@/lib/api";
import { useRequireAuth } from "@/lib/auth";
import type { Agent, Org } from "@/lib/types";

const STEPS = ["Account", "Business", "Business info", "Tasks", "Personality", "Connections", "Knowledge", "Test", "Activate"];

export default function OnboardingPage() {
  return <Suspense><Onboarding /></Suspense>;
}

function Onboarding() {
  const auth = useRequireAuth({ needOrg: false });
  const [stepState, setStep] = useState<number | null>(null);
  const [org, setOrg] = useState<Org | null>(null);
  const [agent, setAgent] = useState<Agent | null>(null);

  const loadOrg = async () => {
    const o = await get<Org>("/organizations/current");
    setOrg(o);
    const agents = await get<Agent[]>("/agents");
    setAgent(agents[0] ?? null);
    return o;
  };

  const hasOrg = !!auth.me?.organizations.length;
  useEffect(() => {
    if (auth.loading || !hasOrg) return;
    Promise.all([get<Org>("/organizations/current"), get<Agent[]>("/agents")])
      .then(([o, agents]) => {
        setOrg(o);
        setAgent(agents[0] ?? null);
        setStep((cur) => cur ?? (o.onboarding_completed ? 9 : Math.max(3, Math.min(o.onboarding_step, 9))));
      })
      .catch(() => setStep((cur) => cur ?? 3));
  }, [auth.loading, hasOrg]);
  // A signed-in user without a business starts at step 2; otherwise wait until progress loads.
  const step = stepState ?? (!auth.loading && auth.me && !hasOrg ? 2 : null);

  const go = async (n: number) => {
    if (org) await post("/organizations/current/onboarding", { step: n }).catch(() => undefined);
    setStep(n);
    window.scrollTo({ top: 0 });
  };

  if (step === null) return <Loading />;
  return (
    <div className="min-h-screen">
      <header className="border-b border-line bg-surface">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <Logo />
          {org && <Link href="/app/dashboard" className="text-sm text-link underline">Finish later</Link>}
        </div>
      </header>
      <main id="main" className="mx-auto max-w-5xl px-4 py-8">
        <ol aria-label="Setup progress" className="mb-8 flex flex-wrap gap-x-4 gap-y-2 text-[13px]">
          {STEPS.map((s, i) => (
            <li key={s} aria-current={i + 1 === step ? "step" : undefined} className={i + 1 === step ? "font-bold text-ink" : i + 1 < step ? "text-go" : "text-muted"}>
              {i + 1}. {s}
            </li>
          ))}
        </ol>
        {step === 2 && <BusinessStep onDone={async () => { await auth.refresh(); await loadOrg(); await go(3); }} />}
        {step === 3 && org && <InfoStep org={org} onDone={async () => { await loadOrg(); await go(4); }} />}
        {(step === 4 || step === 5) && org && <AgentStep org={org} agent={agent} step={step} onNext={async (a) => { setAgent(a); await go(step + 1); }} onBack={() => void go(step - 1)} />}
        {step === 6 && <ConnectionsStep onNext={() => void go(7)} onBack={() => void go(5)} />}
        {step === 7 && <KnowledgeStep onNext={() => void go(8)} onBack={() => void go(6)} />}
        {step === 8 && agent && (
          <section>
            <h1 className="text-4xl font-semibold">Test {agent.name}</h1>
            <p className="mt-1 mb-5 max-w-2xl text-muted">Chat like a customer. You&apos;ll see each action it would take. Nothing is booked, texted or saved as a lead while testing.</p>
            <TestConsole agentId={agent.id} agentName={agent.name} />
            <div className="mt-6 flex gap-3"><Button variant="secondary" onClick={() => void go(7)}>Back</Button><Button onClick={() => void go(9)}>Continue to activation</Button></div>
          </section>
        )}
        {step === 9 && agent && <ActivateStep agent={agent} onBack={() => void go(8)} />}
        {(step >= 4 && !agent && step !== 4 && step !== 5) && <Alert>Create your AI employee first. <button className="underline" onClick={() => void go(4)}>Go to step 4</button></Alert>}
      </main>
    </div>
  );
}

function browserTimezone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "America/Chicago";
  } catch {
    return "America/Chicago";
  }
}

function BusinessStep({ onDone }: { onDone: () => Promise<void> }) {
  const params = useSearchParams();
  const [industries, setIndustries] = useState<{ key: string; name: string; status: string; disabled_reason?: string }[]>([]);
  const [zones, setZones] = useState<string[]>([]);
  const [f, setF] = useState(() => ({ name: "", industry: params.get("industry") ?? "roofing", website: "", phone: "", address: "", timezone: browserTimezone(), employees_count: "1-5" }));
  const [zips, setZips] = useState<string[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    void get<typeof industries>("/industries").then(setIndustries);
    void get<string[]>("/timezones").then(setZones);
  }, []);
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const o = await post<{ id: string }>("/organizations", { ...f, website: f.website || null, phone: f.phone || null, address: f.address || null, service_area_zips: zips });
      setOrgId(o.id);
      await onDone();
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };
  return (
    <form onSubmit={submit} className="space-y-5">
      <h1 className="text-4xl font-semibold">Tell us about your business</h1>
      <div className="grid gap-4 sm:grid-cols-2">
        <Input label="Business name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <Select label="Industry" value={f.industry} onChange={(e) => setF({ ...f, industry: e.target.value })}>
          {industries.map((i) => (
            <option key={i.key} value={i.key} disabled={i.status === "disabled"}>{i.name}{i.status === "beta" ? " (beta)" : i.status === "disabled" ? " — not available yet" : ""}</option>
          ))}
        </Select>
        <Input label="Website" placeholder="yourbusiness.com" value={f.website} onChange={(e) => setF({ ...f, website: e.target.value })} />
        <Input label="Business phone" type="tel" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        <Input className="sm:col-span-2" label="Address" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
        <Select label="Time zone" value={f.timezone} onChange={(e) => setF({ ...f, timezone: e.target.value })}>
          {(zones.length ? zones : [f.timezone]).map((z) => <option key={z}>{z}</option>)}
        </Select>
        <Select label="Number of employees" value={f.employees_count} onChange={(e) => setF({ ...f, employees_count: e.target.value })}>
          {["1-5", "6-20", "21-50", "51-200", "200+"].map((x) => <option key={x}>{x}</option>)}
        </Select>
        <div className="sm:col-span-2"><ZipInput value={zips} onChange={setZips} /></div>
      </div>
      {err && <Alert>{err}</Alert>}
      <Button type="submit" loading={busy}>Continue</Button>
    </form>
  );
}

function InfoStep({ org, onDone }: { org: Org; onDone: () => Promise<void> }) {
  const p = org.profile;
  const [f, setF] = useState({
    description: p?.description ?? "", emergency_instructions: p?.emergency_instructions ?? "", escalation_rules: p?.escalation_rules ?? "",
    escalation_phone: p?.escalation_phone ?? "", pricing_info: p?.pricing_info ?? "", policies: p?.policies ?? "",
  });
  const [hours, setHours] = useState<Hours>(p?.hours ?? {});
  const [services, setServices] = useState<string[]>(org.services.map((s) => s.name));
  const [newService, setNewService] = useState("");
  const [importUrl, setImportUrl] = useState(p?.website ?? "");
  const [consent, setConsent] = useState(false);
  const [importMsg, setImportMsg] = useState<{ tone: "go" | "stop"; text: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const runImport = async () => {
    setBusy("import");
    setImportMsg(null);
    try {
      const r = await post<{ description: string; sources: { title: string }[] }>("/organizations/current/import-website", { url: importUrl, confirm: consent });
      if (r.description && !f.description) setF((x) => ({ ...x, description: r.description }));
      setImportMsg({ tone: "go", text: `Imported ${r.sources.length} page(s). Review them later under Knowledge.` });
    } catch (e) {
      setImportMsg({ tone: "stop", text: errorText(e) });
    } finally {
      setBusy(null);
    }
  };

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setBusy("save");
    setErr(null);
    try {
      await put("/organizations/current/profile", { ...Object.fromEntries(Object.entries(f).map(([k, v]) => [k, v || null])), hours });
      const existing = new Set(org.services.map((s) => s.name));
      for (const s of services.filter((x) => !existing.has(x))) await post("/services", { name: s });
      await onDone();
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(null);
    }
  };

  return (
    <form onSubmit={save} className="space-y-6">
      <h1 className="text-4xl font-semibold">Business information</h1>
      <section className="rounded-lg border border-line bg-surface p-4">
        <h2 className="text-xl font-semibold">Import from your website</h2>
        <p className="text-muted">We&apos;ll read your public pages (home, services, FAQ, about) so your AI employee can answer questions. You can edit everything afterwards.</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
          <Input label="Website address" value={importUrl} onChange={(e) => setImportUrl(e.target.value)} placeholder="https://yourbusiness.com" />
          <Button type="button" variant="secondary" loading={busy === "import"} disabled={!consent || !importUrl} onClick={() => void runImport()}>Import</Button>
        </div>
        <div className="mt-2"><Checkbox label="Yes, read my public website" checked={consent} onChange={setConsent} /></div>
        {importMsg && <div className="mt-2"><Alert tone={importMsg.tone}>{importMsg.text}</Alert></div>}
      </section>
      <Textarea label="What does your business do?" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
      <div>
        <p className="mb-1 text-[13px] font-semibold text-ink-2">Services you offer</p>
        <div className="flex flex-wrap gap-2">
          {services.map((s) => (
            <span key={s} className="inline-flex items-center gap-1 rounded-full border border-line bg-surface px-3 py-1 text-sm">
              {s}
              {!org.services.some((x) => x.name === s) && <button type="button" aria-label={`Remove ${s}`} onClick={() => setServices(services.filter((x) => x !== s))} className="text-muted">×</button>}
            </span>
          ))}
        </div>
        <div className="mt-2 flex gap-2">
          <label htmlFor="svc" className="sr-only">New service</label>
          <input id="svc" value={newService} onChange={(e) => setNewService(e.target.value)} placeholder="e.g. Roof repair" className="h-10 flex-1 rounded-md border border-line px-3" />
          <Button type="button" variant="secondary" onClick={() => { if (newService.trim() && !services.includes(newService.trim())) setServices([...services, newService.trim()]); setNewService(""); }}>Add</Button>
        </div>
      </div>
      <HoursEditor value={hours} onChange={setHours} />
      <div className="grid gap-4 sm:grid-cols-2">
        <Textarea label="Emergency instructions" hint="Read to customers who report an emergency." value={f.emergency_instructions} onChange={(e) => setF({ ...f, emergency_instructions: e.target.value })} />
        <Textarea label="When should a person take over?" hint="Shown to your team with each hand-off." value={f.escalation_rules} onChange={(e) => setF({ ...f, escalation_rules: e.target.value })} />
        <Input label="Transfer calls to" type="tel" hint="Emergencies and 'talk to a person' requests go here." value={f.escalation_phone} onChange={(e) => setF({ ...f, escalation_phone: e.target.value })} />
        <div />
        <Textarea label="Pricing the AI may share (optional)" hint="Leave empty and it will never discuss prices." value={f.pricing_info} onChange={(e) => setF({ ...f, pricing_info: e.target.value })} />
        <Textarea label="Policies (optional)" hint="Warranty, cancellation, payment terms…" value={f.policies} onChange={(e) => setF({ ...f, policies: e.target.value })} />
      </div>
      {err && <Alert>{err}</Alert>}
      <Button type="submit" loading={busy === "save"}>Save and continue</Button>
    </form>
  );
}

function AgentStep({ org, agent, step, onNext, onBack }: { org: Org; agent: Agent | null; step: number; onNext: (a: Agent) => Promise<void>; onBack: () => void }) {
  const [caps, setCaps] = useState<string[]>(agent?.capabilities ?? ["web_chat", "answer_calls", "answer_sms", "answer_faqs", "capture_leads", "qualify_leads", "schedule_appointments", "transfer_calls", "follow_up", "send_reminders"]);
  const [f, setF] = useState({ name: agent?.name ?? "Sarah", greeting: agent?.greeting ?? `Hi, thanks for contacting ${org.name}! I'm Sarah. How can I help you today?`, tone: agent?.tone ?? "friendly", language: agent?.language ?? "en", voice: agent?.voice ?? "" });
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const body = { name: f.name, greeting: f.greeting, tone: f.tone, language: f.language, voice: f.voice || null, capabilities: caps };
      const saved = agent
        ? await patch<Agent>(`/agents/${agent.id}`, body)
        : await post<Agent>("/agents", { ...body, role: "receptionist" });
      await onNext(saved);
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  };
  return (
    <form onSubmit={save} className="space-y-6">
      {step === 4 ? (
        <>
          <h1 className="text-4xl font-semibold">What should your AI employee do?</h1>
          <div className="grid gap-3 sm:grid-cols-2">
            {Object.entries(CAPABILITY_LABELS).map(([k, l]) => (
              <Checkbox key={k} label={l} checked={caps.includes(k)} onChange={(v) => setCaps(v ? [...caps, k] : caps.filter((c) => c !== k))} />
            ))}
          </div>
          {!org.entitlements.features.includes("voice") && <Alert tone="wait">Phone calls and texts need the Growth plan. You can switch plans in Billing.</Alert>}
        </>
      ) : (
        <>
          <h1 className="text-4xl font-semibold">Personality</h1>
          <div className="grid gap-4 sm:grid-cols-2">
            <Input label="Name" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
            <Select label="Tone" value={f.tone} onChange={(e) => setF({ ...f, tone: e.target.value })}>
              {["friendly", "professional", "warm", "concise"].map((t) => <option key={t} value={t}>{t[0]?.toUpperCase() + t.slice(1)}</option>)}
            </Select>
            <Textarea className="sm:col-span-2" label="Greeting" required value={f.greeting} onChange={(e) => setF({ ...f, greeting: e.target.value })} />
            <Select label="Language" value={f.language} onChange={(e) => setF({ ...f, language: e.target.value })}>
              <option value="en">English</option>
              <option value="es">Spanish (answers only; industry questions are in English today)</option>
            </Select>
            <Select label="Phone voice" value={f.voice} onChange={(e) => setF({ ...f, voice: e.target.value })} hint="Used on phone calls.">
              <option value="">Default (Joanna)</option>
              <option value="Polly.Matthew">Matthew</option>
              <option value="Polly.Salli">Salli</option>
              <option value="Polly.Joey">Joey</option>
            </Select>
          </div>
        </>
      )}
      {err && <Alert>{err}</Alert>}
      <div className="flex gap-3">
        <Button type="button" variant="secondary" onClick={onBack} disabled={step === 4 && !agent}>Back</Button>
        <Button type="submit" loading={busy}>{step === 4 && !agent ? "Continue" : "Save and continue"}</Button>
      </div>
    </form>
  );
}

function ConnectionsStep({ onNext, onBack }: { onNext: () => void; onBack: () => void }) {
  return (
    <section className="space-y-5">
      <h1 className="text-4xl font-semibold">Connect your tools</h1>
      <p className="max-w-2xl text-muted">Your AI employee books into its built-in calendar right away. Connect Google Calendar so it also respects your existing events, and add a phone number to answer calls and texts. You can do this now or later.</p>
      <div className="grid gap-3 sm:grid-cols-2">
        {[
          ["Calendar", "Google Calendar — see busy times and add bookings."],
          ["Phone & texts", "Get a local number, or connect one you already use."],
          ["CRM", "Send new leads to HubSpot."],
          ["Billing", "Choose a plan before your trial ends."],
        ].map(([t, d]) => (
          <div key={t} className="rounded-lg border border-line bg-surface p-4">
            <h2 className="text-xl font-semibold">{t}</h2>
            <p className="text-muted">{d}</p>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap gap-3">
        <Button variant="secondary" onClick={onBack}>Back</Button>
        <Link href="/app/integrations" target="_blank" className="inline-flex h-10 items-center rounded-md border border-line bg-surface px-4 text-sm font-semibold">Open connections in a new tab</Link>
        <Button onClick={onNext}>Continue</Button>
      </div>
    </section>
  );
}

function KnowledgeStep({ onNext, onBack }: { onNext: () => void; onBack: () => void }) {
  const [faqs, setFaqs] = useState<Faq[]>([{ question: "", answer: "" }]);
  const [err, setErr] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    const valid = faqs.filter((f) => f.question.trim() && f.answer.trim());
    if (!valid.length) return onNext();
    setBusy(true);
    setErr(null);
    try {
      await post("/knowledge/faqs", { faqs: valid });
      setSaved(true);
      onNext();
    } catch (e) {
      setErr(errorText(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="space-y-5">
      <h1 className="text-4xl font-semibold">Frequently asked questions</h1>
      <p className="max-w-2xl text-muted">Add the questions customers ask most, with the exact answers you approve. Your AI employee will only use approved answers — you can upload documents and edit everything later under Knowledge.</p>
      <FaqEditor value={faqs} onChange={setFaqs} />
      {err && <Alert>{err}</Alert>}
      {saved && <Alert tone="go">Saved.</Alert>}
      <div className="flex gap-3"><Button variant="secondary" onClick={onBack}>Back</Button><Button loading={busy} onClick={() => void save()}>Save and continue</Button></div>
    </section>
  );
}

function ActivateStep({ agent, onBack }: { agent: Agent; onBack: () => void }) {
  const router = useRouter();
  const [checks, setChecks] = useState<{ key: string; ok: boolean; blocking: boolean; label: string }[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { void get<typeof checks>(`/agents/${agent.id}/activation-checks`).then(setChecks); }, [agent.id]);
  const activate = async () => {
    setBusy(true);
    setErr(null);
    try {
      await post(`/agents/${agent.id}/activate`);
      router.replace("/app/dashboard?activated=1");
    } catch (e) {
      setErr(errorText(e));
    } finally {
      setBusy(false);
    }
  };
  const blocked = checks?.some((c) => c.blocking && !c.ok);
  return (
    <section className="space-y-5">
      <h1 className="text-4xl font-semibold">Put {agent.name} to work</h1>
      <p className="max-w-2xl text-muted">{agent.name} starts answering customers only when you activate it. You can pause it at any time.</p>
      {!checks ? <Loading /> : (
        <ul className="space-y-2">
          {checks.map((c) => (
            <li key={c.key} className="flex items-center gap-3 rounded-md border border-line bg-surface px-3 py-2">
              {c.ok ? <Badge tone="go">Done</Badge> : c.blocking ? <Badge tone="stop">Required</Badge> : <Badge tone="wait">Recommended</Badge>}
              {c.label}
            </li>
          ))}
        </ul>
      )}
      {err && <Alert>{err}</Alert>}
      <div className="flex gap-3">
        <Button variant="secondary" onClick={onBack}>Back</Button>
        <Button variant="hivis" size="lg" loading={busy} disabled={!checks || blocked} onClick={() => void activate()}>Activate {agent.name}</Button>
      </div>
    </section>
  );
}
