"use client";

import { useState } from "react";

import { Button, Checkbox, Input, Textarea } from "./ui";

export const DAYS: [string, string][] = [["mon", "Monday"], ["tue", "Tuesday"], ["wed", "Wednesday"], ["thu", "Thursday"], ["fri", "Friday"], ["sat", "Saturday"], ["sun", "Sunday"]];

export type Hours = Record<string, string[][]>;

export function HoursEditor({ value, onChange }: { value: Hours; onChange: (h: Hours) => void }) {
  return (
    <fieldset>
      <legend className="mb-2 text-[13px] font-semibold text-ink-2">Business hours (appointments are only offered inside these hours)</legend>
      <div className="divide-y divide-line rounded-md border border-line">
        {DAYS.map(([key, name]) => {
          const r = value[key]?.[0];
          const open = !!r;
          return (
            <div key={key} className="flex flex-wrap items-center gap-3 px-3 py-2">
              <div className="w-32"><Checkbox label={name} checked={open} onChange={(v) => onChange({ ...value, [key]: v ? [["08:00", "17:00"]] : [] })} /></div>
              {open ? (
                <div className="flex items-center gap-2 text-sm">
                  <label className="sr-only" htmlFor={`${key}-o`}>{name} opens</label>
                  <input id={`${key}-o`} type="time" value={r[0]} onChange={(e) => onChange({ ...value, [key]: [[e.target.value, r[1] ?? "17:00"]] })} className="h-9 rounded border border-line px-2" />
                  <span>to</span>
                  <label className="sr-only" htmlFor={`${key}-c`}>{name} closes</label>
                  <input id={`${key}-c`} type="time" value={r[1]} onChange={(e) => onChange({ ...value, [key]: [[r[0] ?? "08:00", e.target.value]] })} className="h-9 rounded border border-line px-2" />
                </div>
              ) : (
                <span className="text-sm text-muted">Closed</span>
              )}
            </div>
          );
        })}
      </div>
    </fieldset>
  );
}

export interface Faq { question: string; answer: string }

export function FaqEditor({ value, onChange }: { value: Faq[]; onChange: (f: Faq[]) => void }) {
  return (
    <div className="space-y-3">
      {value.map((f, i) => (
        <div key={i} className="rounded-md border border-line p-3">
          <Input label={`Question ${i + 1}`} value={f.question} onChange={(e) => onChange(value.map((x, j) => (j === i ? { ...x, question: e.target.value } : x)))} />
          <Textarea className="mt-2" label="Approved answer" value={f.answer} onChange={(e) => onChange(value.map((x, j) => (j === i ? { ...x, answer: e.target.value } : x)))} />
          <Button type="button" variant="ghost" size="sm" className="mt-1" onClick={() => onChange(value.filter((_, j) => j !== i))}>Remove question</Button>
        </div>
      ))}
      <Button type="button" variant="secondary" size="sm" onClick={() => onChange([...value, { question: "", answer: "" }])}>Add a question</Button>
    </div>
  );
}

export function ZipInput({ value, onChange }: { value: string[]; onChange: (z: string[]) => void }) {
  const [text, setText] = useState(value.join(", "));
  const parsed = text.split(/[\s,]+/).filter(Boolean);
  const bad = parsed.filter((z) => !/^\d{5}$/.test(z));
  return (
    <Input
      label="Service area ZIP codes"
      hint={bad.length ? undefined : "Separate with commas. Leave empty to have the team confirm coverage for every request."}
      error={bad.length ? `Not a 5-digit ZIP: ${bad.join(", ")}` : null}
      value={text}
      onChange={(e) => {
        setText(e.target.value);
        const zs = e.target.value.split(/[\s,]+/).filter(Boolean);
        if (zs.every((z) => /^\d{5}$/.test(z))) onChange(zs);
      }}
    />
  );
}

export const CAPABILITY_LABELS: Record<string, string> = {
  answer_calls: "Answer calls",
  answer_sms: "Answer text messages",
  web_chat: "Website chat",
  capture_leads: "Capture leads",
  qualify_leads: "Qualify leads",
  schedule_appointments: "Schedule appointments",
  collect_quote_info: "Collect quote information and photos",
  follow_up: "Follow up with leads",
  send_reminders: "Send appointment reminders",
  transfer_calls: "Transfer calls to your team",
  answer_faqs: "Answer FAQs",
};
