"use client";

import { useState } from "react";

/** Single-series daily bar chart with hover tooltip and a table fallback. One hue, no legend (the title names the series). */
export function BarSeries({ title, data }: { title: string; data: { label: string; value: number }[] }) {
  const [hover, setHover] = useState<number | null>(null);
  const [table, setTable] = useState(false);
  const max = Math.max(1, ...data.map((d) => d.value));
  const W = 640, H = 180, pad = 24, bw = (W - pad) / Math.max(1, data.length);
  const h = hover != null ? data[hover] : null;
  return (
    <figure className="rounded-lg border border-line bg-surface p-4">
      <figcaption className="mb-2 flex items-center justify-between">
        <span className="font-display text-lg font-semibold">{title}</span>
        <button className="text-sm text-link underline" onClick={() => setTable(!table)}>{table ? "Show chart" : "Show table"}</button>
      </figcaption>
      {table ? (
        <div className="max-h-56 overflow-y-auto"><table className="w-full text-[14px]"><tbody>{data.map((d) => <tr key={d.label} className="border-b border-line"><td className="py-1">{d.label}</td><td className="text-right tabular">{d.value}</td></tr>)}</tbody></table></div>
      ) : (
        <div className="relative">
          <svg viewBox={`0 0 ${W} ${H + 18}`} className="w-full" role="img" aria-label={`${title}: ${data.map((d) => `${d.label} ${d.value}`).join(", ")}`} onMouseLeave={() => setHover(null)}>
            <line x1={pad} x2={W} y1={H} y2={H} stroke="var(--color-line)" />
            <text x={pad - 4} y={10} textAnchor="end" fontSize="10" fill="var(--color-muted)">{max}</text>
            <line x1={pad} x2={W} y1={4} y2={4} stroke="var(--color-line)" strokeDasharray="2 4" />
            {data.map((d, i) => {
              const bh = (d.value / max) * (H - 8);
              const x = pad + i * bw + 1;
              return (
                <g key={d.label} onMouseEnter={() => setHover(i)}>
                  <rect x={x - 1} y={0} width={bw} height={H} fill="transparent" />
                  {d.value > 0 && <path d={`M${x},${H} v${-(bh - 3)} q0,-3 3,-3 h${Math.max(0, bw - 8)} q3,0 3,3 v${bh - 3} z`} fill="var(--color-series)" opacity={hover == null || hover === i ? 1 : 0.45} />}
                </g>
              );
            })}
            {data.length > 0 && <><text x={pad} y={H + 14} fontSize="10" fill="var(--color-muted)">{data[0]!.label}</text><text x={W} y={H + 14} fontSize="10" textAnchor="end" fill="var(--color-muted)">{data[data.length - 1]!.label}</text></>}
          </svg>
          {h && <div className="pointer-events-none absolute top-0 right-0 rounded-md border border-line bg-surface px-2 py-1 text-[13px] shadow"><strong className="tabular">{h.value}</strong> <span className="text-muted">{h.label}</span></div>}
        </div>
      )}
    </figure>
  );
}

/** Horizontal funnel with direct labels on every bar (few bars, so each is labeled). */
export function Funnel({ steps }: { steps: { stage: string; count: number }[] }) {
  const max = Math.max(1, ...steps.map((s) => s.count));
  return (
    <figure className="rounded-lg border border-line bg-surface p-4">
      <figcaption className="mb-3 font-display text-lg font-semibold">Conversion funnel</figcaption>
      <ol className="space-y-2">
        {steps.map((s, i) => {
          const prev = i > 0 ? steps[i - 1]!.count : null;
          return (
            <li key={s.stage} className="grid grid-cols-[110px_1fr_90px] items-center gap-3 text-[14px]">
              <span>{s.stage}</span>
              <span className="h-5 rounded bg-canvas"><span className="block h-5 rounded bg-series" style={{ width: `${(s.count / max) * 100}%`, minWidth: s.count ? 4 : 0 }} /></span>
              <span className="text-right tabular"><strong>{s.count}</strong>{prev ? <span className="text-muted"> · {Math.round((s.count / prev) * 100)}%</span> : null}</span>
            </li>
          );
        })}
      </ol>
    </figure>
  );
}
