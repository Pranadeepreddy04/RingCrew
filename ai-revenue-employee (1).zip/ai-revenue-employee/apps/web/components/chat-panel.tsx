"use client";

import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";

import { Button, cx } from "./ui";

export interface ChatLine {
  role: "customer" | "assistant" | "system" | "action";
  text: string;
  ok?: boolean;
}

/** Transcript + composer used by the public demo and the owner test environment. */
export function ChatPanel({
  lines,
  onSend,
  agentName,
  placeholder = "Type as a customer would…",
  suggestions = [],
  disabled,
  toolbar,
  header,
}: {
  lines: ChatLine[];
  onSend: (text: string) => Promise<void>;
  agentName: string;
  placeholder?: string;
  suggestions?: string[];
  disabled?: boolean;
  /** Extra controls left of the message box (e.g. the voice button). */
  toolbar?: ReactNode;
  /** Bar above the transcript (e.g. the language picker). */
  header?: ReactNode;
}) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => {
    end.current?.scrollIntoView({ block: "nearest" });
  }, [lines.length]);

  const send = async (t: string) => {
    const v = t.trim();
    if (!v || busy) return;
    setBusy(true);
    setText("");
    try {
      await onSend(v);
    } finally {
      setBusy(false);
    }
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    void send(text);
  };

  return (
    <div className="flex h-[560px] flex-col overflow-hidden rounded-lg border border-line bg-surface">
      {header && <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2">{header}</div>}
      <div className="flex-1 space-y-2 overflow-y-auto bg-canvas p-4" aria-live="polite">
        {lines.map((l, i) =>
          l.role === "action" ? (
            <div key={i} className={cx("w-fit rounded px-2 py-1 text-[12px] font-semibold", l.ok === false ? "bg-stop-soft text-stop" : "bg-hivis-soft text-ink")}>
              {l.text}
            </div>
          ) : l.role === "system" ? (
            <p key={i} className="text-center text-[13px] text-muted">{l.text}</p>
          ) : (
            <div key={i} className={cx("max-w-[85%] rounded-xl px-3 py-2 text-[14px] whitespace-pre-wrap", l.role === "customer" ? "ml-auto bg-ink text-white" : "border border-line bg-surface")}>
              {l.role === "assistant" && <span className="mb-0.5 block text-[12px] font-semibold text-muted">{agentName}</span>}
              <span dir="auto" className="block">{l.text}</span>
            </div>
          ),
        )}
        {busy && <p className="text-[13px] text-muted">{agentName} is typing…</p>}
        <div ref={end} />
      </div>
      {suggestions.length > 0 && (
        <div className="flex flex-wrap gap-1.5 border-t border-line px-3 py-2">
          {suggestions.map((s) => (
            <button key={s} type="button" dir="auto" disabled={busy || disabled} onClick={() => void send(s)} className="rounded-full border border-line px-2.5 py-1 text-[13px] hover:border-ink-2 disabled:opacity-50">
              {s}
            </button>
          ))}
        </div>
      )}
      <form onSubmit={submit} className="flex items-center gap-2 border-t border-line p-3">
        {toolbar}
        <label htmlFor="chat-input" className="sr-only">Message</label>
        <input id="chat-input" dir="auto" value={text} onChange={(e) => setText(e.target.value)} disabled={disabled} placeholder={placeholder} maxLength={2000}
          className="h-10 flex-1 rounded-md border border-line px-3 outline-none focus:border-ink-2" />
        <Button type="submit" disabled={!text.trim() || disabled} loading={busy}>Send</Button>
      </form>
    </div>
  );
}
