import Link from "next/link";
import type { ReactNode } from "react";

export function Logo({ light }: { light?: boolean }) {
  return (
    <Link href="/" className={`flex items-center gap-2 font-display text-xl font-bold ${light ? "text-white" : "text-ink"}`}>
      <svg aria-hidden="true" viewBox="0 0 64 64" className="size-7">
        <rect width="64" height="64" rx="12" fill={light ? "#ffffff" : "#102a43"} />
        <path d="M18 42V22h14a8 8 0 010 16h-6l10 4" fill="none" stroke="#ffc400" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      AI Revenue Employee
    </Link>
  );
}

export function SiteHeader() {
  return (
    <header className="border-b border-line bg-surface">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3">
        <Logo />
        <nav aria-label="Main" className="flex flex-wrap items-center gap-1 text-[15px] font-medium">
          <Link className="rounded px-3 py-2 hover:bg-canvas" href="/features">How it works</Link>
          <Link className="rounded px-3 py-2 hover:bg-canvas" href="/industries">Industries</Link>
          <Link className="rounded px-3 py-2 hover:bg-canvas" href="/pricing">Pricing</Link>
          <Link className="rounded px-3 py-2 hover:bg-canvas" href="/login">Sign in</Link>
          <Link className="ml-1 rounded-md bg-ink px-4 py-2 font-semibold text-white hover:bg-ink-2" href="/signup">Build my AI employee</Link>
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-20 bg-ink text-white/80">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:grid-cols-3">
        <div>
          <Logo light />
          <p className="mt-3 max-w-xs text-sm">An AI employee for service businesses: it answers, qualifies, books and follows up.</p>
        </div>
        <FooterCol title="Product" links={[["How it works", "/features"], ["Industries", "/industries"], ["Pricing", "/pricing"], ["Live demo", "/demo"]]} />
        <FooterCol title="Company" links={[["Privacy", "/privacy"], ["Terms", "/terms"], ["Sign in", "/login"]]} />
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: [string, string][] }) {
  return (
    <div>
      <h2 className="font-display text-lg font-semibold text-white">{title}</h2>
      <ul className="mt-2 space-y-1 text-sm">
        {links.map(([l, h]) => (
          <li key={h}>
            <Link className="hover:text-hivis" href={h}>{l}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <>
      <SiteHeader />
      <main id="main">{children}</main>
      <SiteFooter />
    </>
  );
}
