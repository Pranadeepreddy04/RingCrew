"use client";

import { useEffect, useState } from "react";

import { ChatPanel, type ChatLine } from "./chat-panel";
import { Alert, Badge, Button, Select } from "./ui";
import { VoiceButton } from "./voice-button";
import { errorText, label, post } from "@/lib/api";
import { byCode, SAMPLE_OPENERS } from "@/lib/languages";

interface Action { tool: string; ok: boolean; error: string | null }
interface TestReply {
  reply: string | null; handoff: boolean; transfer_to: string | null; actions: Action[];
  state: { stage?: string; fields?: Record<string, unknown> }; conversation: { language: string };
}

const TOOL_NAMES: Record<string, string> = {
  search_business_knowledge: "Searched your business info", get_business_information: "Looked up business details", check_service_area: "Checked service area",
  create_lead: "Would create lead", check_calendar: "Checked your calendar", book_appointment: "Would book appointment", reschedule_appointment: "Would reschedule",
  cancel_appointment: "Would cancel appointment", send_sms: "Would send text", create_task: "Would create staff task", request_human_help: "Would hand off to your team",
  transfer_to_human: "Would transfer to your team", create_quote_request: "Would create quote request",
};

/** Owner test environment: real understanding, knowledge and calendar lookups; all actions are dry runs. */
export function TestConsole({ agentId, agentName, languages = ["en"] }: { agentId: string; agentName: string; languages?: string[] }) {
  const [cid, setCid] = useState<string | null>(null);
  const [lines, setLines] = useState<ChatLine[]>([]);
  const [state, setState] = useState<TestReply["state"]>({});
  const [channel, setChannel] = useState("web");
  const [err, setErr] = useState<string | null>(null);
  const [startLang, setStartLang] = useState("");
  const [lang, setLang] = useState(languages[0] ?? "en");
  const [reply, setReply] = useState<{ id: number; text: string; language: string } | null>(null);
  const [voiceStatus, setVoiceStatus] = useState<string | null>(null);

  const start = async (language = startLang) => {
    setErr(null);
    try {
      const r = await post<{ conversation: { id: string; language: string }; messages: { content: string }[] }>(
        `/agents/${agentId}/test/conversations`, language ? { language } : undefined,
      );
      setCid(r.conversation.id);
      setLang(r.conversation.language);
      setReply(null);
      setLines([{ role: "system", text: "Test mode — nothing is booked or sent." }, ...r.messages.map((m) => ({ role: "assistant" as const, text: m.content }))]);
      setState({});
    } catch (e) {
      setErr(errorText(e));
    }
  };
  useEffect(() => {
    void start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [agentId]);

  const send = async (text: string) => {
    if (!cid) return;
    setLines((l) => [...l, { role: "customer", text }]);
    try {
      const r = await post<TestReply>(`/agents/${agentId}/test/conversations/${cid}/messages`, { text, simulate_channel: channel });
      const acts: ChatLine[] = r.actions.filter((a) => a.tool !== "search_business_knowledge" || a.ok).map((a) => ({
        role: "action", ok: a.ok, text: `${TOOL_NAMES[a.tool] ?? label(a.tool)}${a.ok ? "" : ` — ${label(a.error)}`}`,
      }));
      setLines((l) => [...l, ...acts, ...(r.reply ? [{ role: "assistant" as const, text: r.reply }] : []),
        ...(r.transfer_to ? [{ role: "system" as const, text: `Call would transfer to ${r.transfer_to}` }] : []),
        ...(r.handoff ? [{ role: "system" as const, text: "Handed off to your team — the AI stops replying in this conversation." }] : [])]);
      setState(r.state);
      setLang(r.conversation.language);
      if (r.reply) setReply({ id: Date.now(), text: r.reply, language: r.conversation.language });
    } catch (e) {
      setLines((l) => [...l, { role: "system", text: errorText(e) }]);
    }
  };

  const fields = Object.entries(state.fields ?? {});
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
      <div>
        {err && <Alert>{err}</Alert>}
        <ChatPanel lines={lines} onSend={send} agentName={agentName} disabled={!cid}
          header={<>
            <Badge tone="plain">Speaking: {byCode(lang).native}</Badge>
            {voiceStatus && <span className="text-[13px] text-muted">{voiceStatus}</span>}
          </>}
          toolbar={<VoiceButton language={lang} replyToSpeak={reply} onBrowserText={(t) => void send(t)} onStatus={setVoiceStatus} disabled={!cid} />}
          suggestions={lines.some((l) => l.role === "customer")
            ? ["Do you offer free inspections?", "What does a new roof cost?", "I want to talk to a person"]
            : ["Do you offer free inspections?", "I want to talk to a person", ...languages.map((l) => SAMPLE_OPENERS[l] ?? "").filter(Boolean)]} />
      </div>
      <aside className="space-y-3">
        {languages.length > 1 && (
          <Select label="Start in language" hint="Or just write in any enabled language." value={startLang} onChange={(e) => { setStartLang(e.target.value); void start(e.target.value); }}>
            <option value="">{byCode(languages[0]).native} (default)</option>
            {languages.slice(1).map((c) => <option key={c} value={c}>{byCode(c).native} — {byCode(c).name}</option>)}
          </Select>
        )}
        <Select label="Simulate channel" value={channel} onChange={(e) => setChannel(e.target.value)}>
          <option value="web">Website chat</option>
          <option value="voice">Phone call</option>
          <option value="sms">Text message</option>
        </Select>
        <div className="rounded-md border border-line bg-surface p-3">
          <h3 className="font-semibold">What it has collected</h3>
          {fields.length ? (
            <dl className="mt-2 space-y-1 text-[14px]">
              {fields.map(([k, v]) => (
                <div key={k} className="flex justify-between gap-2"><dt className="text-muted">{label(k)}</dt><dd className="text-right font-medium">{label(String(v))}</dd></div>
              ))}
            </dl>
          ) : <p className="mt-1 text-[14px] text-muted">Nothing yet.</p>}
          {state.stage && <p className="mt-2 text-[13px] text-muted">Stage: {label(state.stage)}</p>}
        </div>
        <Button variant="secondary" className="w-full" onClick={() => void start()}>Start a new test conversation</Button>
      </aside>
    </div>
  );
}
