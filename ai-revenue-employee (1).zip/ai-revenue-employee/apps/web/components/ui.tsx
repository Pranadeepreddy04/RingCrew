"use client";

import Link from "next/link";
import {
  forwardRef,
  useEffect,
  useId,
  useRef,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from "react";

const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");

type Variant = "primary" | "secondary" | "ghost" | "danger" | "hivis";
const VARIANTS: Record<Variant, string> = {
  primary: "bg-ink text-white hover:bg-ink-2 disabled:bg-muted",
  hivis: "bg-hivis text-ink hover:brightness-95 disabled:opacity-60",
  secondary: "bg-surface text-ink border border-line hover:border-ink-2 disabled:opacity-60",
  ghost: "text-ink-2 hover:bg-canvas disabled:opacity-60",
  danger: "bg-stop text-white hover:brightness-95 disabled:opacity-60",
};

export function Button({
  variant = "primary",
  size = "md",
  loading,
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: "sm" | "md" | "lg"; loading?: boolean }) {
  const sz = size === "sm" ? "h-8 px-3 text-[13px]" : size === "lg" ? "h-12 px-6 text-base" : "h-10 px-4 text-sm";
  return (
    <button
      {...rest}
      disabled={rest.disabled || loading}
      aria-busy={loading || undefined}
      className={cx("inline-flex items-center justify-center gap-2 rounded-md font-semibold transition-colors disabled:cursor-not-allowed", sz, VARIANTS[variant], className)}
    >
      {loading && <Spinner small />}
      {children}
    </button>
  );
}

export function ButtonLink({ href, variant = "primary", size = "md", className, children }: { href: string; variant?: Variant; size?: "sm" | "md" | "lg"; className?: string; children: ReactNode }) {
  const sz = size === "sm" ? "h-8 px-3 text-[13px]" : size === "lg" ? "h-12 px-6 text-base" : "h-10 px-4 text-sm";
  return (
    <Link href={href} className={cx("inline-flex items-center justify-center rounded-md font-semibold transition-colors", sz, VARIANTS[variant], className)}>
      {children}
    </Link>
  );
}

export function Spinner({ small }: { small?: boolean }) {
  return <span role="status" aria-label="Loading" className={cx("inline-block animate-spin rounded-full border-2 border-current border-r-transparent", small ? "size-3.5" : "size-5")} />;
}

export function Loading({ label = "Loading" }: { label?: string }) {
  return (
    <div className="flex items-center gap-3 p-8 text-muted" aria-live="polite">
      <Spinner /> {label}…
    </div>
  );
}

interface FieldProps {
  label: string;
  hint?: string;
  error?: string | null;
}

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement> & FieldProps>(function Input({ label, hint, error, className, ...rest }, ref) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-[13px] font-semibold text-ink-2">
        {label}
      </label>
      <input
        ref={ref}
        id={id}
        aria-invalid={!!error || undefined}
        aria-describedby={hint || error ? `${id}-h` : undefined}
        {...rest}
        className="h-10 w-full rounded-md border border-line bg-surface px-3 text-[15px] outline-none focus:border-ink-2 aria-invalid:border-stop"
      />
      {(hint || error) && (
        <p id={`${id}-h`} className={cx("mt-1 text-[13px]", error ? "text-stop" : "text-muted")}>
          {error || hint}
        </p>
      )}
    </div>
  );
});

export function Textarea({ label, hint, error, className, ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement> & FieldProps) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-[13px] font-semibold text-ink-2">
        {label}
      </label>
      <textarea
        id={id}
        aria-invalid={!!error || undefined}
        {...rest}
        className="min-h-24 w-full rounded-md border border-line bg-surface px-3 py-2 text-[15px] outline-none focus:border-ink-2"
      />
      {(hint || error) && <p className={cx("mt-1 text-[13px]", error ? "text-stop" : "text-muted")}>{error || hint}</p>}
    </div>
  );
}

export function Select({ label, hint, className, children, ...rest }: SelectHTMLAttributes<HTMLSelectElement> & FieldProps & { children: ReactNode }) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1 block text-[13px] font-semibold text-ink-2">
        {label}
      </label>
      <select id={id} {...rest} className="h-10 w-full rounded-md border border-line bg-surface px-2.5 text-[15px] outline-none focus:border-ink-2">
        {children}
      </select>
      {hint && <p className="mt-1 text-[13px] text-muted">{hint}</p>}
    </div>
  );
}

export function Checkbox({ label, hint, checked, onChange, disabled }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  const id = useId();
  return (
    <div className="flex items-start gap-2.5">
      <input id={id} type="checkbox" className="mt-1 size-4 accent-ink" checked={checked} disabled={disabled} onChange={(e) => onChange(e.target.checked)} />
      <label htmlFor={id} className="text-[15px]">
        {label}
        {hint && <span className="block text-[13px] text-muted">{hint}</span>}
      </label>
    </div>
  );
}

export function Panel({ title, action, children, className, padded = true }: { title?: ReactNode; action?: ReactNode; children: ReactNode; className?: string; padded?: boolean }) {
  return (
    <section className={cx("rounded-lg border border-line bg-surface", className)}>
      {(title || action) && (
        <header className="flex items-center justify-between gap-3 border-b border-line px-4 py-3">
          {title && <h2 className="text-lg font-semibold">{title}</h2>}
          {action}
        </header>
      )}
      <div className={padded ? "p-4" : ""}>{children}</div>
    </section>
  );
}

const TONES: Record<string, string> = {
  go: "bg-go-soft text-go",
  stop: "bg-stop-soft text-stop",
  wait: "bg-wait-soft text-wait",
  live: "bg-hivis-soft text-ink",
  plain: "bg-canvas text-ink-2",
};

export function Badge({ tone = "plain", children }: { tone?: keyof typeof TONES; children: ReactNode }) {
  return <span className={cx("inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[12px] font-semibold whitespace-nowrap", TONES[tone])}>{children}</span>;
}

export function statusTone(s: string): keyof typeof TONES {
  if (["won", "active", "completed", "confirmed", "delivered", "connected", "paid", "resolved"].includes(s)) return "go";
  if (["lost", "cancelled", "failed", "no_show", "error", "canceled", "past_due", "needs_human"].includes(s)) return "stop";
  if (["appointment", "scheduled", "qualified", "trialing", "open"].includes(s)) return "live";
  if (["draft", "paused", "new", "contacted"].includes(s)) return "wait";
  return "plain";
}

export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-start gap-2 rounded-lg border border-dashed border-line bg-surface p-6">
      <h3 className="text-lg font-semibold">{title}</h3>
      {children && <div className="max-w-prose text-muted">{children}</div>}
      {action}
    </div>
  );
}

export function Alert({ tone = "stop", children }: { tone?: "stop" | "go" | "wait" | "live"; children: ReactNode }) {
  return (
    <div role={tone === "stop" ? "alert" : "status"} className={cx("rounded-md px-3 py-2 text-[14px]", TONES[tone])}>
      {children}
    </div>
  );
}

export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      onClose={onClose}
      aria-label={title}
      className={cx("m-auto w-[calc(100%-24px)] rounded-lg border border-line bg-surface p-0 text-ink backdrop:bg-ink/40", wide ? "max-w-3xl" : "max-w-lg")}
    >
      <header className="flex items-center justify-between border-b border-line px-5 py-3">
        <h2 className="text-xl font-semibold">{title}</h2>
        <button onClick={onClose} className="rounded px-2 text-2xl leading-none text-muted hover:text-ink" aria-label="Close">
          ×
        </button>
      </header>
      <div className="max-h-[75vh] overflow-y-auto p-5">{open && children}</div>
    </dialog>
  );
}

export function PageHeader({ title, description, action }: { title: string; description?: ReactNode; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-3xl font-semibold">{title}</h1>
        {description && <p className="mt-1 max-w-2xl text-muted">{description}</p>}
      </div>
      {action}
    </div>
  );
}

export function Pager({ page, total, pageSize, onPage }: { page: number; total: number; pageSize: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return null;
  return (
    <nav aria-label="Pagination" className="mt-3 flex items-center gap-2 text-[14px]">
      <Button variant="secondary" size="sm" disabled={page <= 1} onClick={() => onPage(page - 1)}>
        Previous
      </Button>
      <span className="text-muted">
        Page {page} of {pages}
      </span>
      <Button variant="secondary" size="sm" disabled={page >= pages} onClick={() => onPage(page + 1)}>
        Next
      </Button>
    </nav>
  );
}

export { cx };
