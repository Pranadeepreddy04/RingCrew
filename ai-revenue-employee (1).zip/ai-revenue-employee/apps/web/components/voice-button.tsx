"use client";

import { useEffect, useRef, useState } from "react";

import { byCode } from "@/lib/languages";
import { cx } from "./ui";

/* Browser voice for the chat panels.
 *
 * Two recognizers, chosen automatically:
 *  1. "stream" — microphone audio is streamed to the API's voice socket, which relays it to the server's
 *     VibeVoice-ASR-Streaming model and runs the AI turn (needs a visitor-token conversation and VOICE_ASR_PROVIDER=vibevoice).
 *  2. "browser" — the browser's own Web Speech API (Chrome, Edge, Safari). Used when the server has no streaming
 *     recognizer, for languages VibeVoice does not cover, and in the owner test console.
 * Replies are spoken with the browser's speech synthesis in the conversation language. While the agent speaks the
 * microphone is muted (half duplex) so the agent does not hear itself.
 */

type SpeechRecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((e: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
};

function recognitionCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function speak(text: string, language: string, onEnd?: () => void): void {
  if (typeof window === "undefined" || !("speechSynthesis" in window) || !text) {
    onEnd?.();
    return;
  }
  const u = new SpeechSynthesisUtterance(text);
  const bcp = byCode(language).bcp47;
  u.lang = bcp;
  const base = bcp.split("-")[0] ?? bcp;
  const voice = window.speechSynthesis.getVoices().find((v) => v.lang === bcp) ?? window.speechSynthesis.getVoices().find((v) => v.lang.startsWith(base));
  if (voice) u.voice = voice;
  u.onend = () => onEnd?.();
  u.onerror = () => onEnd?.();
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(u);
}

export interface StreamTarget {
  conversationId: string;
  visitorToken: string;
}

export interface VoiceReply {
  messages: { content: string }[];
  language: string;
  handoff: boolean;
}

export function VoiceButton({
  language,
  stream,
  replyToSpeak,
  onBrowserText,
  onStreamTurn,
  onStatus,
  disabled,
}: {
  language: string;
  /** Conversation to stream to (website visitors). Omit to use the browser recognizer only. */
  stream?: StreamTarget | null;
  /** The latest assistant reply (spoken while voice mode is on). Change `id` to speak again. */
  replyToSpeak?: { id: string | number; text: string; language?: string } | null;
  /** Browser recognizer produced a final transcript: send it as a normal message. */
  onBrowserText: (text: string) => void;
  /** Server-side turn finished (stream mode): the transcript and the AI reply. */
  onStreamTurn?: (transcript: string, reply: VoiceReply) => void;
  onStatus?: (s: string | null) => void;
  disabled?: boolean;
}) {
  const [on, setOn] = useState(false);
  const [mode, setMode] = useState<"stream" | "browser" | null>(null);
  const [partial, setPartial] = useState("");
  const ws = useRef<WebSocket | null>(null);
  const audio = useRef<{ ctx: AudioContext; media: MediaStream; node: ScriptProcessorNode; src: MediaStreamAudioSourceNode } | null>(null);
  const rec = useRef<SpeechRecognitionLike | null>(null);
  const muted = useRef(false);
  const onRef = useRef(false);
  const langRef = useRef(language);
  const spokenId = useRef<string | number | null>(null);
  const lastFinal = useRef("");
  useEffect(() => {
    langRef.current = language;
  }, [language]);

  const status = (s: string | null) => onStatus?.(s);

  const stopAll = () => {
    onRef.current = false;
    setOn(false);
    setMode(null);
    setPartial("");
    try {
      ws.current?.send(JSON.stringify({ type: "close" }));
    } catch {
      /* socket already closed */
    }
    ws.current?.close();
    ws.current = null;
    if (audio.current) {
      audio.current.node.disconnect();
      audio.current.src.disconnect();
      audio.current.media.getTracks().forEach((t) => t.stop());
      void audio.current.ctx.close();
      audio.current = null;
    }
    rec.current?.abort();
    rec.current = null;
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
    status(null);
  };

  useEffect(() => stopAll, []); // eslint-disable-line react-hooks/exhaustive-deps

  const listenBrowser = () => {
    const Ctor = recognitionCtor();
    if (!Ctor) {
      status("Voice input isn't supported in this browser. Try Chrome, Edge or Safari.");
      stopAll();
      return;
    }
    const r = new Ctor();
    r.lang = byCode(langRef.current).bcp47;
    r.continuous = false;
    r.interimResults = true;
    r.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        if (!res || !res[0]) continue;
        if (res.isFinal) {
          const text = res[0].transcript.trim();
          setPartial("");
          if (text) {
            muted.current = true; // wait for the reply before listening again
            onBrowserText(text);
          }
        } else interim += res[0].transcript;
      }
      if (interim) setPartial(interim);
    };
    r.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        status("Microphone permission was denied.");
        stopAll();
      }
    };
    r.onend = () => {
      if (onRef.current && !muted.current) {
        try {
          r.start();
        } catch {
          /* already started */
        }
      }
    };
    rec.current = r;
    setMode("browser");
    status(`Listening (${byCode(langRef.current).native}, browser speech recognition)`);
    r.start();
  };

  const listenStream = async (target: StreamTarget) => {
    // Hosts that cannot proxy WebSockets (e.g. Netlify) set NEXT_PUBLIC_VOICE_WS_URL to the API's wss:// origin.
    const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
    const origin = process.env.NEXT_PUBLIC_VOICE_WS_URL || `${proto}//${window.location.host}`;
    const sock = new WebSocket(`${origin.replace(/\/$/, "")}/api/v1/public/conversations/${target.conversationId}/voice`);
    sock.binaryType = "arraybuffer";
    ws.current = sock;
    let media: MediaStream;
    try {
      media = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, channelCount: 1 } });
    } catch {
      status("Microphone permission was denied.");
      stopAll();
      return;
    }
    const ctx = new AudioContext();
    const begin = () => sock.send(JSON.stringify({ type: "start", visitor_token: target.visitorToken, sample_rate: ctx.sampleRate, format: "f32", language: langRef.current }));
    if (sock.readyState === WebSocket.OPEN) begin();
    else sock.onopen = begin; // the socket may already be open after the microphone prompt
    sock.onmessage = (ev) => {
      const m = JSON.parse(String(ev.data)) as { type: string; text?: string; reason?: string; code?: string } & Partial<VoiceReply>;
      if (m.type === "ready") {
        setMode("stream");
        status(`Listening (${byCode(langRef.current).native}, VibeVoice streaming ASR)`);
        // ScriptProcessorNode is deprecated but available in every browser and keeps this a single file.
        const src = ctx.createMediaStreamSource(media);
        const node = ctx.createScriptProcessor(4096, 1, 1);
        node.onaudioprocess = (e) => {
          if (muted.current || sock.readyState !== WebSocket.OPEN) return;
          sock.send(new Float32Array(e.inputBuffer.getChannelData(0)).buffer);
        };
        src.connect(node);
        node.connect(ctx.destination);
        audio.current = { ctx, media, node, src };
      } else if (m.type === "unavailable") {
        media.getTracks().forEach((t) => t.stop());
        void ctx.close();
        ws.current = null;
        listenBrowser();
      } else if (m.type === "partial") setPartial(m.text ?? "");
      else if (m.type === "final") setPartial("");
      else if (m.type === "reply") {
        muted.current = true;
        onStreamTurn?.(lastFinal.current, { messages: m.messages ?? [], language: m.language ?? langRef.current, handoff: !!m.handoff });
      } else if (m.type === "error") status(m.code === "asr_unavailable" || m.code === "asr_failed" ? "Speech recognition is unavailable right now." : `Voice error: ${m.code}`);
      if (m.type === "final") lastFinal.current = m.text ?? "";
    };
    sock.onclose = () => {
      if (ws.current === sock && onRef.current && audio.current) stopAll();
    };
  };

  // Speak each new reply while voice mode is on, then resume listening.
  useEffect(() => {
    if (!on || !replyToSpeak || replyToSpeak.id === spokenId.current) return;
    spokenId.current = replyToSpeak.id;
    muted.current = true;
    speak(replyToSpeak.text, replyToSpeak.language ?? langRef.current, () => {
      muted.current = false;
      if (onRef.current && mode === "browser" && rec.current) {
        try {
          rec.current.lang = byCode(langRef.current).bcp47;
          rec.current.start();
        } catch {
          /* already listening */
        }
      }
    });
  }, [replyToSpeak, on, mode]);

  const toggle = () => {
    if (on) {
      stopAll();
      return;
    }
    onRef.current = true;
    muted.current = false;
    spokenId.current = replyToSpeak?.id ?? null; // do not read out the existing transcript
    setOn(true);
    if (stream) void listenStream(stream);
    else listenBrowser();
  };

  return (
    <div className="flex items-center gap-2">
      <button
        type="button"
        onClick={toggle}
        disabled={disabled}
        aria-pressed={on}
        aria-label={on ? "Stop voice conversation" : "Talk to the AI employee"}
        title={on ? "Stop voice" : "Talk (voice)"}
        className={cx(
          "flex h-10 w-10 shrink-0 items-center justify-center rounded-md border disabled:opacity-50",
          on ? "border-stop bg-stop text-white" : "border-line bg-surface text-ink hover:border-ink-2",
        )}
      >
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <rect x="9" y="3" width="6" height="11" rx="3" stroke="currentColor" strokeWidth="2" />
          <path d="M5 11a7 7 0 0 0 14 0M12 18v3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      </button>
      {on && partial && <span className="max-w-48 truncate text-[13px] text-muted" dir="auto">{partial}</span>}
    </div>
  );
}
