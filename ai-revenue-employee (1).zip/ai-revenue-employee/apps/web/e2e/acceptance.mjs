/**
 * Browser acceptance test (spec §94) driving the real UI in headless Chromium.
 *   BASE_URL=http://localhost:3000 node e2e/acceptance.mjs
 * Uses CHROME_PATH if set, otherwise the npm-bundled @sparticuz/chromium binary.
 * Screenshots are written to e2e/screenshots/.
 */
import { mkdirSync } from "node:fs";

import { chromium as pw } from "playwright-core";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const SHOTS = new URL("./screenshots/", import.meta.url).pathname;
mkdirSync(SHOTS, { recursive: true });

async function launch() {
  if (process.env.CHROME_PATH) return pw.launch({ executablePath: process.env.CHROME_PATH, headless: true });
  const { default: chromium } = await import("@sparticuz/chromium");
  return pw.launch({ executablePath: await chromium.executablePath(), args: chromium.args, headless: true });
}

const step = (msg) => console.log(`✓ ${msg}`);
const fail = (msg) => {
  console.error(`✗ ${msg}`);
  process.exitCode = 1;
  throw new Error(msg);
};

const browser = await launch();
const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 } });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(`${e.message}\n${(e.stack ?? "").split("\n").slice(0, 6).join("\n")}`));
const shot = (name) => page.screenshot({ path: `${SHOTS}${name}.png`, fullPage: true });

try {
  // Marketing site
  await page.goto(BASE);
  await page.getByRole("heading", { name: "Never lose a customer because you missed their call" }).waitFor();
  await page.waitForTimeout(5500);
  await shot("01-home");
  step("home page renders");

  // Signup (step 1)
  const email = `owner-${Date.now()}@example.com`;
  await page.goto(`${BASE}/signup`);
  await page.getByLabel("Your name").fill("Mike Owner");
  await page.getByLabel("Work email").fill(email);
  await page.getByLabel("Password").fill("Roof-pass-2026");
  await page.getByRole("button", { name: "Create account" }).click();
  await page.getByRole("heading", { name: "Tell us about your business" }).waitFor();
  step("signed up");

  // Step 2 business
  await page.getByLabel("Business name").fill("Mike's Roofing E2E");
  await page.getByLabel("Industry").selectOption("roofing");
  await page.getByLabel("Time zone").selectOption("America/Chicago");
  await page.getByLabel("Service area ZIP codes").fill("76201, 76205");
  await shot("02-onboarding-business");
  await page.getByRole("button", { name: "Continue" }).click();
  await page.getByRole("heading", { name: "Business information" }).waitFor();
  step("business created");

  // Step 3 info: open every day so tests are day-independent
  await page.getByLabel("What does your business do?").fill("Family-owned roofer in Denton, Texas. Free roof inspections.");
  for (const d of ["Saturday", "Sunday"]) await page.getByLabel(d, { exact: true }).check();
  await page.getByLabel("New service").fill("Roof inspection");
  await page.getByRole("button", { name: "Add", exact: true }).click();
  await page.getByLabel("Transfer calls to").fill("940-555-0199");
  await page.getByRole("button", { name: "Save and continue" }).click();
  await page.getByRole("heading", { name: "What should your AI employee do?" }).waitFor();
  step("business info saved");

  // Steps 4–5
  await page.getByRole("button", { name: "Continue" }).click();
  await page.getByRole("heading", { name: "Personality" }).waitFor();
  await page.getByLabel("Name", { exact: true }).fill("Sarah");
  await page.getByRole("button", { name: "Save and continue" }).click();
  await page.getByRole("heading", { name: "Connect your tools" }).waitFor();
  await page.getByRole("button", { name: "Continue" }).click();
  step("AI employee created");

  // Step 7 knowledge
  await page.getByLabel("Question 1").fill("Do you offer free inspections?");
  await page.getByLabel("Approved answer").fill("Yes — roof inspections are free and take about 45 minutes.");
  await page.getByRole("button", { name: "Save and continue" }).click();
  await page.getByRole("heading", { name: "Test Sarah" }).waitFor();
  step("knowledge added");

  // Step 8 test environment
  const chat = page.getByLabel("Message", { exact: true });
  await chat.fill("Do you offer free inspections?");
  await page.getByRole("button", { name: "Send" }).click();
  await page.getByText("take about 45 minutes").waitFor();
  await shot("03-test-environment");
  step("test environment answers from knowledge");
  await page.getByRole("button", { name: "Continue to activation" }).click();

  // Step 9 activation
  await page.getByRole("button", { name: "Activate Sarah" }).click();
  await page.waitForURL(/\/app\/dashboard/);
  step("AI employee activated");

  // Widget on a customer's website
  await page.goto(`${BASE}/app/ai-employees`);
  await page.getByRole("tab", { name: "Website chat" }).click();
  const code = await page.locator("pre code").textContent();
  const token = code.match(/data-token="([^"]+)"/)[1];
  const site = await ctx.newPage();
  site.on("pageerror", (e) => errors.push(e.message));
  await site.goto(`${BASE}/privacy`);
  await site.evaluate(([src, t]) => { const s = document.createElement("script"); s.src = src; s.dataset.token = t; document.body.appendChild(s); }, [`${BASE}/widget.js`, token]);
  const launcher = site.locator("#are-chat-widget").locator("button.launch");
  await launcher.click();
  const w = site.locator("#are-chat-widget");
  await w.locator(".m.a").first().waitFor();
  const say = async (text, expect) => {
    const before = await w.locator(".m.a").count();
    await w.locator("textarea").fill(text);
    await w.locator("button.send").click();
    await w.locator(".m.a").nth(before).waitFor({ timeout: 15000 });
    const reply = await w.locator(".m.a").nth(before).textContent();
    if (expect && !reply.includes(expect)) fail(`widget reply to "${text}" was "${reply}" (expected "${expect}")`);
    return reply;
  };
  await say("Do you offer free inspections?", "45 minutes");
  await say("My roof started leaking after last night's storm", "home or a commercial");
  await say("It's a house", "ZIP");
  await say("76201", "name");
  await say("James Carter", "phone");
  const offer = await say("940-555-0123", "openings");
  await site.screenshot({ path: `${SHOTS}04-widget-offer.png` });
  const confirm = await say("the first one", "You're all set, James!");
  step(`widget booked: ${confirm.slice(0, 80)}…`);

  // Owner sees it
  await page.goto(`${BASE}/app/dashboard`);
  await page.getByText("James Carter").first().waitFor();
  await shot("05-dashboard");
  step("dashboard shows new lead and appointment");
  await page.goto(`${BASE}/app/inbox`);
  await page.getByRole("button", { name: /James Carter/ }).first().click();
  await page.getByText("AI action · Booked appointment: success").waitFor();
  await shot("06-inbox");
  step("inbox shows conversation with AI actions");
  await page.goto(`${BASE}/app/leads`);
  await page.getByRole("region", { name: "Appointment" }).getByText("James Carter").first().waitFor();
  await shot("07-leads-board");
  step("lead is in the Appointment column");
  await page.goto(`${BASE}/app/analytics`);
  await page.getByText("Conversion funnel").waitFor();
  await shot("08-analytics");
  await page.goto(`${BASE}/app/appointments`);
  await page.getByText("James Carter").first().waitFor();
  step("appointment listed");

  // Mobile
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/app/leads`);
  await page.getByRole("button", { name: "Menu" }).click();
  await shot("09-mobile-leads");
  step("mobile layout");

  if (errors.length) fail(`page errors: ${errors.join(" | ")}`);
  console.log(`\nALL BROWSER ACCEPTANCE STEPS PASSED (offer: ${offer.slice(0, 60)}…)`);
} catch (e) {
  await shot("zz-failure").catch(() => undefined);
  if (errors.length) console.error("PAGE ERRORS:", errors.join("\n"));
  console.error(e);
  process.exitCode = 1;
} finally {
  await browser.close();
}
