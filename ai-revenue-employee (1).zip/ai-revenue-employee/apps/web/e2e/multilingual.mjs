/**
 * Multilingual + voice browser test against the running stack.
 *   BASE_URL=http://localhost:3000 CHROME_PATH=/path/to/chrome node e2e/multilingual.mjs
 *
 * Voice: Chromium's fake microphone plays e2e/fixtures/voice.wav (a voiced test tone with pauses). The page streams it
 * over the voice websocket; the API runs voice-activity detection and relays each utterance to the ASR server named in
 * VIBEVOICE_ASR_URL. In CI that is the protocol simulator (apps/api/tests/fake_vibevoice.py) with scripted transcripts,
 * because the real VibeVoice model needs a GPU — everything else in the voice path is the production code.
 */
import { execFileSync } from "node:child_process";
import { existsSync, mkdirSync } from "node:fs";

import { chromium as pw } from "playwright-core";

const BASE = process.env.BASE_URL ?? "http://localhost:3000";
const SHOTS = new URL("./screenshots/", import.meta.url).pathname;
const FIX = new URL("./fixtures/", import.meta.url).pathname;
mkdirSync(SHOTS, { recursive: true });
mkdirSync(FIX, { recursive: true });
const WAV = `${FIX}voice.wav`;
if (!existsSync(WAV)) {
  // 1.5 s quiet, 1.5 s voiced tone, 2.5 s quiet — looped by Chromium.
  execFileSync("ffmpeg", ["-y", "-loglevel", "error", "-f", "lavfi", "-i",
    "aevalsrc='if(between(t,1.5,3),0.3*sin(2*PI*220*t)*(0.6+0.4*sin(2*PI*3*t)),0)':s=48000:d=5.5", "-ac", "1", WAV]);
}

const step = (msg) => console.log(`✓ ${msg}`);
const browser = await pw.launch({
  executablePath: process.env.CHROME_PATH,
  headless: true,
  args: ["--use-fake-ui-for-media-stream", "--use-fake-device-for-media-stream", `--use-file-for-fake-audio-capture=${WAV}`, "--autoplay-policy=no-user-gesture-required"],
});
const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 }, permissions: ["microphone"] });
const page = await ctx.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const shot = (name, full = false) => page.screenshot({ path: `${SHOTS}${name}.png`, fullPage: full });
const transcript = () => page.locator("[aria-live=polite]").first();

async function newDemo(lang) {
  await page.goto(`${BASE}/demo`);
  await page.getByLabel("Business name").fill("Lone Star Roofing");
  if (lang) await page.getByLabel("Customer language").selectOption(lang);
  await page.getByRole("button", { name: /Create my demo|Start a new demo/ }).click();
  await page.getByText("Speaking:").waitFor();
}
async function say(text, expect) {
  const before = await transcript().innerText();
  await page.getByLabel("Message").fill(text);
  await page.getByRole("button", { name: "Send", exact: true }).click();
  await page.waitForFunction(
    ([n, e]) => { const t = document.querySelector("[aria-live=polite]")?.textContent ?? ""; return t.length > n && t.includes(e); },
    [before.length, expect], { timeout: 15000 },
  );
}

try {
  // ---- Spanish, typed, full booking
  await newDemo();
  await page.getByRole("button", { name: /^Hola, mi techo/ }).click();
  await page.waitForFunction(() => document.querySelector("[aria-live=polite]")?.textContent?.includes("vivienda"), null, { timeout: 15000 });
  await page.getByText("Speaking: Español").waitFor();
  step("Spanish detected from the first message; agent replies in Spanish");
  await say("Es una casa", "código postal");
  await say("76201", "nombre");
  await say("Me llamo José García", "teléfono");
  await say("940-555-0123", "Cuál le conviene");
  await say("la primera", "quedó programada");
  await shot("ml-01-spanish-booking");
  step("Spanish conversation booked an inspection");

  // ---- Voice: microphone -> websocket -> VAD -> VibeVoice ASR -> AI -> spoken reply
  await newDemo("es");
  await page.getByRole("button", { name: "Talk to the AI employee" }).click();
  await page.waitForFunction(() => document.querySelector("[aria-live=polite]")?.textContent?.includes("vivienda"), null, { timeout: 30000 });
  await page.getByText(/VibeVoice streaming ASR/).waitFor({ timeout: 5000 }).catch(() => {});
  await shot("ml-05-voice-streaming");
  step("Voice turn: streamed microphone audio was recognized and answered in Spanish");
  await page.getByRole("button", { name: "Stop voice conversation" }).click();

  // ---- Embeddable widget on a customer's website: one fresh conversation per language
  const demo = await (await page.request.post(`${BASE}/api/v1/public/demo`, { data: { business_name: "Lone Star Roofing", industry: "roofing" } })).json();
  await page.route(`${BASE}/__customer-site`, (r) =>
    r.fulfill({ contentType: "text/html", body: `<!doctype html><html><head><meta charset="utf-8"><title>Lone Star Roofing</title></head><body style="font-family:sans-serif;padding:40px;background:#f3f5f8"><h1>Lone Star Roofing</h1><p>Family roofers in Denton since 1998.</p><script src="${BASE}/widget.js" data-token="${demo.widget_token}" async></script></body></html>` }),
  );
  const host = page.locator("#are-chat-widget");
  const assistantCount = () => page.evaluate(() => document.querySelector("#are-chat-widget")?.shadowRoot?.querySelectorAll(".m.a").length ?? 0);
  for (const [code, text, expect, name] of [
    ["zh", "你好，暴风雨后我家屋顶漏水了，可以来检查吗？", "邮政编码", "chinese"],
    ["ar", "مرحبا، سقف بيتي يسرب الماء بعد العاصفة. هل يمكنكم فحصه؟", "الرمز البريدي", "arabic"],
    ["vi", "Xin chào, mái nhà của tôi bị dột sau cơn bão. Bạn có thể kiểm tra không?", "ZIP", "vietnamese"],
    ["tl", "Magandang araw, may tagas ang bubong ko pagkatapos ng bagyo. Pwede po bang ipa-inspeksyon?", "bahay", "tagalog"],
    ["fr", "Bonjour, mon toit fuit depuis l'orage. Pouvez-vous l'inspecter ?", "maison", "french"],
  ]) {
    await page.goto(`${BASE}/__customer-site`);
    await page.evaluate(() => localStorage.clear());
    await page.reload();
    await host.locator(".launch").click();
    await host.locator(".lang").selectOption(code);
    await page.waitForFunction(() => {
      const m = document.querySelector("#are-chat-widget")?.shadowRoot?.querySelector(".m.a");
      return !!m && !m.textContent?.startsWith("Hi!");
    }, null, { timeout: 10000 });
    const greeting = await host.locator(".m.a").first().innerText();
    const n = await assistantCount();
    await host.locator("textarea").fill(text);
    await host.locator(".send").click();
    await page.waitForFunction((k) => (document.querySelector("#are-chat-widget")?.shadowRoot?.querySelectorAll(".m.a").length ?? 0) > k, n, { timeout: 15000 });
    const reply = await host.locator(".m.a").last().innerText();
    if (!reply.includes(expect)) throw new Error(`${name}: expected "${expect}" in "${reply}"`);
    if (code === "ar") {
      const d = await host.locator(".m.a").last().evaluate((el) => getComputedStyle(el).direction);
      if (d !== "rtl") throw new Error(`Arabic bubble direction is ${d}`);
    }
    await page.waitForTimeout(300);
    await shot(`ml-03-widget-${name}`);
    step(`Website widget in ${name}: greeting "${greeting.slice(0, 40)}…" → reply contains "${expect}"`);
  }

  if (errors.length) throw new Error(`Page errors: ${errors.join(" | ")}`);
  console.log("\nAll multilingual browser checks passed.");
} catch (e) {
  await shot("ml-failure", true).catch(() => {});
  console.error(`✗ ${e.message}`);
  process.exitCode = 1;
} finally {
  await browser.close();
}
