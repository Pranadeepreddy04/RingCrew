/**
 * Owner UI in several languages (run after `python -m app.cli seed-demo`): enables all 7 languages on the seeded
 * Mike's Roofing agent, then captures the languages settings, a Spanish test-console chat and the inbox.
 *   CHROME_PATH=/path/to/chrome node e2e/owner-multilingual.mjs
 */
import { chromium as pw } from "playwright-core";
const BASE = "http://localhost:3000";
const SHOTS = new URL("./screenshots/", import.meta.url).pathname;
const b = await pw.launch({ executablePath: process.env.CHROME_PATH, headless: true });
const ctx = await b.newContext({ viewport: { width: 1360, height: 900 } });
const page = await ctx.newPage();
const login = await (await page.request.post(`${BASE}/api/v1/auth/login`, { data: { email: "mike@mikes-roofing.example.com", password: "DemoPass!2026" } })).json();
const me = await (await page.request.get(`${BASE}/api/v1/auth/me`)).json();
const org = me.organizations[0].id;
const h = { "X-CSRF-Token": login.csrf_token, "X-Organization-Id": org };
const agents = await (await page.request.get(`${BASE}/api/v1/agents`, { headers: h })).json();
const a = agents[0];
const r = await page.request.patch(`${BASE}/api/v1/agents/${a.id}`, { headers: h, data: { languages: ["en", "es", "zh", "tl", "vi", "ar", "fr"], greetings: { es: "¡Hola! Gracias por llamar a Mike's Roofing. Soy Sarah, ¿en qué le puedo ayudar?" } } });
console.log("patch", r.status());
await page.goto(`${BASE}/app/ai-employees`);
await page.getByRole("tab", { name: "Settings" }).click().catch(() => {});
await page.getByText("Languages it speaks").waitFor();
await page.getByText("Languages it speaks").scrollIntoViewIfNeeded();
await page.waitForTimeout(500);
await page.screenshot({ path: `${SHOTS}ml-07-agent-languages.png`, fullPage: true });
await page.getByRole("tab", { name: "Test" }).click();
await page.getByLabel("Start in language").selectOption("es");
await page.waitForTimeout(1500);
await page.getByLabel("Message").fill("Hola, mi techo tiene una gotera después de la tormenta. ¿Pueden inspeccionarlo?");
await page.getByRole("button", { name: "Send", exact: true }).click();
await page.waitForFunction(() => document.body.innerText.includes("vivienda"));
await page.getByLabel("Message").fill("Es una casa");
await page.getByRole("button", { name: "Send", exact: true }).click();
await page.waitForFunction(() => document.body.innerText.includes("código postal"));
await page.waitForTimeout(400);
await page.screenshot({ path: `${SHOTS}ml-08-test-console-spanish.png`, fullPage: true });
await page.goto(`${BASE}/app/inbox`);
await page.waitForTimeout(2500);
await page.screenshot({ path: `${SHOTS}ml-09-inbox.png` });
await b.close();
console.log("ok");
