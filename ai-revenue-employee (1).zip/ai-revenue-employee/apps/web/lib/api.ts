"use client";

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

const ORG_KEY = "are_org";

export function getOrgId(): string | null {
  try {
    return localStorage.getItem(ORG_KEY);
  } catch {
    return null;
  }
}

export function setOrgId(id: string | null): void {
  try {
    if (id) localStorage.setItem(ORG_KEY, id);
    else localStorage.removeItem(ORG_KEY);
  } catch {
    /* storage unavailable (private mode) — the API falls back to the first organization */
  }
}

function csrf(): string | null {
  const m = document.cookie.match(/(?:^|;\s*)are_csrf=([^;]+)/);
  return m?.[1] ? decodeURIComponent(m[1]) : null;
}

type Body = Record<string, unknown> | unknown[] | FormData | undefined;

export async function api<T = unknown>(path: string, opts: { method?: string; body?: Body; headers?: Record<string, string> } = {}): Promise<T> {
  const method = opts.method ?? (opts.body ? "POST" : "GET");
  const headers: Record<string, string> = { ...(opts.headers ?? {}) };
  const org = getOrgId();
  if (org) headers["X-Organization-Id"] = org;
  if (method !== "GET") {
    const token = csrf();
    if (token) headers["X-CSRF-Token"] = token;
  }
  let body: BodyInit | undefined;
  if (opts.body instanceof FormData) body = opts.body;
  else if (opts.body !== undefined) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(opts.body);
  }
  let res: Response;
  try {
    res = await fetch(`/api/v1${path}`, { method, headers, body, credentials: "same-origin" });
  } catch {
    throw new ApiError(0, "network_error", "Can't reach the server. Check your connection and try again.");
  }
  if (res.status === 204) return undefined as T;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = (data as { error?: { code?: string; message?: string; details?: unknown } }).error ?? {};
    throw new ApiError(res.status, err.code ?? "error", err.message ?? `Request failed (${res.status})`, err.details);
  }
  return data as T;
}

export const get = <T,>(p: string) => api<T>(p);
export const post = <T,>(p: string, body?: Body) => api<T>(p, { method: "POST", body: body ?? {} });
export const put = <T,>(p: string, body?: Body) => api<T>(p, { method: "PUT", body: body ?? {} });
export const patch = <T,>(p: string, body?: Body) => api<T>(p, { method: "PATCH", body: body ?? {} });
export const del = <T,>(p: string, body?: Body) => api<T>(p, { method: "DELETE", body });

export function errorText(e: unknown): string {
  if (e instanceof ApiError) {
    if (e.code === "validation_error" && Array.isArray(e.details)) {
      return (e.details as { loc: string[]; msg: string }[]).map((d) => `${d.loc.slice(1).join(".")}: ${d.msg.replace("Value error, ", "")}`).join("; ");
    }
    if (Array.isArray(e.details) && typeof e.details[0] === "string") return `${e.message}: ${(e.details as string[]).join("; ")}`;
    return e.message;
  }
  return "Something went wrong. Try again.";
}

export function money(cents: number | null | undefined): string {
  if (cents == null) return "—";
  return (cents / 100).toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
}

export function when(iso: string | null | undefined, tz?: string): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-US", { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", timeZone: tz });
}

export function ago(iso: string | null | undefined): string {
  if (!iso) return "";
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export function phone(p: string | null | undefined): string {
  if (!p) return "—";
  const m = p.match(/^\+1(\d{3})(\d{3})(\d{4})$/);
  return m ? `(${m[1]}) ${m[2]}-${m[3]}` : p;
}

export const label = (s: string | null | undefined) =>
  s ? s.replace(/^ai_/, "AI ").replace(/_/g, " ").replace(/\bsms\b/gi, "SMS").replace(/^\w/, (c) => c.toUpperCase()) : "—";
