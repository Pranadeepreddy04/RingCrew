"use client";

import { useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";

import { ApiError, get, getOrgId, post, setOrgId } from "./api";
import type { Me, OrgSummary } from "./types";

interface AuthState {
  me: Me | null;
  loading: boolean;
  org: OrgSummary | null;
  refresh: () => Promise<Me | null>;
  switchOrg: (id: string) => void;
  logout: () => Promise<void>;
  can: (perm: Permission) => boolean;
}

export type Permission = "configure" | "billing" | "team" | "integrations" | "leads" | "conversations" | "analytics";

const PERMS: Record<string, Permission[]> = {
  owner: ["configure", "billing", "team", "integrations", "leads", "conversations", "analytics"],
  manager: ["configure", "leads", "conversations", "analytics"],
  staff: ["leads", "conversations"],
  readonly: ["analytics"],
};

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const [orgId, setOrg] = useState<string | null>(null);

  const router = useRouter();

  const apply = useCallback((m: Me | null) => {
    setMe(m);
    if (m) {
      const stored = getOrgId();
      const chosen = m.organizations.find((o) => o.id === stored) ?? m.organizations[0] ?? null;
      setOrgId(chosen?.id ?? null);
      setOrg(chosen?.id ?? null);
    }
    setLoading(false);
    return m;
  }, []);

  const fetchMe = useCallback(
    () =>
      get<Me>("/auth/me").catch((e: unknown) => {
        if (e instanceof ApiError && e.status !== 401) throw e;
        return null;
      }),
    [],
  );

  const refresh = useCallback(async () => apply(await fetchMe().catch(() => null)), [apply, fetchMe]);

  useEffect(() => {
    fetchMe()
      .then(apply)
      .catch(() => setLoading(false));
  }, [apply, fetchMe]);

  const switchOrg = (id: string) => {
    setOrgId(id);
    setOrg(id);
    // Full reload so no page keeps data from the previous business on screen.
    window.location.assign(new URL("/app/dashboard", window.location.origin).href);
  };

  const logout = async () => {
    try {
      await post("/auth/logout");
    } finally {
      setOrgId(null);
      setMe(null);
      router.replace("/login");
    }
  };

  const org = me?.organizations.find((o) => o.id === orgId) ?? null;
  const can = (perm: Permission) => !!org && (PERMS[org.role] ?? []).includes(perm);
  return <Ctx.Provider value={{ me, loading, org, refresh, switchOrg, logout, can }}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used inside AuthProvider");
  return v;
}

/** Redirects to /login when signed out; to onboarding when there's no organization yet. */
export function useRequireAuth(opts: { needOrg?: boolean } = { needOrg: true }) {
  const auth = useAuth();
  const router = useRouter();
  useEffect(() => {
    if (auth.loading) return;
    if (!auth.me) router.replace(`/login?next=${encodeURIComponent(window.location.pathname)}`);
    else if (opts.needOrg && auth.me.organizations.length === 0) router.replace("/onboarding");
  }, [auth.loading, auth.me, opts.needOrg, router]);
  return auth;
}
