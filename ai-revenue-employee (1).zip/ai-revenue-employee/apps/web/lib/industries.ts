export interface IndustryPage {
  slug: string;
  key: string;
  name: string;
  headline: string;
  intro: string;
  asks: string[];
  books: string;
  available: "now" | "beta" | "planned";
}

export const INDUSTRY_PAGES: IndustryPage[] = [
  { slug: "roofing", key: "roofing", name: "Roofing", headline: "Turn more roofing calls into inspections.", available: "now",
    intro: "After a storm your phone rings off the hook while your crews are on roofs. Your AI employee answers every caller, finds out what happened, and puts inspections on your calendar.",
    asks: ["Repair, replacement or inspection", "Home or commercial", "Property ZIP code (checked against your service area)", "Active leak or storm damage", "Name and callback number"],
    books: "Roof inspections, in open slots on your real calendar" },
  { slug: "hvac", key: "hvac", name: "HVAC", headline: "Answer every HVAC lead, even after hours.", available: "now",
    intro: "When the AC quits at 9pm, homeowners call whoever answers. Your AI employee picks up, sorts heating from cooling and repair from replacement, and books the visit.",
    asks: ["Heating or cooling", "Repair, maintenance or replacement estimate", "Home or commercial", "ZIP code", "How urgent it is"],
    books: "Service visits and replacement estimates" },
  { slug: "plumbing", key: "plumbing", name: "Plumbing", headline: "Respond to plumbing calls before customers call someone else.", available: "now",
    intro: "A leaking pipe doesn't wait. Your AI employee answers right away, follows your emergency instructions when water is flowing, and gets a plumber scheduled.",
    asks: ["What's going on (leak, clog, water heater…)", "Whether water is actively leaking", "Home or commercial", "ZIP code", "Urgency"],
    books: "Service visits, with emergencies routed to your on-call number" },
  { slug: "construction", key: "remodeling", name: "Remodeling & construction", headline: "Qualify remodeling projects before you drive out.", available: "now",
    intro: "Your AI employee learns what the project is, where it is and when they want to start, then books a consultation or site visit.",
    asks: ["Project type (kitchen, bath, addition…)", "Home or commercial", "ZIP code", "Desired start timeline", "Budget range, if you want to ask"],
    books: "Consultations and site visits" },
  { slug: "auto-repair", key: "auto_repair", name: "Auto repair", headline: "Turn service calls into booked appointments.", available: "planned",
    intro: "Vehicle intake (year, make, model, mileage, symptoms) and service booking. Planned for a later release.",
    asks: ["Vehicle year, make and model", "Mileage", "Symptoms", "Preferred date"], books: "Service appointments" },
  { slug: "restaurants", key: "restaurants", name: "Restaurants", headline: "Handle routine calls and reservation requests without pulling staff away from guests.", available: "planned",
    intro: "Hours, location, approved menu answers and reservations through supported systems. Planned for a later release.",
    asks: ["Party size", "Date and time", "Catering or private-event details"], books: "Reservations through supported reservation systems" },
  { slug: "real-estate", key: "real_estate", name: "Real estate", headline: "Respond to buyer and seller inquiries the moment they come in.", available: "planned",
    intro: "Buyer and seller intake, showing requests and consultations, configured for Fair Housing compliance. Planned for a later release.",
    asks: ["Buying or selling", "Area and property type", "Timeline"], books: "Consultations and showings" },
  { slug: "salons", key: "salons", name: "Salons & spas", headline: "Fill your book without answering the phone mid-appointment.", available: "planned",
    intro: "Service and stylist selection, booking, reminders and rescheduling. Planned for a later release.",
    asks: ["Service", "Preferred stylist", "Date and time"], books: "Appointments" },
];

export const findIndustry = (slug: string) => INDUSTRY_PAGES.find((p) => p.slug === slug);
