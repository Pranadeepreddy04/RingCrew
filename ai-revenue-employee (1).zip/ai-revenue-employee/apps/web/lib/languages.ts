/** Conversation languages supported by the AI employee (mirrors apps/api/app/ai/i18n.py). */
export interface Language {
  code: string;
  name: string;
  native: string;
  bcp47: string;
  rtl: boolean;
  /** Recognized by VibeVoice-ASR-Streaming when the server has it configured; otherwise the browser/Twilio recognizer is used. */
  vibevoice: boolean;
}

export const LANGUAGES: Language[] = [
  { code: "en", name: "English", native: "English", bcp47: "en-US", rtl: false, vibevoice: true },
  { code: "es", name: "Spanish", native: "Español", bcp47: "es-US", rtl: false, vibevoice: true },
  { code: "zh", name: "Chinese (Mandarin)", native: "中文", bcp47: "zh-CN", rtl: false, vibevoice: true },
  { code: "tl", name: "Tagalog", native: "Tagalog", bcp47: "fil-PH", rtl: false, vibevoice: false },
  { code: "vi", name: "Vietnamese", native: "Tiếng Việt", bcp47: "vi-VN", rtl: false, vibevoice: false },
  { code: "ar", name: "Arabic", native: "العربية", bcp47: "ar-SA", rtl: true, vibevoice: false },
  { code: "fr", name: "French", native: "Français", bcp47: "fr-FR", rtl: false, vibevoice: true },
];

export const byCode = (code: string | null | undefined): Language => LANGUAGES.find((l) => l.code === code) ?? (LANGUAGES[0] as Language);

/** Sample opening lines a customer might say, used as one-tap suggestions in the demo and test console. */
export const SAMPLE_OPENERS: Record<string, string> & { en: string } = {
  en: "My roof is leaking after the storm. Can someone inspect it?",
  es: "Hola, mi techo tiene una gotera después de la tormenta. ¿Pueden inspeccionarlo?",
  zh: "你好，暴风雨后我家屋顶漏水了，可以来检查吗？",
  tl: "Magandang araw, may tagas ang bubong ko pagkatapos ng bagyo. Pwede po bang ipa-inspeksyon?",
  vi: "Xin chào, mái nhà của tôi bị dột sau cơn bão. Bạn có thể kiểm tra không?",
  ar: "مرحبا، سقف بيتي يسرب الماء بعد العاصفة. هل يمكنكم فحصه؟",
  fr: "Bonjour, mon toit fuit depuis l'orage. Pouvez-vous l'inspecter ?",
};
