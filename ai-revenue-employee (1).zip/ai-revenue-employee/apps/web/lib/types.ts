export type Role = "owner" | "manager" | "staff" | "readonly";

export interface OrgSummary {
  id: string;
  name: string;
  role: Role;
  industry: string;
  onboarding_completed: boolean;
  onboarding_step: number;
  is_demo: boolean;
}

export interface Me {
  user: { id: string; email: string; name: string; email_verified: boolean; is_superadmin: boolean };
  organizations: OrgSummary[];
  csrf_token: string;
  impersonating: boolean;
}

export interface CustomerRef {
  id: string;
  name: string | null;
  phone: string | null;
  email?: string | null;
}

export interface Lead {
  id: string;
  customer: CustomerRef | null;
  conversation_id: string | null;
  source: string;
  channel: string;
  service: string | null;
  summary: string | null;
  status: string;
  is_qualified: boolean;
  qualification: Record<string, unknown>;
  urgency: string | null;
  assigned_user_id: string | null;
  last_activity_at: string;
  next_follow_up_at: string | null;
  estimated_value_cents: number | null;
  actual_revenue_cents: number | null;
  attribution_source: string | null;
  created_at: string;
  appointment?: { id: string; start_at: string; status: string } | null;
}

export interface Appointment {
  id: string;
  customer: CustomerRef | null;
  lead_id: string | null;
  conversation_id: string | null;
  service: string;
  location: string | null;
  start_at: string;
  end_at: string;
  timezone: string;
  status: string;
  source: string;
  notes: string | null;
}

export interface Conversation {
  id: string;
  channel: string;
  language?: string;
  status: string;
  handoff_active: boolean;
  handoff_reason: string | null;
  summary: string | null;
  customer: CustomerRef | null;
  lead_id: string | null;
  appointment_id: string | null;
  collected: Record<string, unknown>;
  last_message_at: string;
  created_at: string;
  preview?: string;
}

export interface Message {
  id: string;
  role: "customer" | "ai" | "human" | "system" | "tool";
  content: string;
  created_at: string;
  delivery_status: string | null;
  meta: Record<string, unknown>;
}

export interface Task {
  id: string;
  kind: string;
  title: string;
  description: string | null;
  status: string;
  priority: string;
  conversation_id: string | null;
  lead_id: string | null;
  created_at: string;
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  greeting: string;
  tone: string;
  language: string;
  languages: string[];
  greetings: Record<string, string>;
  voice: string | null;
  capabilities: string[];
  status: "draft" | "active" | "paused";
  industry: string;
  widget_token?: string;
  widget_settings?: Record<string, string>;
  activated_at: string | null;
}

export interface Profile {
  website: string | null;
  phone: string | null;
  address: string | null;
  description: string | null;
  employees_count: string | null;
  service_area_zips: string[];
  service_area_description: string | null;
  hours: Record<string, string[][]>;
  appointment_duration_minutes: number;
  booking_lead_time_hours: number;
  booking_horizon_days: number;
  emergency_instructions: string | null;
  escalation_rules: string | null;
  escalation_phone: string | null;
  pricing_info: string | null;
  policies: string | null;
}

export interface Org {
  id: string;
  name: string;
  industry: string;
  timezone: string;
  status: string;
  is_demo: boolean;
  onboarding_step: number;
  onboarding_completed: boolean;
  pipeline_stages: string[];
  recording: { enabled?: boolean; consent_configured?: boolean };
  ai_settings: { allow_fallback_provider?: boolean };
  notification_prefs: Record<string, boolean>;
  role: Role;
  profile: Profile | null;
  services: { id: string; name: string; description: string | null; active: boolean }[];
  entitlements: { usable: boolean; features: string[]; limits: Record<string, number>; plan: string | null; status: string };
}

export interface Paged<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
}
