import type { NextConfig } from "next";

const API_URL = process.env.API_URL ?? "http://localhost:8000";

const nextConfig: NextConfig = {
  // Docker images use the standalone server; Netlify's Next.js runtime packages the app itself.
  output: process.env.NETLIFY ? undefined : "standalone",
  poweredByHeader: false,
  async rewrites() {
    // The browser only talks to this origin; cookies stay first-party and no secrets reach the client.
    return [
      { source: "/api/:path*", destination: `${API_URL}/api/:path*` },
      { source: "/widget.js", destination: `${API_URL}/widget.js` },
    ];
  },
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(self), geolocation=()" }, // microphone: voice chat in the demo and test console
        ],
      },
    ];
  },
};

export default nextConfig;
