# VibeVoice-ASR-Streaming for the voice agent

[VibeVoice-ASR-Streaming](https://github.com/microsoft/VibeVoice/blob/main/docs/vibevoice-asr-streaming.md) is Microsoft's
open-source (MIT) unified streaming speech-recognition model. It transcribes while the caller is still speaking and
accepts hotwords. The API uses it for phone calls (Twilio Media Streams) and for browser voice in the website widget.

## What runs where

```
caller ──Twilio──> /api/v1/webhooks/voice/*  (TwiML: <Start><Stream>, replies via call update)
           └─ media stream (8 kHz μ-law) ──> wss://API/api/v1/voice/stream ─┐
browser mic (PCM) ──────────────────────> wss://API/api/v1/public/…/voice ─┤
                                                                           ├─ voice-activity detection, 1 ASR session per utterance
                                                                           └─> ws://GPU:7870/ws/asr  (this server, float32 PCM @ 24 kHz)
```

## Run it

Requirements: Linux host with an NVIDIA GPU (the 7B checkpoint needs roughly 20 GB+ of GPU memory in bf16;
check the model card), Docker with the NVIDIA container toolkit.

```bash
docker build -t are-vibevoice infrastructure/vibevoice
docker run -d --gpus all -p 7870:7870 -v vv-models:/models --name vibevoice are-vibevoice
curl http://localhost:7870/healthz      # {"status":"ok"} once the model is loaded
```

Point the API at it (only the API needs to reach port 7870; do not expose it publicly):

```
VOICE_ASR_PROVIDER=vibevoice
VIBEVOICE_ASR_URL=http://<gpu-host>:7870
VIBEVOICE_LANGUAGES=en,es,zh,fr          # languages routed to VibeVoice; others use Twilio speech recognition
VIBEVOICE_HOTWORDS=Mike's Roofing,shingles   # optional; business name, agent name and services are added automatically
VOICE_ENDPOINT_SILENCE_MS=700            # end-of-utterance silence
```

If the ASR server is unreachable during a call, that call switches to Twilio speech recognition automatically.

## Languages

The VibeVoice README states the streaming model supports 10 languages but does not list them in the streaming
docs. English, Spanish, Chinese and French are routed to it by default. Test Vietnamese, Tagalog or Arabic audio with
`demo/vibevoice_asr_streaming_inference_from_file.py` before adding them to `VIBEVOICE_LANGUAGES`.

## Verified here vs. needs your hardware

* Verified in CI: the client speaks the server's exact wire protocol (`/config`, `/ws/asr`, options frame, float32
  frames, cumulative text, `"end"` → `done`) against a protocol-faithful simulator (`apps/api/tests/fake_vibevoice.py`),
  end to end through a real browser microphone stream and through a simulated Twilio media stream.
* Not verified here (no GPU): recognition accuracy and latency of the real model. Measure on your GPU before launch.
