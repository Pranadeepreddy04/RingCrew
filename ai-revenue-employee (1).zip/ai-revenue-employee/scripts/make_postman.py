"""Generate the Postman collection (v2.1) from the API's OpenAPI schema.

    cd apps/api && python ../../scripts/make_postman.py > ../../docs/postman/ai-revenue-employee.postman_collection.json

Folders:
  0. Quick start — multilingual demo   (no account needed: demo → Spanish/Chinese/Arabic… conversations, scripted)
  1. Quick start — owner               (sign up → business → AI employee with 7 languages → test console in Spanish)
  2+. Every REST endpoint, grouped by tag, with example bodies from the schema.
Cookies (session) are kept by Postman's cookie jar; the login/signup test scripts store the CSRF token and organization id.
"""

from __future__ import annotations

import json
import sys
import uuid
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "apps" / "api"))

from app.main import app  # noqa: E402

SPEC = app.openapi()
COMPONENTS = SPEC.get("components", {}).get("schemas", {})

AUTH_HEADERS = [
    {"key": "X-CSRF-Token", "value": "{{csrfToken}}", "description": "Required on unsafe requests with a cookie session"},
    {"key": "X-Organization-Id", "value": "{{organizationId}}"},
]
JSON_HEADER = {"key": "Content-Type", "value": "application/json"}


def _resolve(schema: dict[str, Any]) -> dict[str, Any]:
    while "$ref" in schema:
        schema = COMPONENTS[schema["$ref"].split("/")[-1]]
    return schema


def example(schema: dict[str, Any], depth: int = 0) -> Any:
    schema = _resolve(schema)
    if depth > 4:
        return None
    if "example" in schema:
        return schema["example"]
    if "default" in schema and schema["default"] is not None:
        return schema["default"]
    if "anyOf" in schema:
        options = [s for s in schema["anyOf"] if _resolve(s).get("type") != "null"]
        return example(options[0], depth + 1) if options else None
    t = schema.get("type")
    if t == "object" or "properties" in schema:
        req = set(schema.get("required", []))
        props = schema.get("properties", {})
        return {k: example(v, depth + 1) for k, v in props.items() if k in req or depth == 0}
    if t == "array":
        return [example(schema.get("items", {}), depth + 1)]
    if t == "integer":
        return 1
    if t == "number":
        return 1.0
    if t == "boolean":
        return False
    if schema.get("format") == "email":
        return "owner@example.com"
    if schema.get("format") == "uuid":
        return "00000000-0000-0000-0000-000000000000"
    return ""


def path_to_url(path: str) -> dict[str, Any]:
    raw_path = path.replace("{", "{{").replace("}", "}}")
    segs = [s for s in raw_path.split("/") if s]
    return {"raw": "{{baseUrl}}" + raw_path, "host": ["{{baseUrl}}"], "path": segs}


def item(name: str, method: str, path: str, body: Any = None, *, auth: bool = True, tests: list[str] | None = None, desc: str = "", headers: list[dict[str, str]] | None = None) -> dict[str, Any]:
    url = path_to_url(path)
    if "?" in path:
        base, q = path.split("?", 1)
        url = path_to_url(base)
        url["raw"] += "?" + q
        url["query"] = [{"key": k, "value": v} for k, v in (p.split("=", 1) for p in q.split("&"))]
    req: dict[str, Any] = {"method": method.upper(), "header": list(headers or []) + (AUTH_HEADERS if auth else []), "url": url}
    if desc:
        req["description"] = desc
    if body is not None:
        req["header"].append(JSON_HEADER)
        req["body"] = {"mode": "raw", "raw": json.dumps(body, ensure_ascii=False, indent=2), "options": {"raw": {"language": "json"}}}
    out: dict[str, Any] = {"name": name, "request": req}
    if tests:
        out["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": tests}}]
    return out


def visitor(name: str, text: str, expect: str) -> dict[str, Any]:
    return item(
        name,
        "post",
        "/api/v1/public/conversations/{conversationId}/messages",
        {"text": text},
        auth=False,
        headers=[{"key": "X-Visitor-Token", "value": "{{visitorToken}}"}],
        tests=[
            "const d = pm.response.json();",
            "pm.test('200', () => pm.response.to.have.status(200));",
            f"pm.test('reply contains {expect}', () => pm.expect(d.messages[0].content).to.include({json.dumps(expect, ensure_ascii=False)}));",
            "console.log(`[${d.language}] ${d.messages[0].content}`);",
        ],
    )


def start_conv(name: str, language: str | None) -> dict[str, Any]:
    return item(
        name,
        "post",
        "/api/v1/public/widget/{widgetToken}/conversations",
        {"language": language} if language else {},
        auth=False,
        tests=[
            "const d = pm.response.json();",
            "pm.test('201', () => pm.response.to.have.status(201));",
            "pm.collectionVariables.set('conversationId', d.conversation_id);",
            "pm.collectionVariables.set('visitorToken', d.visitor_token);",
            "console.log(`[${d.language}] ${d.messages[0].content}`);",
        ],
    )


quick_demo = {
    "name": "0. Quick start — multilingual demo (no account)",
    "description": "Creates a temporary demo business (5 per hour per IP), then talks to its AI employee in Spanish, Chinese, Vietnamese, Tagalog, Arabic and French. Run the folder with the Collection Runner. Replies are printed in the Postman console.",
    "item": [
        item(
            "Create demo business",
            "post",
            "/api/v1/public/demo",
            {"business_name": "Lone Star Roofing", "industry": "roofing", "website": None},
            auth=False,
            tests=["const d = pm.response.json();", "pm.test('201', () => pm.response.to.have.status(201));", "pm.collectionVariables.set('widgetToken', d.widget_token);"],
        ),
        item("Widget config (languages, voice mode)", "get", "/api/v1/public/widget/{widgetToken}/config", auth=False,
             tests=["const d = pm.response.json();", "pm.test('7 languages', () => pm.expect(d.languages.length).to.eql(7));", "console.log(d.voice_input);"]),
        start_conv("ES · start conversation (auto-detect)", None),
        visitor("ES · roof leak", "Hola, mi techo tiene una gotera después de la tormenta. ¿Pueden inspeccionarlo?", "vivienda"),
        visitor("ES · house", "Es una casa", "código postal"),
        visitor("ES · ZIP", "76201", "nombre"),
        visitor("ES · name", "Me llamo José García", "teléfono"),
        visitor("ES · phone", "940-555-0123", "conviene"),
        visitor("ES · first slot → booked", "la primera", "programada"),
        start_conv("ZH · start conversation in Chinese", "zh"),
        visitor("ZH · roof leak", "你好，暴风雨后我家屋顶漏水了，可以来检查吗？", "邮政编码"),
        visitor("ZH · hours", "你们的营业时间是几点？", "8:00"),
        start_conv("VI · start conversation", None),
        visitor("VI · roof leak", "Xin chào, mái nhà của tôi bị dột sau cơn bão. Bạn có thể kiểm tra không?", "ZIP"),
        start_conv("TL · start conversation", None),
        visitor("TL · roof leak", "Magandang araw, may tagas ang bubong ko pagkatapos ng bagyo. Pwede po bang ipa-inspeksyon?", "bahay"),
        start_conv("AR · start conversation", None),
        visitor("AR · roof leak", "مرحبا، سقف بيتي يسرب الماء بعد العاصفة. هل يمكنكم فحصه؟", "الرمز البريدي"),
        start_conv("FR · start conversation", None),
        visitor("FR · roof leak", "Bonjour, mon toit fuit depuis l'orage. Pouvez-vous l'inspecter ?", "maison"),
        start_conv("Safety · start", None),
        item(
            "Safety · gas smell in Spanish → handoff",
            "post",
            "/api/v1/public/conversations/{conversationId}/messages",
            {"text": "¡Huele a gas en la cocina!"},
            auth=False,
            headers=[{"key": "X-Visitor-Token", "value": "{{visitorToken}}"}],
            tests=["const d = pm.response.json();", "pm.test('handed off', () => pm.expect(d.handoff).to.eql(true));"],
        ),
    ],
}

quick_owner = {
    "name": "1. Quick start — owner (account, 7-language AI employee)",
    "description": "Signs up a new owner, creates a roofing business, adds an AI employee that speaks 7 languages and runs a Spanish test conversation. Uses the session cookie (Postman cookie jar) + X-CSRF-Token.",
    "item": [
        item(
            "Sign up",
            "post",
            "/api/v1/auth/signup",
            {"name": "Postman Owner", "email": "postman-{{$timestamp}}@example.com", "password": "Sup3r-secret-pw"},
            auth=False,
            tests=["const d = pm.response.json();", "pm.test('201', () => pm.response.to.have.status(201));", "pm.collectionVariables.set('csrfToken', d.csrf_token);"],
        ),
        item(
            "Create business",
            "post",
            "/api/v1/organizations",
            {"name": "Postman Roofing", "industry": "roofing", "timezone": "America/Chicago", "service_area_zips": ["76201", "76205"], "phone": "+19405550100"},
            headers=[{"key": "X-CSRF-Token", "value": "{{csrfToken}}"}],
            auth=False,
            tests=["const d = pm.response.json();", "pm.collectionVariables.set('organizationId', d.id);"],
        ),
        item("Business hours", "put", "/api/v1/organizations/current/profile",
             {"hours": {d: [["08:00", "17:00"]] for d in ("mon", "tue", "wed", "thu", "fri", "sat")}, "booking_lead_time_hours": 1, "escalation_phone": "+19405550199"}),
        item(
            "Create AI employee (7 languages)",
            "post",
            "/api/v1/agents",
            {"name": "Sarah", "role": "receptionist", "languages": ["en", "es", "zh", "tl", "vi", "ar", "fr"],
             "greetings": {"es": "¡Hola! Gracias por comunicarse con Postman Roofing. Soy Sarah, ¿en qué le puedo ayudar?"}},
            tests=["const d = pm.response.json();", "pm.collectionVariables.set('agentId', d.id);", "pm.collectionVariables.set('widgetToken', d.widget_token);"],
        ),
        item("Activate", "post", "/api/v1/agents/{agentId}/activate"),
        item(
            "Test console · start in Spanish",
            "post",
            "/api/v1/agents/{agentId}/test/conversations",
            {"language": "es"},
            tests=["const d = pm.response.json();", "pm.collectionVariables.set('testConversationId', d.conversation.id);", "console.log(d.messages[0].content);"],
        ),
        item(
            "Test console · Spanish message",
            "post",
            "/api/v1/agents/{agentId}/test/conversations/{testConversationId}/messages",
            {"text": "Mi techo tiene una gotera. ¿Pueden venir a revisarlo?", "simulate_channel": "voice"},
            tests=["const d = pm.response.json();", "pm.test('Spanish reply', () => pm.expect(d.conversation.language).to.eql('es'));", "console.log(d.reply);"],
        ),
        item("Inbox (language on each conversation)", "get", "/api/v1/conversations"),
    ],
}

# ---------------------------------------------------------------- every endpoint, grouped by tag
folders: dict[str, list[dict[str, Any]]] = {}
for path, ops in SPEC["paths"].items():
    for method, op in ops.items():
        if method not in ("get", "post", "put", "patch", "delete"):
            continue
        tag = (op.get("tags") or ["other"])[0]
        body = None
        content = (op.get("requestBody") or {}).get("content", {})
        if "application/json" in content:
            body = example(content["application/json"].get("schema", {}))
        elif "multipart/form-data" in content:
            body = None
        public = path.startswith("/api/v1/public") or path.startswith("/api/v1/auth/") and method == "post" and any(
            path.endswith(s) for s in ("signup", "login", "forgot-password", "reset-password", "verify-email")
        )
        name = op.get("summary") or f"{method.upper()} {path}"
        it = item(name, method, path, body, auth=not public, desc=op.get("description") or "")
        if path == "/api/v1/auth/login":
            it["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": [
                "const d = pm.response.json();",
                "if (d.csrf_token) pm.collectionVariables.set('csrfToken', d.csrf_token);",
            ]}}]
            it["request"]["body"]["raw"] = json.dumps({"email": "mike@mikes-roofing.example.com", "password": "DemoPass!2026"}, indent=2)
        folders.setdefault(tag, []).append(it)

realtime = {
    "name": "Realtime voice (WebSocket) — reference",
    "description": (
        "Postman's collection format cannot store WebSocket requests; create them with New → WebSocket.\n\n"
        "Browser voice: ws(s)://HOST/api/v1/public/conversations/{conversationId}/voice\n"
        '  1. send text {"type":"start","visitor_token":"{{visitorToken}}","sample_rate":16000,"format":"s16","language":"es"}\n'
        '  2. receive {"type":"ready","asr":"vibevoice"} or {"type":"unavailable"} (server has no streaming ASR → use browser speech recognition)\n'
        "  3. send binary frames: mono little-endian PCM (s16 or f32) at sample_rate\n"
        '  4. receive speech_start / partial / final / reply {messages, language, handoff}; send {"type":"stop"} to end an utterance\n\n'
        "Phone media stream: wss://HOST/api/v1/voice/stream — opened by Twilio from <Start><Stream> with a signed token "
        "parameter; not for manual use."
    ),
    "item": [],
}

collection = {
    "info": {
        "_postman_id": str(uuid.uuid5(uuid.NAMESPACE_URL, "ai-revenue-employee")),
        "name": "AI Revenue Employee API",
        "description": (
            "Generated from the FastAPI OpenAPI schema (scripts/make_postman.py). Set {{baseUrl}} to your deployment "
            "(e.g. http://localhost:3000 for the web app, which proxies /api, or http://localhost:8000 for the API directly). "
            "Start with folder 0 (no account needed). Seeded demo owner after `python -m app.cli seed-demo`: "
            "mike@mikes-roofing.example.com / DemoPass!2026 (development only)."
        ),
        "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json",
    },
    "variable": [
        {"key": "baseUrl", "value": "http://localhost:3000"},
        {"key": "csrfToken", "value": ""},
        {"key": "organizationId", "value": ""},
        {"key": "agentId", "value": ""},
        {"key": "widgetToken", "value": ""},
        {"key": "conversationId", "value": ""},
        {"key": "visitorToken", "value": ""},
        {"key": "testConversationId", "value": ""},
    ],
    "item": [quick_demo, quick_owner, realtime] + [{"name": f"API · {tag}", "item": items} for tag, items in sorted(folders.items())],
}

# path variables that are not collection variables get a placeholder value
known = {v["key"] for v in collection["variable"]}
for folder in collection["item"][3:]:
    for it in folder["item"]:
        url = it["request"]["url"]
        for seg in url["path"]:
            if seg.startswith("{{") and seg[2:-2] not in known:
                collection["variable"].append({"key": seg[2:-2], "value": ""})
                known.add(seg[2:-2])

json.dump(collection, sys.stdout, ensure_ascii=False, indent=2)
sys.stdout.write("\n")
