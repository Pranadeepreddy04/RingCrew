"""Minimal secret scanner for CI: fails if likely credentials are committed."""
import re
import subprocess
import sys

PATTERNS = {
    "AWS key": r"AKIA[0-9A-Z]{16}",
    "Stripe live key": r"sk_live_[0-9a-zA-Z]{16,}",
    "Stripe test key": r"sk_test_[0-9a-zA-Z]{16,}",
    "Anthropic key": r"sk-ant-[0-9A-Za-z_\-]{20,}",
    "Twilio auth token assignment": r"TWILIO_AUTH_TOKEN\s*=\s*[0-9a-f]{32}",
    "Private key": r"-----BEGIN (RSA |EC )?PRIVATE KEY-----",
    "Slack token": r"xox[baprs]-[0-9A-Za-z-]{10,}",
    "Google API key": r"AIza[0-9A-Za-z_\-]{35}",
}
files = subprocess.run(["git", "ls-files"], capture_output=True, text=True, check=True).stdout.split()
hits = []
for f in files:
    if f.endswith((".png", ".jpg", ".lock", "package-lock.json")) or f == "scripts/secret_scan.py":
        continue
    try:
        text = open(f, encoding="utf-8", errors="ignore").read()
    except (IsADirectoryError, FileNotFoundError):
        continue
    for name, pat in PATTERNS.items():
        for m in re.finditer(pat, text):
            hits.append(f"{f}: {name}: {m.group(0)[:12]}…")
if subprocess.run(["git", "ls-files", "--error-unmatch", ".env"], capture_output=True).returncode == 0:
    hits.append(".env is tracked by git")
print("\n".join(hits) or "secret scan: no findings")
sys.exit(1 if hits else 0)
